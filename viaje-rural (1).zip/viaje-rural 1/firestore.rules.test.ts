/**
 * Security Rule Verification Suite — Viaje Rural ("Dirty Dozen" Payloads)
 * Designed for @firebase/rules-unit-testing against firestore.rules.
 */

export interface DirtyPayloadCase {
  id: string;
  name: string;
  collectionPath: string;
  operation: 'create' | 'update' | 'get' | 'list';
  actorRole: 'passenger' | 'driver' | 'outsider' | 'unverifiedAdmin';
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
  mitigatingRule: string;
}

export const DIRTY_DOZEN_PAYLOADS: DirtyPayloadCase[] = [
  {
    id: 'DD-01',
    name: 'Shadow Update Ghost Field on Conductor',
    collectionPath: 'conductores/driver-carlos',
    operation: 'update',
    actorRole: 'driver',
    payload: { tarifaBase: 1800, isAdmin: true },
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'isValidConductor() keys().hasOnly() + affectedKeys().hasOnly()'
  },
  {
    id: 'DD-02',
    name: 'Self-Activation of Pending Conductor',
    collectionPath: 'conductores/driver-new',
    operation: 'create',
    actorRole: 'driver',
    payload: { uid: 'driver-new', estadoCuenta: 'activo', estadoOperativo: 'disponible' },
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'allow create requires estadoCuenta == "pendiente" unless isAdmin()'
  },
  {
    id: 'DD-03',
    name: 'Driver Reading Passenger Plaintext PIN',
    collectionPath: 'viajes/viaje-101/secreto/codigo',
    operation: 'get',
    actorRole: 'driver',
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'secreto allow get restricted to existing().pasajeroId == request.auth.uid || isAdmin()'
  },
  {
    id: 'DD-04',
    name: 'Passenger Reading Driver Private Phone PII',
    collectionPath: 'usuarios/driver-carlos/private/pii',
    operation: 'get',
    actorRole: 'passenger',
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'Split Collection /private/pii allow get restricted to isOwner(userId) || isAdmin()'
  },
  {
    id: 'DD-05',
    name: 'Terminal Trip State Reopening',
    collectionPath: 'viajes/viaje-finished',
    operation: 'update',
    actorRole: 'passenger',
    payload: { estado: 'buscando' },
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'Terminal State Locking !(existing().estado in ["finalizado", "cancelado"])'
  },
  {
    id: 'DD-06',
    name: 'Client-Forged Timestamp on Trip Create',
    collectionPath: 'viajes/viaje-102',
    operation: 'create',
    actorRole: 'passenger',
    payload: { createdAt: '2020-01-01T00:00:00Z' },
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'Temporal Integrity incoming().createdAt == request.time'
  },
  {
    id: 'DD-07',
    name: 'ID Poisoning (>128 chars or invalid chars)',
    collectionPath: 'viajes/' + 'a'.repeat(200),
    operation: 'create',
    actorRole: 'passenger',
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'isValidId(viajeId) size <= 128 && regex guard'
  },
  {
    id: 'DD-08',
    name: 'Denial of Wallet 5000-char Chat Message',
    collectionPath: 'chats/viaje-101/mensajes/msg-1',
    operation: 'create',
    actorRole: 'passenger',
    payload: { texto: 'x'.repeat(5000) },
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'isValidMensajeChat() texto.size() <= 400'
  },
  {
    id: 'DD-09',
    name: 'Chat Author Identity Spoofing',
    collectionPath: 'chats/viaje-101/mensajes/msg-2',
    operation: 'create',
    actorRole: 'outsider',
    payload: { autorUid: 'passenger-real-uid', texto: 'Hola' },
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'incoming().autorUid == request.auth.uid + parent viaje participant check'
  },
  {
    id: 'DD-10',
    name: 'Unverified Admin Email Spoofing',
    collectionPath: 'admins/spoof-uid',
    operation: 'create',
    actorRole: 'unverifiedAdmin',
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'isAdmin() mandates request.auth.token.email_verified == true'
  },
  {
    id: 'DD-11',
    name: 'Unqueued Driver Hijacking Trip Offer',
    collectionPath: 'viajes/viaje-101',
    operation: 'update',
    actorRole: 'outsider',
    payload: { estado: 'aceptado', conductorId: 'outsider-uid' },
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'request.auth.uid in existing().colaConductores'
  },
  {
    id: 'DD-12',
    name: 'Blanket Collection Scrape on Usuarios',
    collectionPath: 'usuarios',
    operation: 'list',
    actorRole: 'passenger',
    expectedResult: 'PERMISSION_DENIED',
    mitigatingRule: 'usuarios allow list restricted strictly to isAdmin()'
  }
];
