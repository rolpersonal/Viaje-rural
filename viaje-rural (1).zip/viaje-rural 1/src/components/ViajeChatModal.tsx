import React from 'react';
import { X } from 'lucide-react';
import { ViajeChatPanel } from './ViajeChatPanel';

interface ViajeChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  viajeId: string;
  autorUid: string;
  autorRol: 'pasajero' | 'conductor';
  autorNombre: string;
  onIncomingHeadsUp?: (autor: string, texto: string) => void;
}

/**
 * CHAT BAJO DEMANDA:
 * No permanece montado ni suscrito por defecto en las pantallas principales.
 * Solo se abre en ventana modal cuando el Pasajero o Conductor presiona "Abrir Chat".
 */
export const ViajeChatModal: React.FC<ViajeChatModalProps> = ({
  isOpen,
  onClose,
  viajeId,
  autorUid,
  autorRol,
  autorNombre,
  onIncomingHeadsUp,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Chat privado del viaje"
    >
      <div className="w-full max-w-lg space-y-2">
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-white px-3.5 text-xs font-semibold text-[#14231A] shadow-lg hover:bg-[#F7F8F6]"
          >
            <X className="h-4 w-4" />
            Cerrar Chat
          </button>
        </div>
        <ViajeChatPanel
          viajeId={viajeId}
          autorUid={autorUid}
          autorRol={autorRol}
          autorNombre={autorNombre}
          onIncomingHeadsUp={onIncomingHeadsUp}
        />
      </div>
    </div>
  );
};
