import React, { useEffect } from 'react';
import { MapPin, Navigation, ShieldCheck, X } from 'lucide-react';
import { Viaje } from '../types/viajeRural';

interface OnDemandMapModalProps {
  isOpen: boolean;
  onClose: () => void;
  viaje: Viaje;
}

/**
 * MAPAS BAJO DEMANDA:
 * Este componente retorna null si !isOpen para no consumir memoria, tiles ni ancho de banda
 * en las pantallas principales. Solo se monta al pulsar "Ver Mapa" y se destruye al cerrar
 * o cuando el conductor confirma el PIN de 3 dígitos.
 */
export const OnDemandMapModal: React.FC<OnDemandMapModalProps> = ({
  isOpen,
  onClose,
  viaje,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    // Al ingresar el PIN, esta vista se detiene y el mapa se cierra automáticamente
    if (viaje.estado !== 'aceptado' || viaje.pinVerificado) {
      onClose();
    }
  }, [isOpen, viaje.estado, viaje.pinVerificado, onClose]);

  if (!isOpen) {
    return null;
  }

  const cLat = viaje.conductorLat ?? viaje.origenLat + 0.012;
  const cLng = viaje.conductorLng ?? viaje.origenLng + 0.012;

  // Normalizar coordenadas al lienzo SVG topográfico rural (600 x 340)
  const minLat = Math.min(viaje.origenLat, viaje.destinoLat, cLat) - 0.01;
  const maxLat = Math.max(viaje.origenLat, viaje.destinoLat, cLat) + 0.01;
  const minLng = Math.min(viaje.origenLng, viaje.destinoLng, cLng) - 0.01;
  const maxLng = Math.max(viaje.origenLng, viaje.destinoLng, cLng) + 0.01;

  const toX = (lng: number) => {
    const ratio = (lng - minLng) / Math.max(0.0001, maxLng - minLng);
    return 60 + ratio * 480;
  };
  const toY = (lat: number) => {
    const ratio = (lat - minLat) / Math.max(0.0001, maxLat - minLat);
    return 290 - ratio * 230;
  };

  const pX = toX(viaje.origenLat ? viaje.origenLng : -83.68);
  const pY = toY(viaje.origenLat);
  const dX = toX(viaje.destinoLng);
  const dY = toY(viaje.destinoLat);
  const condX = toX(cLng);
  const condY = toY(cLat);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Mapa de acercamiento bajo demanda"
    >
      <div className="w-full max-w-2xl overflow-hidden rounded-2xl border border-[#E2E6DF] bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#E2E6DF] px-5 py-4">
          <div>
            <h3 className="text-lg font-semibold text-[#14231A]">
              Mapa de Acercamiento (Bajo Demanda)
            </h3>
            <p className="text-xs text-[#525B50]">
              Actualización GPS del conductor cada 90s · Se destruye al cerrar o ingresar PIN
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF] text-[#14231A] transition-colors hover:bg-[#F7F8F6]"
            aria-label="Cerrar mapa y liberar memoria"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5">
          <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 py-3">
              <div className="text-xs text-[#525B50]">ETA Estimado</div>
              <div className="font-mono text-xl font-bold text-[#15803D]">
                {viaje.etaMinutos ?? 5} min
              </div>
            </div>
            <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 py-3">
              <div className="text-xs text-[#525B50]">Vehículo asignado</div>
              <div className="truncate text-sm font-semibold text-[#14231A]">
                {viaje.conductorPlaca || 'En ruta'} · {viaje.vehiculoTipoSeleccionado || '4x4'}
              </div>
            </div>
            <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 py-3">
              <div className="text-xs text-[#525B50]">Cadencia GPS</div>
              <div className="font-mono text-sm font-semibold text-[#14231A]">
                Cada 90s (Modo Recogida)
              </div>
            </div>
          </div>

          {/* Lienzo SVG topográfico ligero (0 KB de tiles de mapas externos) */}
          <div className="relative overflow-hidden rounded-xl border border-[#E2E6DF] bg-[#EEF2EB]">
            <svg viewBox="0 0 600 340" className="h-72 w-full sm:h-80">
              {/* Curvas de nivel rural */}
              <path
                d="M-20,90 Q140,40 310,110 T620,80"
                fill="none"
                stroke="#D5DDD0"
                strokeWidth="1.5"
              />
              <path
                d="M-20,180 Q180,130 340,210 T620,175"
                fill="none"
                stroke="#D5DDD0"
                strokeWidth="1.5"
              />
              <path
                d="M-20,270 Q200,230 390,290 T620,250"
                fill="none"
                stroke="#D5DDD0"
                strokeWidth="1.5"
              />

              {/* Ruta conductor -> pasajero */}
              <line
                x1={condX}
                y1={condY}
                x2={pX}
                y2={pY}
                stroke="#15803D"
                strokeWidth="3"
                strokeDasharray="6 5"
              />

              {/* Ruta proyectada pasajero -> destino */}
              <line
                x1={pX}
                y1={pY}
                x2={dX}
                y2={dY}
                stroke="#64748B"
                strokeWidth="2"
                strokeDasharray="3 4"
              />

              {/* Destino */}
              <g transform={`translate(${dX}, ${dY})`}>
                <circle r="10" fill="#14231A" />
                <circle r="4" fill="#FFFFFF" />
                <text
                  y="-16"
                  textAnchor="middle"
                  className="fill-[#14231A] text-[11px] font-semibold"
                >
                  Destino
                </text>
              </g>

              {/* Pasajero (Origen) */}
              <g transform={`translate(${pX}, ${pY})`}>
                <circle r="16" fill="#D97706" fillOpacity="0.18" />
                <circle r="9" fill="#D97706" stroke="#FFFFFF" strokeWidth="2" />
                <text
                  y="24"
                  textAnchor="middle"
                  className="fill-[#14231A] text-[11px] font-semibold"
                >
                  Tú (Origen)
                </text>
              </g>

              {/* Conductor en acercamiento */}
              <g transform={`translate(${condX}, ${condY})`}>
                <circle r="18" fill="#15803D" fillOpacity="0.18" />
                <circle r="11" fill="#15803D" stroke="#FFFFFF" strokeWidth="2.5" />
                <text
                  y="-18"
                  textAnchor="middle"
                  className="fill-[#15803D] text-[11px] font-bold"
                >
                  {viaje.conductorNombre?.split(' ')[0] || 'Conductor'}
                </text>
              </g>
            </svg>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#E2E6DF] bg-white/95 px-4 py-2.5 text-xs text-[#525B50]">
              <span className="inline-flex items-center gap-1.5">
                <Navigation className="h-3.5 w-3.5 text-[#15803D]" />
                Conductor: <span className="font-mono">{cLat.toFixed(4)}, {cLng.toFixed(4)}</span>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-[#D97706]" />
                Recogida: <span className="font-mono">{viaje.origenLat.toFixed(4)}, {viaje.origenLng.toFixed(4)}</span>
              </span>
            </div>
          </div>

          <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2 text-xs text-[#525B50]">
              <ShieldCheck className="h-4 w-4 shrink-0 text-[#15803D]" />
              <span>
                El mapa se cerrará automáticamente cuando el conductor ingrese tu PIN de 3 dígitos.
              </span>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] whitespace-nowrap rounded-xl bg-[#14231A] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#1E3527]"
            >
              Cerrar Mapa y Liberar Memoria
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
