import React, { useEffect, useRef, useState } from 'react';
import { BellRing, Lock, Send, Volume2, VolumeX } from 'lucide-react';
import { playChatAlertSound } from '../lib/ruralUtils';
import { enviarMensajeChat, subscribeChatViaje } from '../services/viajeService';
import { MensajeChat } from '../types/viajeRural';

interface ViajeChatPanelProps {
  viajeId: string;
  autorUid: string;
  autorRol: 'pasajero' | 'conductor';
  autorNombre: string;
  onIncomingHeadsUp?: (remitente: string, texto: string) => void;
}

export const ViajeChatPanel: React.FC<ViajeChatPanelProps> = ({
  viajeId,
  autorUid,
  autorRol,
  autorNombre,
  onIncomingHeadsUp,
}) => {
  const [mensajes, setMensajes] = useState<MensajeChat[]>([]);
  const [texto, setTexto] = useState('');
  const [avisoTelefono, setAvisoTelefono] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [sonidoActivo, setSonidoActivo] = useState(true);
  const [headsUpLocal, setHeadsUpLocal] = useState<{ autor: string; texto: string } | null>(null);
  const initialLoadRef = useRef(true);
  const seenIdsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    initialLoadRef.current = true;
    seenIdsRef.current.clear();
    const unsub = subscribeChatViaje(viajeId, (lista) => {
      if (initialLoadRef.current) {
        lista.forEach((m) => seenIdsRef.current.add(m.id));
        initialLoadRef.current = false;
      } else {
        for (const m of lista) {
          if (!seenIdsRef.current.has(m.id)) {
            seenIdsRef.current.add(m.id);
            if (m.autorRol !== autorRol) {
              if (sonidoActivo) {
                playChatAlertSound();
              }
              setHeadsUpLocal({ autor: m.autorNombre, texto: m.texto });
              onIncomingHeadsUp?.(m.autorNombre, m.texto);
              setTimeout(() => setHeadsUpLocal(null), 5000);
            }
          }
        }
      }
      setMensajes(lista);
    });
    return () => unsub();
  }, [viajeId, autorRol, sonidoActivo, onIncomingHeadsUp]);

  const handleEnviar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!texto.trim() || enviando) return;
    setEnviando(true);
    try {
      const res = await enviarMensajeChat({
        viajeId,
        autorUid,
        autorRol,
        autorNombre,
        texto,
      });
      setAvisoTelefono(res.conteniaTelefono);
      setTexto('');
    } finally {
      setEnviando(false);
    }
  };

  return (
    <div className="relative rounded-2xl border border-[#E2E6DF] bg-white p-4">
      {/* Notificación flotante Heads-up local */}
      {headsUpLocal && (
        <div
          role="status"
          className="mb-3 flex items-start gap-2.5 rounded-xl border border-[#15803D]/35 bg-[#F0FDF4] p-3 shadow-sm"
        >
          <BellRing className="mt-0.5 h-4 w-4 shrink-0 text-[#15803D]" />
          <div className="min-w-0 flex-1 text-xs">
            <div className="font-bold text-[#14231A]">
              Nuevo mensaje de {headsUpLocal.autor}
            </div>
            <p className="truncate text-[#333D32]">{headsUpLocal.texto}</p>
          </div>
        </div>
      )}

      <div className="mb-3 flex items-center justify-between border-b border-[#E2E6DF] pb-3">
        <div>
          <h4 className="text-sm font-semibold text-[#14231A]">
            Chat Exclusivo del Viaje
          </h4>
          <p className="text-xs text-[#525B50]">
            Sin números telefónicos · Notificación flotante y sonido activo
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSonidoActivo((v) => !v)}
            className="flex min-h-[36px] min-w-[36px] items-center justify-center rounded-lg border border-[#E2E6DF] text-[#14231A] hover:bg-[#F7F8F6]"
            title={sonidoActivo ? 'Silenciar alertas de chat' : 'Activar sonido de chat'}
            aria-label="Alternar sonido de chat"
          >
            {sonidoActivo ? (
              <Volume2 className="h-4 w-4 text-[#15803D]" />
            ) : (
              <VolumeX className="h-4 w-4 text-[#525B50]" />
            )}
          </button>
          <Lock className="h-4 w-4 text-[#15803D]" />
        </div>
      </div>

      <div className="mb-3 max-h-52 space-y-2 overflow-y-auto pr-1">
        {mensajes.length === 0 ? (
          <p className="py-6 text-center text-xs text-[#525B50]">
            Coordina puntos de referencia rurales aquí. Los números de teléfono se ocultan automáticamente.
          </p>
        ) : (
          mensajes.map((m) => {
            const esMio = m.autorRol === autorRol;
            return (
              <div
                key={m.id}
                className={`flex flex-col ${esMio ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-xl px-3.5 py-2 text-sm ${
                    esMio
                      ? 'bg-[#15803D] text-white'
                      : 'border border-[#E2E6DF] bg-[#F7F8F6] text-[#14231A]'
                  }`}
                >
                  <div className="mb-0.5 text-[11px] opacity-75">
                    {m.autorNombre} · {m.autorRol === 'conductor' ? 'Conductor' : 'Pasajero'}
                  </div>
                  <p className="break-words">{m.texto}</p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {avisoTelefono && (
        <div className="mb-2 rounded-lg border border-[#D97706]/30 bg-[#D97706]/10 px-3 py-1.5 text-xs text-[#92400E]">
          Por privacidad de la plataforma, los números de teléfono se bloquean en el chat.
        </div>
      )}

      <form onSubmit={handleEnviar} className="flex gap-2">
        <input
          type="text"
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          maxLength={350}
          placeholder="Escribe una indicación rápida..."
          className="min-h-[44px] flex-1 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 text-sm text-[#14231A] outline-none focus:border-[#15803D] focus:bg-white"
        />
        <button
          type="submit"
          disabled={!texto.trim() || enviando}
          className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl bg-[#14231A] px-4 text-white transition-colors hover:bg-[#1E3527] disabled:opacity-40"
          aria-label="Enviar mensaje"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
};
