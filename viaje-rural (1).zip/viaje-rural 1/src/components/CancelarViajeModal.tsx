import React, { useEffect, useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface CancelarViajeModalProps {
  isOpen: boolean;
  rol: 'pasajero' | 'conductor';
  onClose: () => void;
  onConfirm: (motivo: string) => Promise<void>;
}

const MOTIVOS_CONDUCTOR = [
  'Camino bloqueado o derrumbe',
  'Falla mecánica del vehículo',
  'No logro ubicar el punto de recogida',
  'Emergencia personal',
];

const MOTIVOS_PASAJERO = [
  'El conductor tarda demasiado',
  'Ya no necesito el viaje',
  'Error en punto de recogida',
  'Emergencia personal',
];

export const CancelarViajeModal: React.FC<CancelarViajeModalProps> = ({
  isOpen,
  rol,
  onClose,
  onConfirm,
}) => {
  const [motivo, setMotivo] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setMotivo('');
      setError(null);
      setEnviando(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const sugerencias = rol === 'conductor' ? MOTIVOS_CONDUCTOR : MOTIVOS_PASAJERO;
  const limpio = motivo.trim();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (limpio.length < 3) {
      setError('Ingresa una nota indicando el motivo (mínimo 3 caracteres).');
      return;
    }
    setError(null);
    setEnviando(true);
    try {
      await onConfirm(limpio);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo cancelar el viaje.');
    } finally {
      setEnviando(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Cancelar viaje con nota"
    >
      <div className="w-full max-w-md rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl">
        <div className="flex items-start justify-between gap-3 border-b border-[#E2E6DF] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#FEF2F2] text-[#DC2626]">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#14231A]">Cancelar viaje</h3>
              <p className="text-xs text-[#525B50]">
                Indica por qué cancelas para notificar al{' '}
                {rol === 'conductor' ? 'pasajero' : 'conductor'}.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl text-[#525B50] hover:bg-[#F7F8F6]"
            aria-label="Cerrar ventana"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <div className="mb-1.5 text-xs font-semibold text-[#525B50]">
              Motivos frecuentes
            </div>
            <div className="flex flex-wrap gap-1.5">
              {sugerencias.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => {
                    setMotivo(item);
                    setError(null);
                  }}
                  className={`min-h-[36px] rounded-xl border px-3 py-1.5 text-left text-xs font-medium transition-colors ${
                    motivo === item
                      ? 'border-[#DC2626] bg-[#FEF2F2] text-[#991B1B]'
                      : 'border-[#E2E6DF] bg-[#F7F8F6] text-[#14231A] hover:bg-[#E2E6DF]/50'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label
              htmlFor="nota-cancelacion"
              className="mb-1.5 flex items-center justify-between text-xs font-semibold text-[#14231A]"
            >
              <span>Nota explicando el motivo (obligatoria)</span>
              <span className="font-mono text-[11px] font-normal text-[#525B50]">
                {limpio.length}/280
              </span>
            </label>
            <textarea
              id="nota-cancelacion"
              rows={3}
              maxLength={280}
              required
              value={motivo}
              onChange={(e) => {
                setMotivo(e.target.value);
                if (error) setError(null);
              }}
              placeholder={
                rol === 'conductor'
                  ? 'Ej: Derrumbe en el camino hacia Santa Elena, imposible pasar con el vehículo.'
                  : 'Ej: Surgió un imprevisto familiar y no podré realizar el viaje.'
              }
              className="w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3 text-sm text-[#14231A] outline-none focus:border-[#DC2626] focus:bg-white"
            />
          </div>

          {error && (
            <div className="rounded-xl border border-[#DC2626]/30 bg-[#FEF2F2] px-3 py-2 text-xs font-semibold text-[#991B1B]">
              {error}
            </div>
          )}

          <div className="flex gap-2.5 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={enviando}
              className="min-h-[44px] flex-1 rounded-xl border border-[#E2E6DF] bg-white px-4 text-sm font-semibold text-[#14231A] hover:bg-[#F7F8F6]"
            >
              Volver
            </button>
            <button
              type="submit"
              disabled={enviando || limpio.length < 3}
              className="min-h-[44px] flex-1 rounded-xl bg-[#DC2626] px-4 text-sm font-semibold text-white hover:bg-[#B91C1C] disabled:opacity-45"
            >
              {enviando ? 'Cancelando...' : 'Confirmar cancelación'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
