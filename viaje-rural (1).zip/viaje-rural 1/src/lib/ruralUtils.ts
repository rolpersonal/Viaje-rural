import { Conductor, RuralDestino, TipoVehiculo, VehiculoTipoConfig } from '../types/viajeRural';

export const ADMIN_EMAIL = 'sindicatosiserge@gmail.com';

export const RURAL_DESTINOS: RuralDestino[] = [
  { nombre: 'Centro de Pérez Zeledón (Mercado)', canton: 'San Isidro, Pérez Zeledón', lat: 9.3738, lng: -83.7042 },
  { nombre: 'Santa Elena Centro', canton: 'General Viejo, Pérez Zeledón', lat: 9.3895, lng: -83.6490 },
  { nombre: 'San Gerardo de Rivas', canton: 'Rivas, Pérez Zeledón', lat: 9.4545, lng: -83.5752 },
  { nombre: 'EBAIS de Santa Elena', canton: 'General Viejo, Pérez Zeledón', lat: 9.3912, lng: -83.6358 },
  { nombre: 'Cooperativa Cafetalera El Roble', canton: 'Pejibaye, Pérez Zeledón', lat: 9.1667, lng: -83.5501 },
  { nombre: 'Terminal de Buses Quebradas', canton: 'San Isidro, Pérez Zeledón', lat: 9.4234, lng: -83.6941 },
  { nombre: 'Plaza de Deportes La Palma', canton: 'Daniel Flores, Pérez Zeledón', lat: 9.3425, lng: -83.6712 },
  { nombre: 'Escuela Rural Monte Carlo', canton: 'Rivas, Pérez Zeledón', lat: 9.4198, lng: -83.6114 },
  { nombre: 'Feria del Agricultor San Marcos', canton: 'Tarrazú, San José', lat: 9.6594, lng: -84.0205 },
  { nombre: 'Compañía de Galletas Pozuelo (La Uruca)', canton: 'La Uruca, San José', lat: 9.9562, lng: -84.1157 },
  { nombre: 'Cruce de Pozuelo (Radial Uruca - Heredia)', canton: 'La Uruca, San José', lat: 9.9585, lng: -84.1142 },
  { nombre: 'Pozuelo — Jardines del Recuerdo', canton: 'Valencia / Uruca, Heredia', lat: 9.9614, lng: -84.1135 },
  { nombre: 'Hospital México (La Uruca)', canton: 'La Uruca, San José', lat: 9.9516, lng: -84.1139 },
  { nombre: 'San José Centro (Parque Central / Avenida Segunda)', canton: 'Carmen / Catedral, San José', lat: 9.9327, lng: -84.0796 },
  { nombre: 'Heredia Centro (Parque Nicolás Ulloa)', canton: 'Heredia', lat: 9.9986, lng: -84.1165 },
  { nombre: 'Alajuela Centro (Parque Juan Santamaría)', canton: 'Alajuela', lat: 10.0162, lng: -84.2116 },
  { nombre: 'Cartago Centro (Basílica de los Ángeles)', canton: 'Cartago', lat: 9.8644, lng: -83.9135 },
  { nombre: 'Desamparados Centro', canton: 'Desamparados, San José', lat: 9.8981, lng: -84.0658 },
  { nombre: 'San Pedro de Montes de Oca (UCR)', canton: 'Montes de Oca, San José', lat: 9.9366, lng: -84.0510 },
  { nombre: 'Buenos Aires Centro (Zona Sur)', canton: 'Buenos Aires, Puntarenas', lat: 9.1725, lng: -83.3342 },
  { nombre: 'Dominical Centro (Playa / Costanera)', canton: 'Osa, Puntarenas', lat: 9.2535, lng: -83.8615 },
  { nombre: 'Uvita Centro (Bahía Ballena)', canton: 'Osa, Puntarenas', lat: 9.1628, lng: -83.7365 },
  { nombre: 'San Vito de Coto Brus', canton: 'Coto Brus, Puntarenas', lat: 8.8213, lng: -82.9711 },
  { nombre: 'Ciudad Neily Centro', canton: 'Corredores, Puntarenas', lat: 8.6489, lng: -82.9422 },
  { nombre: 'Turrialba Centro (Mercado)', canton: 'Turrialba, Cartago', lat: 9.9056, lng: -83.6833 },
  { nombre: 'San Ramón Centro', canton: 'San Ramón, Alajuela', lat: 10.0884, lng: -84.4698 },
  { nombre: 'Ciudad Quesada (Parque Central)', canton: 'San Carlos, Alajuela', lat: 10.3238, lng: -84.4271 },
  { nombre: 'Liberia Centro (Parque Mario Cañas)', canton: 'Liberia, Guanacaste', lat: 10.6346, lng: -85.4407 },
];

export function filtrarUbicacionesLocales(texto: string): RuralDestino[] {
  const q = texto.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (!q) return RURAL_DESTINOS.slice(0, 8);
  return RURAL_DESTINOS.filter((d) => {
    const nombreNorm = d.nombre.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const cantonNorm = d.canton.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return nombreNorm.includes(q) || cantonNorm.includes(q);
  }).slice(0, 8);
}

export async function buscarUbicacionesAutocomplete(
  texto: string,
  signal?: AbortSignal
): Promise<RuralDestino[]> {
  const locales = filtrarUbicacionesLocales(texto);
  const q = texto.trim();
  if (q.length < 3) return locales;

  try {
    const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=cr&addressdetails=1&limit=5&q=${encodeURIComponent(q)}`;
    const res = await fetch(url, {
      signal,
      headers: { 'Accept-Language': 'es' },
    });
    if (!res.ok) return locales;
    const data = (await res.json()) as Array<{
      display_name?: string;
      name?: string;
      lat?: string;
      lon?: string;
      address?: {
        road?: string;
        suburb?: string;
        neighbourhood?: string;
        town?: string;
        city?: string;
        county?: string;
        state?: string;
      };
    }>;

    const remotos: RuralDestino[] = data
      .filter((item) => item.lat && item.lon)
      .map((item) => {
        const parts = (item.display_name || '').split(',').map((s) => s.trim());
        const nombreCorto = item.name?.trim() || parts.slice(0, 2).join(', ') || q;
        const canton =
          item.address?.county ||
          item.address?.city ||
          item.address?.town ||
          item.address?.state ||
          parts.slice(2, 4).join(', ') ||
          'Costa Rica';
        return {
          nombre: nombreCorto.slice(0, 110),
          canton: canton.slice(0, 70),
          lat: Number(Number(item.lat).toFixed(6)),
          lng: Number(Number(item.lon).toFixed(6)),
        };
      });

    const vistos = new Set(locales.map((l) => l.nombre.toLowerCase()));
    const combinados = [...locales];
    for (const r of remotos) {
      if (!vistos.has(r.nombre.toLowerCase())) {
        vistos.add(r.nombre.toLowerCase());
        combinados.push(r);
      }
    }
    return combinados.slice(0, 8);
  } catch {
    return locales;
  }
}

export interface UbicacionPrecisaResult {
  lat: number;
  lng: number;
  precisionMetros: number | null;
  nombreDireccion: string;
  canton: string;
}

export async function reverseGeocodeUbicacion(
  lat: number,
  lng: number
): Promise<{ nombre: string; canton: string }> {
  const nearest = [...RURAL_DESTINOS]
    .map((d) => ({ d, km: calcularDistanciaKm(lat, lng, d.lat, d.lng) }))
    .sort((a, b) => a.km - b.km)[0];

  const fallbackNombre = nearest
    ? `Cerca de ${nearest.d.nombre} (~${nearest.km} km)`
    : `Ubicación GPS (${lat.toFixed(5)}, ${lng.toFixed(5)})`;
  const fallbackCanton = nearest?.d.canton || 'Costa Rica';

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3500);
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'Accept-Language': 'es' },
    });
    clearTimeout(timer);
    if (!res.ok) return { nombre: fallbackNombre, canton: fallbackCanton };

    const data = (await res.json()) as {
      name?: string;
      display_name?: string;
      address?: {
        road?: string;
        house_number?: string;
        neighbourhood?: string;
        suburb?: string;
        village?: string;
        hamlet?: string;
        town?: string;
        city_district?: string;
        city?: string;
        county?: string;
        state?: string;
      };
    };

    const addr = data.address;
    const calle = addr?.road
      ? addr.house_number
        ? `${addr.road} #${addr.house_number}`
        : addr.road
      : '';
    const sector =
      addr?.neighbourhood ||
      addr?.suburb ||
      addr?.hamlet ||
      addr?.village ||
      addr?.city_district ||
      '';
    const canton = addr?.county || addr?.town || addr?.city || addr?.state || fallbackCanton;

    const partes = [data.name, calle, sector].filter(
      (v, idx, arr) => Boolean(v) && arr.indexOf(v) === idx
    );
    const nombre =
      partes.length > 0
        ? partes.slice(0, 2).join(', ').slice(0, 120)
        : (data.display_name || fallbackNombre).split(',').slice(0, 2).join(', ').slice(0, 120);

    return { nombre: nombre || fallbackNombre, canton: canton.slice(0, 70) };
  } catch {
    return { nombre: fallbackNombre, canton: fallbackCanton };
  }
}

export function capturarUbicacionGpsPrecisa(
  maxWaitMs = 4500,
  targetAccuracyM = 20
): Promise<UbicacionPrecisaResult> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      reject(new Error('Geolocalización no disponible en este navegador.'));
      return;
    }

    let bestPos: GeolocationPosition | null = null;
    let settled = false;
    let watchId: number | null = null;
    let timerId: ReturnType<typeof setTimeout> | null = null;

    const finish = async (pos: GeolocationPosition | null, err?: GeolocationPositionError) => {
      if (settled) return;
      settled = true;
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
      if (timerId !== null) clearTimeout(timerId);

      const finalPos = pos || bestPos;
      if (!finalPos) {
        reject(
          new Error(
            err?.code === 1
              ? 'Permiso de ubicación denegado. Activa el GPS en tu navegador para obtener tu posición exacta.'
              : 'No se pudo obtener la señal GPS. Intenta en un espacio abierto o escribe tu sector.'
          )
        );
        return;
      }

      const lat = Number(finalPos.coords.latitude.toFixed(6));
      const lng = Number(finalPos.coords.longitude.toFixed(6));
      const precisionMetros =
        typeof finalPos.coords.accuracy === 'number' && Number.isFinite(finalPos.coords.accuracy)
          ? Math.max(1, Math.round(finalPos.coords.accuracy))
          : null;

      const geo = await reverseGeocodeUbicacion(lat, lng);
      resolve({
        lat,
        lng,
        precisionMetros,
        nombreDireccion: geo.nombre,
        canton: geo.canton,
      });
    };

    watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (!bestPos || pos.coords.accuracy < bestPos.coords.accuracy) {
          bestPos = pos;
        }
        if (pos.coords.accuracy <= targetAccuracyM) {
          void finish(pos);
        }
      },
      (err) => {
        if (bestPos) {
          void finish(bestPos);
        } else if (err.code === 1) {
          void finish(null, err);
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: maxWaitMs + 3000,
      }
    );

    timerId = setTimeout(() => {
      void finish(bestPos);
    }, maxWaitMs);
  });
}


export const DEFAULT_TIPOS_VEHICULO: VehiculoTipoConfig[] = [
  { nombre: 'Pickup 4x4', maxPasajeros: 5, descripcion: 'Cuesta empinada, barro y carga · Hasta 5 pax' },
  { nombre: 'SUV Rural', maxPasajeros: 5, descripcion: 'Doble tracción cómoda · Hasta 5 pax' },
  { nombre: 'Sedan', maxPasajeros: 4, descripcion: 'Camino pavimentado o lastre liviano · Hasta 4 pax' },
  { nombre: 'Microbus', maxPasajeros: 12, descripcion: 'Grupos, familias o cuadrillas · Hasta 12 pax' },
  { nombre: 'Moto', maxPasajeros: 1, descripcion: 'Moto rural ágil para 1 pasajero y caminos estrechos' },
];

export const VEHICLE_CAPACITY_MAP: Record<TipoVehiculo, { maxPasajeros: number; descripcion: string }> = {
  'Sedan': { maxPasajeros: 4, descripcion: 'Camino pavimentado o lastre liviano · Hasta 4 pax' },
  'SUV Rural': { maxPasajeros: 5, descripcion: 'Doble tracción cómoda · Hasta 5 pax' },
  'Pickup 4x4': { maxPasajeros: 5, descripcion: 'Cuesta empinada, barro y carga · Hasta 5 pax' },
  'Microbus': { maxPasajeros: 12, descripcion: 'Grupos, familias o cuadrillas · Hasta 12 pax' },
  'Moto': { maxPasajeros: 1, descripcion: 'Moto rural ágil para 1 pasajero y caminos estrechos' },
};

export const DRIVER_AVATARS: Record<string, string> = {
  'driver-carlos': '/src/assets/images/driver_avatar_carlos_1794748978515.jpg',
  'driver-maria': '/src/assets/images/driver_avatar_maria_1794748978503.jpg',
  'driver-jose': '/src/assets/images/driver_avatar_jose_1794748978779.jpg',
};

export const PASSENGER_AVATAR = '/src/assets/images/passenger_avatar_elena_1794748979532.jpg';
export const HERO_ROAD_IMAGE = '/src/assets/images/rural_hero_road_1794748979890.jpg';

export function calcularDistanciaKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanciaRecta = R * c;
  // Factor de sinuosidad rural (1.28x por curvas y pendientes de montaña)
  return Math.max(0.8, Number((distanciaRecta * 1.28).toFixed(1)));
}

export function calcularMontoAproximado(tarifaBase: number, tarifaPorKm: number, distanciaKm: number): number {
  const raw = tarifaBase + tarifaPorKm * distanciaKm;
  return Math.round(raw / 50) * 50;
}

export function formatearColones(monto: number): string {
  return `₡${Math.round(monto).toLocaleString('es-CR')}`;
}

export function generarPin3Digitos(): string {
  return String(Math.floor(100 + Math.random() * 900));
}

export async function sha256Hex(texto: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(texto);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function sanitizeChatSinTelefonos(texto: string): { limpio: string; conteniaTelefono: boolean } {
  const phoneRegex = /(\+?\d[\d\s\-()]{6,}\d)/g;
  const conteniaTelefono = phoneRegex.test(texto);
  const limpio = texto.replace(phoneRegex, '[teléfono bloqueado por seguridad]');
  return { limpio, conteniaTelefono };
}

export function calcularPromediosTarifas(conductores: Conductor[]): {
  promedioBase: number;
  promedioKm: number;
} {
  if (conductores.length === 0) {
    return { promedioBase: 1500, promedioKm: 650 };
  }
  const sumBase = conductores.reduce((acc, c) => acc + c.tarifaBase, 0);
  const sumKm = conductores.reduce((acc, c) => acc + c.tarifaPorKm, 0);
  return {
    promedioBase: Math.round(sumBase / conductores.length),
    promedioKm: Math.round(sumKm / conductores.length),
  };
}

export function esTarifaAbusiva(
  tarifaBase: number,
  tarifaPorKm: number,
  promedioBase: number,
  promedioKm: number
): { abusiva: boolean; motivo: string } {
  const umbralBase = promedioBase * 1.3;
  const umbralKm = promedioKm * 1.3;
  if (tarifaBase > umbralBase && tarifaPorKm > umbralKm) {
    return {
      abusiva: true,
      motivo: `Base (+${Math.round(((tarifaBase - promedioBase) / promedioBase) * 100)}%) y km (+${Math.round(((tarifaPorKm - promedioKm) / promedioKm) * 100)}%) superan el +30% del promedio`,
    };
  }
  if (tarifaBase > umbralBase) {
    return {
      abusiva: true,
      motivo: `Tarifa base supera en +${Math.round(((tarifaBase - promedioBase) / promedioBase) * 100)}% el promedio (${formatearColones(promedioBase)})`,
    };
  }
  if (tarifaPorKm > umbralKm) {
    return {
      abusiva: true,
      motivo: `Tarifa por km supera en +${Math.round(((tarifaPorKm - promedioKm) / promedioKm) * 100)}% el promedio (${formatearColones(promedioKm)}/km)`,
    };
  }
  return { abusiva: false, motivo: '' };
}

export function calcularMensualidadActualConAjusteAnual(fecha: Date = new Date()): {
  montoActual: number;
  montoProximoEnero: number;
  anioActual: number;
} {
  // Tarifa base 2026: 7,000 colones, aumento del 10% anual cada 1 de enero
  const anioBase = 2026;
  const anioActual = fecha.getFullYear();
  const aniosTranscurridos = Math.max(0, anioActual - anioBase);
  const montoActual = Math.round(7000 * Math.pow(1.1, aniosTranscurridos));
  const montoProximoEnero = Math.round(montoActual * 1.1);
  return { montoActual, montoProximoEnero, anioActual };
}

export function calcularDiasLicenciaRestantes(
  licenciaExp?: { toDate?: () => Date } | Date | null
): {
  dias: number;
  fechaTexto: string;
  estado: 'vencida' | 'por_vencer' | 'vigente';
  etiqueta: string;
} {
  const fecha =
    licenciaExp instanceof Date
      ? licenciaExp
      : licenciaExp && typeof licenciaExp.toDate === 'function'
      ? licenciaExp.toDate()
      : new Date();
  const diffMs = fecha.getTime() - Date.now();
  const dias = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  const fechaTexto = fecha.toLocaleDateString('es-CR');
  const estado = dias <= 0 ? 'vencida' : dias <= 7 ? 'por_vencer' : 'vigente';
  const etiqueta =
    dias <= 0
      ? `Vencida (${Math.abs(dias)} d)`
      : dias === 1
      ? 'Queda 1 día'
      : `Quedan ${dias} días`;
  return { dias, fechaTexto, estado, etiqueta };
}

export function buildWazeUrl(lat: number, lng: number): string {
  return `https://waze.com/ul?ll=${lat.toFixed(6)},${lng.toFixed(6)}&navigate=yes`;
}

export function sanitizeFirestoreId(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
}

export function playChatAlertSound(): void {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now);
    osc1.frequency.setValueAtTime(1174.66, now + 0.11);
    gain1.gain.setValueAtTime(0.08, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.33);
  } catch {
    // Ignorar si el navegador bloquea AudioContext antes de interacción
  }
}

export const DEFAULT_TERMINOS_CONDICIONES = `1. Naturaleza de la Plataforma (Solo Conexión)
Viaje Rural actúa exclusivamente como una herramienta tecnológica de conexión entre pasajeros y conductores locales independientes en zonas rurales. La plataforma no es intermediaria de cobros, no procesa pagos electrónicos ni retiene porcentajes por viaje. Todo acuerdo de transporte se liquida directamente en efectivo entre el pasajero y el conductor.

2. Licencia Mensual de Conductores y Pago SINPE Móvil
Los conductores verificados abonan una cuota fija mensual de conexión de ₡7,000 colones mediante SINPE Móvil al número autorizado por la administración. Esta tarifa tendrá un aumento automático del 10% anual cada 1 de enero. El sistema enviará una notificación mensual de recordatorio antes del vencimiento de la licencia.

3. Transparencia Tarifaria y Uso Responsable
Cada conductor define libremente su tarifa base y tarifa por kilómetro, las cuales se muestran al pasajero antes de confirmar. El Administrador podrá emitir alertas por tarifas abusivas fuera del promedio local (+30%) y suspender cuentas con registros duplicados o incumplimiento de seguridad.

4. Privacidad de Teléfonos y Aceptación Obligatoria
Los números telefónicos permanecen ocultos en el chat y vistas operativas; únicamente el Administrador autorizado puede consultarlos para soporte o verificación. La aceptación expresa de estos términos es requisito obligatorio al registrarse en Viaje Rural.`;

export const DEFAULT_CONFIGURACION_GENERAL = {
  whatsappSoporte: '62546546',
  sinpeNumero: '62546546',
  adminNombre: 'Administrador Viaje Rural',
  adminTelefono: '62546546',
  adminEmail: ADMIN_EMAIL,
  adminSinpeTitular: 'Viaje Rural CR',
  terminosCondiciones: DEFAULT_TERMINOS_CONDICIONES,
  tiposVehiculo: DEFAULT_TIPOS_VEHICULO,
};

export function buildWhatsAppSupportUrl(numeroRaw: string, mensaje?: string): string {
  const digits = (numeroRaw || '62546546').replace(/\D/g, '');
  const fullNumber = digits.startsWith('506') ? digits : `506${digits}`;
  const text = encodeURIComponent(
    mensaje || 'Hola Soporte Viaje Rural, necesito ayuda con la plataforma / pago SINPE.'
  );
  return `https://wa.me/${fullNumber}?text=${text}`;
}

export function compressImageToDataUrl(
  file: File,
  maxWidth = 640,
  quality = 0.6
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('No se pudo leer la imagen seleccionada.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Formato de imagen inválido.'));
      img.onload = () => {
        const scale = Math.min(1, maxWidth / Math.max(1, img.width));
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result || '').slice(0, 150000));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
  });
}


