# Security Specification — Viaje Rural

## 1. Data Invariants
1. **Aislamiento de PII (Teléfonos y Cédulas)**: Ningún número de teléfono ni correo aparece en `/conductores`, `/pasajeros`, `/viajes` ni `/chats`. Toda PII reside en `/usuarios/{userId}/private/pii` y solo puede ser leída por el propio usuario o por `isAdmin()`.
2. **Privacidad del PIN de 3 dígitos**: El PIN en texto plano reside únicamente en `/viajes/{viajeId}/secreto/codigo`, accesible exclusivamente para el pasajero creador (`pasajeroId == request.auth.uid`) y el Administrador. El conductor solo valida contra `viaje.pinHash`.
3. **Bloqueo de Estado Terminal**: Un viaje en estado `finalizado` o `cancelado` no puede ser modificado por pasajero ni conductor (solo `isAdmin()`).
4. **Anti-Autoasignación de Roles**: Un usuario no puede crearse como `admin` ni activar su propia cuenta de conductor (`estadoCuenta: 'activo'`); el administrador verifica y activa conductores pendientes.
5. **Integridad Temporal**: Todos los `createdAt` y `updatedAt` deben coincidir estrictamente con `request.time`.
6. **Prevención de Denegación de Billetera**: Todos los IDs cumplen `^[a-zA-Z0-9_\-]+$` ($\le 128$ chars), todas las cadenas tienen límites de `.size()`, y las listas (`colaConductores`, `tiposVehiculoPermitidos`, `favoritos`) están acotadas ($\le 20$ elementos).
7. **Consultas de Lista Seguras**: Ningún `allow list` utiliza `get()` ni `exists()`; evalúan exclusivamente `resource.data` o `isAdmin()`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Ghost Field Shadow Update**: `PATCH /conductores/{uid}` con `{ tarifaBase: 1500, isAdmin: true }`. -> `PERMISSION_DENIED`.
2. **Self-Activation Bypass**: `POST /conductores/{uid}` con `{ estadoCuenta: 'activo' }` por usuario no admin. -> `PERMISSION_DENIED`.
3. **Driver Reading Plaintext PIN**: `GET /viajes/{viajeId}/secreto/codigo` autenticado como `conductorId`. -> `PERMISSION_DENIED`.
4. **Passenger Reading Driver PII**: `GET /usuarios/{driverUid}/private/pii` autenticado como pasajero. -> `PERMISSION_DENIED`.
5. **Terminal Trip Tampering**: `PATCH /viajes/{viajeId}` intentando cambiar `estado` de `'finalizado'` a `'buscando'`. -> `PERMISSION_DENIED`.
6. **Timestamp Forgery**: `POST /viajes/{viajeId}` enviando `createdAt: "2020-01-01T00:00:00Z"` en lugar de `request.time`. -> `PERMISSION_DENIED`.
7. **ID Poisoning**: `POST /viajes/<1500-char-string>` con ID inválido. -> `PERMISSION_DENIED`.
8. **1MB String Exhaustion**: `POST /chats/{viajeId}/mensajes/{id}` con `texto` de 5,000 caracteres. -> `PERMISSION_DENIED`.
9. **Spoofed Authorship in Chat**: `POST /chats/{viajeId}/mensajes/{id}` con `autorUid` distinto de `request.auth.uid`. -> `PERMISSION_DENIED`.
10. **Unverified Admin Email Spoofing**: Token con `email: "sindicatosiserge@gmail.com"` pero `email_verified: false`. -> `PERMISSION_DENIED`.
11. **Double Assignment / Hijack**: Conductor no incluido en `colaConductores` intentando aceptar un viaje. -> `PERMISSION_DENIED`.
12. **Blanket List Scrape**: `LIST /usuarios` o `LIST /viajes` por usuario sin relación al viaje. -> `PERMISSION_DENIED`.
