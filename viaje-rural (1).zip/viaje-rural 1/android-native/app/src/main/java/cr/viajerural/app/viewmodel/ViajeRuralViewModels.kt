package cr.viajerural.app.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Timestamp
import cr.viajerural.app.data.AdminResumenLigero
import cr.viajerural.app.data.LicenciaRestanteInfo
import cr.viajerural.app.data.RutaFavoritaData
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.UbicacionSugerida
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularDiasLicenciaRestantes
import cr.viajerural.app.worker.MonthlyPaymentReminderWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// =============================================================================
// 1. AUTH VIEWMODEL (Login y Registro separados para Pasajero y Conductor)
// =============================================================================
data class AuthUiState(
    val cargando: Boolean = false,
    val error: String? = null,
    val uidAutenticado: String? = null
)

class AuthViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun login(email: String, password: String, esConductor: Boolean, context: Context) {
        viewModelScope.launch {
            _uiState.value = AuthUiState(cargando = true)
            val result = repository.iniciarSesion(email, password)
            result.fold(
                onSuccess = { uid ->
                    if (esConductor) {
                        MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    }
                    _uiState.value = AuthUiState(uidAutenticado = uid)
                },
                onFailure = { err ->
                    _uiState.value = AuthUiState(error = err.message ?: "Error al iniciar sesión")
                }
            )
        }
    }

    fun registrarPasajero(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String
    ) {
        viewModelScope.launch {
            _uiState.value = AuthUiState(cargando = true)
            val result = repository.registrarPasajero(nombre, email, telefono, cedula, password)
            result.fold(
                onSuccess = { uid -> _uiState.value = AuthUiState(uidAutenticado = uid) },
                onFailure = { err -> _uiState.value = AuthUiState(error = err.message) }
            )
        }
    }

    fun registrarConductor(
        context: Context,
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        vehiculoTipo: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        fotoVehiculoDataUrl: String = "",
        fotoCedulaDataUrl: String = "",
        fotoLicenciaDataUrl: String = "",
        fotoCirculacionDataUrl: String = ""
    ) {
        viewModelScope.launch {
            _uiState.value = AuthUiState(cargando = true)
            val result = repository.registrarConductor(
                nombre, email, telefono, cedula, password,
                vehiculoTipo, vehiculoModelo, vehiculoColor, vehiculoAnio,
                placa, capacidad, tarifaBase, tarifaPorKm,
                fotoVehiculoDataUrl, fotoCedulaDataUrl, fotoLicenciaDataUrl, fotoCirculacionDataUrl
            )
            result.fold(
                onSuccess = { uid ->
                    MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    _uiState.value = AuthUiState(uidAutenticado = uid)
                },
                onFailure = { err -> _uiState.value = AuthUiState(error = err.message) }
            )
        }
    }
}

// =============================================================================
// 2. CONDUCTOR VIEWMODEL (4 pestañas BottomNavigation, Finanzas 2-datos, Historial lazy)
// =============================================================================
enum class ConductorTab { INICIO, FINANZAS, HISTORIAL, PERFIL }

data class ConductorFinanzasSimple(
    val gananciasHoy: Double = 0.0,
    val gananciasMes: Double = 0.0
)

data class ConductorUiState(
    val tabActual: ConductorTab = ConductorTab.INICIO,
    val viajeActivo: Map<String, Any>? = null,
    val finanzas: ConductorFinanzasSimple = ConductorFinanzasSimple(),
    val nombreConductor: String = "",
    val placa: String = "",
    val vehiculoTipo: String = "",
    val vehiculoModelo: String = "",
    val vehiculoColor: String = "",
    val vehiculoAnio: String = "",
    val capacidad: Int = 4,
    val tarifaBase: Double = 1500.0,
    val tarifaPorKm: Double = 650.0,
    val licenciaRestante: LicenciaRestanteInfo? = null,
    val misSolicitudes: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val historial: List<Map<String, Any>> = emptyList(),
    val historialCargado: Boolean = false,
    val cargandoHistorial: Boolean = false,
    val mostrarModalCobro: Boolean = false,
    val montoACobrar: Double = 0.0,
    val ultimoViajeId: String? = null,
    val ultimoPasajeroId: String? = null,
    val mensajeEstado: String? = null,
    val avisoCancelacionFlotante: String? = null
)

class ConductorViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConductorUiState())
    val uiState: StateFlow<ConductorUiState> = _uiState.asStateFlow()

    fun seleccionarTab(tab: ConductorTab, conductorId: String) {
        _uiState.value = _uiState.value.copy(tabActual = tab)
        if (tab == ConductorTab.HISTORIAL && !_uiState.value.historialCargado) {
            cargarHistorial(conductorId)
        }
        if (tab == ConductorTab.FINANZAS) {
            restaurarEstadoYFinanzas(conductorId)
        }
        if (tab == ConductorTab.PERFIL && !_uiState.value.solicitudesCargadas) {
            cargarMisSolicitudes(conductorId)
        }
    }

    fun restaurarEstadoYFinanzas(conductorId: String) {
        viewModelScope.launch {
            val viaje = repository.recuperarViajeActivoConductor(conductorId)
            val perfil = repository.obtenerPerfilYLicenciaConductor(conductorId)
            val hoy = (perfil?.get("gananciasHoy") as? Number)?.toDouble() ?: 0.0
            val mes = (perfil?.get("gananciasMes") as? Number)?.toDouble() ?: 0.0
            val licInfo = calcularDiasLicenciaRestantes(perfil?.get("licenciaExp") as? Timestamp)
            _uiState.value = _uiState.value.copy(
                viajeActivo = viaje,
                finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
                nombreConductor = perfil?.get("nombre") as? String ?: "",
                placa = perfil?.get("placa") as? String ?: "",
                vehiculoTipo = perfil?.get("vehiculoTipo") as? String ?: "",
                vehiculoModelo = perfil?.get("vehiculoModelo") as? String ?: "",
                vehiculoColor = perfil?.get("vehiculoColor") as? String ?: "",
                vehiculoAnio = perfil?.get("vehiculoAnio") as? String ?: "",
                capacidad = (perfil?.get("capacidad") as? Number)?.toInt() ?: 4,
                tarifaBase = (perfil?.get("tarifaBase") as? Number)?.toDouble() ?: 1500.0,
                tarifaPorKm = (perfil?.get("tarifaPorKm") as? Number)?.toDouble() ?: 650.0,
                licenciaRestante = licInfo
            )
        }
    }

    fun cargarMisSolicitudes(conductorId: String) {
        viewModelScope.launch {
            val lista = repository.obtenerMisSolicitudesCambio(conductorId)
            _uiState.value = _uiState.value.copy(
                misSolicitudes = lista,
                solicitudesCargadas = true
            )
        }
    }

    fun enviarSolicitudCambioConductor(
        conductorId: String,
        cambios: Map<String, Any>,
        motivo: String
    ) {
        if (cambios.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            val creada = repository.crearSolicitudCambioDatos(
                solicitanteUid = conductorId,
                rol = "conductor",
                nombreActual = _uiState.value.nombreConductor.ifBlank { "Conductor Rural" },
                resumenActual = "${_uiState.value.vehiculoTipo} · Placa ${_uiState.value.placa}",
                cambios = cambios,
                motivo = motivo
            )
            _uiState.value = _uiState.value.copy(
                misSolicitudes = listOf(creada) + _uiState.value.misSolicitudes,
                mensajeEstado = "Petición enviada al Administrador para su aprobación."
            )
        }
    }

    fun cargarHistorial(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargandoHistorial = true)
            val lista = repository.obtenerHistorialConductor(conductorId, 20L)
            _uiState.value = _uiState.value.copy(
                historial = lista,
                historialCargado = true,
                cargandoHistorial = false
            )
        }
    }

    fun finalizarViaje(viajeId: String, conductorId: String, pasajeroId: String, montoCobrado: Double) {
        viewModelScope.launch {
            repository.finalizarViajeConFinanzas(viajeId, conductorId, montoCobrado)
            val (hoy, mes) = repository.obtenerFinanzasConductor(conductorId)
            _uiState.value = _uiState.value.copy(
                viajeActivo = null,
                finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
                mostrarModalCobro = true,
                montoACobrar = montoCobrado,
                ultimoViajeId = viajeId,
                ultimoPasajeroId = pasajeroId
            )
        }
    }

    fun calificarPasajero(conductorId: String, estrellas: Int, comentario: String) {
        val viajeId = _uiState.value.ultimoViajeId ?: return
        val pasajeroId = _uiState.value.ultimoPasajeroId ?: return
        viewModelScope.launch {
            repository.enviarCalificacionYActualizarPromedio(
                viajeId = viajeId,
                autorUid = conductorId,
                destinatarioUid = pasajeroId,
                destinatarioRol = "pasajero",
                estrellas = estrellas,
                comentario = comentario
            )
            _uiState.value = _uiState.value.copy(mostrarModalCobro = false)
        }
    }

    fun cancelarViajeActivo(viajeId: String, conductorId: String, motivo: String) {
        if (motivo.trim().length < 3) return
        viewModelScope.launch {
            repository.cancelarViajeConMotivo(
                viajeId = viajeId,
                canceladoPor = "conductor",
                motivo = motivo,
                conductorId = conductorId
            )
            _uiState.value = _uiState.value.copy(
                viajeActivo = null,
                mensajeEstado = "Viaje cancelado. Motivo registrado: ${motivo.trim()}"
            )
        }
    }

    fun onViajeCanceladoPorPasajero(pasajeroNombre: String, motivo: String) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            avisoCancelacionFlotante = "$pasajeroNombre canceló el viaje: \"$motivo\""
        )
    }

    fun limpiarAvisoCancelacionFlotante() {
        _uiState.value = _uiState.value.copy(avisoCancelacionFlotante = null)
    }

    fun cerrarModalCobro() {
        _uiState.value = _uiState.value.copy(mostrarModalCobro = false)
    }
}

// =============================================================================
// 3. PASAJERO VIEWMODEL (3 pestañas BottomNavigation, Rutas Favoritas, Autocompletado)
// =============================================================================
enum class PasajeroTab { VIAJE, HISTORIAL, PERFIL }

data class PasajeroUiState(
    val tabActual: PasajeroTab = PasajeroTab.VIAJE,
    val viajeActivo: Map<String, Any>? = null,
    val pinPersistente: String? = null,
    val nombrePasajero: String = "",
    val misSolicitudes: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val historial: List<Map<String, Any>> = emptyList(),
    val historialCargado: Boolean = false,
    val cargandoHistorial: Boolean = false,
    val rutasFavoritas: List<RutaFavoritaData> = emptyList(),
    val sugerenciasOrigen: List<UbicacionSugerida> = emptyList(),
    val sugerenciasDestino: List<UbicacionSugerida> = emptyList(),
    val mostrarModalPago: Boolean = false,
    val montoAPagar: Double = 0.0,
    val ultimoViajeId: String? = null,
    val ultimoConductorId: String? = null,
    val avisoCancelacion: String? = null,
    val precisionUbicacionMetros: Int? = null
)

class PasajeroViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(PasajeroUiState())
    val uiState: StateFlow<PasajeroUiState> = _uiState.asStateFlow()

    fun seleccionarTab(tab: PasajeroTab, pasajeroId: String) {
        _uiState.value = _uiState.value.copy(tabActual = tab)
        if (tab == PasajeroTab.HISTORIAL && !_uiState.value.historialCargado) {
            cargarHistorial(pasajeroId)
        }
        if (tab == PasajeroTab.PERFIL && !_uiState.value.solicitudesCargadas) {
            cargarMisSolicitudes(pasajeroId)
        }
    }

    fun cargarMisSolicitudes(pasajeroId: String) {
        viewModelScope.launch {
            val lista = repository.obtenerMisSolicitudesCambio(pasajeroId)
            _uiState.value = _uiState.value.copy(
                misSolicitudes = lista,
                solicitudesCargadas = true
            )
        }
    }

    fun enviarSolicitudCambioPasajero(
        pasajeroId: String,
        nombreActual: String,
        cambios: Map<String, Any>,
        motivo: String
    ) {
        if (cambios.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            val creada = repository.crearSolicitudCambioDatos(
                solicitanteUid = pasajeroId,
                rol = "pasajero",
                nombreActual = nombreActual.ifBlank { "Pasajero Rural" },
                resumenActual = "Pasajero registrado",
                cambios = cambios,
                motivo = motivo
            )
            _uiState.value = _uiState.value.copy(
                misSolicitudes = listOf(creada) + _uiState.value.misSolicitudes
            )
        }
    }

    fun restaurarViajeActivo(pasajeroId: String) {
        viewModelScope.launch {
            val resultado = repository.recuperarViajeActivoPasajero(pasajeroId)
            val favoritas = repository.obtenerRutasFavoritasPasajero(pasajeroId)
            _uiState.value = _uiState.value.copy(
                viajeActivo = resultado?.first,
                pinPersistente = resultado?.second,
                rutasFavoritas = favoritas
            )
        }
    }

    fun buscarSugerenciasOrigen(query: String) {
        _uiState.value = _uiState.value.copy(
            sugerenciasOrigen = repository.buscarUbicacionesSugeridas(query)
        )
    }

    fun buscarSugerenciasDestino(query: String) {
        _uiState.value = _uiState.value.copy(
            sugerenciasDestino = repository.buscarUbicacionesSugeridas(query)
        )
    }

    fun guardarRutaFavorita(pasajeroId: String, ruta: RutaFavoritaData) {
        viewModelScope.launch {
            val actualizadas = repository.guardarRutaFavoritaPasajero(pasajeroId, ruta)
            _uiState.value = _uiState.value.copy(rutasFavoritas = actualizadas)
        }
    }

    fun eliminarRutaFavorita(pasajeroId: String, rutaId: String) {
        viewModelScope.launch {
            val actualizadas = repository.eliminarRutaFavoritaPasajero(pasajeroId, rutaId)
            _uiState.value = _uiState.value.copy(rutasFavoritas = actualizadas)
        }
    }

    fun cargarHistorial(pasajeroId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargandoHistorial = true)
            val lista = repository.obtenerHistorialPasajero(pasajeroId, 20L)
            _uiState.value = _uiState.value.copy(
                historial = lista,
                historialCargado = true,
                cargandoHistorial = false
            )
        }
    }

    fun onViajeFinalizado(viajeId: String, conductorId: String, montoAPagar: Double) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            pinPersistente = null,
            mostrarModalPago = true,
            montoAPagar = montoAPagar,
            ultimoViajeId = viajeId,
            ultimoConductorId = conductorId
        )
    }

    fun calificarConductor(pasajeroId: String, estrellas: Int, comentario: String) {
        val viajeId = _uiState.value.ultimoViajeId ?: return
        val conductorId = _uiState.value.ultimoConductorId ?: return
        viewModelScope.launch {
            repository.enviarCalificacionYActualizarPromedio(
                viajeId = viajeId,
                autorUid = pasajeroId,
                destinatarioUid = conductorId,
                destinatarioRol = "conductor",
                estrellas = estrellas,
                comentario = comentario
            )
            _uiState.value = _uiState.value.copy(mostrarModalPago = false)
        }
    }

    fun cancelarViajeActivo(viajeId: String, motivo: String) {
        if (motivo.trim().length < 3) return
        viewModelScope.launch {
            repository.cancelarViajeConMotivo(
                viajeId = viajeId,
                canceladoPor = "pasajero",
                motivo = motivo
            )
            _uiState.value = _uiState.value.copy(
                viajeActivo = null,
                pinPersistente = null
            )
        }
    }

    fun onViajeCanceladoPorConductor(motivo: String) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            pinPersistente = null,
            avisoCancelacion = motivo
        )
    }

    fun limpiarAvisoCancelacion() {
        _uiState.value = _uiState.value.copy(avisoCancelacion = null)
    }

    fun cerrarModalPago() {
        _uiState.value = _uiState.value.copy(mostrarModalPago = false)
    }
}

// =============================================================================
// 4. ADMIN VIEWMODEL (Pestañas Modulares, Lazy limit(20), Fichas en Modal)
// =============================================================================
enum class AdminSeccion { RESUMEN, CONDUCTORES, PASAJEROS, SOLICITUDES, ALERTAS, DUPLICADOS, CONFIGURACION }

data class ConductorAdminItem(
    val uid: String,
    val nombre: String,
    val placa: String,
    val vehiculoTipo: String,
    val tarifaBase: Double,
    val tarifaPorKm: Double,
    val gananciasMes: Double,
    val esTarifaAbusiva: Boolean,
    val estadoCuenta: String,
    val cedulaHash: String = "",
    val diasLicenciaRestantes: Int = 30,
    val etiquetaLicencia: String = "Quedan 30 días",
    val estadoLicencia: String = "vigente",
    val fechaLicenciaTexto: String = ""
)

data class PasajeroAdminItem(
    val uid: String,
    val nombre: String,
    val promedioCalificacion: Double,
    val bloqueado: Boolean,
    val telefono: String = "",
    val email: String = "",
    val cedula: String = ""
)

data class VehiculoTipoUi(
    val nombre: String,
    val maxPasajeros: Int,
    val descripcion: String = ""
)

data class ConfiguracionGeneralUi(
    val whatsappSoporte: String = "62546546",
    val sinpeNumero: String = "62546546",
    val sinpeTitular: String = "Administración Viaje Rural",
    val adminNombre: String = "Administrador Viaje Rural",
    val adminTelefono: String = "62546546",
    val adminEmail: String = "sindicatosiserge@gmail.com",
    val terminosCondiciones: String = "",
    val tiposVehiculo: List<VehiculoTipoUi> = emptyList()
)

data class AdminUiState(
    val seccionActual: AdminSeccion = AdminSeccion.RESUMEN,
    val resumen: AdminResumenLigero = AdminResumenLigero(),
    val conductores: List<ConductorAdminItem> = emptyList(),
    val conductoresCargados: Boolean = false,
    val pasajeros: List<PasajeroAdminItem> = emptyList(),
    val pasajerosCargados: Boolean = false,
    val solicitudesCambio: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val conductorSeleccionado: ConductorAdminItem? = null,
    val pasajeroSeleccionado: PasajeroAdminItem? = null,
    val configuracion: ConfiguracionGeneralUi = ConfiguracionGeneralUi(),
    val promedioBaseFlota: Double = 1500.0,
    val promedioKmFlota: Double = 650.0,
    val cargando: Boolean = false
)

class AdminViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    fun cargarResumenInicial() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true)
            val resumen = repository.obtenerResumenAdminLigero()
            _uiState.value = _uiState.value.copy(resumen = resumen, cargando = false)
        }
    }

    /**
     * Carga cada pestaña bajo demanda con limit(20) ÚNICAMENTE cuando el Admin la toca.
     */
    fun seleccionarSeccion(seccion: AdminSeccion) {
        _uiState.value = _uiState.value.copy(seccionActual = seccion)
        when (seccion) {
            AdminSeccion.RESUMEN -> cargarResumenInicial()
            AdminSeccion.CONDUCTORES, AdminSeccion.ALERTAS, AdminSeccion.DUPLICADOS -> {
                if (!_uiState.value.conductoresCargados) cargarConductoresLazy()
            }
            AdminSeccion.PASAJEROS -> {
                if (!_uiState.value.pasajerosCargados) cargarPasajerosLazy()
            }
            AdminSeccion.SOLICITUDES -> {
                if (!_uiState.value.solicitudesCargadas) cargarSolicitudesCambioLazy()
            }
            AdminSeccion.CONFIGURACION -> cargarConfiguracion()
        }
    }

    fun cargarSolicitudesCambioLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true)
            val lista = repository.obtenerSolicitudesCambioAdmin(20L)
            _uiState.value = _uiState.value.copy(
                solicitudesCambio = lista,
                solicitudesCargadas = true,
                cargando = false
            )
        }
    }

    fun resolverSolicitudCambio(
        solicitud: SolicitudCambioData,
        aprobar: Boolean,
        respuestaAdmin: String = ""
    ) {
        viewModelScope.launch {
            repository.resolverSolicitudCambioAdmin(solicitud, aprobar, respuestaAdmin)
            val actualizadas = _uiState.value.solicitudesCambio.map {
                if (it.id == solicitud.id) {
                    it.copy(
                        estado = if (aprobar) "aprobada" else "rechazada",
                        respuestaAdmin = respuestaAdmin
                    )
                } else it
            }
            _uiState.value = _uiState.value.copy(
                solicitudesCambio = actualizadas,
                conductoresCargados = if (aprobar && solicitud.rol == "conductor") false else _uiState.value.conductoresCargados,
                pasajerosCargados = if (aprobar && solicitud.rol == "pasajero") false else _uiState.value.pasajerosCargados
            )
            cargarResumenInicial()
        }
    }

    fun cargarConductoresLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true)
            val rawConductores = repository.obtenerConductoresAdmin(20L)
            val promedioBase = if (rawConductores.isNotEmpty()) {
                rawConductores.mapNotNull { (it["tarifaBase"] as? Number)?.toDouble() }.average()
            } else 1500.0
            val promedioKm = if (rawConductores.isNotEmpty()) {
                rawConductores.mapNotNull { (it["tarifaPorKm"] as? Number)?.toDouble() }.average()
            } else 650.0

            val conductoresUi = rawConductores.map { c ->
                val tBase = (c["tarifaBase"] as? Number)?.toDouble() ?: 0.0
                val tKm = (c["tarifaPorKm"] as? Number)?.toDouble() ?: 0.0
                val abusiva = tBase > promedioBase * 1.30 || tKm > promedioKm * 1.30
                val licInfo = calcularDiasLicenciaRestantes(c["licenciaExp"] as? Timestamp)
                ConductorAdminItem(
                    uid = c["uid"] as? String ?: "",
                    nombre = c["nombre"] as? String ?: "",
                    placa = c["placa"] as? String ?: "",
                    vehiculoTipo = c["vehiculoTipo"] as? String ?: "",
                    tarifaBase = tBase,
                    tarifaPorKm = tKm,
                    gananciasMes = (c["gananciasMes"] as? Number)?.toDouble() ?: 0.0,
                    esTarifaAbusiva = abusiva,
                    estadoCuenta = c["estadoCuenta"] as? String ?: "pendiente",
                    cedulaHash = c["cedulaHash"] as? String ?: "",
                    diasLicenciaRestantes = licInfo.dias,
                    etiquetaLicencia = licInfo.etiqueta,
                    estadoLicencia = licInfo.estado,
                    fechaLicenciaTexto = licInfo.fechaTexto
                )
            }
            _uiState.value = _uiState.value.copy(
                conductores = conductoresUi,
                conductoresCargados = true,
                promedioBaseFlota = promedioBase,
                promedioKmFlota = promedioKm,
                cargando = false
            )
        }
    }

    fun cargarPasajerosLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true)
            val rawPasajeros = repository.obtenerPasajerosAdmin(20L)
            val pasajerosUi = rawPasajeros.map { p ->
                PasajeroAdminItem(
                    uid = p["uid"] as? String ?: "",
                    nombre = p["nombre"] as? String ?: "",
                    promedioCalificacion = (p["promedioCalificacion"] as? Number)?.toDouble() ?: 5.0,
                    bloqueado = p["bloqueado"] as? Boolean ?: false
                )
            }
            _uiState.value = _uiState.value.copy(
                pasajeros = pasajerosUi,
                pasajerosCargados = true,
                cargando = false
            )
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun cargarConfiguracion() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true)
            val rawConfig = repository.obtenerConfiguracionGeneral()
            val tiposRaw = (rawConfig["tiposVehiculo"] as? List<Map<String, Any>>).orEmpty()
            val tiposUi = tiposRaw.map { t ->
                VehiculoTipoUi(
                    nombre = t["nombre"] as? String ?: "",
                    maxPasajeros = (t["maxPasajeros"] as? Number)?.toInt() ?: 4,
                    descripcion = t["descripcion"] as? String ?: ""
                )
            }
            val configUi = ConfiguracionGeneralUi(
                whatsappSoporte = rawConfig["whatsappSoporte"] as? String ?: "62546546",
                sinpeNumero = rawConfig["sinpeNumero"] as? String ?: "62546546",
                sinpeTitular = rawConfig["adminSinpeTitular"] as? String ?: "Administración Viaje Rural",
                adminNombre = rawConfig["adminNombre"] as? String ?: "Administrador Viaje Rural",
                adminTelefono = rawConfig["adminTelefono"] as? String ?: "62546546",
                adminEmail = rawConfig["adminEmail"] as? String ?: "sindicatosiserge@gmail.com",
                terminosCondiciones = rawConfig["terminosCondiciones"] as? String ?: "",
                tiposVehiculo = tiposUi
            )
            _uiState.value = _uiState.value.copy(configuracion = configUi, cargando = false)
        }
    }

    fun seleccionarConductor(conductor: ConductorAdminItem) {
        _uiState.value = _uiState.value.copy(conductorSeleccionado = conductor)
    }

    fun cerrarFichaConductor() {
        _uiState.value = _uiState.value.copy(conductorSeleccionado = null)
    }

    fun seleccionarPasajero(pasajero: PasajeroAdminItem) {
        viewModelScope.launch {
            val pii = repository.obtenerPiiUsuarioAdmin(pasajero.uid)
            _uiState.value = _uiState.value.copy(
                pasajeroSeleccionado = pasajero.copy(
                    telefono = pii?.get("telefono") as? String ?: "",
                    email = pii?.get("email") as? String ?: "",
                    cedula = pii?.get("cedula") as? String ?: ""
                )
            )
        }
    }

    fun guardarFichaPasajero(
        uid: String,
        nombre: String,
        telefono: String,
        email: String,
        cedula: String
    ) {
        viewModelScope.launch {
            repository.actualizarFichaPasajeroAdmin(uid, nombre, telefono, email, cedula)
            _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null)
            cargarPasajerosLazy()
        }
    }

    fun cerrarFichaPasajero() {
        _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null)
    }

    fun guardarConfiguracion(config: ConfiguracionGeneralUi) {
        viewModelScope.launch {
            val tiposMap = config.tiposVehiculo.map {
                mapOf(
                    "nombre" to it.nombre,
                    "maxPasajeros" to it.maxPasajeros,
                    "descripcion" to it.descripcion
                )
            }
            repository.guardarConfiguracionGeneralAdmin(
                whatsappSoporte = config.whatsappSoporte,
                sinpeNumero = config.sinpeNumero,
                sinpeTitular = config.sinpeTitular,
                adminNombre = config.adminNombre,
                adminTelefono = config.adminTelefono,
                adminEmail = config.adminEmail,
                terminosCondiciones = config.terminosCondiciones,
                tiposVehiculo = tiposMap
            )
            _uiState.value = _uiState.value.copy(configuracion = config)
        }
    }
}
