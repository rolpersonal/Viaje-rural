package cr.viajerural.app.messaging

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import cr.viajerural.app.R

/**
 * Receptor FCM de alta prioridad para Viaje Rural:
 * - PING_1S: Enciende el GPS 1 segundo, envía coordenadas y lo apaga.
 * - OFERTA_15S: Oferta secuencial de viaje (15s).
 * - CHAT_MENSAJE (Requisito 4): Notificación flotante (Heads-up) con sonido de alerta.
 * - ACEPTADO / PROXIMIDAD / MENSUALIDAD_7000.
 */
class ViajeRuralMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val tipo = message.data["tipo"] ?: return

        when (tipo) {
            "PING_1S" -> ejecutarPingGpsDeUnSegundo()
            "CHAT_MENSAJE" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_CHAT_HEADS_UP,
                channelName = "Chat en Vivo (Heads-up con Sonido)",
                titulo = "Nuevo mensaje de ${message.data["autorNombre"] ?: "Viaje Rural"}",
                cuerpo = message.data["texto"] ?: "Tienes un mensaje nuevo en el viaje."
            )
            "OFERTA_15S" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "Nueva oferta de viaje (15s)",
                cuerpo = message.data["resumen"] ?: "Tienes 15 segundos para aceptar."
            )
            "ACEPTADO" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "¡Conductor asignado!",
                cuerpo = "Tu conductor va en camino. Revisa tu PIN de 3 dígitos."
            )
            "PROXIMIDAD" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "Conductor cerca de tu ubicación",
                cuerpo = "Ten a mano tu PIN de 3 dígitos para abordar."
            )
            "MENSUALIDAD_7000" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "Recordatorio mensual — Viaje Rural",
                cuerpo = "Renueva tu licencia mensual (₡7,000 colones) para seguir recibiendo viajes."
            )
            "VIAJE_CANCELADO" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "Viaje cancelado por ${message.data["pasajeroNombre"] ?: "el pasajero"}",
                cuerpo = message.data["motivoCancelacion"] ?: "El pasajero canceló el viaje."
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun ejecutarPingGpsDeUnSegundo() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val fused = LocationServices.getFusedLocationProviderClient(this)
        val cts = CancellationTokenSource()

        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    FirebaseFirestore.getInstance()
                        .collection("conductores")
                        .document(uid)
                        .update(
                            mapOf(
                                "lat" to location.latitude,
                                "lng" to location.longitude,
                                "ultimoPingAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                }
                cts.cancel()
            }
            .addOnFailureListener { cts.cancel() }
    }

    /**
     * Requisito 4: Notificación flotante (Heads-up, IMPORTANCE_HIGH + PRIORITY_MAX)
     * con sonido del sistema y vibración.
     */
    private fun mostrarNotificacionFlotanteConSonido(
        channelId: String,
        channelName: String,
        titulo: String,
        cuerpo: String
    ) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val audioAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound(soundUri, audioAttrs)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 220, 120, 220)
            }
            manager.createNotificationChannel(channel)
        }

        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setSound(soundUri)
            .setAutoCancel(true)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notif)
    }

    companion object {
        const val CHANNEL_HIGH_PRIORITY = "viaje_rural_high_priority"
        const val CHANNEL_CHAT_HEADS_UP = "viaje_rural_chat_heads_up"
    }
}
