package cr.viajerural.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import cr.viajerural.app.data.RutaFavoritaData
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.UbicacionSugerida
import cr.viajerural.app.viewmodel.PasajeroTab

/**
 * Pantalla Principal del Pasajero (Jetpack Compose) con BottomNavigation (3 pestañas):
 * - Viaje: Rutas favoritas, autocompletado de ubicación actual y destino (ej. Pozuelo), PIN persistente, modales Mapa/Chat bajo demanda.
 * - Historial: Carga lazy limit(20) solo al tocar la pestaña.
 * - Perfil: Datos, rutas favoritas y soporte.
 */
@Composable
fun PasajeroScreen(
    tabActual: PasajeroTab,
    onSelectTab: (PasajeroTab) -> Unit,
    estadoViaje: String,
    pinPersistente: String?,
    conductorNombre: String?,
    conductorPlaca: String?,
    etaMinutos: Int?,
    montoAproximado: Int,
    rutasFavoritas: List<RutaFavoritaData>,
    sugerenciasOrigen: List<UbicacionSugerida>,
    sugerenciasDestino: List<UbicacionSugerida>,
    historial: List<Map<String, Any>>,
    cargandoHistorial: Boolean,
    mostrarModalPago: Boolean,
    onBuscarOrigen: (String) -> Unit,
    onBuscarDestino: (String) -> Unit,
    onGuardarFavorita: (RutaFavoritaData) -> Unit,
    onEliminarFavorita: (String) -> Unit,
    onSolicitarViaje: (pasajeros: Int, origen: String, destino: String, resenaUbicacion: String) -> Unit,
    onCalificarConductor: (estrellas: Int, comentario: String) -> Unit,
    onDismissModalPago: () -> Unit,
    nombrePasajero: String = "",
    misSolicitudes: List<SolicitudCambioData> = emptyList(),
    onEnviarSolicitudCambio: (cambios: Map<String, Any>, motivo: String) -> Unit = { _, _ -> },
    avisoCancelacion: String? = null,
    onDismissAvisoCancelacion: () -> Unit = {},
    onCancelarViaje: (motivo: String) -> Unit = {},
    precisionUbicacionMetros: Int? = null,
    onUsarGpsPreciso: () -> Unit = {}
) {
    var mostrarMapaModal by remember { mutableStateOf(false) }
    var mostrarChatModal by remember { mutableStateOf(false) }
    var mostrarModalSolicitud by remember { mutableStateOf(false) }
    var mostrarModalCancelar by remember { mutableStateOf(false) }
    var motivoCancelacionInput by remember { mutableStateOf("") }
    var cantidadPasajeros by remember { mutableIntStateOf(0) }
    var origen by remember { mutableStateOf("Santa Elena Centro") }
    var origenLat by remember { mutableDoubleStateOf(9.3895) }
    var origenLng by remember { mutableDoubleStateOf(-83.6490) }
    var destino by remember { mutableStateOf("") }
    var destinoLat by remember { mutableDoubleStateOf(9.3738) }
    var destinoLng by remember { mutableDoubleStateOf(-83.7042) }
    var mostrarListaOrigen by remember { mutableStateOf(false) }
    var mostrarListaDestino by remember { mutableStateOf(false) }
    var resenaUbicacion by remember { mutableStateOf("") }
    var estrellas by remember { mutableIntStateOf(5) }
    var comentario by remember { mutableStateOf("") }

    LaunchedEffect(estadoViaje) {
        if (estadoViaje != "aceptado" && mostrarMapaModal) mostrarMapaModal = false
        if (estadoViaje != "aceptado" && estadoViaje != "en_curso") mostrarChatModal = false
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.VIAJE,
                    onClick = { onSelectTab(PasajeroTab.VIAJE) },
                    icon = { Text("🚗") },
                    label = { Text("Viaje") }
                )
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.HISTORIAL,
                    onClick = { onSelectTab(PasajeroTab.HISTORIAL) },
                    icon = { Text("📜") },
                    label = { Text("Historial") }
                )
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.PERFIL,
                    onClick = { onSelectTab(PasajeroTab.PERFIL) },
                    icon = { Text("👤") },
                    label = { Text("Perfil") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            when (tabActual) {
                PasajeroTab.VIAJE -> {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Viaje Rural — Pasajero",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )

                        if (!avisoCancelacion.isNullOrBlank()) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Viaje cancelado", fontWeight = FontWeight.Bold)
                                        Text(avisoCancelacion, style = MaterialTheme.typography.bodySmall)
                                    }
                                    TextButton(onClick = onDismissAvisoCancelacion) { Text("Cerrar") }
                                }
                            }
                        }

                        if (estadoViaje == "aceptado" && !pinPersistente.isNullOrBlank()) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "TU PIN DE SEGURIDAD (ENTREGAR AL SUBIR)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = pinPersistente,
                                        fontSize = 42.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 8.sp
                                    )
                                    Text("Conductor: ${conductorNombre.orEmpty()} · Placa: ${conductorPlaca.orEmpty()}")
                                    Text("ETA aproximado: ${etaMinutos ?: "--"} min · Tarifa aprox: ₡$montoAproximado")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { mostrarMapaModal = true },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Ver Mapa") }
                                        OutlinedButton(
                                            onClick = { mostrarChatModal = true },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Abrir Chat") }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            motivoCancelacionInput = ""
                                            mostrarModalCancelar = true
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Cancelar viaje (ingresar nota)") }
                                }
                            }
                        } else if (estadoViaje == "en_curso") {
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("Viaje en curso con ${conductorNombre.orEmpty()}", fontWeight = FontWeight.Bold)
                                    Text("Tarifa estimada: ₡$montoAproximado")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { mostrarChatModal = true },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Abrir Chat") }
                                        OutlinedButton(
                                            onClick = {
                                                motivoCancelacionInput = ""
                                                mostrarModalCancelar = true
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Cancelar viaje") }
                                    }
                                }
                            }
                        } else if (estadoViaje == "idle") {
                            // Rutas Favoritas en un toque
                            if (rutasFavoritas.isNotEmpty()) {
                                Text("Rutas favoritas", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(rutasFavoritas) { fav ->
                                        AssistChip(
                                            onClick = {
                                                origen = fav.origenNombre
                                                origenLat = fav.origenLat
                                                origenLng = fav.origenLng
                                                destino = fav.destinoNombre
                                                destinoLat = fav.destinoLat
                                                destinoLng = fav.destinoLng
                                            },
                                            label = { Text(fav.alias) }
                                        )
                                    }
                                }
                            }

                            // Buscador desplegable de Ubicación Actual + GPS preciso
                            OutlinedTextField(
                                value = origen,
                                onValueChange = {
                                    origen = it
                                    mostrarListaOrigen = true
                                    onBuscarOrigen(it)
                                },
                                label = { Text("Ubicación actual (escribe ej. Pozuelo o usa GPS preciso)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(onClick = onUsarGpsPreciso) {
                                    Text(
                                        if (precisionUbicacionMetros != null) {
                                            "Recalibrar GPS (±${precisionUbicacionMetros} m)"
                                        } else {
                                            "Usar GPS de alta precisión"
                                        }
                                    )
                                }
                                if (precisionUbicacionMetros != null) {
                                    Text(
                                        text = if (precisionUbicacionMetros <= 25) "Alta precisión" else "Precisión media",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            if (mostrarListaOrigen && sugerenciasOrigen.isNotEmpty()) {
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column {
                                        sugerenciasOrigen.take(4).forEach { opc ->
                                            ListItem(
                                                headlineContent = { Text(opc.nombre) },
                                                supportingContent = { Text(opc.canton) },
                                                modifier = Modifier.clickable {
                                                    origen = opc.nombre
                                                    origenLat = opc.lat
                                                    origenLng = opc.lng
                                                    mostrarListaOrigen = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // Buscador desplegable de Destino
                            OutlinedTextField(
                                value = destino,
                                onValueChange = {
                                    destino = it
                                    mostrarListaDestino = true
                                    onBuscarDestino(it)
                                },
                                label = { Text("Destino (escribe ej. Pozuelo)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (mostrarListaDestino && sugerenciasDestino.isNotEmpty()) {
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column {
                                        sugerenciasDestino.take(4).forEach { opc ->
                                            ListItem(
                                                headlineContent = { Text(opc.nombre) },
                                                supportingContent = { Text(opc.canton) },
                                                modifier = Modifier.clickable {
                                                    destino = opc.nombre
                                                    destinoLat = opc.lat
                                                    destinoLng = opc.lng
                                                    mostrarListaDestino = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            TextButton(
                                onClick = {
                                    if (origen.isNotBlank() && destino.isNotBlank()) {
                                        onGuardarFavorita(
                                            RutaFavoritaData(
                                                id = "fav_${System.currentTimeMillis()}",
                                                alias = "${origen.take(15)} → ${destino.take(15)}",
                                                origenNombre = origen,
                                                origenLat = origenLat,
                                                origenLng = origenLng,
                                                destinoNombre = destino,
                                                destinoLat = destinoLat,
                                                destinoLng = destinoLng
                                            )
                                        )
                                    }
                                }
                            ) {
                                Text("★ Guardar ruta actual como favorita")
                            }

                            OutlinedTextField(
                                value = resenaUbicacion,
                                onValueChange = { resenaUbicacion = it },
                                label = { Text("Reseña exacta de dónde estás") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = if (cantidadPasajeros == 0) {
                                        "Pasajeros: 0 (obligatorio indicar)"
                                    } else {
                                        "Pasajeros: $cantidadPasajeros"
                                    }
                                )
                                FilledTonalButton(
                                    onClick = { if (cantidadPasajeros > 0) cantidadPasajeros-- },
                                    enabled = cantidadPasajeros > 0
                                ) { Text("-") }
                                FilledTonalButton(
                                    onClick = { if (cantidadPasajeros < 12) cantidadPasajeros++ },
                                    enabled = cantidadPasajeros < 12
                                ) { Text("+") }
                            }
                            if (cantidadPasajeros == 0) {
                                Text(
                                    text = "Indica al menos 1 pasajero para poder solicitar el viaje.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            Button(
                                onClick = {
                                    onSolicitarViaje(cantidadPasajeros, origen, destino, resenaUbicacion)
                                    cantidadPasajeros = 0
                                },
                                enabled = cantidadPasajeros >= 1 && origen.isNotBlank() && destino.isNotBlank() && resenaUbicacion.length >= 3,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                            ) {
                                Text("Solicitar viaje (Dispara Ping 1s)")
                            }
                        }
                    }
                }

                PasajeroTab.HISTORIAL -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Historial de Viajes (limit(20))", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (cargandoHistorial) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(historial) { v ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("${v["origenNombre"] ?: ""} → ${v["destinoNombre"] ?: ""}", fontWeight = FontWeight.Bold)
                                        Text("Estado: ${v["estado"] ?: ""} · ₡${v["montoAproximado"] ?: 0}", fontFamily = FontFamily.Monospace)
                                        val motivoHist = v["motivoCancelacion"] as? String
                                        if (!motivoHist.isNullOrBlank()) {
                                            val por = if (v["canceladoPor"] == "conductor") "conductor" else "pasajero"
                                            Text(
                                                text = "Cancelado por $por: \"$motivoHist\"",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                PasajeroTab.PERFIL -> {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Perfil y Rutas Favoritas", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Datos Personales (Bloqueados)", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Para evitar manipulación de datos después del registro, cualquier cambio debe aprobarlo el Administrador.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (nombrePasajero.isNotBlank()) {
                                    Text("Nombre: $nombrePasajero")
                                }
                                OutlinedButton(
                                    onClick = { mostrarModalSolicitud = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Solicitar cambio de datos al Administrador")
                                }
                            }
                        }

                        if (misSolicitudes.isNotEmpty()) {
                            Text("Mis Peticiones de Cambio", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            misSolicitudes.forEach { sol ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("${sol.estado.uppercase()} · ${sol.motivo}", fontWeight = FontWeight.SemiBold)
                                        if (sol.respuestaAdmin.isNotBlank()) {
                                            Text("Admin: ${sol.respuestaAdmin}", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }

                        rutasFavoritas.forEach { fav ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(fav.alias, fontWeight = FontWeight.Bold)
                                        Text("${fav.origenNombre} → ${fav.destinoNombre}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    TextButton(onClick = { onEliminarFavorita(fav.id) }) { Text("Quitar") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (mostrarModalPago) {
        AlertDialog(
            onDismissRequest = onDismissModalPago,
            title = { Text("Viaje Finalizado — Pago en Efectivo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Monto a pagar al conductor:")
                    Text(
                        text = "₡$montoAproximado",
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text("Califica a ${conductorNombre ?: "tu conductor"} ($estrellas/5 ★):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { n ->
                            FilledTonalButton(onClick = { estrellas = n }) {
                                Text(if (n <= estrellas) "★" else "☆")
                            }
                        }
                    }
                    OutlinedTextField(
                        value = comentario,
                        onValueChange = { comentario = it },
                        label = { Text("Comentario opcional") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = { onCalificarConductor(estrellas, comentario) }) {
                    Text("Confirmar y Calificar")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissModalPago) { Text("Cerrar") }
            }
        )
    }

    if (mostrarMapaModal) {
        Dialog(
            onDismissRequest = { mostrarMapaModal = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            OnDemandMapModalContent(
                etaMinutos = etaMinutos,
                onClose = { mostrarMapaModal = false }
            )
        }
    }

    if (mostrarChatModal) {
        Dialog(onDismissRequest = { mostrarChatModal = false }) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Chat Privado (Bajo Demanda)", fontWeight = FontWeight.Bold)
                    Text("Sin exposición de números telefónicos.", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { mostrarChatModal = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cerrar Chat")
                    }
                }
            }
        }
    }

    if (mostrarModalSolicitud) {
        var reqNombre by remember { mutableStateOf("") }
        var reqTelefono by remember { mutableStateOf("") }
        var reqCorreo by remember { mutableStateOf("") }
        var reqCedula by remember { mutableStateOf("") }
        var reqMotivo by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { mostrarModalSolicitud = false },
            title = { Text("Solicitar Cambio de Datos") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Indica únicamente los campos que necesitas corregir.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = reqNombre, onValueChange = { reqNombre = it }, label = { Text("Nuevo nombre (opcional)") })
                    OutlinedTextField(value = reqTelefono, onValueChange = { reqTelefono = it }, label = { Text("Nuevo teléfono (opcional)") })
                    OutlinedTextField(value = reqCorreo, onValueChange = { reqCorreo = it }, label = { Text("Nuevo correo (opcional)") })
                    OutlinedTextField(value = reqCedula, onValueChange = { reqCedula = it }, label = { Text("Nueva cédula (opcional)") })
                    OutlinedTextField(value = reqMotivo, onValueChange = { reqMotivo = it }, label = { Text("Motivo del cambio (obligatorio)") })
                }
            },
            confirmButton = {
                Button(
                    enabled = reqMotivo.trim().length >= 3 && (reqNombre.isNotBlank() || reqTelefono.isNotBlank() || reqCorreo.isNotBlank() || reqCedula.isNotBlank()),
                    onClick = {
                        val cambios = mutableMapOf<String, Any>()
                        if (reqNombre.isNotBlank()) cambios["nombre"] = reqNombre.trim()
                        if (reqTelefono.isNotBlank()) cambios["telefono"] = reqTelefono.trim()
                        if (reqCorreo.isNotBlank()) cambios["email"] = reqCorreo.trim()
                        if (reqCedula.isNotBlank()) cambios["cedula"] = reqCedula.trim()
                        onEnviarSolicitudCambio(cambios, reqMotivo.trim())
                        mostrarModalSolicitud = false
                    }
                ) { Text("Enviar Petición") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalSolicitud = false }) { Text("Cancelar") }
            }
        )
    }

    if (mostrarModalCancelar) {
        val sugerenciasPasajero = listOf(
            "El conductor no puede llegar hasta mi ubicación",
            "Cambio de planes / ya no necesito el viaje",
            "Emergencia personal"
        )
        AlertDialog(
            onDismissRequest = { mostrarModalCancelar = false },
            title = { Text("Cancelar viaje") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Indica en una nota por qué deseas cancelar el viaje. El conductor recibirá este motivo.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    sugerenciasPasajero.forEach { opc ->
                        OutlinedButton(
                            onClick = { motivoCancelacionInput = opc },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(opc) }
                    }
                    OutlinedTextField(
                        value = motivoCancelacionInput,
                        onValueChange = { if (it.length <= 280) motivoCancelacionInput = it },
                        label = { Text("Nota de cancelación (obligatoria)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = motivoCancelacionInput.trim().length >= 3,
                    onClick = {
                        onCancelarViaje(motivoCancelacionInput.trim())
                        mostrarModalCancelar = false
                    }
                ) { Text("Confirmar cancelación") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalCancelar = false }) { Text("Volver") }
            }
        )
    }
}

@Composable
private fun OnDemandMapModalContent(
    etaMinutos: Int?,
    onClose: () -> Unit
) {
    DisposableEffect(Unit) {
        onDispose {
            // Liberación de MapView al cerrar ventana modal
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Mapa de Acercamiento · ETA ${etaMinutos ?: "--"} min", fontWeight = FontWeight.Bold)
                TextButton(onClick = onClose) { Text("Cerrar y liberar") }
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("AndroidView { MapView } inicializado bajo demanda (actualización cada 90s)")
            }
            Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
                Text("Cerrar Mapa")
            }
        }
    }
}
