package cr.viajerural.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.window.Dialog
import cr.viajerural.app.data.LicenciaRestanteInfo
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.service.PickupLocationService
import cr.viajerural.app.viewmodel.ConductorTab

/**
 * Pantalla del Conductor con BottomNavigation (4 pestañas):
 * - Inicio: Ofertas de viaje 15s, estado Activo/Inactivo, días de licencia, Waze, PIN y botones bajo demanda Ver Mapa / Abrir Chat.
 * - Finanzas: SOLO 2 datos (Generado Hoy y Generado en el Mes) + estado de licencia.
 * - Historial: Carga lazy limit(20) solo al tocar la pestaña.
 * - Perfil: Tarifa base (₡), Precio por kilómetro adicional (₡), ficha bloqueada y peticiones de cambio al Admin.
 */
@Composable
fun ConductorScreen(
    tabActual: ConductorTab,
    onSelectTab: (ConductorTab) -> Unit,
    conductorId: String,
    viajeActivoId: String?,
    estadoViaje: String?,
    pasajeroNombre: String?,
    cantidadPasajeros: Int,
    resenaUbicacion: String?,
    origenLat: Double?,
    origenLng: Double?,
    destinoLat: Double?,
    destinoLng: Double?,
    segundosOfertaRestantes: Int?,
    gananciasHoy: Double,
    gananciasMes: Double,
    historial: List<Map<String, Any>>,
    cargandoHistorial: Boolean,
    mostrarModalCobro: Boolean,
    montoACobrar: Double,
    onAceptarOferta: () -> Unit,
    onRechazarOferta: () -> Unit,
    onVerificarPin: (String) -> Unit,
    onFinalizarViaje: () -> Unit,
    onCalificarPasajero: (estrellas: Int, comentario: String) -> Unit,
    onDismissModalCobro: () -> Unit,
    licenciaRestante: LicenciaRestanteInfo? = null,
    nombreConductor: String = "",
    placa: String = "",
    vehiculoTipo: String = "",
    tarifaBase: Double = 1500.0,
    tarifaPorKm: Double = 650.0,
    misSolicitudes: List<SolicitudCambioData> = emptyList(),
    onEnviarSolicitudCambio: (cambios: Map<String, Any>, motivo: String) -> Unit = { _, _ -> },
    onCancelarViaje: (motivo: String) -> Unit = {},
    avisoCancelacionFlotante: String? = null,
    onDismissAvisoCancelacion: () -> Unit = {}
) {
    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var estrellasPasajero by remember { mutableIntStateOf(5) }
    var comentarioPasajero by remember { mutableStateOf("") }
    var mostrarMapaModal by remember { mutableStateOf(false) }
    var mostrarChatModal by remember { mutableStateOf(false) }
    var mostrarModalSolicitud by remember { mutableStateOf(false) }
    var mostrarModalCancelar by remember { mutableStateOf(false) }
    var motivoCancelacionInput by remember { mutableStateOf("") }
    var tarifaBaseInput by remember(tarifaBase) { mutableStateOf(tarifaBase.toInt().toString()) }
    var tarifaKmInput by remember(tarifaPorKm) { mutableStateOf(tarifaPorKm.toInt().toString()) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tabActual == ConductorTab.INICIO,
                    onClick = { onSelectTab(ConductorTab.INICIO) },
                    icon = { Text("🏠") },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.FINANZAS,
                    onClick = { onSelectTab(ConductorTab.FINANZAS) },
                    icon = { Text("₡") },
                    label = { Text("Finanzas") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.HISTORIAL,
                    onClick = { onSelectTab(ConductorTab.HISTORIAL) },
                    icon = { Text("📜") },
                    label = { Text("Historial") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.PERFIL,
                    onClick = { onSelectTab(ConductorTab.PERFIL) },
                    icon = { Text("⚙️") },
                    label = { Text("Perfil") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (tabActual) {
                ConductorTab.INICIO -> {
                    Text(
                        text = "Viaje Rural — Conductor",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    licenciaRestante?.let { lic ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = when (lic.estado) {
                                    "vencida" -> MaterialTheme.colorScheme.errorContainer
                                    "por_vencer" -> MaterialTheme.colorScheme.tertiaryContainer
                                    else -> MaterialTheme.colorScheme.secondaryContainer
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Licencia restante", fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${lic.etiqueta} (vence ${lic.fechaTexto})",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (viajeActivoId != null && estadoViaje == "aceptado" && origenLat != null && origenLng != null) {
                        Button(
                            onClick = { abrirWaze(context, origenLat, origenLng) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                        ) { Text("Retomar recogida (Waze)") }

                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Pasajero: ${pasajeroNombre.orEmpty()} ($cantidadPasajeros pax)", fontWeight = FontWeight.Bold)
                                Text("Reseña de ubicación: ${resenaUbicacion.orEmpty()}")

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { mostrarMapaModal = true }, modifier = Modifier.weight(1f)) {
                                        Text("Ver Mapa")
                                    }
                                    OutlinedButton(onClick = { mostrarChatModal = true }, modifier = Modifier.weight(1f)) {
                                        Text("Abrir Chat")
                                    }
                                }

                                OutlinedTextField(
                                    value = pinInput,
                                    onValueChange = { if (it.length <= 3) pinInput = it.filter(Char::isDigit) },
                                    label = { Text("Ingresar PIN de 3 dígitos del pasajero") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Button(
                                    onClick = {
                                        PickupLocationService.stop(context)
                                        onVerificarPin(pinInput)
                                    },
                                    enabled = pinInput.length == 3,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Confirmar PIN y apagar GPS") }

                                OutlinedButton(
                                    onClick = {
                                        motivoCancelacionInput = ""
                                        mostrarModalCancelar = true
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Cancelar viaje (ingresar nota)") }
                            }
                        }
                    } else if (viajeActivoId != null && estadoViaje == "en_curso" && destinoLat != null && destinoLng != null) {
                        Button(
                            onClick = { abrirWaze(context, destinoLat, destinoLng) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                        ) { Text("Retomar viaje al destino (Waze)") }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { mostrarMapaModal = true }, modifier = Modifier.weight(1f)) {
                                Text("Ver Mapa")
                            }
                            OutlinedButton(onClick = { mostrarChatModal = true }, modifier = Modifier.weight(1f)) {
                                Text("Abrir Chat")
                            }
                        }

                        Button(onClick = onFinalizarViaje, modifier = Modifier.fillMaxWidth()) {
                            Text("Finalizar viaje y cobrar")
                        }

                        OutlinedButton(
                            onClick = {
                                motivoCancelacionInput = ""
                                mostrarModalCancelar = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Cancelar viaje (ingresar nota)") }
                    } else if (segundosOfertaRestantes != null) {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("Nueva solicitud (${segundosOfertaRestantes}s)", fontWeight = FontWeight.Bold)
                                Text("Reseña: ${resenaUbicacion.orEmpty()} · $cantidadPasajeros pasajeros")
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    OutlinedButton(onClick = onRechazarOferta, modifier = Modifier.weight(1f)) {
                                        Text("Rechazar")
                                    }
                                    Button(
                                        onClick = {
                                            onAceptarOferta()
                                            if (viajeActivoId != null) {
                                                PickupLocationService.start(context, viajeActivoId, conductorId)
                                            }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Aceptar") }
                                }
                            }
                        }
                    } else {
                        Text("Modo Espera: GPS apagado para ahorrar batería y datos.")
                    }
                }

                ConductorTab.FINANZAS -> {
                    Text("Finanzas del Conductor", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Solo dos montos (FieldValue.increment() — Ahorro de Datos)",
                                style = MaterialTheme.typography.labelMedium
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Generado Hoy", style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        text = "₡${gananciasHoy.toInt()}",
                                        fontSize = 24.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Column {
                                    Text("Generado en el Mes", style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        text = "₡${gananciasMes.toInt()}",
                                        fontSize = 24.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    licenciaRestante?.let { lic ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Estado de Licencia Mensual", style = MaterialTheme.typography.labelMedium)
                                Text(
                                    text = lic.etiqueta,
                                    fontSize = 22.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("Vence: ${lic.fechaTexto} · Cuota mensual ₡7,000 (+10% cada 1 de enero)", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                ConductorTab.HISTORIAL -> {
                    Text("Historial del Conductor (limit(20))", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (cargandoHistorial) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(historial) { v ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("${v["pasajeroNombre"] ?: ""} · ${v["destinoNombre"] ?: ""}", fontWeight = FontWeight.Bold)
                                    Text("₡${v["montoAproximado"] ?: 0} · ${v["estado"] ?: ""}", fontFamily = FontFamily.Monospace)
                                    val motivoHist = v["motivoCancelacion"] as? String
                                    if (!motivoHist.isNullOrBlank()) {
                                        val por = if (v["canceladoPor"] == "conductor") "conductor" else "pasajero"
                                        Text(
                                            text = "Cancelado por $por: \"$motivoHist\"",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                ConductorTab.PERFIL -> {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Configuración de Tarifas y Perfil", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Ajusta tu tarifa base y precio por kilómetro adicional. El administrador monitorea variaciones >30%.", style = MaterialTheme.typography.bodySmall)

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = tarifaBaseInput,
                                onValueChange = { tarifaBaseInput = it.filter(Char::isDigit) },
                                label = { Text("Tarifa base (₡)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = tarifaKmInput,
                                onValueChange = { tarifaKmInput = it.filter(Char::isDigit) },
                                label = { Text("Precio por kilómetro adicional (₡)") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        licenciaRestante?.let { lic ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Licencia de Conducción", fontWeight = FontWeight.Bold)
                                    Text("${lic.etiqueta} · Vence ${lic.fechaTexto}", fontFamily = FontFamily.Monospace)
                                }
                            }
                        }

                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Datos Registrados (Bloqueados)", fontWeight = FontWeight.Bold)
                                Text("Para evitar manipulación de identidad o placa, estos datos solo se modifican mediante petición al Administrador.", style = MaterialTheme.typography.bodySmall)
                                Text("Conductor: ${nombreConductor.ifBlank { "Registrado" }}")
                                Text("Vehículo: ${vehiculoTipo.ifBlank { "-" }} · Placa: ${placa.ifBlank { "-" }}")
                                OutlinedButton(
                                    onClick = { mostrarModalSolicitud = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Solicitar cambio de datos al Administrador")
                                }
                            }
                        }

                        if (misSolicitudes.isNotEmpty()) {
                            Text("Mis Peticiones de Cambio", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            misSolicitudes.forEach { sol ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("${sol.estado.uppercase()} · ${sol.motivo}", fontWeight = FontWeight.SemiBold)
                                        if (sol.respuestaAdmin.isNotBlank()) {
                                            Text("Admin: ${sol.respuestaAdmin}", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!avisoCancelacionFlotante.isNullOrBlank()) {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Viaje cancelado por el pasajero", fontWeight = FontWeight.Bold)
                        Text(avisoCancelacionFlotante, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = onDismissAvisoCancelacion) { Text("Cerrar") }
                }
            }
        }
        }
    }

    if (mostrarModalCobro) {
        AlertDialog(
            onDismissRequest = onDismissModalCobro,
            title = { Text("Viaje Finalizado — Cobro en Efectivo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Monto a cobrar al pasajero:")
                    Text(
                        text = "₡${montoACobrar.toInt()}",
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text("Califica al pasajero ($estrellasPasajero/5 ★):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { n ->
                            FilledTonalButton(onClick = { estrellasPasajero = n }) {
                                Text(if (n <= estrellasPasajero) "★" else "☆")
                            }
                        }
                    }
                    OutlinedTextField(
                        value = comentarioPasajero,
                        onValueChange = { comentarioPasajero = it },
                        label = { Text("Comentario opcional") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = { onCalificarPasajero(estrellasPasajero, comentarioPasajero) }) {
                    Text("Guardar Calificación")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissModalCobro) { Text("Cerrar") }
            }
        )
    }

    if (mostrarMapaModal) {
        Dialog(onDismissRequest = { mostrarMapaModal = false }) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Mapa Bajo Demanda", fontWeight = FontWeight.Bold)
                    Text("Solo activo mientras esta ventana está abierta.")
                    Button(onClick = { mostrarMapaModal = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cerrar y liberar mapa")
                    }
                }
            }
        }
    }

    if (mostrarChatModal) {
        Dialog(onDismissRequest = { mostrarChatModal = false }) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Chat Privado (Bajo Demanda)", fontWeight = FontWeight.Bold)
                    Text("Mensajes en tiempo real con sonido y notificación flotante.")
                    Button(onClick = { mostrarChatModal = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cerrar Chat")
                    }
                }
            }
        }
    }

    if (mostrarModalSolicitud) {
        var reqNombre by remember { mutableStateOf("") }
        var reqTelefono by remember { mutableStateOf("") }
        var reqPlaca by remember { mutableStateOf("") }
        var reqModelo by remember { mutableStateOf("") }
        var reqMotivo by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { mostrarModalSolicitud = false },
            title = { Text("Petición de Cambio al Administrador") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Completa solo los campos que deseas corregir o actualizar.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = reqNombre, onValueChange = { reqNombre = it }, label = { Text("Nuevo nombre (opcional)") })
                    OutlinedTextField(value = reqTelefono, onValueChange = { reqTelefono = it }, label = { Text("Nuevo teléfono (opcional)") })
                    OutlinedTextField(value = reqPlaca, onValueChange = { reqPlaca = it.uppercase() }, label = { Text("Nueva placa (opcional)") })
                    OutlinedTextField(value = reqModelo, onValueChange = { reqModelo = it }, label = { Text("Nuevo modelo de vehículo (opcional)") })
                    OutlinedTextField(value = reqMotivo, onValueChange = { reqMotivo = it }, label = { Text("Motivo del cambio (obligatorio)") })
                }
            },
            confirmButton = {
                Button(
                    enabled = reqMotivo.trim().length >= 3 && (reqNombre.isNotBlank() || reqTelefono.isNotBlank() || reqPlaca.isNotBlank() || reqModelo.isNotBlank()),
                    onClick = {
                        val cambios = mutableMapOf<String, Any>()
                        if (reqNombre.isNotBlank()) cambios["nombre"] = reqNombre.trim()
                        if (reqTelefono.isNotBlank()) cambios["telefono"] = reqTelefono.trim()
                        if (reqPlaca.isNotBlank()) cambios["placa"] = reqPlaca.trim().uppercase()
                        if (reqModelo.isNotBlank()) cambios["vehiculoModelo"] = reqModelo.trim()
                        onEnviarSolicitudCambio(cambios, reqMotivo.trim())
                        mostrarModalSolicitud = false
                    }
                ) { Text("Enviar Petición") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalSolicitud = false }) { Text("Cancelar") }
            }
        )
    }

    if (mostrarModalCancelar) {
        val sugerenciasConductor = listOf(
            "Camino bloqueado o derrumbe",
            "Falla mecánica en el vehículo",
            "No puedo llegar al punto de recogida"
        )
        AlertDialog(
            onDismissRequest = { mostrarModalCancelar = false },
            title = { Text("Cancelar viaje aceptado") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Ingresa una nota explicando por qué no puedes completar o llegar al destino. El pasajero la verá de inmediato.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    sugerenciasConductor.forEach { opc ->
                        OutlinedButton(
                            onClick = { motivoCancelacionInput = opc },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(opc) }
                    }
                    OutlinedTextField(
                        value = motivoCancelacionInput,
                        onValueChange = { if (it.length <= 280) motivoCancelacionInput = it },
                        label = { Text("Nota de cancelación (obligatoria)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = motivoCancelacionInput.trim().length >= 3,
                    onClick = {
                        PickupLocationService.stop(context)
                        onCancelarViaje(motivoCancelacionInput.trim())
                        mostrarModalCancelar = false
                    }
                ) { Text("Confirmar cancelación") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalCancelar = false }) { Text("Volver") }
            }
        )
    }
}

private fun abrirWaze(context: Context, lat: Double, lng: Double) {
    val uri = Uri.parse("https://waze.com/ul?ll=$lat,$lng&navigate=yes")
    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)
}
