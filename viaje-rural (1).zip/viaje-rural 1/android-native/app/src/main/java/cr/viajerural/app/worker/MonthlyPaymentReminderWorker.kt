package cr.viajerural.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import cr.viajerural.app.R
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlin.math.pow

/**
 * Requisito 2: Recordatorio Mensual Automático con WorkManager.
 * Envía una notificación local cada 30 días recordando el pago de ₡7,000 colones
 * (con ajuste del 10% anual cada 1 de enero).
 */
class MonthlyPaymentReminderWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val montoActual = calcularCuotaVigente()
        mostrarNotificacionRecordatorio(montoActual)
        return Result.success()
    }

    private fun calcularCuotaVigente(): Int {
        val anioActual = Calendar.getInstance().get(Calendar.YEAR)
        val anios = (anioActual - 2026).coerceAtLeast(0)
        return Math.round(7000.0 * 1.1.pow(anios)).toInt()
    }

    private fun mostrarNotificacionRecordatorio(monto: Int) {
        val manager =
            applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "viaje_rural_monthly_fee"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Recordatorio Mensualidad Conductor",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Aviso automático mensual de licencia de uso (₡7,000 base)."
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Recordatorio Mensual — Viaje Rural")
            .setContentText(
                "Recuerda abonar tu mensualidad de ₡$monto colones para mantener tu licencia activa."
            )
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "Tu licencia mensual de conexión tiene un costo de ₡$monto colones " +
                        "(base ₡7,000 con ajuste del 10% anual cada 1 de enero). Contacta al Administrador para renovar +1 mes."
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setAutoCancel(true)
            .build()

        manager.notify(NOTIFICATION_ID, notification)
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "viaje_rural_monthly_payment_reminder"
        private const val NOTIFICATION_ID = 7000

        /**
         * Programa el recordatorio periódico mensual al iniciar sesión como Conductor.
         */
        fun scheduleMonthlyReminder(context: Context) {
            val request = PeriodicWorkRequestBuilder<MonthlyPaymentReminderWorker>(
                30, TimeUnit.DAYS
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun cancelReminder(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }
    }
}
