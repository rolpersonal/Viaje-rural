package cr.viajerural.app.ui

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import cr.viajerural.app.viewmodel.AuthViewModel
import java.io.ByteArrayOutputStream

/**
 * Requisito 5 + Registro Completo: Pantallas funcionales de Login y Registro separadas
 * para Pasajeros y Conductores, con selector de tipo de vehículo (Moto, Pickup 4x4, etc.)
 * y carga comprimida de fotos del vehículo y documentos (Cédula, Licencia, Circulación/RTV).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AuthScreen(
    viewModel: AuthViewModel,
    tiposVehiculo: List<String> = listOf("Moto", "Sedán", "Pickup 4x4", "SUV 4x4", "Microbús Rural"),
    onAuthenticated: (uid: String, esConductor: Boolean) -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsState()

    var rolTab by remember { mutableIntStateOf(0) } // 0 = Pasajero, 1 = Conductor
    var esRegistro by remember { mutableStateOf(false) }

    var nombre by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }
    var cedula by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    // Campos completos de Conductor y Vehículo
    var vehiculoTipo by remember { mutableStateOf(tiposVehiculo.firstOrNull() ?: "Pickup 4x4") }
    var vehiculoModelo by remember { mutableStateOf("") }
    var vehiculoColor by remember { mutableStateOf("") }
    var vehiculoAnio by remember { mutableStateOf("2020") }
    var placa by remember { mutableStateOf("") }
    var capacidad by remember { mutableStateOf("4") }
    var tarifaBase by remember { mutableStateOf("1500") }
    var tarifaPorKm by remember { mutableStateOf("650") }

    // Fotos comprimidas (Vehículo + Documentos)
    var fotoVehiculo by remember { mutableStateOf("") }
    var fotoCedula by remember { mutableStateOf("") }
    var fotoLicencia by remember { mutableStateOf("") }
    var fotoCirculacion by remember { mutableStateOf("") }

    var aceptoTerminos by remember { mutableStateOf(false) }

    fun uriToCompressedDataUrl(uri: Uri): String {
        val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
        val scaled = Bitmap.createScaledBitmap(bitmap, 640, (bitmap.height * 640f / bitmap.width).toInt().coerceAtLeast(360), true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 58, out)
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    val pickVehiculo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { fotoVehiculo = uriToCompressedDataUrl(it) }
    }
    val pickCedula = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { fotoCedula = uriToCompressedDataUrl(it) }
    }
    val pickLicencia = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { fotoLicencia = uriToCompressedDataUrl(it) }
    }
    val pickCirculacion = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { fotoCirculacion = uriToCompressedDataUrl(it) }
    }

    LaunchedEffect(state.uidAutenticado) {
        state.uidAutenticado?.let { uid ->
            onAuthenticated(uid, rolTab == 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Viaje Rural — Acceso",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        TabRow(selectedTabIndex = rolTab) {
            Tab(
                selected = rolTab == 0,
                onClick = { rolTab = 0 },
                text = { Text("Pasajero") }
            )
            Tab(
                selected = rolTab == 1,
                onClick = { rolTab = 1 },
                text = { Text("Conductor") }
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !esRegistro,
                onClick = { esRegistro = false },
                label = { Text("Iniciar Sesión") }
            )
            FilterChip(
                selected = esRegistro,
                onClick = { esRegistro = true },
                label = { Text(if (rolTab == 0) "Registrar Pasajero" else "Registrar Conductor") }
            )
        }

        if (esRegistro) {
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre completo") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = telefono,
                onValueChange = { telefono = it },
                label = { Text("Teléfono (solo visible para Admin)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cedula,
                onValueChange = { cedula = it },
                label = { Text("Cédula / Identificación") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo electrónico") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña (mín. 6 caracteres)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        if (esRegistro && rolTab == 1) {
            Text("Tipo de Vehículo", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                tiposVehiculo.forEach { tipo ->
                    FilterChip(
                        selected = vehiculoTipo == tipo,
                        onClick = { vehiculoTipo = tipo },
                        label = { Text(tipo) }
                    )
                }
            }

            OutlinedTextField(
                value = vehiculoModelo,
                onValueChange = { vehiculoModelo = it },
                label = { Text("Marca y Modelo (Ej: Honda XR150 / Hilux)") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = vehiculoColor,
                    onValueChange = { vehiculoColor = it },
                    label = { Text("Color") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = vehiculoAnio,
                    onValueChange = { vehiculoAnio = it.filter(Char::isDigit).take(4) },
                    label = { Text("Año") },
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = placa,
                    onValueChange = { placa = it.uppercase() },
                    label = { Text("Placa") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = capacidad,
                    onValueChange = { capacidad = it.filter(Char::isDigit) },
                    label = { Text("Capacidad") },
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = tarifaBase,
                    onValueChange = { tarifaBase = it.filter(Char::isDigit) },
                    label = { Text("Tarifa base (₡)") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = tarifaPorKm,
                    onValueChange = { tarifaPorKm = it.filter(Char::isDigit) },
                    label = { Text("Precio por kilómetro adicional (₡)") },
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "Fotos del Vehículo y Documentos",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickVehiculo.launch("image/*") }, modifier = Modifier.weight(1f)) {
                    Text(if (fotoVehiculo.isNotBlank()) "Vehículo ✓" else "Foto Vehículo")
                }
                OutlinedButton(onClick = { pickCedula.launch("image/*") }, modifier = Modifier.weight(1f)) {
                    Text(if (fotoCedula.isNotBlank()) "Cédula ✓" else "Foto Cédula")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickLicencia.launch("image/*") }, modifier = Modifier.weight(1f)) {
                    Text(if (fotoLicencia.isNotBlank()) "Licencia ✓" else "Foto Licencia")
                }
                OutlinedButton(onClick = { pickCirculacion.launch("image/*") }, modifier = Modifier.weight(1f)) {
                    Text(if (fotoCirculacion.isNotBlank()) "RTV/March. ✓" else "Circulación/RTV")
                }
            }
        }

        if (esRegistro) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = aceptoTerminos, onCheckedChange = { aceptoTerminos = it })
                Text(
                    text = "Acepto Términos (solo conexión efectivo; cuota ₡7,000/mes + 10% cada 1 de enero).",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        state.error?.let {
            Text(text = it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Button(
            onClick = {
                if (!esRegistro) {
                    viewModel.login(email, password, rolTab == 1, context)
                } else if (rolTab == 0) {
                    viewModel.registrarPasajero(nombre, email, telefono, cedula, password)
                } else {
                    viewModel.registrarConductor(
                        context, nombre, email, telefono, cedula, password,
                        vehiculoTipo, vehiculoModelo, vehiculoColor, vehiculoAnio, placa,
                        capacidad.toIntOrNull() ?: 4,
                        tarifaBase.toDoubleOrNull() ?: 1500.0,
                        tarifaPorKm.toDoubleOrNull() ?: 650.0,
                        fotoVehiculo, fotoCedula, fotoLicencia, fotoCirculacion
                    )
                }
            },
            enabled = !state.cargando && (!esRegistro || aceptoTerminos),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text(
                when {
                    state.cargando -> "Conectando..."
                    !esRegistro -> "Iniciar Sesión (${if (rolTab == 0) "Pasajero" else "Conductor"})"
                    rolTab == 0 -> "Crear cuenta Pasajero"
                    else -> "Enviar registro Conductor"
                }
            )
        }
    }
}
