import React, { useCallback, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import {
  Bell,
  BookOpen,
  FileCode2,
  FileText,
  Headphones,
  LogOut,
  Menu,
  MessageSquare,
  ShieldCheck,
  X,
  XCircle,
} from 'lucide-react';
import { AdminView } from './components/AdminView';
import { AndroidCodeViewer } from './components/AndroidCodeViewer';
import { AuthScreens } from './components/AuthScreens';
import { ConductorView } from './components/ConductorView';
import { PasajeroView } from './components/PasajeroView';
import {
  ComoSeUtilizaModal,
  NotificacionesDrawerModal,
  SoporteWhatsappSinpeModal,
  TerminosCondicionesModal,
} from './components/TermsAndGuideModals';
import { auth, googleProvider } from './lib/firebase';
import {
  ADMIN_EMAIL,
  calcularMensualidadActualConAjusteAnual,
  DEFAULT_CONFIGURACION_GENERAL,
  formatearColones,
  HERO_ROAD_IMAGE,
  playChatAlertSound,
} from './lib/ruralUtils';
import {
  ensureUserProfile,
  seedConfiguracionGeneralIfNeeded,
  seedInitialRuralFleetIfNeeded,
  subscribeConductoresActivos,
  subscribeConfiguracionGeneral,
} from './services/viajeService';
import { Conductor, ConfiguracionGeneral, NotificacionApp } from './types/viajeRural';

type TabVista = 'pasajero' | 'conductor' | 'admin' | 'android';

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error.message };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="mx-auto my-12 max-w-xl rounded-2xl border border-[#DC2626]/30 bg-white p-6">
          <h2 className="text-lg font-bold text-[#14231A]">Error de comunicación con Firebase</h2>
          <p className="mt-2 break-words font-mono text-xs text-[#DC2626]">
            {this.state.message}
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-4 min-h-[44px] rounded-xl bg-[#14231A] px-5 text-sm font-semibold text-white"
          >
            Reintentar
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [tab, setTab] = useState<TabVista>('pasajero');
  const [drawerAbierto, setDrawerAbierto] = useState(false);
  const [guiaAbierta, setGuiaAbierta] = useState(false);
  const [terminosAbiertos, setTerminosAbiertos] = useState(false);
  const [terminosModo, setTerminosModo] = useState<'pasajero' | 'conductor'>('pasajero');
  const [soporteAbierto, setSoporteAbierto] = useState(false);
  const [notifAbiertas, setNotifAbiertas] = useState(false);
  const [aceptoTerminosLogin, setAceptoTerminosLogin] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const [conductoresActivos, setConductoresActivos] = useState<Conductor[]>([]);
  const [notificaciones, setNotificaciones] = useState<NotificacionApp[]>([]);
  const [configuracion, setConfiguracion] = useState<ConfiguracionGeneral>({
    ...DEFAULT_CONFIGURACION_GENERAL,
  });

  // Notificación flotante Heads-up para chat entrante y cancelación/alertas
  const [headsUpNotif, setHeadsUpNotif] = useState<{
    titulo: string;
    texto: string;
    variante: 'chat' | 'alerta';
  } | null>(null);

  const isAdmin = Boolean(user?.email === ADMIN_EMAIL && user?.emailVerified);

  const pushNotificacion = useCallback(
    (
      titulo: string,
      cuerpo: string,
      tipo: 'oferta' | 'aceptado' | 'proximidad' | 'mensualidad' | 'alerta'
    ) => {
      const hora = new Date().toLocaleTimeString('es-CR', {
        hour: '2-digit',
        minute: '2-digit',
      });
      setNotificaciones((prev) => [
        {
          id: `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          titulo,
          cuerpo,
          tipo,
          hora,
          leida: false,
        },
        ...prev.slice(0, 19),
      ]);
      if (tipo === 'alerta') {
        playChatAlertSound();
        setHeadsUpNotif({
          titulo,
          texto: cuerpo,
          variante: 'alerta',
        });
      }
    },
    []
  );

  const handleIncomingChatHeadsUp = useCallback((autor: string, texto: string) => {
    setHeadsUpNotif({
      titulo: `Nuevo mensaje de ${autor}`,
      texto,
      variante: 'chat',
    });
  }, []);

  useEffect(() => {
    if (!headsUpNotif) return;
    const ms = headsUpNotif.variante === 'alerta' ? 9000 : 5500;
    const t = setTimeout(() => setHeadsUpNotif(null), ms);
    return () => clearTimeout(t);
  }, [headsUpNotif]);

  useEffect(() => {
    const unsubConfig = subscribeConfiguracionGeneral(setConfiguracion);
    return () => unsubConfig();
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
      if (firebaseUser) {
        await ensureUserProfile(
          firebaseUser.uid,
          firebaseUser.displayName || 'Usuario Rural',
          firebaseUser.email,
          firebaseUser.photoURL || undefined
        );
        if (firebaseUser.email === ADMIN_EMAIL && firebaseUser.emailVerified) {
          await seedInitialRuralFleetIfNeeded();
          await seedConfiguracionGeneralIfNeeded();
        }
      }
    });
    return () => unsub();
  }, []);

  // Suscripción bajo demanda: solo escucha conductores activos cuando la vista actual es Pasajero
  useEffect(() => {
    if (!authReady || !user || tab !== 'pasajero') return;
    const unsubActivos = subscribeConductoresActivos(setConductoresActivos);
    return () => {
      unsubActivos();
    };
  }, [authReady, user, tab]);

  const handleLoginGoogle = async () => {
    setLoginError(null);
    if (!aceptoTerminosLogin) {
      setLoginError('Debes aceptar los Términos y Condiciones obligatorios para ingresar.');
      return;
    }
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setLoginError(
        err instanceof Error ? err.message : 'No se pudo completar el inicio de sesión.'
      );
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setDrawerAbierto(false);
  };

  const { montoActual, montoProximoEnero } = calcularMensualidadActualConAjusteAnual();

  return (
    <AppErrorBoundary>
      <div className="min-h-screen bg-[#F7F8F6] text-[#14231A]">
        {/* Notificación flotante Heads-up (Chat y Cancelación/Alertas) */}
        {headsUpNotif && (
          <div
            role="status"
            aria-live="assertive"
            className={`fixed right-4 top-20 z-50 flex w-[calc(100%-2rem)] max-w-sm items-start gap-3 rounded-2xl border-2 p-4 text-white shadow-2xl ${
              headsUpNotif.variante === 'alerta'
                ? 'border-[#F87171] bg-[#7F1D1D]'
                : 'border-[#15803D] bg-[#14231A]'
            }`}
          >
            {headsUpNotif.variante === 'alerta' ? (
              <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-[#FCA5A5]" />
            ) : (
              <MessageSquare className="mt-0.5 h-5 w-5 shrink-0 text-[#4ADE80]" />
            )}
            <div className="min-w-0 flex-1">
              <div
                className={`text-xs font-bold ${
                  headsUpNotif.variante === 'alerta' ? 'text-[#FECACA]' : 'text-[#4ADE80]'
                }`}
              >
                {headsUpNotif.titulo}
              </div>
              <p className="mt-0.5 line-clamp-3 text-xs text-white/95">{headsUpNotif.texto}</p>
            </div>
            <button
              type="button"
              onClick={() => setHeadsUpNotif(null)}
              className="flex min-h-[36px] min-w-[36px] items-center justify-center rounded-lg text-white/80 hover:bg-white/15 hover:text-white"
              aria-label="Cerrar notificación flotante"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* TOP BAR CONTRACT: 3 zonas separadas por gap-8 */}
        <header className="sticky top-0 z-30 border-b border-[#E2E6DF] bg-white/95 backdrop-blur-md">
          <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6">
            {/* Zona 1: Menú hamburguesa + Wordmark de una sola línea */}
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setDrawerAbierto(true)}
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF] text-[#14231A] hover:bg-[#F7F8F6]"
                aria-label="Abrir menú lateral"
              >
                <Menu className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() => setTab('pasajero')}
                className="font-display text-xl font-bold tracking-tight text-[#14231A] whitespace-nowrap shrink-0"
              >
                Viaje Rural
              </button>
            </div>

            {/* Zona 2: Enlaces de navegación de una sola línea */}
            {user && (
              <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#525B50]">
                {(
                  [
                    { id: 'pasajero', label: 'Pasajero' },
                    { id: 'conductor', label: 'Conductor' },
                    { id: 'admin', label: 'Administrador' },
                    { id: 'android', label: 'Código Android' },
                  ] as const
                ).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setTab(item.id)}
                    className={`whitespace-nowrap shrink-0 border-b-2 py-5 transition-colors ${
                      tab === item.id
                        ? 'border-[#15803D] font-semibold text-[#14231A]'
                        : 'border-transparent hover:text-[#14231A]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </nav>
            )}

            {/* Zona 3: 1 acción principal */}
            <div className="flex items-center gap-3 shrink-0">
              {user ? (
                <button
                  type="button"
                  onClick={handleLogout}
                  className="inline-flex min-h-[40px] items-center gap-2 whitespace-nowrap shrink-0 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 py-2 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]/60"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  Salir
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setSoporteAbierto(true)}
                  className="inline-flex min-h-[40px] items-center gap-1.5 whitespace-nowrap shrink-0 rounded-xl bg-[#15803D] px-4 py-2 text-xs font-semibold text-white hover:bg-[#166534]"
                >
                  <Headphones className="h-3.5 w-3.5" />
                  Soporte
                </button>
              )}
            </div>
          </div>
        </header>

        {/* Menú Hamburguesa Lateral (Drawer) */}
        {drawerAbierto && (
          <div className="fixed inset-0 z-50 flex">
            <div
              className="fixed inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setDrawerAbierto(false)}
            />
            <aside className="relative z-10 flex h-full w-80 max-w-[85vw] flex-col justify-between bg-white p-5 shadow-2xl">
              <div>
                <div className="flex items-center justify-between border-b border-[#E2E6DF] pb-4">
                  <span className="font-display text-lg font-bold text-[#14231A]">
                    Menú — Viaje Rural
                  </span>
                  <button
                    type="button"
                    onClick={() => setDrawerAbierto(false)}
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF]"
                    aria-label="Cerrar menú"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                {user && (
                  <div className="mt-4 border-b border-[#E2E6DF] pb-4">
                    <div className="text-sm font-bold text-[#14231A]">
                      {user.displayName || 'Usuario Rural'}
                    </div>
                    <div className="text-xs text-[#525B50]">{user.email}</div>
                  </div>
                )}

                <div className="mt-4 space-y-1.5">
                  {user && (
                    <div className="mb-3 space-y-1 md:hidden">
                      {(
                        [
                          { id: 'pasajero', label: 'Modo Pasajero' },
                          { id: 'conductor', label: 'Modo Conductor' },
                          { id: 'admin', label: 'Panel Administrador' },
                          { id: 'android', label: 'Código Android Nativo' },
                        ] as const
                      ).map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => {
                            setTab(item.id);
                            setDrawerAbierto(false);
                          }}
                          className={`flex min-h-[44px] w-full items-center rounded-xl px-3.5 text-left text-sm font-semibold ${
                            tab === item.id
                              ? 'bg-[#15803D] text-white'
                              : 'text-[#14231A] hover:bg-[#F7F8F6]'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setSoporteAbierto(true);
                      setDrawerAbierto(false);
                    }}
                    className="flex min-h-[46px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-[#14231A] hover:bg-[#F7F8F6]"
                  >
                    <Headphones className="h-4 w-4 text-[#15803D]" />
                    Soporte WhatsApp y SINPE ({configuracion.whatsappSoporte})
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setGuiaAbierta(true);
                      setDrawerAbierto(false);
                    }}
                    className="flex min-h-[46px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-[#14231A] hover:bg-[#F7F8F6]"
                  >
                    <BookOpen className="h-4 w-4 text-[#15803D]" />
                    Cómo se utiliza la app
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTerminosModo(tab === 'conductor' ? 'conductor' : 'pasajero');
                      setTerminosAbiertos(true);
                      setDrawerAbierto(false);
                    }}
                    className="flex min-h-[46px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-[#14231A] hover:bg-[#F7F8F6]"
                  >
                    <FileText className="h-4 w-4 text-[#15803D]" />
                    Términos y Condiciones
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setNotifAbiertas(true);
                      setDrawerAbierto(false);
                    }}
                    className="flex min-h-[46px] w-full items-center justify-between rounded-xl px-3.5 text-left text-sm font-medium text-[#14231A] hover:bg-[#F7F8F6]"
                  >
                    <span className="flex items-center gap-3">
                      <Bell className="h-4 w-4 text-[#15803D]" />
                      Notificaciones FCM
                    </span>
                    {notificaciones.length > 0 && (
                      <span className="font-mono text-xs font-bold text-[#15803D]">
                        {notificaciones.length}
                      </span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTab('android');
                      setDrawerAbierto(false);
                    }}
                    className="flex min-h-[46px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-[#14231A] hover:bg-[#F7F8F6]"
                  >
                    <FileCode2 className="h-4 w-4 text-[#15803D]" />
                    Código Kotlin + Gradle
                  </button>
                </div>
              </div>

              <div className="border-t border-[#E2E6DF] pt-3 text-xs text-[#525B50]">
                SINPE: <strong className="font-mono">{configuracion.sinpeNumero}</strong> · Licencia:{' '}
                {formatearColones(montoActual)}/mes (1 de enero: {formatearColones(montoProximoEnero)}).
              </div>
            </aside>
          </div>
        )}

        {/* CONTENIDO PRINCIPAL */}
        <main
          className={`mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:py-8 ${
            user && (tab === 'pasajero' || tab === 'conductor') ? 'pb-24' : ''
          }`}
        >
          {!authReady ? (
            <div className="py-20 text-center text-sm text-[#525B50]">
              Conectando con Firebase...
            </div>
          ) : !user && tab !== 'android' ? (
            /* PANTALLA DE BIENVENIDA + LOGIN / REGISTRO SEPARADOS */
            <div className="space-y-8">
              <div className="grid grid-cols-1 items-stretch overflow-hidden rounded-3xl border border-[#E2E6DF] bg-white lg:grid-cols-12">
                <div className="flex flex-col justify-between p-6 sm:p-8 lg:col-span-7">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider text-[#15803D]">
                      Movilidad Comunitaria · Ahorro de Datos y Batería
                    </div>
                    <h1 className="mt-2 text-balance text-2xl font-bold leading-tight text-[#14231A] sm:text-3xl">
                      Transporte rural confiable con GPS bajo demanda y cobro directo en efectivo
                    </h1>
                    <p className="mt-2.5 max-w-xl text-sm leading-relaxed text-[#525B50]">
                      Ingresa o crea tu cuenta como Pasajero o Conductor. El mapa solo carga al presionarlo y cada
                      recogida está protegida con PIN de 3 dígitos.
                    </p>

                    <div className="mt-5">
                      <AuthScreens
                        aceptoTerminos={aceptoTerminosLogin}
                        onChangeAceptoTerminos={setAceptoTerminosLogin}
                        onAbrirTerminos={(modo) => {
                          setTerminosModo(modo || 'pasajero');
                          setTerminosAbiertos(true);
                        }}
                        onLoginGoogle={handleLoginGoogle}
                        onSuccessAuthRole={(rol) => setTab(rol)}
                        tiposVehiculo={configuracion.tiposVehiculo}
                        terminosPasajero={configuracion.terminosCondicionesPasajero}
                      />
                    </div>

                    {loginError && (
                      <p className="mt-3 text-xs font-semibold text-[#DC2626]">{loginError}</p>
                    )}
                  </div>

                  <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-[#E2E6DF] pt-4 text-xs text-[#525B50]">
                    <span className="inline-flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4 text-[#15803D]" />
                      Auth, Firestore en tiempo real y reglas activas
                    </span>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setSoporteAbierto(true)}
                        className="font-semibold text-[#15803D] hover:underline"
                      >
                        Soporte WhatsApp ({configuracion.whatsappSoporte})
                      </button>
                      <button
                        type="button"
                        onClick={() => setTab('android')}
                        className="font-semibold text-[#14231A] hover:underline"
                      >
                        Ver Gradle + Kotlin
                      </button>
                    </div>
                  </div>
                </div>

                <div className="relative min-h-[260px] lg:col-span-5">
                  <img
                    src={HERO_ROAD_IMAGE}
                    alt="Camino rural montañoso con vehículo 4x4"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>

              {/* Tira de 4 pilares técnicos */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
                  <div className="font-mono text-xs font-semibold text-[#15803D]">01. MAPA BAJO DEMANDA</div>
                  <div className="mt-1 text-sm font-bold text-[#14231A]">0 KB por defecto</div>
                  <p className="mt-1 text-xs text-[#525B50]">
                    Solo se inicializa en ventana modal al pulsar Ver Mapa y se destruye al cerrar.
                  </p>
                </div>
                <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
                  <div className="font-mono text-xs font-semibold text-[#15803D]">02. PING DE 1 SEGUNDO</div>
                  <div className="mt-1 text-sm font-bold text-[#14231A]">GPS apagado en espera</div>
                  <p className="mt-1 text-xs text-[#525B50]">
                    Al solicitar viaje, los conductores activos envían un pulso de 1s y apagan su GPS.
                  </p>
                </div>
                <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
                  <div className="font-mono text-xs font-semibold text-[#15803D]">03. RECOGIDA 90S + PIN</div>
                  <div className="mt-1 text-sm font-bold text-[#14231A]">PIN de 3 dígitos fijo</div>
                  <p className="mt-1 text-xs text-[#525B50]">
                    Envío cada 90s hasta que el conductor ingresa el PIN del pasajero y detiene el GPS.
                  </p>
                </div>
                <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
                  <div className="font-mono text-xs font-semibold text-[#15803D]">04. COLA ATÓMICA 15S</div>
                  <div className="mt-1 text-sm font-bold text-[#14231A]">Cero doble asignación</div>
                  <p className="mt-1 text-xs text-[#525B50]">
                    Ofertas secuenciales por cercanía protegidas por transacciones atómicas en Firestore.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* ESPACIO DE TRABAJO MULTI-ROL AUTENTICADO */
            <div className="space-y-6">
              {/* Sub-barra de cambio de rol visible en móvil y escritorio */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E2E6DF] pb-4">
                <div className="flex flex-wrap items-center gap-1.5 rounded-xl bg-[#E8ECE5] p-1">
                  {(
                    [
                      { id: 'pasajero', label: 'Pasajero' },
                      { id: 'conductor', label: 'Conductor' },
                      { id: 'admin', label: 'Administrador' },
                      { id: 'android', label: 'Código Android' },
                    ] as const
                  ).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setTab(item.id)}
                      className={`min-h-[38px] whitespace-nowrap rounded-lg px-3.5 text-xs font-semibold transition-colors ${
                        tab === item.id
                          ? 'bg-white text-[#14231A] shadow-sm'
                          : 'text-[#525B50] hover:text-[#14231A]'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>

                <div className="flex flex-wrap items-center gap-2.5 text-xs text-[#525B50]">
                  <button
                    type="button"
                    onClick={() => setSoporteAbierto(true)}
                    className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[#15803D]/30 bg-[#15803D]/10 px-3 font-semibold text-[#15803D] hover:bg-[#15803D]/20"
                  >
                    <Headphones className="h-3.5 w-3.5" />
                    Soporte ({configuracion.whatsappSoporte})
                  </button>
                  <button
                    type="button"
                    onClick={() => setNotifAbiertas(true)}
                    className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-white px-3 font-medium text-[#14231A] hover:bg-[#F7F8F6]"
                  >
                    <Bell className="h-3.5 w-3.5 text-[#15803D]" />
                    Notificaciones ({notificaciones.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setGuiaAbierta(true)}
                    className="hidden sm:inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-white px-3 font-medium text-[#14231A] hover:bg-[#F7F8F6]"
                  >
                    <BookOpen className="h-3.5 w-3.5 text-[#15803D]" />
                    Cómo se utiliza
                  </button>
                </div>
              </div>

              {tab === 'pasajero' && user && (
                <PasajeroView
                  userUid={user.uid}
                  userName={user.displayName || 'Pasajero Rural'}
                  userPhoto={user.photoURL || undefined}
                  conductoresActivos={conductoresActivos}
                  tiposVehiculo={configuracion.tiposVehiculo}
                  linkDescarga={configuracion.linkDescarga}
                  terminosCondicionesPasajero={configuracion.terminosCondicionesPasajero}
                  onAbrirSoporte={() => setSoporteAbierto(true)}
                  onAbrirTerminos={() => {
                    setTerminosModo('pasajero');
                    setTerminosAbiertos(true);
                  }}
                  onLogout={handleLogout}
                  onPushNotificacion={pushNotificacion}
                  onIncomingChatHeadsUp={handleIncomingChatHeadsUp}
                />
              )}

              {tab === 'conductor' && user && (
                <ConductorView
                  userUid={user.uid}
                  userName={user.displayName || 'Conductor Rural'}
                  userEmail={user.email || ''}
                  isAdmin={isAdmin}
                  configuracion={configuracion}
                  onAbrirTerminos={() => {
                    setTerminosModo('conductor');
                    setTerminosAbiertos(true);
                  }}
                  onAbrirSoporte={() => setSoporteAbierto(true)}
                  onLogout={handleLogout}
                  onPushNotificacion={pushNotificacion}
                  onIncomingChatHeadsUp={handleIncomingChatHeadsUp}
                />
              )}

              {tab === 'admin' && (
                <AdminView
                  isAdmin={isAdmin}
                  configuracion={configuracion}
                  onPushNotificacion={pushNotificacion}
                />
              )}

              {tab === 'android' && <AndroidCodeViewer />}
            </div>
          )}
        </main>

        {/* Modales globales */}
        <ComoSeUtilizaModal isOpen={guiaAbierta} onClose={() => setGuiaAbierta(false)} />
        <TerminosCondicionesModal
          isOpen={terminosAbiertos}
          onClose={() => setTerminosAbiertos(false)}
          configuracion={configuracion}
          modoInicial={terminosModo}
        />
        <SoporteWhatsappSinpeModal
          isOpen={soporteAbierto}
          onClose={() => setSoporteAbierto(false)}
          configuracion={configuracion}
        />
        <NotificacionesDrawerModal
          isOpen={notifAbiertas}
          onClose={() => setNotifAbiertas(false)}
          notificaciones={notificaciones}
        />
      </div>
    </AppErrorBoundary>
  );
}
