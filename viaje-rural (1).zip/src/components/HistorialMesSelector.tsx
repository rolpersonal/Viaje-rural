import React, { useMemo } from 'react';
import { Calendar, ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';
import { Viaje } from '../types/viajeRural';
import {
  construirOpcionesMesesCostaRica,
  formatMesKeyLabel,
  formatearColones,
  getMesAnioCostaRica,
  stepMesAnioKey,
} from '../lib/ruralUtils';

interface HistorialMesSelectorProps {
  viajes: Viaje[];
  viajesFiltrados: Viaje[];
  mesSeleccionado: string;
  onChangeMes: (nuevoMesKey: string) => void;
  etiquetaTotal?: string;
}

export const HistorialMesSelector: React.FC<HistorialMesSelectorProps> = ({
  viajes,
  viajesFiltrados,
  mesSeleccionado,
  onChangeMes,
  etiquetaTotal = 'Total del mes',
}) => {
  const mesActual = useMemo(() => getMesAnioCostaRica(), []);
  const opcionesMeses = useMemo(
    () => construirOpcionesMesesCostaRica(viajes, mesSeleccionado),
    [viajes, mesSeleccionado]
  );

  const resumenMes = useMemo(() => {
    let finalizados = 0;
    let totalColones = 0;
    for (const v of viajesFiltrados) {
      if (v.estado === 'finalizado') {
        finalizados += 1;
        totalColones += Math.max(0, Number(v.montoAproximado) || 0);
      }
    }
    return {
      cantidad: viajesFiltrados.length,
      finalizados,
      totalColones,
    };
  }, [viajesFiltrados]);

  const esMesActual = mesSeleccionado === mesActual.key;

  return (
    <div className="mt-4 space-y-3 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs font-bold text-[#14231A]">
          <Calendar className="h-4 w-4 text-[#15803D]" />
          <span>Mes consultado ({formatMesKeyLabel(mesSeleccionado)})</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => onChangeMes(stepMesAnioKey(mesSeleccionado, -1))}
            className="flex min-h-[36px] min-w-[36px] items-center justify-center rounded-lg border border-[#E2E6DF] bg-white text-[#14231A] hover:bg-[#E2E6DF]/50"
            aria-label="Mes anterior"
            title="Mes anterior"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>

          <select
            aria-label="Seleccionar mes del historial"
            value={mesSeleccionado}
            onChange={(e) => onChangeMes(e.target.value)}
            className="min-h-[36px] rounded-lg border border-[#E2E6DF] bg-white px-3 text-xs font-semibold text-[#14231A] focus:border-[#15803D] focus:outline-none"
          >
            {opcionesMeses.map((op) => (
              <option key={op.key} value={op.key}>
                {op.label}
                {op.key === mesActual.key ? ' (Actual)' : ''}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => onChangeMes(stepMesAnioKey(mesSeleccionado, 1))}
            className="flex min-h-[36px] min-w-[36px] items-center justify-center rounded-lg border border-[#E2E6DF] bg-white text-[#14231A] hover:bg-[#E2E6DF]/50"
            aria-label="Mes siguiente"
            title="Mes siguiente"
          >
            <ChevronRight className="h-4 w-4" />
          </button>

          {!esMesActual && (
            <button
              type="button"
              onClick={() => onChangeMes(mesActual.key)}
              className="inline-flex min-h-[36px] items-center gap-1 rounded-lg border border-[#15803D]/30 bg-[#F0FDF4] px-2.5 text-xs font-semibold text-[#15803D] hover:bg-[#15803D]/15"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Mes actual
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-lg border border-[#E2E6DF] bg-white px-3 py-2">
          <div className="text-[11px] font-medium text-[#525B50]">Viajes del mes</div>
          <div className="font-mono text-base font-bold tabular-nums text-[#14231A]">
            {resumenMes.cantidad}
          </div>
        </div>
        <div className="rounded-lg border border-[#E2E6DF] bg-white px-3 py-2">
          <div className="text-[11px] font-medium text-[#525B50]">Completados</div>
          <div className="font-mono text-base font-bold tabular-nums text-[#14231A]">
            {resumenMes.finalizados}
          </div>
        </div>
        <div className="rounded-lg border border-[#E2E6DF] bg-white px-3 py-2">
          <div className="text-[11px] font-medium text-[#525B50]">{etiquetaTotal}</div>
          <div className="font-mono text-base font-bold tabular-nums text-[#15803D]">
            {formatearColones(resumenMes.totalColones)}
          </div>
        </div>
      </div>
    </div>
  );
};
