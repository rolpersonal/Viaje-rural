import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  BatteryCharging,
  Camera,
  Clock,
  DollarSign,
  ExternalLink,
  FileCheck2,
  FileText,
  Headphones,
  History,
  Home,
  KeyRound,
  Lock,
  LogOut,
  MapPin,
  MessageSquare,
  Navigation,
  Power,
  Radio,
  RefreshCw,
  Send,
  Share2,
  ShieldAlert,
  Star,
  User,
  Users,
  XCircle,
} from 'lucide-react';
import {
  aceptarViajeAtomicamente,
  actualizarTarifasConductor,
  avanzarColaOfertaSecuencial,
  cambiarEstadoOperativoConductor,
  cancelarViajeConMotivo,
  crearSolicitudCambioDatos,
  enviarCalificacion,
  enviarPosicion90sRecogida,
  fetchConductoresAdminPaginado,
  fetchHistorialConductor,
  fetchMiPII,
  fetchMisSolicitudesCambio,
  fetchViajeById,
  finalizarViaje,
  registrarNuevoConductor,
  subscribeConductorById,
  subscribeOfertasParaConductor,
  subscribeViajeActivoConductor,
  verificarPinYComenzarViaje,
} from '../services/viajeService';
import {
  buildWazeUrl,
  buildWhatsAppShareAppUrl,
  buildWhatsAppSupportUrl,
  calcularDiasLicenciaRestantes,
  calcularDistanciaKm,
  calcularMensualidadActualConAjusteAnual,
  calcularPromediosTarifas,
  compartirAppEnDispositivo,
  compressImageToDataUrl,
  DEFAULT_CONFIGURACION_GENERAL,
  DEFAULT_TIPOS_VEHICULO,
  esTarifaAbusiva,
  formatearColones,
  PASSENGER_AVATAR,
} from '../lib/ruralUtils';
import {
  CambiosSolicitados,
  Conductor,
  ConfiguracionGeneral,
  SolicitudCambioDatos,
  TipoVehiculo,
  UsuarioPII,
  Viaje,
} from '../types/viajeRural';
import { OnDemandMapModal } from './OnDemandMapModal';
import { ViajeChatModal } from './ViajeChatModal';
import { CancelarViajeModal } from './CancelarViajeModal';

type ConductorTab = 'inicio' | 'finanzas' | 'historial' | 'perfil';

interface ConductorViewProps {
  userUid: string;
  userName: string;
  userEmail: string;
  isAdmin: boolean;
  configuracion?: ConfiguracionGeneral;
  onAbrirTerminos: () => void;
  onAbrirSoporte?: () => void;
  onLogout?: () => void;
  onPushNotificacion: (
    titulo: string,
    cuerpo: string,
    tipo: 'oferta' | 'aceptado' | 'proximidad' | 'mensualidad' | 'alerta'
  ) => void;
  onIncomingChatHeadsUp?: (autor: string, texto: string) => void;
}

export const ConductorView: React.FC<ConductorViewProps> = ({
  userUid,
  userName,
  userEmail,
  isAdmin,
  configuracion,
  onAbrirTerminos,
  onAbrirSoporte,
  onLogout,
  onPushNotificacion,
  onIncomingChatHeadsUp,
}) => {
  // BottomNavigation modular de 4 pestañas: Inicio, Finanzas, Historial (lazy), Perfil
  const [activeTab, setActiveTab] = useState<ConductorTab>('inicio');

  const [selectedConductorId, setSelectedConductorId] = useState<string>(userUid);
  const [conductor, setConductor] = useState<Conductor | null>(null);
  const [flotaAdminLazy, setFlotaAdminLazy] = useState<Conductor[]>([]);
  const [flotaAdminCargada, setFlotaAdminCargada] = useState(false);

  const [viajeActivo, setViajeActivo] = useState<Viaje | null>(null);
  const [ofertasCola, setOfertasCola] = useState<Viaje[]>([]);
  const [segundosOferta, setSegundosOferta] = useState<number>(15);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [accionMsg, setAccionMsg] = useState<string | null>(null);
  const [shareToast, setShareToast] = useState<string | null>(null);
  const [ultimoViajeFinalizado, setUltimoViajeFinalizado] = useState<Viaje | null>(null);
  const [estrellasPasajero, setEstrellasPasajero] = useState(5);
  const [calificacionEnviada, setCalificacionEnviada] = useState(false);

  // Modales bajo demanda (Mapa, Chat y Cancelación NO se cargan siempre)
  const [mapaAbierto, setMapaAbierto] = useState(false);
  const [chatAbierto, setChatAbierto] = useState(false);
  const [cancelarModalAbierto, setCancelarModalAbierto] = useState(false);
  const [viajeActivoInicialCargado, setViajeActivoInicialCargado] = useState(false);
  const lastViajeActivoIdRef = React.useRef<string | null>(null);
  const accionPropiaTerminoRef = React.useRef<boolean>(false);

  // Historial bajo demanda (limit(20) solo al tocar la pestaña 'Historial')
  const [historial, setHistorial] = useState<Viaje[]>([]);
  const [historialCargado, setHistorialCargado] = useState(false);
  const [cargandoHistorial, setCargandoHistorial] = useState(false);

  // Configuración de tarifas
  const [tarifaBaseEdit, setTarifaBaseEdit] = useState<number>(1500);
  const [tarifaKmEdit, setTarifaKmEdit] = useState<number>(650);
  const [guardandoTarifas, setGuardandoTarifas] = useState(false);

  // Datos protegidos y peticiones de cambio al Administrador
  const [miPii, setMiPii] = useState<UsuarioPII | null>(null);
  const [misSolicitudes, setMisSolicitudes] = useState<SolicitudCambioDatos[]>([]);
  const [solicitudesCargadas, setSolicitudesCargadas] = useState(false);
  const [mostrarFormCambio, setMostrarFormCambio] = useState(false);
  const [reqNombre, setReqNombre] = useState('');
  const [reqTelefono, setReqTelefono] = useState('');
  const [reqCedula, setReqCedula] = useState('');
  const [reqTipoVehiculo, setReqTipoVehiculo] = useState<TipoVehiculo>('Pickup 4x4');
  const [reqModelo, setReqModelo] = useState('');
  const [reqColor, setReqColor] = useState('');
  const [reqAnio, setReqAnio] = useState('');
  const [reqPlaca, setReqPlaca] = useState('');
  const [reqCapacidad, setReqCapacidad] = useState(5);
  const [reqMotivo, setReqMotivo] = useState('');
  const [enviandoSolicitud, setEnviandoSolicitud] = useState(false);
  const [solicitudFeedback, setSolicitudFeedback] = useState<string | null>(null);

  // Registro de nuevo conductor
  const [regNombre, setRegNombre] = useState(userName || '');
  const [regTelefono, setRegTelefono] = useState('+506 8800-0000');
  const [regCedula, setRegCedula] = useState('1-1111-1111');
  const [regTipo, setRegTipo] = useState<TipoVehiculo>('Pickup 4x4');
  const [regModelo, setRegModelo] = useState('Toyota Hilux 4x4');
  const [regColor, setRegColor] = useState('Blanco');
  const [regAnio, setRegAnio] = useState('2022');
  const [regPlaca, setRegPlaca] = useState('CL-552109');
  const [regCapacidad, setRegCapacidad] = useState(5);
  const [regTarifaBase, setRegTarifaBase] = useState(1500);
  const [regTarifaKm, setRegTarifaKm] = useState(650);
  const [regFotoVehiculo, setRegFotoVehiculo] = useState('');
  const [regFotoCedula, setRegFotoCedula] = useState('');
  const [regFotoLicencia, setRegFotoLicencia] = useState('');
  const [regFotoCirculacion, setRegFotoCirculacion] = useState('');
  const [regError, setRegError] = useState<string | null>(null);
  const [regAceptoTerminos, setRegAceptoTerminos] = useState(false);
  const [registrando, setRegistrando] = useState(false);

  // Suscribirse al conductor seleccionado, su viaje activo (Recuperación de estado) y ofertas
  useEffect(() => {
    if (!selectedConductorId) return;
    setHistorialCargado(false);
    setHistorial([]);
    const unsubCond = subscribeConductorById(selectedConductorId, (c) => {
      setConductor(c);
      if (c) {
        setTarifaBaseEdit(c.tarifaBase);
        setTarifaKmEdit(c.tarifaPorKm);
      }
    });
    const storageKey = `viaje_rural_conductor_activo_${selectedConductorId}`;
    const unsubViaje = subscribeViajeActivoConductor(selectedConductorId, (v) => {
      const prevId = lastViajeActivoIdRef.current || localStorage.getItem(storageKey);
      setViajeActivo(v);
      setViajeActivoInicialCargado(true);
      if (v) {
        lastViajeActivoIdRef.current = v.id;
        localStorage.setItem(storageKey, v.id);
        accionPropiaTerminoRef.current = false;
      } else {
        setMapaAbierto(false);
        setChatAbierto(false);
        setCancelarModalAbierto(false);
        localStorage.removeItem(storageKey);
        if (prevId && !accionPropiaTerminoRef.current) {
          lastViajeActivoIdRef.current = null;
          fetchViajeById(prevId)
            .then((cerrado) => {
              if (cerrado && cerrado.estado === 'cancelado' && cerrado.canceladoPor !== 'conductor') {
                const quien =
                  cerrado.canceladoPor === 'pasajero'
                    ? cerrado.pasajeroNombre || 'El pasajero'
                    : 'El sistema';
                const cuerpoAlerta = cerrado.motivoCancelacion
                  ? `${quien} canceló el viaje: "${cerrado.motivoCancelacion}"`
                  : `${quien} canceló el viaje.`;
                setAccionMsg(cuerpoAlerta);
                onPushNotificacion(
                  'Viaje cancelado por el pasajero',
                  cuerpoAlerta,
                  'alerta'
                );
              }
            })
            .catch(() => {});
        } else {
          lastViajeActivoIdRef.current = null;
          accionPropiaTerminoRef.current = false;
        }
      }
    });
    const unsubOfertas = subscribeOfertasParaConductor(selectedConductorId, (list) => {
      setOfertasCola(list);
    });
    return () => {
      unsubCond();
      unsubViaje();
      unsubOfertas();
    };
  }, [selectedConductorId, onPushNotificacion]);

  // Si el pasajero canceló mientras el conductor tenía la app cerrada, restaurar a 'disponible'
  useEffect(() => {
    if (
      viajeActivoInicialCargado &&
      !viajeActivo &&
      conductor &&
      (conductor.estadoOperativo === 'en_camino' || conductor.estadoOperativo === 'en_viaje')
    ) {
      cambiarEstadoOperativoConductor(conductor.uid, 'disponible').catch(() => {});
    }
  }, [viajeActivoInicialCargado, viajeActivo, conductor]);

  // Carga LAZY del historial SOLO cuando el conductor toca la pestaña 'Historial'
  const cargarHistorialLazy = async (forzar = false) => {
    if (!conductor) return;
    if (historialCargado && !forzar) return;
    setCargandoHistorial(true);
    try {
      const list = await fetchHistorialConductor(conductor.uid);
      setHistorial(list);
      setHistorialCargado(true);
    } finally {
      setCargandoHistorial(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'historial' && conductor && !historialCargado) {
      cargarHistorialLazy(false);
    }
    if (activeTab === 'perfil' && conductor && !solicitudesCargadas) {
      Promise.all([
        fetchMiPII(conductor.uid).catch(() => null),
        fetchMisSolicitudesCambio(conductor.uid).catch(() => []),
      ]).then(([pii, sols]) => {
        setMiPii(pii);
        setMisSolicitudes(sols);
        setSolicitudesCargadas(true);
      });
    }
    if (activeTab === 'perfil' && isAdmin && !flotaAdminCargada) {
      fetchConductoresAdminPaginado(20)
        .then((list) => {
          setFlotaAdminLazy(list);
          setFlotaAdminCargada(true);
        })
        .catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, conductor, isAdmin]);

  // Temporizador GPS cada 90 segundos SOLO durante estado == 'aceptado' (Modo Recogida)
  useEffect(() => {
    if (!viajeActivo || viajeActivo.estado !== 'aceptado' || !conductor) return;

    const enviarPulso90s = async () => {
      const cLat = viajeActivo.conductorLat ?? conductor.lat ?? viajeActivo.origenLat + 0.01;
      const cLng = viajeActivo.conductorLng ?? conductor.lng ?? viajeActivo.origenLng + 0.01;
      const nextLat = Number((cLat + (viajeActivo.origenLat - cLat) * 0.22).toFixed(6));
      const nextLng = Number((cLng + (viajeActivo.origenLng - cLng) * 0.22).toFixed(6));
      await enviarPosicion90sRecogida(
        viajeActivo.id,
        conductor.uid,
        nextLat,
        nextLng,
        viajeActivo.origenLat,
        viajeActivo.origenLng
      );
    };

    const interval = setInterval(enviarPulso90s, 90_000);
    return () => clearInterval(interval);
  }, [viajeActivo, conductor]);

  const ofertasActivasParaMi = useMemo(() => {
    return ofertasCola.filter((v) => {
      if (v.colaConductores.length === 0) return false;
      const turnoUid = v.colaConductores[v.ofertaActualIndex % v.colaConductores.length];
      return turnoUid === selectedConductorId;
    });
  }, [ofertasCola, selectedConductorId]);

  const ofertaPrincipal = ofertasActivasParaMi[0] || null;

  useEffect(() => {
    if (!ofertaPrincipal) return;
    const updateTimer = () => {
      const expira = ofertaPrincipal.ofertaExpiraAt ?? Date.now() + 15000;
      setSegundosOferta(Math.max(0, Math.ceil((expira - Date.now()) / 1000)));
    };
    updateTimer();
    const t = setInterval(updateTimer, 1000);
    return () => clearInterval(t);
  }, [ofertaPrincipal]);

  const promedios = useMemo(
    () =>
      flotaAdminLazy.length > 0
        ? calcularPromediosTarifas(flotaAdminLazy)
        : { promedioBase: 1500, promedioKm: 650 },
    [flotaAdminLazy]
  );

  const alertaTarifaPropia = useMemo(
    () =>
      esTarifaAbusiva(
        tarifaBaseEdit,
        tarifaKmEdit,
        promedios.promedioBase,
        promedios.promedioKm
      ),
    [tarifaBaseEdit, tarifaKmEdit, promedios]
  );

  const { montoActual, montoProximoEnero } = calcularMensualidadActualConAjusteAnual();

  const handleSimularPulso90s = async () => {
    if (!viajeActivo || !conductor) return;
    const cLat = viajeActivo.conductorLat ?? conductor.lat ?? viajeActivo.origenLat + 0.015;
    const cLng = viajeActivo.conductorLng ?? conductor.lng ?? viajeActivo.origenLng + 0.015;
    const nextLat = Number((cLat + (viajeActivo.origenLat - cLat) * 0.35).toFixed(6));
    const nextLng = Number((cLng + (viajeActivo.origenLng - cLng) * 0.35).toFixed(6));
    const eta = await enviarPosicion90sRecogida(
      viajeActivo.id,
      conductor.uid,
      nextLat,
      nextLng,
      viajeActivo.origenLat,
      viajeActivo.origenLng
    );
    setAccionMsg(`Posición GPS enviada (ciclo 90s). Nuevo ETA al pasajero: ~${eta} min.`);
  };

  const handleAceptarOferta = async (viaje: Viaje) => {
    if (!conductor) return;
    setAccionMsg(null);
    const res = await aceptarViajeAtomicamente(viaje.id, conductor);
    if (!res.exito) {
      setAccionMsg(res.motivo || 'No se pudo aceptar la oferta.');
      return;
    }
    onPushNotificacion(
      'Viaje aceptado — Modo Recogida 90s',
      `Dirígete por Waze a recoger a ${viaje.pasajeroNombre}. El GPS enviará posición cada 90s hasta ingresar el PIN.`,
      'aceptado'
    );
  };

  const handleVerificarPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!viajeActivo) return;
    setPinError(null);
    const res = await verificarPinYComenzarViaje(viajeActivo, pinInput);
    if (!res.valido) {
      setPinError(res.mensaje);
      return;
    }
    setPinInput('');
    setAccionMsg(res.mensaje);
  };

  const handleFinalizarViaje = async () => {
    if (!viajeActivo) return;
    accionPropiaTerminoRef.current = true;
    const viajeCerrado = { ...viajeActivo };
    await finalizarViaje(viajeActivo);
    setUltimoViajeFinalizado(viajeCerrado);
    setCalificacionEnviada(false);
  };

  const handleConfirmarCancelacionConductor = async (motivo: string) => {
    if (!viajeActivo) return;
    accionPropiaTerminoRef.current = true;
    await cancelarViajeConMotivo({
      viaje: viajeActivo,
      canceladoPor: 'conductor',
      motivo,
    });
    setAccionMsg(`Viaje cancelado. Nota registrada: "${motivo}"`);
  };

  const handleUploadRegDoc = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (val: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageToDataUrl(file, 800, 0.7);
      setter(compressed);
      setRegError(null);
    } catch (err) {
      setRegError(err instanceof Error ? err.message : 'No se pudo cargar la imagen.');
    }
  };

  const handleRegistrarConductor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regAceptoTerminos) return;
    if (!regFotoVehiculo || !regFotoCedula || !regFotoLicencia || !regFotoCirculacion) {
      setRegError('Adjunta la foto del vehículo y las 3 fotos de documentos (Cédula, Licencia y Circulación/RTV).');
      return;
    }
    setRegError(null);
    setRegistrando(true);
    try {
      await registrarNuevoConductor({
        uid: userUid,
        nombre: regNombre,
        telefono: regTelefono,
        cedula: regCedula,
        email: userEmail,
        fotoVehiculoUrl: regFotoVehiculo,
        vehiculoTipo: regTipo,
        vehiculoModelo: regModelo,
        vehiculoColor: regColor,
        vehiculoAnio: regAnio,
        placa: regPlaca,
        capacidad: regCapacidad,
        tarifaBase: regTarifaBase,
        tarifaPorKm: regTarifaKm,
        terminosAceptados: true,
        fotoCedula: regFotoCedula,
        fotoLicencia: regFotoLicencia,
        fotoCirculacion: regFotoCirculacion,
      });
      setSelectedConductorId(userUid);
    } finally {
      setRegistrando(false);
    }
  };

  // --- SI NO TIENE FICHA DE CONDUCTOR TODAVÍA (O ADMIN DESEA PROBAR OTRO) ---
  if (!conductor) {
    return (
      <div className="mx-auto max-w-2xl space-y-4">
        {isAdmin && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#E2E6DF] bg-white p-4">
            <span className="text-xs font-semibold text-[#525B50]">
              Administrador: puedes operar cualquier conductor activo de la flota
            </span>
            <button
              type="button"
              onClick={async () => {
                const list = await fetchConductoresAdminPaginado(20);
                setFlotaAdminLazy(list);
                setFlotaAdminCargada(true);
                const activo = list.find((c) => c.estadoCuenta === 'activo');
                if (activo) setSelectedConductorId(activo.uid);
              }}
              className="min-h-[40px] rounded-xl bg-[#14231A] px-4 text-xs font-semibold text-white hover:bg-[#1E3527]"
            >
              Cargar conductor activo de prueba
            </button>
          </div>
        )}

        <div className="rounded-2xl border border-[#E2E6DF] bg-white p-6">
          <h2 className="text-xl font-bold text-[#14231A]">Registro de Conductor — Viaje Rural</h2>
          <p className="mt-1 text-sm text-[#525B50]">
            Tu ficha quedará en estado pendiente hasta que el Administrador la verifique.
          </p>

          <form onSubmit={handleRegistrarConductor} className="mt-5 space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold">Nombre completo</label>
                <input
                  required
                  value={regNombre}
                  onChange={(e) => setRegNombre(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold">Teléfono (solo visible para Admin)</label>
                <input
                  required
                  value={regTelefono}
                  onChange={(e) => setRegTelefono(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold">Cédula (control duplicados)</label>
                <input
                  required
                  value={regCedula}
                  onChange={(e) => setRegCedula(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold">Tipo de vehículo</label>
                <select
                  value={regTipo}
                  onChange={(e) => {
                    const val = e.target.value as TipoVehiculo;
                    setRegTipo(val);
                    const list =
                      configuracion?.tiposVehiculo && configuracion.tiposVehiculo.length > 0
                        ? configuracion.tiposVehiculo
                        : DEFAULT_TIPOS_VEHICULO;
                    const match = list.find((v) => v.nombre === val);
                    if (match) setRegCapacidad(match.maxPasajeros);
                  }}
                  className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                >
                  {(configuracion?.tiposVehiculo && configuracion.tiposVehiculo.length > 0
                    ? configuracion.tiposVehiculo
                    : DEFAULT_TIPOS_VEHICULO
                  ).map((vt) => (
                    <option key={vt.nombre} value={vt.nombre}>
                      {vt.nombre} (máx. {vt.maxPasajeros} pax)
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold">Modelo y Año</label>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    required
                    value={regModelo}
                    onChange={(e) => setRegModelo(e.target.value)}
                    placeholder="Modelo"
                    className="col-span-2 min-h-[44px] rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                  />
                  <input
                    required
                    value={regAnio}
                    onChange={(e) => setRegAnio(e.target.value)}
                    placeholder="Año"
                    className="min-h-[44px] rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-2 font-mono text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold">Color y Placa</label>
                <div className="flex gap-2">
                  <input
                    required
                    value={regColor}
                    onChange={(e) => setRegColor(e.target.value)}
                    placeholder="Color"
                    className="min-h-[44px] flex-1 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                  />
                  <input
                    required
                    value={regPlaca}
                    onChange={(e) => setRegPlaca(e.target.value)}
                    placeholder="Placa"
                    className="min-h-[44px] w-28 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm uppercase"
                  />
                </div>
              </div>
              <div className="sm:col-span-2">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <div>
                    <label
                      htmlFor="reg-capacidad"
                      className="mb-1 block text-xs font-semibold text-[#14231A]"
                    >
                      Capacidad (pasajeros)
                    </label>
                    <input
                      id="reg-capacidad"
                      type="number"
                      min={1}
                      max={16}
                      value={regCapacidad}
                      onChange={(e) => setRegCapacidad(Number(e.target.value))}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="reg-tarifa-base"
                      className="mb-1 block text-xs font-semibold text-[#14231A]"
                    >
                      Tarifa base (₡)
                    </label>
                    <input
                      id="reg-tarifa-base"
                      type="number"
                      min={500}
                      step={100}
                      value={regTarifaBase}
                      onChange={(e) => setRegTarifaBase(Number(e.target.value))}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="reg-tarifa-km"
                      className="mb-1 block text-xs font-semibold text-[#14231A]"
                    >
                      Precio por kilómetro adicional (₡)
                    </label>
                    <input
                      id="reg-tarifa-km"
                      type="number"
                      min={100}
                      step={50}
                      value={regTarifaKm}
                      onChange={(e) => setRegTarifaKm(Number(e.target.value))}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-2.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4">
              <div className="text-xs font-bold text-[#14231A]">
                Foto del Vehículo y Documentos Legales (Obligatorio para verificación)
              </div>
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {(
                  [
                    { label: 'Foto del Vehículo', value: regFotoVehiculo, setter: setRegFotoVehiculo },
                    { label: 'Foto de Cédula', value: regFotoCedula, setter: setRegFotoCedula },
                    { label: 'Foto de Licencia', value: regFotoLicencia, setter: setRegFotoLicencia },
                    {
                      label: 'Tarjeta Circulación / RTV / Marchamo',
                      value: regFotoCirculacion,
                      setter: setRegFotoCirculacion,
                    },
                  ] as const
                ).map((docItem) => (
                  <label
                    key={docItem.label}
                    className={`flex min-h-[46px] cursor-pointer items-center justify-between gap-2 rounded-xl border px-3 py-2 text-xs ${
                      docItem.value
                        ? 'border-[#15803D] bg-[#15803D]/8 text-[#14231A]'
                        : 'border-dashed border-[#CBD5E1] bg-white text-[#525B50]'
                    }`}
                  >
                    <span className="flex items-center gap-2 font-medium">
                      {docItem.value ? (
                        <FileCheck2 className="h-4 w-4 shrink-0 text-[#15803D]" />
                      ) : (
                        <Camera className="h-4 w-4 shrink-0 text-[#525B50]" />
                      )}
                      <span>{docItem.label}</span>
                    </span>
                    {docItem.value ? (
                      <img
                        src={docItem.value}
                        alt={docItem.label}
                        className="h-8 w-11 rounded border border-[#E2E6DF] object-cover"
                      />
                    ) : (
                      <span className="font-semibold text-[#15803D]">Subir</span>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleUploadRegDoc(e, docItem.setter)}
                      className="hidden"
                    />
                  </label>
                ))}
              </div>
            </div>

            {regError && (
              <div className="rounded-xl border border-[#DC2626]/30 bg-[#FEF2F2] p-3 text-xs font-semibold text-[#991B1B]">
                {regError}
              </div>
            )}

            <label className="flex items-start gap-3 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 text-xs text-[#333D32]">
              <input
                type="checkbox"
                checked={regAceptoTerminos}
                onChange={(e) => setRegAceptoTerminos(e.target.checked)}
                className="mt-0.5 h-4 w-4 accent-[#15803D]"
              />
              <span>
                Acepto obligatoriamente los{' '}
                <button
                  type="button"
                  onClick={onAbrirTerminos}
                  className="font-semibold text-[#15803D] underline"
                >
                  Términos y Condiciones de Viaje Rural
                </button>
                : plataforma solo de conexión (cobros en efectivo) y pago mensual de{' '}
                <strong className="font-mono">{formatearColones(montoActual)}</strong> colones con aumento del 10% anual
                cada 1 de enero (próximo: {formatearColones(montoProximoEnero)}).
              </span>
            </label>

            <button
              type="submit"
              disabled={!regAceptoTerminos || registrando}
              className="min-h-[48px] w-full rounded-xl bg-[#15803D] px-5 py-3 text-sm font-semibold text-white hover:bg-[#166534] disabled:opacity-45"
            >
              {registrando ? 'Enviando solicitud...' : 'Enviar registro para verificación'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  const infoLicencia = calcularDiasLicenciaRestantes(conductor.licenciaExp);
  const diasLicencia = infoLicencia.dias;
  const cfgGeneral = configuracion || DEFAULT_CONFIGURACION_GENERAL;

  return (
    <div className="space-y-5">
      {/* MODAL ALERTDIALOG DE COBRO EN EFECTIVO + CALIFICACIÓN MUTUA AL PASAJERO */}
      {ultimoViajeFinalizado && !calificacionEnviada && !viajeActivo && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Modal de Cobro en Efectivo"
        >
          <div className="w-full max-w-md rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#15803D]">
              Viaje Finalizado — Cobro Directo
            </div>
            <h3 className="mt-1 text-xl font-bold text-[#14231A]">
              Monto a Cobrar al Pasajero
            </h3>
            <div className="mt-3 rounded-xl border border-[#15803D]/25 bg-[#F0FDF4] p-4 text-center">
              <div className="font-mono text-4xl font-bold tabular-nums text-[#15803D]">
                {formatearColones(ultimoViajeFinalizado.montoAproximado)}
              </div>
              <p className="mt-1 text-xs text-[#525B50]">
                Sumado automáticamente a tus Finanzas de Hoy y del Mes
              </p>
            </div>

            <div className="mt-5 border-t border-[#E2E6DF] pt-4">
              <div className="text-sm font-semibold text-[#14231A]">
                Califica al pasajero: {ultimoViajeFinalizado.pasajeroNombre}
              </div>
              <div className="mt-3 flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setEstrellasPasajero(n)}
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF]"
                    aria-label={`${n} estrellas al pasajero`}
                  >
                    <Star
                      className={`h-5 w-5 ${
                        n <= estrellasPasajero
                          ? 'fill-[#D97706] text-[#D97706]'
                          : 'text-[#CBD5E1]'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 flex gap-2.5">
              <button
                type="button"
                onClick={() => setCalificacionEnviada(true)}
                className="min-h-[44px] flex-1 rounded-xl border border-[#E2E6DF] text-sm font-semibold text-[#14231A]"
              >
                Cerrar
              </button>
              <button
                type="button"
                onClick={async () => {
                  await enviarCalificacion({
                    viajeId: ultimoViajeFinalizado.id,
                    autorUid: conductor.uid,
                    destinatarioUid: ultimoViajeFinalizado.pasajeroId,
                    destinatarioRol: 'pasajero',
                    estrellas: estrellasPasajero,
                  });
                  setCalificacionEnviada(true);
                }}
                className="min-h-[44px] flex-1 rounded-xl bg-[#15803D] px-4 text-sm font-semibold text-white hover:bg-[#166534]"
              >
                Guardar Calificación
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* PESTAÑA 1: INICIO (ESTADO ACTIVO/INACTIVO, OFERTAS 15S, VIAJE ACTIVO) */}
      {/* ===================================================================== */}
      {activeTab === 'inicio' && (
        <div className="space-y-5">
          {/* RECUPERACIÓN DE ESTADO (CRÍTICO): Botón persistente tras cerrar o reiniciar app */}
          {viajeActivo && (
            <div className="rounded-2xl border-2 border-[#15803D] bg-[#F0FDF4] p-4 shadow-sm">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-[#15803D]">
                    Recuperación de Estado Activo (Firestore)
                  </div>
                  <div className="text-base font-bold text-[#14231A]">
                    {viajeActivo.estado === 'aceptado'
                      ? `Recogida activa: ${viajeActivo.pasajeroNombre} (${viajeActivo.cantidadPasajeros} pax)`
                      : `Viaje en curso hacia ${viajeActivo.destinoNombre}`}
                  </div>
                </div>
                <a
                  href={
                    viajeActivo.estado === 'aceptado'
                      ? buildWazeUrl(viajeActivo.origenLat, viajeActivo.origenLng)
                      : buildWazeUrl(viajeActivo.destinoLat, viajeActivo.destinoLng)
                  }
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-[#15803D] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#166534]"
                >
                  <Navigation className="h-4 w-4" />
                  {viajeActivo.estado === 'aceptado'
                    ? 'Retomar recogida (Waze)'
                    : 'Retomar viaje al destino (Waze)'}
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </div>
            </div>
          )}

          {accionMsg && (
            <div className="rounded-xl border border-[#15803D]/30 bg-white px-4 py-3 text-sm font-medium text-[#15803D]">
              {accionMsg}
            </div>
          )}

          {/* Cabecera operativa + toggle Activo/Inactivo */}
          <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-xs text-[#525B50]">
                  {conductor.vehiculoTipo} · Placa <span className="font-mono font-bold">{conductor.placa}</span> · ★{' '}
                  {conductor.promedioCalificacion.toFixed(1)}
                </div>
                <h2 className="text-xl font-bold text-[#14231A]">{conductor.nombre}</h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    const res = await compartirAppEnDispositivo(cfgGeneral.linkDescarga);
                    setShareToast(
                      res.status === 'shared'
                        ? 'Menú para compartir abierto.'
                        : 'Enlace copiado para compartir por WhatsApp.'
                    );
                    setTimeout(() => setShareToast(null), 4500);
                  }}
                  className="inline-flex min-h-[44px] items-center gap-2 whitespace-nowrap rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] px-3.5 py-2 text-xs font-semibold text-[#15803D] hover:bg-[#15803D]/15"
                >
                  <Share2 className="h-4 w-4" />
                  Compartir App
                </button>

                <button
                  type="button"
                  disabled={Boolean(viajeActivo) || conductor.estadoCuenta !== 'activo'}
                  onClick={() =>
                    cambiarEstadoOperativoConductor(
                      conductor.uid,
                      conductor.estadoOperativo === 'disponible' ? 'offline' : 'disponible'
                    )
                  }
                  className={`inline-flex min-h-[44px] items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2 text-xs font-semibold transition-colors disabled:opacity-50 ${
                    conductor.estadoOperativo === 'disponible'
                      ? 'bg-[#15803D] text-white'
                      : 'border border-[#E2E6DF] bg-[#F7F8F6] text-[#14231A]'
                  }`}
                >
                  <Power className="h-4 w-4" />
                  {conductor.estadoCuenta !== 'activo'
                    ? `Cuenta ${conductor.estadoCuenta}`
                    : conductor.estadoOperativo === 'disponible'
                    ? 'Activo (Esperando ofertas)'
                    : conductor.estadoOperativo === 'offline'
                    ? 'Inactivo (Activar)'
                    : `Estado: ${conductor.estadoOperativo}`}
                </button>
              </div>
            </div>

            {shareToast && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] px-3 py-2 text-xs font-medium text-[#15803D]">
                <span>{shareToast}</span>
                <a
                  href={buildWhatsAppShareAppUrl(cfgGeneral.linkDescarga)}
                  target="_blank"
                  rel="noreferrer"
                  className="font-bold underline"
                >
                  Enviar por WhatsApp
                </a>
              </div>
            )}

            <div className="mt-4 grid grid-cols-1 gap-3 border-t border-[#E2E6DF] pt-4 sm:grid-cols-3">
              <div className="rounded-xl bg-[#F7F8F6] px-3.5 py-2.5">
                <div className="flex items-center gap-1.5 text-[11px] text-[#525B50]">
                  <BatteryCharging className="h-3.5 w-3.5 text-[#15803D]" />
                  Estado del GPS
                </div>
                <div className="mt-0.5 font-mono text-xs font-bold text-[#14231A]">
                  {viajeActivo?.estado === 'aceptado'
                    ? 'ACTIVO (Cada 90s)'
                    : 'APAGADO (Modo Ahorro)'}
                </div>
              </div>
              <div className="rounded-xl bg-[#F7F8F6] px-3.5 py-2.5">
                <div className="text-[11px] text-[#525B50]">Tarifa Base / Km</div>
                <div className="mt-0.5 font-mono text-xs font-bold text-[#14231A]">
                  {formatearColones(conductor.tarifaBase)} + {formatearColones(conductor.tarifaPorKm)}/km
                </div>
              </div>
              <div className="rounded-xl bg-[#F7F8F6] px-3.5 py-2.5">
                <div className="text-[11px] text-[#525B50]">Licencia restante</div>
                <div
                  className={`mt-0.5 font-mono text-xs font-bold ${
                    infoLicencia.estado === 'vencida'
                      ? 'text-[#DC2626]'
                      : infoLicencia.estado === 'por_vencer'
                      ? 'text-[#D97706]'
                      : 'text-[#15803D]'
                  }`}
                >
                  {infoLicencia.etiqueta}{' '}
                  <span className="font-normal text-[#525B50]">({infoLicencia.fechaTexto})</span>
                </div>
              </div>
            </div>
          </div>

          {/* FLUJO DE VIAJE ACTIVO, OFERTA 15S O MODO ESPERA */}
          {viajeActivo ? (
            <div className="space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-5">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#E2E6DF] pb-4">
                <div className="flex items-center gap-3.5">
                  <img
                    src={viajeActivo.pasajeroFotoUrl || PASSENGER_AVATAR}
                    alt={viajeActivo.pasajeroNombre}
                    referrerPolicy="no-referrer"
                    className="h-14 w-14 rounded-full border border-[#E2E6DF] object-cover"
                  />
                  <div>
                    <div className="text-base font-bold text-[#14231A]">
                      {viajeActivo.pasajeroNombre}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#525B50]">
                      <Users className="h-3.5 w-3.5" />
                      <span>{viajeActivo.cantidadPasajeros} pasajero(s)</span>
                      <span>·</span>
                      <span className="font-mono font-semibold tabular-nums text-[#15803D]">
                        {formatearColones(viajeActivo.montoAproximado)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Botones bajo demanda: Mapa y Chat (NO montados siempre) */}
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setMapaAbierto(true)}
                    className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]/50"
                  >
                    <MapPin className="h-4 w-4 text-[#15803D]" />
                    Ver Mapa
                  </button>
                  <button
                    type="button"
                    onClick={() => setChatAbierto(true)}
                    className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl bg-[#14231A] px-4 text-xs font-semibold text-white hover:bg-[#1E3527]"
                  >
                    <MessageSquare className="h-4 w-4" />
                    Abrir Chat
                  </button>
                </div>
              </div>

              <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 text-sm">
                <div className="text-xs font-semibold text-[#525B50]">Reseña de ubicación exacta</div>
                <p className="mt-1 font-medium text-[#14231A]">{viajeActivo.resenaUbicacion}</p>
                <div className="mt-2 text-xs text-[#525B50]">
                  Destino: <strong className="text-[#14231A]">{viajeActivo.destinoNombre}</strong> ({viajeActivo.distanciaKm} km)
                </div>
              </div>

              {viajeActivo.estado === 'aceptado' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2.5">
                    <a
                      href={buildWazeUrl(viajeActivo.origenLat, viajeActivo.origenLng)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex min-h-[48px] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-[#14231A] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#1E3527]"
                    >
                      <Navigation className="h-4 w-4" />
                      Ir a recoger por Waze
                    </a>
                    <button
                      type="button"
                      onClick={handleSimularPulso90s}
                      className="inline-flex min-h-[48px] items-center justify-center gap-2 whitespace-nowrap rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 py-2.5 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]/50"
                    >
                      <Radio className="h-4 w-4 text-[#15803D]" />
                      Enviar pulso GPS 90s ahora
                    </button>
                  </div>

                  {/* Ingresar PIN de 3 dígitos para apagar GPS y empezar el viaje */}
                  <form
                    onSubmit={handleVerificarPin}
                    className="rounded-xl border border-[#D97706]/40 bg-[#FFFBEB] p-4"
                  >
                    <label className="mb-2 flex items-center gap-2 text-xs font-bold text-[#92400E]">
                      <KeyRound className="h-4 w-4" />
                      Al llegar, ingresa el PIN de 3 dígitos del pasajero
                    </label>
                    <div className="flex flex-col gap-2 sm:flex-row">
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={3}
                        value={pinInput}
                        onChange={(e) => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 3))}
                        placeholder="Ej: 482"
                        className="min-h-[48px] w-full rounded-xl border border-[#D97706]/40 bg-white px-4 font-mono text-2xl font-bold tracking-[0.3em] text-[#14231A] sm:w-44"
                      />
                      <button
                        type="submit"
                        disabled={pinInput.length !== 3}
                        className="min-h-[48px] flex-1 rounded-xl bg-[#15803D] px-5 text-sm font-semibold text-white hover:bg-[#166534] disabled:opacity-45"
                      >
                        Confirmar PIN y Apagar GPS
                      </button>
                    </div>
                    {pinError && (
                      <p className="mt-2 text-xs font-semibold text-[#DC2626]">{pinError}</p>
                    )}
                  </form>

                  <button
                    type="button"
                    onClick={() => setCancelarModalAbierto(true)}
                    className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-[#DC2626]/35 bg-white px-4 text-xs font-semibold text-[#DC2626] transition-colors hover:bg-[#FEF2F2]"
                  >
                    <XCircle className="h-4 w-4" />
                    Cancelar viaje (ingresar nota de motivo)
                  </button>
                </div>
              )}

              {viajeActivo.estado === 'en_curso' && (
                <div className="space-y-3">
                  <div className="rounded-xl border border-[#15803D]/30 bg-[#15803D]/10 px-4 py-3 text-xs font-semibold text-[#15803D]">
                    PIN confirmado · GPS de recogida apagado por completo.
                  </div>
                  <div className="flex flex-col gap-2.5 sm:flex-row">
                    <a
                      href={buildWazeUrl(viajeActivo.destinoLat, viajeActivo.destinoLng)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex min-h-[48px] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-[#14231A] px-5 text-sm font-semibold text-white hover:bg-[#1E3527]"
                    >
                      <Navigation className="h-4 w-4" />
                      Iniciar viaje por Waze
                    </a>
                    <button
                      type="button"
                      onClick={handleFinalizarViaje}
                      className="min-h-[48px] flex-1 rounded-xl bg-[#15803D] px-5 text-sm font-semibold text-white hover:bg-[#166534]"
                    >
                      Finalizar viaje (Cobro efectivo)
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCancelarModalAbierto(true)}
                    className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-[#DC2626]/35 bg-white px-4 text-xs font-semibold text-[#DC2626] transition-colors hover:bg-[#FEF2F2]"
                  >
                    <XCircle className="h-4 w-4" />
                    Cancelar viaje (si no es posible llegar al destino)
                  </button>
                </div>
              )}

              {/* Modales bajo demanda de Mapa, Chat y Cancelación */}
              <OnDemandMapModal
                isOpen={mapaAbierto}
                onClose={() => setMapaAbierto(false)}
                viaje={viajeActivo}
              />
              <ViajeChatModal
                isOpen={chatAbierto}
                onClose={() => setChatAbierto(false)}
                viajeId={viajeActivo.id}
                autorUid={conductor.uid}
                autorRol="conductor"
                autorNombre={conductor.nombre}
                onIncomingHeadsUp={onIncomingChatHeadsUp}
              />
              <CancelarViajeModal
                isOpen={cancelarModalAbierto}
                rol="conductor"
                onClose={() => setCancelarModalAbierto(false)}
                onConfirm={handleConfirmarCancelacionConductor}
              />
            </div>
          ) : ofertasActivasParaMi.length > 0 ? (
            <div className="space-y-4">
              {ofertasActivasParaMi.map((oferta) => {
                const distRecogida = calcularDistanciaKm(
                  conductor.lat ?? 9.385,
                  conductor.lng ?? -83.682,
                  oferta.origenLat,
                  oferta.origenLng
                );
                return (
                  <div
                    key={oferta.id}
                    className="rounded-2xl border-2 border-[#D97706] bg-white p-5 shadow-sm"
                  >
                    <div className="flex items-center justify-between border-b border-[#E2E6DF] pb-3">
                      <div className="flex items-center gap-2 text-sm font-bold text-[#92400E]">
                        <Clock className="h-4 w-4 text-[#D97706]" />
                        Oferta de Viaje (Transacción Atómica)
                      </div>
                      <span className="font-mono text-xl font-bold tabular-nums text-[#D97706]">
                        {segundosOferta}s
                      </span>
                    </div>

                    <div className="mt-3 space-y-2 text-sm">
                      <div className="font-semibold text-[#14231A]">
                        {oferta.pasajeroNombre} · {oferta.cantidadPasajeros} pasajero(s) · A {distRecogida} km
                      </div>
                      <div className="text-xs text-[#525B50]">
                        Recogida: <strong className="text-[#14231A]">{oferta.resenaUbicacion}</strong>
                      </div>
                      <div className="text-xs text-[#525B50]">
                        Destino: <strong className="text-[#14231A]">{oferta.destinoNombre}</strong> ({oferta.distanciaKm} km)
                      </div>
                    </div>

                    <div className="mt-4 flex gap-3">
                      <button
                        type="button"
                        onClick={() =>
                          avanzarColaOfertaSecuencial(oferta.id, conductor.uid, true)
                        }
                        className="min-h-[48px] flex-1 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] text-sm font-semibold text-[#14231A] hover:bg-[#E2E6DF]/50"
                      >
                        Rechazar (ir al final)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAceptarOferta(oferta)}
                        className="min-h-[48px] flex-1 rounded-xl bg-[#15803D] text-sm font-semibold text-white hover:bg-[#166534]"
                      >
                        Aceptar Viaje
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="rounded-2xl border border-[#E2E6DF] bg-white p-6 text-center">
              <BatteryCharging className="mx-auto h-8 w-8 text-[#15803D]" />
              <h3 className="mt-2 text-base font-bold text-[#14231A]">
                Modo Espera — GPS Apagado
              </h3>
              <p className="mt-1 text-xs text-[#525B50]">
                No estás enviando ubicación continua. Tu dispositivo solo despertará 1 segundo cuando un pasajero
                dispare un ping de búsqueda cercana.
              </p>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* PESTAÑA 2: FINANZAS (SOLO DOS MONTOS: HOY Y MES + RECORDATORIO ₡7,000) */}
      {/* ===================================================================== */}
      {activeTab === 'finanzas' && (
        <div className="mx-auto max-w-2xl space-y-5">
          {(conductor.mensualidadPendiente || diasLicencia <= 7) && (
            <div className="flex items-start gap-3 rounded-2xl border border-[#D97706]/40 bg-[#FFFBEB] p-4">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-[#D97706]" />
              <div>
                <div className="text-sm font-bold text-[#92400E]">
                  Recordatorio mensual de licencia ({formatearColones(montoActual)} colones)
                </div>
                <p className="text-xs text-[#78350F]">
                  Tu licencia vence en {Math.max(0, diasLicencia)} día(s). Recuerda renovar tu mensualidad con el Administrador (ajuste anual del 10% cada 1 de enero).
                </p>
              </div>
            </div>
          )}

          <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
            <div className="border-b border-[#E2E6DF] pb-3">
              <h2 className="text-lg font-bold text-[#14231A]">Finanzas</h2>
              <p className="text-xs text-[#525B50]">
                Solo totales acumulados con FieldValue.increment() (ahorro de datos móviles)
              </p>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4">
                <div className="text-xs font-medium text-[#525B50]">Generado Hoy</div>
                <div className="mt-1 font-mono text-3xl font-bold tabular-nums text-[#15803D]">
                  {formatearColones(conductor.gananciasHoy ?? 0)}
                </div>
              </div>
              <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4">
                <div className="text-xs font-medium text-[#525B50]">Generado en el Mes</div>
                <div className="mt-1 font-mono text-3xl font-bold tabular-nums text-[#14231A]">
                  {formatearColones(conductor.gananciasMes ?? 0)}
                </div>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 py-2.5 text-xs">
              <span className="text-[#525B50]">
                Estado de licencia:{' '}
                <strong
                  className={`font-mono ${
                    infoLicencia.estado === 'vencida'
                      ? 'text-[#DC2626]'
                      : infoLicencia.estado === 'por_vencer'
                      ? 'text-[#D97706]'
                      : 'text-[#15803D]'
                  }`}
                >
                  {infoLicencia.etiqueta}
                </strong>
              </span>
              <span className="font-mono text-[#525B50]">
                Vence: <strong className="text-[#14231A]">{infoLicencia.fechaTexto}</strong>
              </span>
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#E2E6DF] pt-3 text-xs text-[#525B50]">
              <span>Recordatorio mensual automático (WorkManager): {formatearColones(montoActual)}</span>
              <button
                type="button"
                onClick={() =>
                  onPushNotificacion(
                    'Recordatorio Mensual Automático (WorkManager)',
                    `Recuerda abonar tu mensualidad de ${formatearColones(montoActual)} colones al SINPE ${cfgGeneral.sinpeNumero} (ajuste 10% cada 1 de enero).`,
                    'mensualidad'
                  )
                }
                className="font-semibold text-[#15803D] underline"
              >
                Probar aviso
              </button>
            </div>

            <div className="mt-3 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 text-xs text-[#333D32]">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  SINPE Móvil mensualidad:{' '}
                  <strong className="font-mono text-[#14231A]">{cfgGeneral.sinpeNumero}</strong> (
                  {cfgGeneral.adminSinpeTitular})
                </div>
                <a
                  href={buildWhatsAppSupportUrl(
                    cfgGeneral.whatsappSoporte,
                    `Hola, soy ${conductor.nombre} (placa ${conductor.placa}). Adjunto comprobante SINPE o consulta de soporte.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-semibold text-[#15803D] underline"
                >
                  <ExternalLink className="h-3 w-3" />
                  WhatsApp Soporte ({cfgGeneral.whatsappSoporte})
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* PESTAÑA 3: HISTORIAL (CARGA LAZY limit(20) SOLO AL TOCAR PESTAÑA)      */}
      {/* ===================================================================== */}
      {activeTab === 'historial' && (
        <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E2E6DF] pb-4">
            <div>
              <h2 className="text-lg font-bold text-[#14231A]">
                Historial de Viajes del Conductor (Máx. 20 recientes)
              </h2>
              <p className="text-xs text-[#525B50]">
                Se consulta únicamente cuando abres esta pestaña para proteger tu plan de datos.
              </p>
            </div>
            <button
              type="button"
              onClick={() => cargarHistorialLazy(true)}
              disabled={cargandoHistorial}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]/50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${cargandoHistorial ? 'animate-spin' : ''}`} />
              Actualizar
            </button>
          </div>

          {cargandoHistorial ? (
            <div className="py-10 text-center text-sm text-[#525B50]">
              Cargando historial desde Firestore...
            </div>
          ) : historial.length === 0 ? (
            <div className="py-10 text-center text-sm text-[#525B50]">
              Aún no tienes viajes finalizados en tu historial.
            </div>
          ) : (
            <div className="divide-y divide-[#E2E6DF]">
              {historial.map((v) => (
                <div
                  key={v.id}
                  className="flex flex-col gap-2 py-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div>
                    <div className="text-sm font-bold text-[#14231A]">
                      {v.pasajeroNombre} · {v.origenNombre} → {v.destinoNombre}
                    </div>
                    <div className="text-xs text-[#525B50]">
                      Estado: {v.estado} · {v.distanciaKm} km · {v.cantidadPasajeros} pax ·{' '}
                      {v.updatedAt?.toDate?.()?.toLocaleDateString('es-CR') || 'Reciente'}
                    </div>
                    {v.estado === 'cancelado' && v.motivoCancelacion && (
                      <div className="mt-1 text-xs text-[#991B1B]">
                        Cancelado por {v.canceladoPor || 'usuario'}: &ldquo;{v.motivoCancelacion}&rdquo;
                      </div>
                    )}
                  </div>
                  <div className="font-mono text-base font-bold tabular-nums text-[#15803D]">
                    {formatearColones(v.montoAproximado)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* PESTAÑA 4: PERFIL (CONFIGURACIÓN DE TARIFAS Y DATOS DEL CONDUCTOR)    */}
      {/* ===================================================================== */}
      {activeTab === 'perfil' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5 lg:col-span-6">
            <h3 className="text-base font-bold text-[#14231A]">Configuración de Tarifas</h3>
            <p className="mt-0.5 text-xs text-[#525B50]">
              Promedio de referencia: Base{' '}
              <span className="font-mono font-semibold">{formatearColones(promedios.promedioBase)}</span> · Km{' '}
              <span className="font-mono font-semibold">{formatearColones(promedios.promedioKm)}</span>
            </p>

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                  Tarifa base (₡)
                </label>
                <input
                  type="number"
                  min={500}
                  max={50000}
                  step={100}
                  value={tarifaBaseEdit}
                  onChange={(e) => setTarifaBaseEdit(Number(e.target.value))}
                  className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                  Precio por kilómetro adicional (₡)
                </label>
                <input
                  type="number"
                  min={100}
                  max={10000}
                  step={50}
                  value={tarifaKmEdit}
                  onChange={(e) => setTarifaKmEdit(Number(e.target.value))}
                  className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                />
              </div>
            </div>

            {alertaTarifaPropia.abusiva && (
              <div className="mt-3 flex items-start gap-2 rounded-xl border border-[#DC2626]/30 bg-[#DC2626]/10 p-3 text-xs text-[#991B1B]">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-[#DC2626]" />
                <span>
                  <strong>Alerta de tarifa fuera del promedio:</strong> {alertaTarifaPropia.motivo}. El administrador verá esta alerta.
                </span>
              </div>
            )}

            <button
              type="button"
              disabled={guardandoTarifas}
              onClick={async () => {
                setGuardandoTarifas(true);
                try {
                  await actualizarTarifasConductor(
                    conductor.uid,
                    tarifaBaseEdit,
                    tarifaKmEdit
                  );
                  setAccionMsg('Tarifas actualizadas en Firestore.');
                } finally {
                  setGuardandoTarifas(false);
                }
              }}
              className="mt-4 min-h-[44px] w-full rounded-xl bg-[#14231A] px-4 text-sm font-semibold text-white hover:bg-[#1E3527]"
            >
              {guardandoTarifas ? 'Guardando...' : 'Guardar mis tarifas'}
            </button>
          </div>

          <div className="space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-5 lg:col-span-6">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="text-base font-bold text-[#14231A]">
                  Datos Protegidos del Conductor y Vehículo
                </h3>
                <p className="text-xs text-[#525B50]">
                  Bloqueados tras el registro para evitar manipulación. Cambios solo mediante petición al Administrador.
                </p>
              </div>
              <Lock className="mt-0.5 h-4 w-4 shrink-0 text-[#15803D]" />
            </div>

            <div className="space-y-1.5 rounded-xl bg-[#F7F8F6] p-3.5 text-xs text-[#333D32]">
              <div>
                Conductor: <strong>{conductor.nombre}</strong>
              </div>
              <div>
                Teléfono: <strong className="font-mono">{miPii?.telefono || 'Registrado'}</strong> ·
                Cédula: <strong className="font-mono">{miPii?.cedula || conductor.cedulaHash || 'N/D'}</strong>
              </div>
              <div>
                Vehículo: <strong>{conductor.vehiculoTipo}</strong> ({conductor.vehiculoModelo || 'N/D'}
                {conductor.vehiculoColor ? ` · ${conductor.vehiculoColor}` : ''}
                {conductor.vehiculoAnio ? ` · ${conductor.vehiculoAnio}` : ''})
              </div>
              <div>
                Placa: <strong className="font-mono">{conductor.placa}</strong> · Capacidad:{' '}
                <strong>{conductor.capacidad} pax</strong>
              </div>
              <div>
                Calificación promedio:{' '}
                <strong className="font-mono">★ {conductor.promedioCalificacion.toFixed(2)}</strong>
              </div>
              <div>
                Licencia de conducción:{' '}
                <strong
                  className={`font-mono ${
                    infoLicencia.estado === 'vencida'
                      ? 'text-[#DC2626]'
                      : infoLicencia.estado === 'por_vencer'
                      ? 'text-[#D97706]'
                      : 'text-[#15803D]'
                  }`}
                >
                  {infoLicencia.etiqueta}
                </strong>{' '}
                (vence <span className="font-mono">{infoLicencia.fechaTexto}</span>)
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                if (!mostrarFormCambio) {
                  setReqNombre(conductor.nombre);
                  setReqTelefono(miPii?.telefono || '');
                  setReqCedula(miPii?.cedula || conductor.cedulaHash || '');
                  setReqTipoVehiculo(conductor.vehiculoTipo);
                  setReqModelo(conductor.vehiculoModelo || '');
                  setReqColor(conductor.vehiculoColor || '');
                  setReqAnio(conductor.vehiculoAnio || '');
                  setReqPlaca(conductor.placa);
                  setReqCapacidad(conductor.capacidad);
                  setReqMotivo('');
                  setSolicitudFeedback(null);
                }
                setMostrarFormCambio((v) => !v);
              }}
              className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-[#15803D]/40 bg-[#15803D]/10 px-4 text-xs font-bold text-[#15803D] hover:bg-[#15803D]/15"
            >
              <Send className="h-4 w-4" />
              {mostrarFormCambio
                ? 'Ocultar formulario de petición'
                : 'Solicitar cambio de datos al Administrador'}
            </button>

            {mostrarFormCambio && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setSolicitudFeedback(null);
                  const cambios: CambiosSolicitados = {};
                  if (reqNombre.trim() && reqNombre.trim() !== conductor.nombre) {
                    cambios.nombre = reqNombre.trim();
                  }
                  if (reqTelefono.trim() && reqTelefono.trim() !== (miPii?.telefono || '')) {
                    cambios.telefono = reqTelefono.trim();
                  }
                  if (
                    reqCedula.trim() &&
                    reqCedula.trim() !== (miPii?.cedula || conductor.cedulaHash || '')
                  ) {
                    cambios.cedula = reqCedula.trim();
                  }
                  if (reqTipoVehiculo && reqTipoVehiculo !== conductor.vehiculoTipo) {
                    cambios.vehiculoTipo = reqTipoVehiculo;
                  }
                  if (reqModelo.trim() && reqModelo.trim() !== (conductor.vehiculoModelo || '')) {
                    cambios.vehiculoModelo = reqModelo.trim();
                  }
                  if (reqColor.trim() && reqColor.trim() !== (conductor.vehiculoColor || '')) {
                    cambios.vehiculoColor = reqColor.trim();
                  }
                  if (reqAnio.trim() && reqAnio.trim() !== (conductor.vehiculoAnio || '')) {
                    cambios.vehiculoAnio = reqAnio.trim();
                  }
                  if (reqPlaca.trim().toUpperCase() !== conductor.placa.toUpperCase()) {
                    cambios.placa = reqPlaca.trim().toUpperCase();
                  }
                  if (reqCapacidad !== conductor.capacidad) {
                    cambios.capacidad = reqCapacidad;
                  }

                  if (Object.keys(cambios).length === 0) {
                    setSolicitudFeedback('Modifica al menos un campo antes de enviar la petición.');
                    return;
                  }
                  if (reqMotivo.trim().length < 3) {
                    setSolicitudFeedback('Indica el motivo del cambio (mínimo 3 caracteres).');
                    return;
                  }

                  setEnviandoSolicitud(true);
                  try {
                    const creada = await crearSolicitudCambioDatos({
                      solicitanteUid: conductor.uid,
                      rol: 'conductor',
                      nombreActual: conductor.nombre,
                      resumenActual: `${conductor.vehiculoTipo} · Placa ${conductor.placa} · ${conductor.capacidad} pax`,
                      cambios,
                      motivo: reqMotivo,
                    });
                    setMisSolicitudes((prev) => [creada, ...prev]);
                    setMostrarFormCambio(false);
                    setSolicitudFeedback(
                      'Petición enviada al Administrador. Tus datos cambiarán únicamente si el Administrador la aprueba.'
                    );
                  } finally {
                    setEnviandoSolicitud(false);
                  }
                }}
                className="space-y-3 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4"
              >
                <div className="text-xs font-bold text-[#14231A]">
                  Nueva Petición de Cambio al Administrador
                </div>
                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Nombre completo
                    </label>
                    <input
                      value={reqNombre}
                      onChange={(e) => setReqNombre(e.target.value)}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 text-xs"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Teléfono
                    </label>
                    <input
                      value={reqTelefono}
                      onChange={(e) => setReqTelefono(e.target.value)}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Cédula
                    </label>
                    <input
                      value={reqCedula}
                      onChange={(e) => setReqCedula(e.target.value)}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Tipo de vehículo
                    </label>
                    <select
                      value={reqTipoVehiculo}
                      onChange={(e) => setReqTipoVehiculo(e.target.value)}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 text-xs"
                    >
                      {(configuracion?.tiposVehiculo && configuracion.tiposVehiculo.length > 0
                        ? configuracion.tiposVehiculo
                        : DEFAULT_TIPOS_VEHICULO
                      ).map((vt) => (
                        <option key={vt.nombre} value={vt.nombre}>
                          {vt.nombre}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Modelo
                    </label>
                    <input
                      value={reqModelo}
                      onChange={(e) => setReqModelo(e.target.value)}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 text-xs"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Placa
                    </label>
                    <input
                      value={reqPlaca}
                      onChange={(e) => setReqPlaca(e.target.value.toUpperCase())}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 font-mono text-xs uppercase"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Color / Año
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      <input
                        value={reqColor}
                        onChange={(e) => setReqColor(e.target.value)}
                        placeholder="Color"
                        className="min-h-[40px] rounded-lg border border-[#E2E6DF] bg-white px-2 text-xs"
                      />
                      <input
                        value={reqAnio}
                        onChange={(e) => setReqAnio(e.target.value)}
                        placeholder="Año"
                        className="min-h-[40px] rounded-lg border border-[#E2E6DF] bg-white px-2 font-mono text-xs"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Capacidad (pasajeros)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={16}
                      value={reqCapacidad}
                      onChange={(e) => setReqCapacidad(Number(e.target.value))}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 font-mono text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                    Motivo del cambio (obligatorio)
                  </label>
                  <textarea
                    required
                    minLength={3}
                    maxLength={280}
                    rows={2}
                    value={reqMotivo}
                    onChange={(e) => setReqMotivo(e.target.value)}
                    placeholder="Ej: Cambio de vehículo o actualización de placa / número telefónico"
                    className="w-full rounded-lg border border-[#E2E6DF] bg-white p-2.5 text-xs"
                  />
                </div>
                <button
                  type="submit"
                  disabled={enviandoSolicitud}
                  className="min-h-[42px] w-full rounded-xl bg-[#15803D] px-4 text-xs font-semibold text-white hover:bg-[#166534] disabled:opacity-50"
                >
                  {enviandoSolicitud ? 'Enviando petición...' : 'Enviar petición al Administrador'}
                </button>
              </form>
            )}

            {solicitudFeedback && (
              <div className="rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] p-3 text-xs font-semibold text-[#15803D]">
                {solicitudFeedback}
              </div>
            )}

            {misSolicitudes.length > 0 && (
              <div className="space-y-2 border-t border-[#E2E6DF] pt-3">
                <div className="text-xs font-bold text-[#14231A]">
                  Mis peticiones de cambio ({misSolicitudes.length})
                </div>
                <div className="space-y-1.5">
                  {misSolicitudes.slice(0, 4).map((sol) => (
                    <div
                      key={sol.id}
                      className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-2.5 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[#14231A]">
                          {Object.keys(sol.cambios).join(', ')}
                        </span>
                        <span
                          className={`font-mono text-[11px] font-bold uppercase ${
                            sol.estado === 'aprobada'
                              ? 'text-[#15803D]'
                              : sol.estado === 'rechazada'
                              ? 'text-[#DC2626]'
                              : 'text-[#D97706]'
                          }`}
                        >
                          {sol.estado}
                        </span>
                      </div>
                      <div className="mt-0.5 text-[11px] text-[#525B50]">{sol.motivo}</div>
                      {sol.respuestaAdmin && (
                        <div className="mt-1 text-[11px] font-medium text-[#14231A]">
                          Admin: {sol.respuestaAdmin}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {isAdmin && flotaAdminLazy.length > 0 && (
              <div className="space-y-2 border-t border-[#E2E6DF] pt-3">
                <div className="text-xs font-semibold text-[#525B50]">
                  Cambiar conductor de prueba (Admin):
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {flotaAdminLazy.map((c) => (
                    <button
                      key={c.uid}
                      type="button"
                      onClick={() => setSelectedConductorId(c.uid)}
                      className={`min-h-[36px] rounded-lg px-3 text-xs font-semibold ${
                        selectedConductorId === c.uid
                          ? 'bg-[#14231A] text-white'
                          : 'bg-[#F7F8F6] text-[#14231A]'
                      }`}
                    >
                      {c.nombre.split(' ')[0]} · {c.vehiculoTipo}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-2 pt-1">
              <a
                href={buildWhatsAppShareAppUrl(cfgGeneral.linkDescarga)}
                target="_blank"
                rel="noreferrer"
                onClick={() => {
                  void compartirAppEnDispositivo(cfgGeneral.linkDescarga);
                }}
                className="flex min-h-[44px] w-full items-center justify-between rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] px-4 text-sm font-semibold text-[#15803D]"
              >
                <span className="flex items-center gap-2">
                  <Share2 className="h-4 w-4" />
                  Compartir App por WhatsApp
                </span>
                <span className="text-xs font-bold">Compartir</span>
              </a>
              {onAbrirSoporte && (
                <button
                  type="button"
                  onClick={onAbrirSoporte}
                  className="flex min-h-[44px] w-full items-center justify-between rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 text-sm font-semibold text-[#14231A]"
                >
                  <span className="flex items-center gap-2">
                    <Headphones className="h-4 w-4 text-[#15803D]" />
                    Soporte WhatsApp y SINPE
                  </span>
                  <span className="text-xs text-[#15803D]">Abrir</span>
                </button>
              )}
              <button
                type="button"
                onClick={onAbrirTerminos}
                className="flex min-h-[44px] w-full items-center justify-between rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 text-sm font-semibold text-[#14231A]"
              >
                <span className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-[#15803D]" />
                  Términos y Condiciones
                </span>
                <span className="text-xs text-[#525B50]">Ver</span>
              </button>
              {onLogout && (
                <button
                  type="button"
                  onClick={onLogout}
                  className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-[#DC2626]/30 bg-[#FEF2F2] px-4 text-sm font-semibold text-[#991B1B]"
                >
                  <LogOut className="h-4 w-4" />
                  Cerrar sesión
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* BOTTOM NAVIGATION FIJO DEL CONDUCTOR (4 PESTAÑAS)                     */}
      {/* ===================================================================== */}
      <nav
        aria-label="Navegación de Conductor"
        className="fixed bottom-0 left-0 right-0 z-30 border-t border-[#E2E6DF] bg-white/95 backdrop-blur-md"
      >
        <div className="mx-auto grid h-16 max-w-2xl grid-cols-4">
          {(
            [
              { id: 'inicio', label: 'Inicio', Icon: Home },
              { id: 'finanzas', label: 'Finanzas', Icon: DollarSign },
              { id: 'historial', label: 'Historial', Icon: History },
              { id: 'perfil', label: 'Perfil', Icon: User },
            ] as const
          ).map(({ id, label, Icon }) => {
            const activo = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={`flex flex-col items-center justify-center gap-1 text-xs font-semibold transition-colors ${
                  activo ? 'text-[#15803D]' : 'text-[#525B50] hover:text-[#14231A]'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
