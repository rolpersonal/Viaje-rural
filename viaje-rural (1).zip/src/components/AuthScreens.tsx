import React, { useState } from 'react';
import { Camera, Car, CheckCircle2, FileCheck2, Lock, Mail, User as UserIcon } from 'lucide-react';
import {
  iniciarSesionAdminEmail,
  iniciarSesionEmail,
  registrarConductorEmail,
  registrarPasajeroEmail,
} from '../services/viajeService';
import {
  calcularMensualidadActualConAjusteAnual,
  compressImageToDataUrl,
  DEFAULT_TIPOS_VEHICULO,
  formatearColones,
} from '../lib/ruralUtils';
import { TipoVehiculo, VehiculoTipoConfig } from '../types/viajeRural';

interface AuthScreensProps {
  aceptoTerminos: boolean;
  onChangeAceptoTerminos: (val: boolean) => void;
  onAbrirTerminos: () => void;
  onLoginGoogle: () => Promise<void>;
  onSuccessAuthRole: (rol: 'pasajero' | 'conductor' | 'admin') => void;
  tiposVehiculo?: VehiculoTipoConfig[];
}

export const AuthScreens: React.FC<AuthScreensProps> = ({
  aceptoTerminos,
  onChangeAceptoTerminos,
  onAbrirTerminos,
  onLoginGoogle,
  onSuccessAuthRole,
  tiposVehiculo,
}) => {
  const [rolAuth, setRolAuth] = useState<'pasajero' | 'conductor' | 'admin'>('pasajero');
  const [modo, setModo] = useState<'login' | 'registro'>('login');

  // Campos compartidos
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [telefono, setTelefono] = useState('');
  const [cedula, setCedula] = useState('');
  const [comunidad, setComunidad] = useState('');
  const [password, setPassword] = useState('');
  const [fotoPerfil, setFotoPerfil] = useState('');

  // Campos exclusivos Conductor y Documentos
  const [vehiculoTipo, setVehiculoTipo] = useState<TipoVehiculo>('Pickup 4x4');
  const [vehiculoModelo, setVehiculoModelo] = useState('');
  const [vehiculoColor, setVehiculoColor] = useState('');
  const [vehiculoAnio, setVehiculoAnio] = useState('');
  const [placa, setPlaca] = useState('');
  const [capacidad, setCapacidad] = useState(5);
  const [tarifaBase, setTarifaBase] = useState(1500);
  const [tarifaPorKm, setTarifaPorKm] = useState(650);

  // Fotos de vehículo y documentos legales
  const [fotoVehiculoUrl, setFotoVehiculoUrl] = useState('');
  const [fotoCedula, setFotoCedula] = useState('');
  const [fotoLicencia, setFotoLicencia] = useState('');
  const [fotoCirculacion, setFotoCirculacion] = useState('');

  const [cargando, setCargando] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const { montoActual } = calcularMensualidadActualConAjusteAnual();
  const catalogoVehiculos =
    tiposVehiculo && tiposVehiculo.length > 0 ? tiposVehiculo : DEFAULT_TIPOS_VEHICULO;

  const handleUploadImage = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (dataUrl: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageToDataUrl(file, 640, 0.58);
      setter(compressed);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Error al procesar imagen.');
    }
  };

  const traducirErrorFirebase = (err: unknown): string => {
    const raw = err instanceof Error ? err.message : String(err);
    if (raw.includes('auth/operation-not-allowed')) {
      return 'El proveedor Correo/Contraseña aún no está habilitado en Firebase Console (Authentication → Sign-in method → Email/Password). Puedes activarlo allí o ingresar ahora con Google.';
    }
    if (raw.includes('auth/invalid-credential') || raw.includes('auth/wrong-password')) {
      return 'Correo o contraseña incorrectos.';
    }
    if (raw.includes('auth/email-already-in-use')) {
      return 'Este correo ya está registrado. Cambia a "Iniciar Sesión".';
    }
    if (raw.includes('auth/weak-password')) {
      return 'La contraseña debe tener al menos 6 caracteres.';
    }
    return raw;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!aceptoTerminos) {
      setErrorMsg('Debes aceptar los Términos y Condiciones obligatorios para continuar.');
      return;
    }

    if (modo === 'registro' && rolAuth === 'conductor') {
      if (!fotoVehiculoUrl || !fotoCedula || !fotoLicencia || !fotoCirculacion) {
        setErrorMsg(
          'Por favor adjunta la foto del vehículo y las 3 fotos de documentos (Cédula, Licencia y Circulación/RTV).'
        );
        return;
      }
    }

    setCargando(true);
    try {
      if (rolAuth === 'admin') {
        await iniciarSesionAdminEmail(email, password);
        onSuccessAuthRole('admin');
      } else if (modo === 'login') {
        await iniciarSesionEmail(email, password);
        onSuccessAuthRole(rolAuth);
      } else if (rolAuth === 'pasajero') {
        await registrarPasajeroEmail({
          nombre,
          email,
          telefono,
          cedula,
          comunidad,
          fotoUrl: fotoPerfil || undefined,
          password,
        });
        onSuccessAuthRole('pasajero');
      } else {
        await registrarConductorEmail({
          nombre,
          email,
          telefono,
          cedula,
          password,
          fotoUrl: fotoPerfil || undefined,
          fotoVehiculoUrl,
          fotoCedula,
          fotoLicencia,
          fotoCirculacion,
          vehiculoTipo,
          vehiculoModelo,
          vehiculoColor,
          vehiculoAnio,
          placa,
          capacidad,
          tarifaBase,
          tarifaPorKm,
        });
        onSuccessAuthRole('conductor');
      }
    } catch (err) {
      setErrorMsg(traducirErrorFirebase(err));
    } finally {
      setCargando(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Selector de Rol: Pasajero vs Conductor vs Administrador */}
      <div className="grid grid-cols-3 gap-1.5 rounded-xl bg-[#E8ECE5] p-1">
        <button
          type="button"
          onClick={() => {
            setRolAuth('pasajero');
            setErrorMsg(null);
          }}
          className={`flex min-h-[42px] items-center justify-center gap-1.5 rounded-lg text-xs font-semibold transition-colors ${
            rolAuth === 'pasajero'
              ? 'bg-white text-[#14231A] shadow-sm'
              : 'text-[#525B50] hover:text-[#14231A]'
          }`}
        >
          <UserIcon className="h-3.5 w-3.5 text-[#15803D]" />
          Pasajero
        </button>
        <button
          type="button"
          onClick={() => {
            setRolAuth('conductor');
            setErrorMsg(null);
          }}
          className={`flex min-h-[42px] items-center justify-center gap-1.5 rounded-lg text-xs font-semibold transition-colors ${
            rolAuth === 'conductor'
              ? 'bg-white text-[#14231A] shadow-sm'
              : 'text-[#525B50] hover:text-[#14231A]'
          }`}
        >
          <Car className="h-3.5 w-3.5 text-[#D97706]" />
          Conductor
        </button>
        <button
          type="button"
          onClick={() => {
            setRolAuth('admin');
            setModo('login');
            setErrorMsg(null);
          }}
          className={`flex min-h-[42px] items-center justify-center gap-1.5 rounded-lg text-xs font-semibold transition-colors ${
            rolAuth === 'admin'
              ? 'bg-white text-[#14231A] shadow-sm'
              : 'text-[#525B50] hover:text-[#14231A]'
          }`}
        >
          <Lock className="h-3.5 w-3.5 text-[#14231A]" />
          Administrador
        </button>
      </div>

      {/* Sub-modo Login / Registro */}
      <div className="flex items-center justify-between border-b border-[#E2E6DF] pb-2.5">
        <span className="text-sm font-bold text-[#14231A]">
          {rolAuth === 'admin'
            ? 'Acceso Administrador (Verificación de Rol)'
            : modo === 'login'
            ? rolAuth === 'pasajero'
              ? 'Acceso Pasajero'
              : 'Acceso Conductor'
            : rolAuth === 'pasajero'
            ? 'Formulario Completo — Registro Pasajero'
            : 'Formulario Completo — Registro Conductor'}
        </span>
        {rolAuth !== 'admin' && (
          <button
            type="button"
            onClick={() => {
              setModo(modo === 'login' ? 'registro' : 'login');
              setErrorMsg(null);
            }}
            className="text-xs font-semibold text-[#15803D] hover:underline"
          >
            {modo === 'login' ? 'Crear cuenta nueva' : 'Ya tengo cuenta'}
          </button>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        {modo === 'registro' && (
          <div className="space-y-2.5">
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <input
                required
                type="text"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Nombre completo"
                className="min-h-[42px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 text-sm outline-none focus:border-[#15803D]"
              />
              <input
                required
                type="tel"
                value={telefono}
                onChange={(e) => setTelefono(e.target.value)}
                placeholder="Teléfono (+506 8888-8888)"
                className="min-h-[42px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 font-mono text-sm outline-none focus:border-[#15803D]"
              />
              <input
                required
                type="text"
                value={cedula}
                onChange={(e) => setCedula(e.target.value)}
                placeholder="Cédula (1-1234-5678)"
                className="min-h-[42px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 font-mono text-sm outline-none focus:border-[#15803D]"
              />
              {rolAuth === 'pasajero' ? (
                <input
                  required
                  type="text"
                  value={comunidad}
                  onChange={(e) => setComunidad(e.target.value)}
                  placeholder="Comunidad / Distrito rural"
                  className="min-h-[42px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 text-sm outline-none focus:border-[#15803D]"
                />
              ) : (
                <label className="flex min-h-[42px] cursor-pointer items-center justify-between gap-2 rounded-xl border border-dashed border-[#E2E6DF] bg-[#F7F8F6] px-3 text-xs text-[#525B50] hover:border-[#15803D]">
                  <span className="inline-flex items-center gap-1.5 font-medium text-[#14231A]">
                    <Camera className="h-3.5 w-3.5 text-[#15803D]" />
                    {fotoPerfil ? 'Foto perfil lista' : 'Foto del conductor (opc.)'}
                  </span>
                  {fotoPerfil && <CheckCircle2 className="h-4 w-4 text-[#15803D]" />}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleUploadImage(e, setFotoPerfil)}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            {rolAuth === 'pasajero' && (
              <label className="flex min-h-[42px] cursor-pointer items-center justify-between gap-2 rounded-xl border border-dashed border-[#E2E6DF] bg-[#F7F8F6] px-3.5 text-xs text-[#525B50] hover:border-[#15803D]">
                <span className="inline-flex items-center gap-2 font-medium text-[#14231A]">
                  <Camera className="h-4 w-4 text-[#15803D]" />
                  {fotoPerfil ? 'Foto de perfil adjuntada' : 'Subir foto de perfil (opcional)'}
                </span>
                {fotoPerfil && <CheckCircle2 className="h-4 w-4 text-[#15803D]" />}
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleUploadImage(e, setFotoPerfil)}
                  className="hidden"
                />
              </label>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3.5 top-3.5 h-4 w-4 text-[#525B50]" />
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Correo electrónico"
              className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] pl-10 pr-3.5 text-sm outline-none focus:border-[#15803D]"
            />
          </div>

          <div className="relative">
            <Lock className="pointer-events-none absolute left-3.5 top-3.5 h-4 w-4 text-[#525B50]" />
            <input
              required
              minLength={6}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Contraseña (mín. 6)"
              className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] pl-10 pr-3.5 text-sm outline-none focus:border-[#15803D]"
            />
          </div>
        </div>

        {modo === 'registro' && rolAuth === 'conductor' && (
          <div className="space-y-3 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5">
            <div className="text-xs font-bold text-[#14231A]">
              1. Datos del Vehículo y Tarifa Inicial
            </div>
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                  Tipo de vehículo
                </label>
                <select
                  value={vehiculoTipo}
                  onChange={(e) => {
                    const tipo = e.target.value;
                    setVehiculoTipo(tipo);
                    const found = catalogoVehiculos.find((v) => v.nombre === tipo);
                    if (found) setCapacidad(found.maxPasajeros);
                  }}
                  className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-3 text-sm"
                >
                  {catalogoVehiculos.map((vt) => (
                    <option key={vt.nombre} value={vt.nombre}>
                      {vt.nombre} (máx. {vt.maxPasajeros} pax)
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                  Marca y Modelo
                </label>
                <input
                  required
                  type="text"
                  value={vehiculoModelo}
                  onChange={(e) => setVehiculoModelo(e.target.value)}
                  placeholder="Ej: Hilux 4x4 / Honda XR150"
                  className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-3 text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                  Color del vehículo
                </label>
                <input
                  required
                  type="text"
                  value={vehiculoColor}
                  onChange={(e) => setVehiculoColor(e.target.value)}
                  placeholder="Ej: Blanco / Rojo"
                  className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-3 text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                  Año / Placa
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    required
                    type="text"
                    maxLength={4}
                    value={vehiculoAnio}
                    onChange={(e) => setVehiculoAnio(e.target.value)}
                    placeholder="Año (2022)"
                    className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-2.5 font-mono text-sm"
                  />
                  <input
                    required
                    type="text"
                    value={placa}
                    onChange={(e) => setPlaca(e.target.value)}
                    placeholder="Placa"
                    className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-2.5 font-mono text-sm uppercase"
                  />
                </div>
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                  Capacidad máxima (pax)
                </label>
                <input
                  required
                  type="number"
                  min={1}
                  max={16}
                  value={capacidad}
                  onChange={(e) => setCapacidad(Number(e.target.value))}
                  className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-3 font-mono text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                    Tarifa base (₡)
                  </label>
                  <input
                    required
                    type="number"
                    min={500}
                    step={100}
                    value={tarifaBase}
                    onChange={(e) => setTarifaBase(Number(e.target.value))}
                    className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-2.5 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                    Precio por km adicional (₡)
                  </label>
                  <input
                    required
                    type="number"
                    min={100}
                    step={50}
                    value={tarifaPorKm}
                    onChange={(e) => setTarifaPorKm(Number(e.target.value))}
                    className="min-h-[40px] w-full rounded-xl border border-[#E2E6DF] bg-white px-2.5 font-mono text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="border-t border-[#E2E6DF] pt-2.5">
              <div className="mb-2 text-xs font-bold text-[#14231A]">
                2. Foto del Vehículo y Documentos Obligatorios (Verificación Admin)
              </div>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {(
                  [
                    {
                      label: 'Foto del Vehículo',
                      value: fotoVehiculoUrl,
                      setter: setFotoVehiculoUrl,
                    },
                    {
                      label: 'Foto de Cédula',
                      value: fotoCedula,
                      setter: setFotoCedula,
                    },
                    {
                      label: 'Foto de Licencia',
                      value: fotoLicencia,
                      setter: setFotoLicencia,
                    },
                    {
                      label: 'Circulación / RTV / Marchamo',
                      value: fotoCirculacion,
                      setter: setFotoCirculacion,
                    },
                  ] as const
                ).map((docItem) => (
                  <label
                    key={docItem.label}
                    className={`flex min-h-[44px] cursor-pointer items-center justify-between gap-2 rounded-xl border px-3 py-2 text-xs transition-colors ${
                      docItem.value
                        ? 'border-[#15803D] bg-[#15803D]/8 text-[#14231A]'
                        : 'border-dashed border-[#CBD5E1] bg-white text-[#525B50] hover:border-[#15803D]'
                    }`}
                  >
                    <span className="flex items-center gap-2 font-medium">
                      {docItem.value ? (
                        <FileCheck2 className="h-4 w-4 shrink-0 text-[#15803D]" />
                      ) : (
                        <Camera className="h-4 w-4 shrink-0 text-[#525B50]" />
                      )}
                      <span className="truncate">{docItem.label}</span>
                    </span>
                    {docItem.value ? (
                      <img
                        src={docItem.value}
                        alt={docItem.label}
                        className="h-7 w-10 rounded object-cover border border-[#E2E6DF]"
                      />
                    ) : (
                      <span className="text-[11px] font-semibold text-[#15803D]">Subir</span>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleUploadImage(e, docItem.setter)}
                      className="hidden"
                    />
                  </label>
                ))}
              </div>
            </div>

            <p className="text-[11px] text-[#525B50]">
              Cuota mensual de licencia: <strong className="font-mono">{formatearColones(montoActual)}</strong> (se activa al ser verificado por el Administrador).
            </p>
          </div>
        )}

        <label className="flex items-start gap-2.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3 text-xs text-[#333D32]">
          <input
            type="checkbox"
            checked={aceptoTerminos}
            onChange={(e) => onChangeAceptoTerminos(e.target.checked)}
            className="mt-0.5 h-4 w-4 accent-[#15803D]"
          />
          <span>
            Acepto los{' '}
            <button
              type="button"
              onClick={onAbrirTerminos}
              className="font-semibold text-[#15803D] underline"
            >
              Términos y Condiciones
            </button>{' '}
            (cobro directo en efectivo y mensualidad {formatearColones(montoActual)} para conductores con +10% cada 1 de enero).
          </span>
        </label>

        {errorMsg && (
          <p className="rounded-xl border border-[#DC2626]/30 bg-[#FEF2F2] p-3 text-xs font-medium text-[#991B1B]">
            {errorMsg}
          </p>
        )}

        <div className="flex flex-col gap-2.5 pt-1 sm:flex-row">
          <button
            type="submit"
            disabled={cargando}
            className="min-h-[46px] flex-1 rounded-xl bg-[#15803D] px-5 text-sm font-semibold text-white transition-colors hover:bg-[#166534] disabled:opacity-60"
          >
            {cargando
              ? 'Procesando...'
              : rolAuth === 'admin'
              ? 'Ingresar como Administrador'
              : modo === 'login'
              ? `Ingresar como ${rolAuth === 'pasajero' ? 'Pasajero' : 'Conductor'}`
              : `Registrar ${rolAuth === 'pasajero' ? 'Pasajero' : 'Conductor'}`}
          </button>
          <button
            type="button"
            onClick={() => {
              onSuccessAuthRole(rolAuth);
              onLoginGoogle();
            }}
            className="min-h-[46px] rounded-xl border border-[#E2E6DF] bg-white px-5 text-sm font-semibold text-[#14231A] hover:bg-[#F7F8F6]"
          >
            Continuar con Google
          </button>
        </div>
      </form>
    </div>
  );
};
