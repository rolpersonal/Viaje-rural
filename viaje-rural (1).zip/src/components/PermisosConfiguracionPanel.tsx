import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  BatteryCharging,
  Bell,
  CheckCircle2,
  LocateFixed,
  RefreshCw,
  Settings,
  ShieldAlert,
  Wifi,
  X,
} from 'lucide-react';
import { capturarUbicacionGpsPrecisa } from '../lib/ruralUtils';
import { verificarSincronizacionServidor } from '../services/viajeService';

interface PermisosConfiguracionPanelProps {
  rol: 'conductor' | 'pasajero';
  isModal?: boolean;
  onClose?: () => void;
}

type EstadoPermiso = 'concedido' | 'pendiente' | 'denegado';

export const PermisosConfiguracionPanel: React.FC<PermisosConfiguracionPanelProps> = ({
  rol,
  isModal = false,
  onClose,
}) => {
  const [estadoGps, setEstadoGps] = useState<EstadoPermiso>('pendiente');
  const [detalleGps, setDetalleGps] = useState<string>('Verificando estado de ubicación...');
  const [precisionGpsM, setPrecisionGpsM] = useState<number | null>(null);
  const [verificandoGps, setVerificandoGps] = useState(false);

  const [estadoNotif, setEstadoNotif] = useState<EstadoPermiso>('pendiente');
  const [detalleNotif, setDetalleNotif] = useState<string>('Verificando permisos de notificación...');
  const [solicitandoNotif, setSolicitandoNotif] = useState(false);

  const [wakeLockActivo, setWakeLockActivo] = useState(false);
  const [soportaWakeLock, setSoportaWakeLock] = useState(false);
  const [esPwaInstalada, setEsPwaInstalada] = useState(false);
  const wakeLockRef = useRef<{ release: () => Promise<void> } | null>(null);

  const [enLinea, setEnLinea] = useState<boolean>(
    typeof navigator === 'undefined' ? true : navigator.onLine
  );
  const [sincronizadoServidor, setSincronizadoServidor] = useState<boolean>(false);
  const [detalleConexion, setDetalleConexion] = useState<string>('Comprobando sincronización...');
  const [verificandoSync, setVerificandoSync] = useState(false);
  const [mensajeAyuda, setMensajeAyuda] = useState<string | null>(null);

  const verificarPermisosDispositivo = useCallback(async () => {
    // 1. GPS / Ubicación
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setEstadoGps('denegado');
      setDetalleGps('Tu navegador no soporta geolocalización.');
    } else if ('permissions' in navigator && navigator.permissions?.query) {
      try {
        const perm = await navigator.permissions.query({
          name: 'geolocation' as PermissionName,
        });
        if (perm.state === 'granted') {
          setEstadoGps('concedido');
          setDetalleGps(
            precisionGpsM != null
              ? `Concedida · Alta precisión activa (±${precisionGpsM} m)`
              : 'Concedida · Lista para ubicación de alta precisión'
          );
        } else if (perm.state === 'denied') {
          setEstadoGps('denegado');
          setDetalleGps('Bloqueada en el navegador. Habilítala en el candado de la barra de dirección.');
        } else {
          setEstadoGps('pendiente');
          setDetalleGps('Pendiente de autorización del navegador.');
        }
      } catch {
        setEstadoGps('pendiente');
        setDetalleGps('Pulsa Verificar GPS para comprobar alta precisión.');
      }
    }

    // 2. Notificaciones Push
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setEstadoNotif('denegado');
      setDetalleNotif('Este navegador no soporta notificaciones web.');
    } else if (Notification.permission === 'granted') {
      setEstadoNotif('concedido');
      setDetalleNotif('Habilitadas para ofertas, llegadas y mensajes.');
    } else if (Notification.permission === 'denied') {
      setEstadoNotif('denegado');
      setDetalleNotif('Bloqueadas en el navegador. Actívalas en ajustes del sitio.');
    } else {
      setEstadoNotif('pendiente');
      setDetalleNotif('Aún no autorizadas. Actívalas para recibir avisos al instante.');
    }

    // 3. Segundo plano / WakeLock / PWA
    if (typeof window !== 'undefined') {
      const standalone =
        window.matchMedia?.('(display-mode: standalone)')?.matches ||
        Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
      setEsPwaInstalada(standalone);
      setSoportaWakeLock('wakeLock' in navigator);
    }

    setEnLinea(typeof navigator === 'undefined' ? true : navigator.onLine);
  }, [precisionGpsM]);

  const verificarSync = useCallback(async () => {
    setVerificandoSync(true);
    try {
      const res = await verificarSincronizacionServidor();
      setEnLinea(typeof navigator === 'undefined' ? true : navigator.onLine);
      setSincronizadoServidor(res.conectado);
      setDetalleConexion(res.detalle);
    } finally {
      setVerificandoSync(false);
    }
  }, []);

  useEffect(() => {
    void verificarPermisosDispositivo();
    void verificarSync();

    const onRefresh = () => {
      void verificarPermisosDispositivo();
      if (document.visibilityState === 'visible') {
        void verificarSync();
      }
    };
    const onOnline = () => {
      setEnLinea(true);
      void verificarSync();
    };
    const onOffline = () => {
      setEnLinea(false);
      setSincronizadoServidor(false);
      setDetalleConexion('Sin conexión a internet en este dispositivo.');
    };

    window.addEventListener('focus', onRefresh);
    document.addEventListener('visibilitychange', onRefresh);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    return () => {
      window.removeEventListener('focus', onRefresh);
      document.removeEventListener('visibilitychange', onRefresh);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [verificarPermisosDispositivo, verificarSync]);

  const handleActivarGps = async () => {
    setVerificandoGps(true);
    setMensajeAyuda(null);
    try {
      const res = await capturarUbicacionGpsPrecisa(4500, 25);
      setPrecisionGpsM(res.precisionMetros);
      setEstadoGps('concedido');
      setDetalleGps(
        res.precisionMetros != null
          ? `Concedida · Alta precisión activa (±${res.precisionMetros} m)`
          : 'Concedida · Alta precisión activa'
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'No se pudo acceder al GPS.';
      if (msg.toLowerCase().includes('denegado')) {
        setEstadoGps('denegado');
        setMensajeAyuda(
          'Si el permiso de ubicación fue denegado, toca el ícono de candado/ajustes junto a la URL del navegador y cambia Ubicación a "Permitir".'
        );
      } else {
        setEstadoGps('pendiente');
      }
      setDetalleGps(msg);
    } finally {
      setVerificandoGps(false);
    }
  };

  const handleActivarNotificaciones = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    setSolicitandoNotif(true);
    setMensajeAyuda(null);
    try {
      if (Notification.permission === 'denied') {
        setMensajeAyuda(
          'Las notificaciones están bloqueadas por el navegador. Ábrelas desde el ícono de ajustes del sitio en la barra de direcciones.'
        );
        return;
      }
      const permiso = await Notification.requestPermission();
      if (permiso === 'granted') {
        setEstadoNotif('concedido');
        setDetalleNotif('Habilitadas para ofertas, llegadas y mensajes.');
      } else if (permiso === 'denied') {
        setEstadoNotif('denegado');
        setDetalleNotif('Denegadas. Actívalas en los permisos del sitio.');
      } else {
        setEstadoNotif('pendiente');
        setDetalleNotif('Solicitud cerrada sin activar.');
      }
    } finally {
      setSolicitandoNotif(false);
    }
  };

  const handleToggleWakeLock = async () => {
    setMensajeAyuda(null);
    const navWithWake = navigator as Navigator & {
      wakeLock?: { request: (type: 'screen') => Promise<{ release: () => Promise<void> }> };
    };
    if (!navWithWake.wakeLock) {
      setMensajeAyuda(
        'En navegador móvil, mantén la pestaña abierta (sin cerrar la app) y desactiva el ahorro agresivo de batería en los ajustes del navegador para evitar cortes.'
      );
      return;
    }
    if (wakeLockActivo && wakeLockRef.current) {
      await wakeLockRef.current.release().catch(() => {});
      wakeLockRef.current = null;
      setWakeLockActivo(false);
      return;
    }
    try {
      const sentinel = await navWithWake.wakeLock.request('screen');
      wakeLockRef.current = sentinel;
      setWakeLockActivo(true);
    } catch {
      setMensajeAyuda(
        'No se pudo activar pantalla activa en esta pestaña. En Android nativo puedes permitir ejecución sin restricciones desde Ajustes de batería.'
      );
    }
  };

  const renderBadge = (ok: boolean, labelOk = 'Activo / Concedido', labelPendiente = 'Pendiente / Denegado') => (
    <span
      className={`inline-flex items-center gap-1 rounded-lg px-2 py-0.5 text-[11px] font-bold ${
        ok
          ? 'bg-[#DCFCE7] text-[#15803D]'
          : 'bg-[#FEF3C7] text-[#B45309]'
      }`}
    >
      {ok ? (
        <CheckCircle2 className="h-3 w-3" />
      ) : (
        <ShieldAlert className="h-3 w-3" />
      )}
      {ok ? labelOk : labelPendiente}
    </span>
  );

  const content = (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E2E6DF] pb-3">
        <div className="flex items-center gap-2">
          <Settings className="h-4 w-4 text-[#15803D]" />
          <div>
            <h3 className="text-base font-bold text-[#14231A]">
              Permisos y Configuración
            </h3>
            <p className="text-xs text-[#525B50]">
              Estado en tiempo real para operar sin cortes ({rol === 'conductor' ? 'Modo Conductor' : 'Modo Pasajero'})
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              void verificarPermisosDispositivo();
              void verificarSync();
            }}
            className="inline-flex min-h-[36px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]/60"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${verificandoSync ? 'animate-spin' : ''}`} />
            Actualizar
          </button>
          {isModal && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="flex min-h-[36px] min-w-[36px] items-center justify-center rounded-xl border border-[#E2E6DF] text-[#525B50] hover:bg-[#F7F8F6]"
              aria-label="Cerrar permisos y configuración"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <div className="space-y-2.5">
        {/* 1. Ubicación GPS */}
        <div className="flex flex-col gap-2.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <LocateFixed className="h-4 w-4 text-[#15803D]" />
              <span className="text-xs font-bold text-[#14231A]">Ubicación GPS (Alta precisión)</span>
              {renderBadge(
                estadoGps === 'concedido',
                'Activo / Concedido',
                estadoGps === 'denegado' ? 'Denegado' : 'Pendiente'
              )}
            </div>
            <p className="text-[11px] text-[#525B50]">{detalleGps}</p>
          </div>
          <button
            type="button"
            disabled={verificandoGps}
            onClick={handleActivarGps}
            className={`min-h-[38px] shrink-0 rounded-xl px-3.5 text-xs font-semibold transition-colors ${
              estadoGps === 'concedido'
                ? 'border border-[#E2E6DF] bg-white text-[#14231A] hover:bg-[#F0FDF4]'
                : 'bg-[#15803D] text-white hover:bg-[#166534]'
            }`}
          >
            {verificandoGps
              ? 'Verificando...'
              : estadoGps === 'concedido'
              ? 'Probar precisión'
              : 'Conceder GPS'}
          </button>
        </div>

        {/* 2. Notificaciones Push */}
        <div className="flex flex-col gap-2.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <Bell className="h-4 w-4 text-[#15803D]" />
              <span className="text-xs font-bold text-[#14231A]">Notificaciones Push</span>
              {renderBadge(
                estadoNotif === 'concedido',
                'Activo / Concedido',
                estadoNotif === 'denegado' ? 'Denegado' : 'Pendiente'
              )}
            </div>
            <p className="text-[11px] text-[#525B50]">{detalleNotif}</p>
          </div>
          <button
            type="button"
            disabled={solicitandoNotif}
            onClick={handleActivarNotificaciones}
            className={`min-h-[38px] shrink-0 rounded-xl px-3.5 text-xs font-semibold transition-colors ${
              estadoNotif === 'concedido'
                ? 'border border-[#E2E6DF] bg-white text-[#14231A] hover:bg-[#F0FDF4]'
                : 'bg-[#15803D] text-white hover:bg-[#166534]'
            }`}
          >
            {solicitandoNotif
              ? 'Solicitando...'
              : estadoNotif === 'concedido'
              ? 'Habilitadas'
              : estadoNotif === 'denegado'
              ? 'Cómo activar'
              : 'Activar'}
          </button>
        </div>

        {/* 3. Segundo plano / Optimización de batería */}
        <div className="flex flex-col gap-2.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <BatteryCharging className="h-4 w-4 text-[#15803D]" />
              <span className="text-xs font-bold text-[#14231A]">
                Segundo plano / Optimización de batería
              </span>
              {renderBadge(
                wakeLockActivo || esPwaInstalada,
                wakeLockActivo ? 'Pantalla activa ON' : 'App instalada (PWA)',
                rol === 'conductor' ? 'Revisar ahorro' : 'Estándar navegador'
              )}
            </div>
            <p className="text-[11px] text-[#525B50]">
              {rol === 'conductor'
                ? 'Permite cambiar a Waze sin desconectar tu disponibilidad. En Android nativo permite ignorar ahorro de batería.'
                : 'Mantiene activa la espera del conductor y los avisos de llegada en tiempo real.'}
            </p>
          </div>
          <button
            type="button"
            onClick={handleToggleWakeLock}
            className={`min-h-[38px] shrink-0 rounded-xl px-3.5 text-xs font-semibold transition-colors ${
              wakeLockActivo
                ? 'border border-[#15803D]/30 bg-[#DCFCE7] text-[#15803D]'
                : soportaWakeLock
                ? 'bg-[#14231A] text-white hover:bg-[#1E3527]'
                : 'border border-[#E2E6DF] bg-white text-[#14231A]'
            }`}
          >
            {wakeLockActivo
              ? 'Desactivar bloqueo'
              : soportaWakeLock
              ? 'Evitar suspensión'
              : 'Ver recomendación'}
          </button>
        </div>

        {/* 4. Conexión y sincronización */}
        <div className="flex flex-col gap-2.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <Wifi className="h-4 w-4 text-[#15803D]" />
              <span className="text-xs font-bold text-[#14231A]">
                Conexión y sincronización
              </span>
              {renderBadge(
                enLinea && sincronizadoServidor,
                'Conectado y sincronizado',
                enLinea ? 'Verificando servidor' : 'Sin conexión'
              )}
            </div>
            <p className="text-[11px] text-[#525B50]">{detalleConexion}</p>
          </div>
          <button
            type="button"
            disabled={verificandoSync}
            onClick={() => void verificarSync()}
            className="min-h-[38px] shrink-0 rounded-xl border border-[#E2E6DF] bg-white px-3.5 text-xs font-semibold text-[#14231A] hover:bg-[#F0FDF4]"
          >
            {verificandoSync ? 'Probando...' : 'Verificar red'}
          </button>
        </div>
      </div>

      {mensajeAyuda && (
        <div className="rounded-xl border border-[#D97706]/30 bg-[#FFFBEB] p-3 text-xs text-[#92400E]">
          {mensajeAyuda}
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#E2E6DF] bg-white px-3.5 py-2.5 text-[11px] text-[#525B50]">
        <span>Zona horaria operativa: <strong className="text-[#14231A]">America/Costa_Rica (UTC-6)</strong></span>
        <span>Plataforma: <strong className="font-mono text-[#14231A]">Viaje Rural Web/PWA</strong></span>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 backdrop-blur-sm"
        role="dialog"
        aria-modal="true"
        aria-label="Permisos y Configuración"
      >
        <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[#E2E6DF] bg-white p-5 shadow-2xl">
          {content}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
      {content}
    </div>
  );
};
