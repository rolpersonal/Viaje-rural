import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Timestamp } from 'firebase/firestore';
import {
  AlertTriangle,
  Ban,
  Bell,
  CalendarPlus,
  CheckCircle2,
  ChevronRight,
  Clock,
  Copy,
  CopyCheck,
  Edit3,
  FileImage,
  Inbox,
  LayoutDashboard,
  Link2,
  Phone,
  RefreshCw,
  Settings,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  Users,
  Car,
  X,
} from 'lucide-react';
import {
  adminActualizarFichaConductor,
  adminActualizarFichaPasajero,
  adminAprobarYActivarConductor1Mes,
  adminCambiarEstadoConductor,
  adminExtenderLicencia1Mes,
  adminFetchConductorDocumentos,
  adminFetchPII,
  adminGuardarConfiguracionGeneral,
  adminResolverSolicitudCambio,
  AdminResumenTotales,
  adminToggleBloqueoPasajero,
  fetchAdminResumenTotales,
  fetchConductoresAdminPaginado,
  fetchConductoresPendientesAdmin,
  fetchPasajerosAdminPaginado,
  fetchSolicitudesCambioAdmin,
  seedInitialRuralFleetIfNeeded,
} from '../services/viajeService';
import {
  calcularDiasLicenciaRestantes,
  calcularMensualidadActualConAjusteAnual,
  calcularPromediosTarifas,
  DEFAULT_LINK_DESCARGA,
  DEFAULT_TIPOS_VEHICULO,
  DRIVER_AVATARS,
  esTarifaAbusiva,
  formatearColones,
  PASSENGER_AVATAR,
} from '../lib/ruralUtils';
import {
  Conductor,
  ConductorDocumentos,
  ConfiguracionGeneral,
  Pasajero,
  SolicitudCambioDatos,
  TipoVehiculo,
  UsuarioPII,
  VehiculoTipoConfig,
} from '../types/viajeRural';

type AdminTab =
  | 'resumen'
  | 'pendientes'
  | 'conductores'
  | 'pasajeros'
  | 'solicitudes'
  | 'alertas'
  | 'duplicados'
  | 'configuracion';

interface AdminViewProps {
  isAdmin: boolean;
  configuracion: ConfiguracionGeneral;
  onPushNotificacion: (
    titulo: string,
    cuerpo: string,
    tipo: 'oferta' | 'aceptado' | 'proximidad' | 'mensualidad' | 'alerta'
  ) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  isAdmin,
  configuracion,
  onPushNotificacion,
}) => {
  const [adminTab, setAdminTab] = useState<AdminTab>('resumen');

  // Datos cargados estrictamente bajo demanda según la pestaña activa (limit(20))
  const [resumen, setResumen] = useState<AdminResumenTotales | null>(null);
  const [pendientes, setPendientes] = useState<Conductor[]>([]);
  const [pendientesCargados, setPendientesCargados] = useState(false);
  const [conductores, setConductores] = useState<Conductor[]>([]);
  const [conductoresCargados, setConductoresCargados] = useState(false);
  const [pasajeros, setPasajeros] = useState<Pasajero[]>([]);
  const [pasajerosCargados, setPasajerosCargados] = useState(false);
  const [solicitudes, setSolicitudes] = useState<SolicitudCambioDatos[]>([]);
  const [solicitudesCargadas, setSolicitudesCargadas] = useState(false);
  const [notasRespuesta, setNotasRespuesta] = useState<Record<string, string>>({});
  const [procesandoSolId, setProcesandoSolId] = useState<string | null>(null);
  const [piiMap, setPiiMap] = useState<Record<string, UsuarioPII>>({});
  const [duplicadosCargados, setDuplicadosCargados] = useState(false);
  const [cargandoTab, setCargandoTab] = useState(false);
  const [filtroEstado, setFiltroEstado] = useState<
    'todos' | 'pendiente' | 'activo' | 'bloqueado'
  >('todos');

  // Modal único de Ficha de Conductor (tocar en lista -> abre modal)
  const [fichaConductor, setFichaConductor] = useState<Conductor | null>(null);
  const [editNombre, setEditNombre] = useState('');
  const [editPlaca, setEditPlaca] = useState('');
  const [editTipo, setEditTipo] = useState<TipoVehiculo>('Pickup 4x4');
  const [editCapacidad, setEditCapacidad] = useState(5);
  const [editTarifaBase, setEditTarifaBase] = useState(1500);
  const [editTarifaKm, setEditTarifaKm] = useState(650);
  const [editTelefono, setEditTelefono] = useState('');
  const [editCedula, setEditCedula] = useState('');
  const [cargandoPiiConductor, setCargandoPiiConductor] = useState(false);
  const [guardandoConductor, setGuardandoConductor] = useState(false);
  const [aprobandoConductor, setAprobandoConductor] = useState(false);
  const [docsConductor, setDocsConductor] = useState<{
    docs: ConductorDocumentos | null;
    cargando: boolean;
    abierto: boolean;
  }>({ docs: null, cargando: false, abierto: false });

  // Modal único de Ficha de Pasajero (tocar en lista -> abre modal)
  const [fichaPasajero, setFichaPasajero] = useState<Pasajero | null>(null);
  const [pasNombre, setPasNombre] = useState('');
  const [pasTelefono, setPasTelefono] = useState('');
  const [pasEmail, setPasEmail] = useState('');
  const [pasCedula, setPasCedula] = useState('');
  const [cargandoPiiPasajero, setCargandoPiiPasajero] = useState(false);
  const [guardandoPasajero, setGuardandoPasajero] = useState(false);

  // Configuración general (WhatsApp soporte 62546546, SINPE, datos Admin, Términos, Link Descarga, Tipos vehículo)
  const [cfgWhatsapp, setCfgWhatsapp] = useState(configuracion.whatsappSoporte);
  const [cfgSinpe, setCfgSinpe] = useState(configuracion.sinpeNumero);
  const [cfgAdminNombre, setCfgAdminNombre] = useState(configuracion.adminNombre);
  const [cfgAdminTel, setCfgAdminTel] = useState(configuracion.adminTelefono);
  const [cfgAdminEmail, setCfgAdminEmail] = useState(configuracion.adminEmail);
  const [cfgSinpeTitular, setCfgSinpeTitular] = useState(configuracion.adminSinpeTitular);
  const [cfgTerminos, setCfgTerminos] = useState(configuracion.terminosCondiciones);
  const [cfgLinkDescarga, setCfgLinkDescarga] = useState(
    configuracion.linkDescarga || DEFAULT_LINK_DESCARGA
  );
  const [linkCopiado, setLinkCopiado] = useState(false);
  const [cfgTiposVehiculo, setCfgTiposVehiculo] = useState<VehiculoTipoConfig[]>(
    configuracion.tiposVehiculo && configuracion.tiposVehiculo.length > 0
      ? configuracion.tiposVehiculo
      : DEFAULT_TIPOS_VEHICULO
  );
  const [nuevoTipoNombre, setNuevoTipoNombre] = useState('');
  const [nuevoTipoPax, setNuevoTipoPax] = useState(1);
  const [nuevoTipoDesc, setNuevoTipoDesc] = useState('');
  const [guardandoConfig, setGuardandoConfig] = useState(false);
  const [configGuardadaMsg, setConfigGuardadaMsg] = useState<string | null>(null);

  useEffect(() => {
    setCfgWhatsapp(configuracion.whatsappSoporte);
    setCfgSinpe(configuracion.sinpeNumero);
    setCfgAdminNombre(configuracion.adminNombre);
    setCfgAdminTel(configuracion.adminTelefono);
    setCfgAdminEmail(configuracion.adminEmail);
    setCfgSinpeTitular(configuracion.adminSinpeTitular);
    setCfgTerminos(configuracion.terminosCondiciones);
    setCfgLinkDescarga(configuracion.linkDescarga || DEFAULT_LINK_DESCARGA);
    if (configuracion.tiposVehiculo && configuracion.tiposVehiculo.length > 0) {
      setCfgTiposVehiculo(configuracion.tiposVehiculo);
    }
  }, [configuracion]);

  const cargarResumen = useCallback(async () => {
    if (!isAdmin) return;
    setCargandoTab(true);
    try {
      const data = await fetchAdminResumenTotales();
      setResumen(data);
    } finally {
      setCargandoTab(false);
    }
  }, [isAdmin]);

  const cargarPendientesLim20 = useCallback(async () => {
    if (!isAdmin) return;
    setCargandoTab(true);
    try {
      const list = await fetchConductoresPendientesAdmin(20);
      setPendientes(list);
      setPendientesCargados(true);
    } finally {
      setCargandoTab(false);
    }
  }, [isAdmin]);

  const cargarConductoresLim20 = useCallback(async () => {
    if (!isAdmin) return;
    setCargandoTab(true);
    try {
      const list = await fetchConductoresAdminPaginado(20);
      setConductores(list);
      setConductoresCargados(true);
    } finally {
      setCargandoTab(false);
    }
  }, [isAdmin]);

  const cargarPasajerosLim20 = useCallback(async () => {
    if (!isAdmin) return;
    setCargandoTab(true);
    try {
      const list = await fetchPasajerosAdminPaginado(20);
      setPasajeros(list);
      setPasajerosCargados(true);
    } finally {
      setCargandoTab(false);
    }
  }, [isAdmin]);

  const cargarDuplicados = useCallback(async () => {
    if (!isAdmin) return;
    setCargandoTab(true);
    try {
      const list = conductoresCargados
        ? conductores
        : await fetchConductoresAdminPaginado(20);
      if (!conductoresCargados) {
        setConductores(list);
        setConductoresCargados(true);
      }
      const updates: Record<string, UsuarioPII> = {};
      for (const c of list) {
        if (!piiMap[c.uid]) {
          const pii = await adminFetchPII(c.uid);
          if (pii) updates[c.uid] = pii;
        }
      }
      if (Object.keys(updates).length > 0) {
        setPiiMap((prev) => ({ ...prev, ...updates }));
      }
      setDuplicadosCargados(true);
    } finally {
      setCargandoTab(false);
    }
  }, [isAdmin, conductores, conductoresCargados, piiMap]);

  const cargarSolicitudesLim20 = useCallback(async () => {
    if (!isAdmin) return;
    setCargandoTab(true);
    try {
      const list = await fetchSolicitudesCambioAdmin(20);
      setSolicitudes(list);
      setSolicitudesCargadas(true);
    } finally {
      setCargandoTab(false);
    }
  }, [isAdmin]);

  // Carga perezosa: solo consulta Firestore para la pestaña que el admin selecciona
  useEffect(() => {
    if (!isAdmin) return;
    if (adminTab === 'resumen' && !resumen) {
      void cargarResumen();
    } else if (adminTab === 'pendientes' && !pendientesCargados) {
      void cargarPendientesLim20();
    } else if (
      (adminTab === 'conductores' || adminTab === 'alertas') &&
      !conductoresCargados
    ) {
      void cargarConductoresLim20();
    } else if (adminTab === 'pasajeros' && !pasajerosCargados) {
      void cargarPasajerosLim20();
    } else if (adminTab === 'solicitudes' && !solicitudesCargadas) {
      void cargarSolicitudesLim20();
    } else if (adminTab === 'duplicados' && !duplicadosCargados) {
      void cargarDuplicados();
    }
  }, [
    isAdmin,
    adminTab,
    resumen,
    pendientesCargados,
    conductoresCargados,
    pasajerosCargados,
    solicitudesCargadas,
    duplicadosCargados,
    cargarResumen,
    cargarPendientesLim20,
    cargarConductoresLim20,
    cargarPasajerosLim20,
    cargarSolicitudesLim20,
    cargarDuplicados,
  ]);

  const promedios = useMemo(() => calcularPromediosTarifas(conductores), [conductores]);

  const alertasTarifa = useMemo(() => {
    return conductores
      .map((c) => {
        const res = esTarifaAbusiva(
          c.tarifaBase,
          c.tarifaPorKm,
          promedios.promedioBase,
          promedios.promedioKm
        );
        return { conductor: c, ...res };
      })
      .filter((x) => x.abusiva);
  }, [conductores, promedios]);

  const alertasLicencia = useMemo(() => {
    return conductores.filter((c) => {
      const exp = c.licenciaExp?.toDate?.()?.getTime?.() ?? Date.now();
      const dias = Math.ceil((exp - Date.now()) / (1000 * 60 * 60 * 24));
      return c.mensualidadPendiente || dias <= 7;
    });
  }, [conductores]);

  const duplicados = useMemo(() => {
    const placas: Record<string, Conductor[]> = {};
    const cedulas: Record<string, Conductor[]> = {};
    const telefonos: Record<string, Conductor[]> = {};

    for (const c of conductores) {
      const pKey = c.placa.trim().toUpperCase();
      placas[pKey] = placas[pKey] || [];
      placas[pKey].push(c);

      const ced = (piiMap[c.uid]?.cedula || c.cedulaHash || '').trim();
      if (ced) {
        cedulas[ced] = cedulas[ced] || [];
        cedulas[ced].push(c);
      }

      const tel = (piiMap[c.uid]?.telefono || '').trim();
      if (tel) {
        telefonos[tel] = telefonos[tel] || [];
        telefonos[tel].push(c);
      }
    }

    const hallazgos: Array<{ campo: string; valor: string; nombres: string[] }> = [];
    for (const [k, list] of Object.entries(placas)) {
      if (list.length > 1) {
        hallazgos.push({
          campo: 'Placa duplicada',
          valor: k,
          nombres: list.map((x) => x.nombre),
        });
      }
    }
    for (const [k, list] of Object.entries(cedulas)) {
      if (list.length > 1) {
        hallazgos.push({
          campo: 'Cédula duplicada',
          valor: k,
          nombres: list.map((x) => x.nombre),
        });
      }
    }
    for (const [k, list] of Object.entries(telefonos)) {
      if (list.length > 1) {
        hallazgos.push({
          campo: 'Teléfono duplicado',
          valor: k,
          nombres: list.map((x) => x.nombre),
        });
      }
    }
    return hallazgos;
  }, [conductores, piiMap]);

  const conductoresFiltrados = useMemo(() => {
    if (filtroEstado === 'todos') return conductores;
    return conductores.filter((c) => c.estadoCuenta === filtroEstado);
  }, [conductores, filtroEstado]);

  const { montoActual, montoProximoEnero } = calcularMensualidadActualConAjusteAnual();

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-xl rounded-2xl border border-[#E2E6DF] bg-white p-8 text-center">
        <ShieldCheck className="mx-auto h-10 w-10 text-[#15803D]" />
        <h2 className="mt-3 text-xl font-bold text-[#14231A]">
          Acceso restringido a Administrador
        </h2>
        <p className="mt-1.5 text-sm text-[#525B50]">
          Las reglas de seguridad de Firestore restringen la consulta de teléfonos,
          verificación de cuentas y control de licencias exclusivamente al administrador
          autorizado (<span className="font-mono">sindicatosiserge@gmail.com</span>).
        </p>
      </div>
    );
  }

  const handleCopiarLinkDescarga = async () => {
    const link = (cfgLinkDescarga || configuracion.linkDescarga || DEFAULT_LINK_DESCARGA).trim();
    if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(link);
        setLinkCopiado(true);
        setTimeout(() => setLinkCopiado(false), 2500);
      } catch {
        // Ignorar si clipboard no disponible
      }
    }
  };

  const abrirModalConductor = async (c: Conductor) => {
    setFichaConductor(c);
    setEditNombre(c.nombre);
    setEditPlaca(c.placa);
    setEditTipo(c.vehiculoTipo);
    setEditCapacidad(c.capacidad);
    setEditTarifaBase(c.tarifaBase);
    setEditTarifaKm(c.tarifaPorKm);
    const esPendiente = c.estadoCuenta === 'pendiente';
    setDocsConductor({ docs: null, cargando: esPendiente, abierto: esPendiente });

    const cached = piiMap[c.uid];
    if (cached) {
      setEditTelefono(cached.telefono || '');
      setEditCedula(cached.cedula || c.cedulaHash || '');
      if (esPendiente) {
        const docs = await adminFetchConductorDocumentos(c.uid);
        setDocsConductor({ docs, cargando: false, abierto: true });
      }
      return;
    }

    setEditTelefono('');
    setEditCedula(c.cedulaHash || '');
    setCargandoPiiConductor(true);
    try {
      const [pii, docs] = await Promise.all([
        adminFetchPII(c.uid),
        esPendiente ? adminFetchConductorDocumentos(c.uid) : Promise.resolve(null),
      ]);
      if (pii) {
        setPiiMap((prev) => ({ ...prev, [c.uid]: pii }));
        setEditTelefono(pii.telefono || '');
        setEditCedula(pii.cedula || c.cedulaHash || '');
      }
      if (esPendiente) {
        setDocsConductor({ docs, cargando: false, abierto: true });
      }
    } finally {
      setCargandoPiiConductor(false);
    }
  };

  const handleGuardarConductor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fichaConductor) return;
    setGuardandoConductor(true);
    try {
      await adminActualizarFichaConductor(fichaConductor.uid, {
        nombre: editNombre,
        placa: editPlaca,
        vehiculoTipo: editTipo,
        capacidad: editCapacidad,
        tarifaBase: editTarifaBase,
        tarifaPorKm: editTarifaKm,
        telefono: editTelefono,
        cedula: editCedula,
      });
      setPiiMap((prev) => ({
        ...prev,
        [fichaConductor.uid]: {
          uid: fichaConductor.uid,
          telefono: editTelefono,
          cedula: editCedula,
        },
      }));
      setConductores((prev) =>
        prev.map((item) =>
          item.uid === fichaConductor.uid
            ? {
                ...item,
                nombre: editNombre,
                placa: editPlaca.toUpperCase(),
                vehiculoTipo: editTipo,
                capacidad: editCapacidad,
                tarifaBase: editTarifaBase,
                tarifaPorKm: editTarifaKm,
                cedulaHash: editCedula,
              }
            : item
        )
      );
      setFichaConductor(null);
    } finally {
      setGuardandoConductor(false);
    }
  };

  const abrirModalPasajero = async (p: Pasajero) => {
    setFichaPasajero(p);
    setPasNombre(p.nombre);
    const cached = piiMap[p.uid];
    if (cached) {
      setPasTelefono(cached.telefono || '');
      setPasEmail(cached.email || '');
      setPasCedula(cached.cedula || '');
      return;
    }
    setPasTelefono('');
    setPasEmail('');
    setPasCedula('');
    setCargandoPiiPasajero(true);
    try {
      const pii = await adminFetchPII(p.uid);
      if (pii) {
        setPiiMap((prev) => ({ ...prev, [p.uid]: pii }));
        setPasTelefono(pii.telefono || '');
        setPasEmail(pii.email || '');
        setPasCedula(pii.cedula || '');
      }
    } finally {
      setCargandoPiiPasajero(false);
    }
  };

  const handleGuardarPasajero = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fichaPasajero) return;
    setGuardandoPasajero(true);
    try {
      await adminActualizarFichaPasajero(fichaPasajero.uid, {
        nombre: pasNombre,
        telefono: pasTelefono,
        email: pasEmail,
        cedula: pasCedula,
      });
      setPiiMap((prev) => ({
        ...prev,
        [fichaPasajero.uid]: {
          uid: fichaPasajero.uid,
          telefono: pasTelefono,
          email: pasEmail,
          cedula: pasCedula,
        },
      }));
      setPasajeros((prev) =>
        prev.map((item) =>
          item.uid === fichaPasajero.uid ? { ...item, nombre: pasNombre } : item
        )
      );
      setFichaPasajero(null);
    } finally {
      setGuardandoPasajero(false);
    }
  };

  const navItems: Array<{
    id: AdminTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'resumen', label: 'Resumen', icon: LayoutDashboard },
    {
      id: 'pendientes',
      label:
        resumen && resumen.conductoresPendientes > 0
          ? `Pendientes (${resumen.conductoresPendientes})`
          : 'Pendientes',
      icon: Clock,
    },
    { id: 'conductores', label: 'Conductores', icon: Car },
    { id: 'pasajeros', label: 'Pasajeros', icon: Users },
    { id: 'solicitudes', label: 'Peticiones', icon: Inbox },
    { id: 'alertas', label: 'Alertas', icon: ShieldAlert },
    { id: 'duplicados', label: 'Duplicados', icon: CopyCheck },
    { id: 'configuracion', label: 'Configuración', icon: Settings },
  ];

  return (
    <div className="space-y-5">
      {/* Menú modular de pestañas del Administrador */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#E2E6DF] bg-white p-2">
        <div className="flex flex-wrap items-center gap-1" role="tablist" aria-label="Secciones de Administrador">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = adminTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setAdminTab(item.id)}
                className={`inline-flex min-h-[42px] items-center gap-2 whitespace-nowrap rounded-xl px-3.5 text-xs font-semibold transition-colors ${
                  active
                    ? 'bg-[#14231A] text-white'
                    : 'text-[#525B50] hover:bg-[#F7F8F6] hover:text-[#14231A]'
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => {
            if (adminTab === 'resumen') void cargarResumen();
            else if (adminTab === 'pendientes') void cargarPendientesLim20();
            else if (adminTab === 'conductores' || adminTab === 'alertas')
              void cargarConductoresLim20();
            else if (adminTab === 'pasajeros') void cargarPasajerosLim20();
            else if (adminTab === 'solicitudes') void cargarSolicitudesLim20();
            else if (adminTab === 'duplicados') void cargarDuplicados();
          }}
          disabled={cargandoTab}
          className="inline-flex min-h-[40px] items-center gap-1.5 whitespace-nowrap rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]/60 disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${cargandoTab ? 'animate-spin' : ''}`} />
          Actualizar
        </button>
      </div>

      {/* PESTAÑA 1: RESUMEN (Solo totales agregados, sin descargar listas ni PII) */}
      {adminTab === 'resumen' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <button
              type="button"
              onClick={() => setAdminTab('conductores')}
              className="rounded-2xl border border-[#E2E6DF] bg-white p-5 text-left transition-colors hover:border-[#15803D]"
            >
              <div className="text-xs text-[#525B50]">Conductores registrados</div>
              <div className="mt-1 font-mono text-3xl font-bold tabular-nums text-[#14231A]">
                {resumen ? resumen.totalConductores : '—'}
              </div>
              <div className="mt-1 text-xs text-[#15803D]">
                {resumen ? `${resumen.conductoresActivos} activos` : 'Conteo ligero'}
              </div>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('pendientes')}
              className="rounded-2xl border border-[#E2E6DF] bg-white p-5 text-left transition-colors hover:border-[#D97706]"
            >
              <div className="text-xs text-[#525B50]">Pendientes de verificación</div>
              <div className="mt-1 font-mono text-3xl font-bold tabular-nums text-[#D97706]">
                {resumen ? resumen.conductoresPendientes : '—'}
              </div>
              <div className="mt-1 text-xs text-[#525B50]">Toca para revisar documentos</div>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('pasajeros')}
              className="rounded-2xl border border-[#E2E6DF] bg-white p-5 text-left transition-colors hover:border-[#15803D]"
            >
              <div className="text-xs text-[#525B50]">Pasajeros registrados</div>
              <div className="mt-1 font-mono text-3xl font-bold tabular-nums text-[#14231A]">
                {resumen ? resumen.totalPasajeros : '—'}
              </div>
              <div className="mt-1 text-xs text-[#525B50]">Toca para abrir fichas</div>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('solicitudes')}
              className="rounded-2xl border border-[#E2E6DF] bg-white p-5 text-left transition-colors hover:border-[#D97706]"
            >
              <div className="text-xs text-[#525B50]">Peticiones de cambio</div>
              <div className="mt-1 font-mono text-3xl font-bold tabular-nums text-[#D97706]">
                {resumen ? resumen.solicitudesPendientes : '—'}
              </div>
              <div className="mt-1 text-xs text-[#525B50]">Toca para aprobar/rechazar</div>
            </button>

            <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
              <div className="text-xs text-[#525B50]">Mensualidad vigente</div>
              <div className="mt-1 font-mono text-3xl font-bold tabular-nums text-[#15803D]">
                {formatearColones(montoActual)}
              </div>
              <div className="mt-1 text-xs text-[#525B50]">
                1 de enero: {formatearColones(montoProximoEnero)} (+10%)
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#E2E6DF] bg-white p-5">
            <div>
              <h3 className="text-base font-bold text-[#14231A]">
                Modo Ahorro de Datos Activo en Resumen
              </h3>
              <p className="mt-0.5 text-xs text-[#525B50]">
                Esta vista solo lee conteos del servidor. Las listas (máx. 20 registros) y
                teléfonos privados solo se consultan al abrir su pestaña correspondiente.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {resumen && resumen.totalConductores === 0 && (
                <button
                  type="button"
                  onClick={async () => {
                    await seedInitialRuralFleetIfNeeded();
                    await cargarResumen();
                  }}
                  className="min-h-[44px] whitespace-nowrap rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]"
                >
                  Sembrar Flota Rural Inicial
                </button>
              )}
              <button
                type="button"
                onClick={() =>
                  onPushNotificacion(
                    'Recordatorio mensual enviado a conductores',
                    `Se notificó el cobro mensual de ${formatearColones(montoActual)} colones (ajuste +10% cada 1 de enero).`,
                    'mensualidad'
                  )
                }
                className="inline-flex min-h-[44px] items-center gap-2 whitespace-nowrap rounded-xl bg-[#15803D] px-4 text-xs font-semibold text-white hover:bg-[#166534]"
              >
                <Bell className="h-4 w-4" />
                Enviar recordatorio mensual ({formatearColones(montoActual)})
              </button>
            </div>
          </div>

          {/* Enlace de Descarga de la App (Copia rápida y sincronizado con Compartir App) */}
          <div className="rounded-2xl border border-[#15803D]/30 bg-[#F0FDF4] p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 text-sm font-bold text-[#14231A]">
                  <Link2 className="h-4 w-4 text-[#15803D]" />
                  Enlace de Descarga de la App (Compartir)
                </div>
                <p className="mt-0.5 text-xs text-[#525B50]">
                  Mismo enlace que usan Pasajeros y Conductores en el botón &ldquo;Compartir App&rdquo; por WhatsApp.
                </p>
                <div className="mt-2 truncate rounded-xl border border-[#E2E6DF] bg-white px-3 py-2 font-mono text-xs font-semibold text-[#15803D]">
                  {configuracion.linkDescarga || DEFAULT_LINK_DESCARGA}
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={handleCopiarLinkDescarga}
                  className="inline-flex min-h-[44px] items-center gap-2 whitespace-nowrap rounded-xl bg-[#15803D] px-4 text-xs font-semibold text-white hover:bg-[#166534]"
                >
                  <Copy className="h-4 w-4" />
                  {linkCopiado ? '¡Enlace copiado!' : 'Copiar enlace'}
                </button>
                <button
                  type="button"
                  onClick={() => setAdminTab('configuracion')}
                  className="inline-flex min-h-[44px] items-center gap-2 whitespace-nowrap rounded-xl border border-[#E2E6DF] bg-white px-4 text-xs font-semibold text-[#14231A] hover:bg-[#F7F8F6]"
                >
                  Editar en Configuración
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PESTAÑA 1B: PENDIENTES DE VERIFICACIÓN (Revisión de documentos y aprobación 1 mes) */}
      {adminTab === 'pendientes' && (
        <div className="space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-5">
          <div className="border-b border-[#E2E6DF] pb-4">
            <h3 className="text-lg font-bold text-[#14231A]">
              Conductores Pendientes de Verificación ({pendientes.length})
            </h3>
            <p className="text-xs text-[#525B50]">
              Toca la ficha de un conductor pendiente para revisar las fotos de sus documentos (Vehículo, Cédula, Licencia, RTV) y aprobar su activación con 1 mes de licencia.
            </p>
          </div>

          {cargandoTab && !pendientesCargados ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              Consultando conductores pendientes en Firestore...
            </p>
          ) : pendientes.length === 0 ? (
            <div className="rounded-xl border border-dashed border-[#E2E6DF] py-8 text-center text-sm text-[#525B50]">
              No hay conductores pendientes de verificación en este momento.
            </div>
          ) : (
            <div className="divide-y divide-[#E2E6DF]">
              {pendientes.map((c) => (
                <button
                  key={c.uid}
                  type="button"
                  onClick={() => abrirModalConductor(c)}
                  className="flex w-full items-center justify-between gap-3 rounded-xl px-2 py-3.5 text-left transition-colors hover:bg-[#FFFBEB]"
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <img
                      src={c.fotoUrl || DRIVER_AVATARS['driver-carlos']}
                      alt={c.nombre}
                      referrerPolicy="no-referrer"
                      className="h-11 w-11 shrink-0 rounded-full border border-[#D97706]/40 object-cover"
                    />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="truncate text-sm font-bold text-[#14231A]">{c.nombre}</span>
                        <span className="text-xs font-semibold text-[#D97706]">· PENDIENTE</span>
                      </div>
                      <div className="mt-0.5 text-xs text-[#525B50]">
                        {c.vehiculoTipo} · Placa <span className="font-mono font-semibold">{c.placa}</span> · Base{' '}
                        {formatearColones(c.tarifaBase)}
                      </div>
                    </div>
                  </div>
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-xl border border-[#D97706]/40 bg-[#FFFBEB] px-3 py-1.5 text-xs font-semibold text-[#92400E]">
                    Ver documentos
                    <ChevronRight className="h-4 w-4" />
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PESTAÑA 2: CONDUCTORES (Consulta bajo demanda limit(20) + Modal Ficha al tocar) */}
      {adminTab === 'conductores' && (
        <div className="space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E2E6DF] pb-4">
            <div>
              <h3 className="text-lg font-bold text-[#14231A]">
                Conductores (consulta máx. 20)
              </h3>
              <p className="text-xs text-[#525B50]">
                Toca cualquier conductor para abrir su ficha, fotos y documentos en ventana modal.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {(['todos', 'pendiente', 'activo', 'bloqueado'] as const).map((est) => (
                <button
                  key={est}
                  type="button"
                  onClick={() => setFiltroEstado(est)}
                  className={`min-h-[38px] whitespace-nowrap rounded-xl px-3 text-xs font-semibold capitalize transition-colors ${
                    filtroEstado === est
                      ? 'bg-[#14231A] text-white'
                      : 'bg-[#F7F8F6] text-[#14231A] hover:bg-[#E2E6DF]/60'
                  }`}
                >
                  {est}
                </button>
              ))}
            </div>
          </div>

          {cargandoTab && !conductoresCargados ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              Consultando primeros 20 conductores en Firestore...
            </p>
          ) : conductoresFiltrados.length === 0 ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              No hay conductores en esta categoría.
            </p>
          ) : (
            <div className="divide-y divide-[#E2E6DF]">
              {conductoresFiltrados.map((c) => {
                const tarifaCheck = esTarifaAbusiva(
                  c.tarifaBase,
                  c.tarifaPorKm,
                  promedios.promedioBase,
                  promedios.promedioKm
                );
                const infoLic = calcularDiasLicenciaRestantes(c.licenciaExp);
                return (
                  <button
                    key={c.uid}
                    type="button"
                    onClick={() => abrirModalConductor(c)}
                    className="flex w-full items-center justify-between gap-3 rounded-xl px-2 py-3.5 text-left transition-colors hover:bg-[#F7F8F6]"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <img
                        src={c.fotoUrl || DRIVER_AVATARS['driver-carlos']}
                        alt={c.nombre}
                        referrerPolicy="no-referrer"
                        className="h-11 w-11 shrink-0 rounded-full border border-[#E2E6DF] object-cover"
                      />
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="truncate text-sm font-bold text-[#14231A]">
                            {c.nombre}
                          </span>
                          <span
                            className={`text-xs font-semibold ${
                              c.estadoCuenta === 'activo'
                                ? 'text-[#15803D]'
                                : c.estadoCuenta === 'pendiente'
                                ? 'text-[#D97706]'
                                : 'text-[#DC2626]'
                            }`}
                          >
                            · {c.estadoCuenta.toUpperCase()}
                          </span>
                          {tarifaCheck.abusiva && (
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#DC2626]">
                              <AlertTriangle className="h-3.5 w-3.5" />
                              Tarifa +30%
                            </span>
                          )}
                        </div>
                        <div className="mt-0.5 flex flex-wrap items-center gap-x-2.5 text-xs text-[#525B50]">
                          <span>
                            {c.vehiculoTipo} · <span className="font-mono">{c.placa}</span>
                          </span>
                          <span>·</span>
                          <span className="font-mono font-semibold text-[#15803D] tabular-nums">
                            Mes: {formatearColones(c.gananciasMes ?? 0)}
                          </span>
                          <span>·</span>
                          <span
                            className={`font-mono font-semibold tabular-nums ${
                              infoLic.estado === 'vencida'
                                ? 'text-[#DC2626]'
                                : infoLic.estado === 'por_vencer'
                                ? 'text-[#D97706]'
                                : 'text-[#14231A]'
                            }`}
                          >
                            Licencia: {infoLic.etiqueta} ({infoLic.fechaTexto})
                          </span>
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-[#525B50]" />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* PESTAÑA 3: PASAJEROS (Consulta bajo demanda limit(20) + Modal Ficha al tocar) */}
      {adminTab === 'pasajeros' && (
        <div className="space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-5">
          <div className="border-b border-[#E2E6DF] pb-3.5">
            <h3 className="text-lg font-bold text-[#14231A]">
              Pasajeros Registrados (consulta máx. 20)
            </h3>
            <p className="text-xs text-[#525B50]">
              Toca un pasajero para abrir su ficha completa en ventana modal y modificar nombre,
              teléfono o correo.
            </p>
          </div>

          {cargandoTab && !pasajerosCargados ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              Consultando primeros 20 pasajeros en Firestore...
            </p>
          ) : pasajeros.length === 0 ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              Aún no hay pasajeros registrados en Firestore.
            </p>
          ) : (
            <div className="divide-y divide-[#E2E6DF]">
              {pasajeros.map((p) => (
                <button
                  key={p.uid}
                  type="button"
                  onClick={() => abrirModalPasajero(p)}
                  className="flex w-full items-center justify-between gap-3 rounded-xl px-2 py-3.5 text-left transition-colors hover:bg-[#F7F8F6]"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={p.fotoUrl || PASSENGER_AVATAR}
                      alt={p.nombre}
                      referrerPolicy="no-referrer"
                      className="h-10 w-10 rounded-full border border-[#E2E6DF] object-cover"
                    />
                    <div>
                      <div className="text-sm font-bold text-[#14231A]">{p.nombre}</div>
                      <div className="flex items-center gap-2 text-xs text-[#525B50]">
                        <span>★ {p.promedioCalificacion.toFixed(1)}</span>
                        <span>·</span>
                        <span className={p.bloqueado ? 'font-semibold text-[#DC2626]' : 'text-[#15803D]'}>
                          {p.bloqueado ? 'Bloqueado' : 'Activo'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#15803D]">
                    <span>Ver ficha</span>
                    <ChevronRight className="h-4 w-4" />
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PESTAÑA 3B: PETICIONES DE CAMBIO DE DATOS (Pasajeros y Conductores) */}
      {adminTab === 'solicitudes' && (
        <div className="space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-5">
          <div className="border-b border-[#E2E6DF] pb-3.5">
            <h3 className="text-lg font-bold text-[#14231A]">
              Peticiones de Cambio de Datos (máx. 20)
            </h3>
            <p className="text-xs text-[#525B50]">
              Conductores y pasajeros no pueden alterar sus datos registrados directamente. Aprueba o rechaza aquí cada petición.
            </p>
          </div>

          {cargandoTab && !solicitudesCargadas ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              Consultando peticiones en Firestore...
            </p>
          ) : solicitudes.length === 0 ? (
            <div className="rounded-xl border border-dashed border-[#E2E6DF] py-8 text-center text-sm text-[#525B50]">
              No hay peticiones de cambio de datos registradas.
            </div>
          ) : (
            <div className="space-y-3">
              {solicitudes.map((sol) => (
                <div
                  key={sol.id}
                  className={`rounded-xl border p-4 ${
                    sol.estado === 'pendiente'
                      ? 'border-[#D97706]/50 bg-[#FFFBEB]/60'
                      : 'border-[#E2E6DF] bg-[#F7F8F6]'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-bold text-[#14231A]">
                          {sol.nombreActual}
                        </span>
                        <span className="font-mono text-[11px] font-semibold uppercase text-[#525B50]">
                          · {sol.rol}
                        </span>
                      </div>
                      <div className="text-xs text-[#525B50]">
                        Actual: {sol.resumenActual}
                      </div>
                    </div>
                    <span
                      className={`font-mono text-xs font-bold uppercase ${
                        sol.estado === 'aprobada'
                          ? 'text-[#15803D]'
                          : sol.estado === 'rechazada'
                          ? 'text-[#DC2626]'
                          : 'text-[#D97706]'
                      }`}
                    >
                      {sol.estado}
                    </span>
                  </div>

                  <div className="mt-3 rounded-lg border border-[#E2E6DF] bg-white p-3">
                    <div className="mb-1.5 text-[11px] font-bold uppercase text-[#525B50]">
                      Cambios solicitados
                    </div>
                    <div className="grid grid-cols-1 gap-1.5 text-xs sm:grid-cols-2">
                      {Object.entries(sol.cambios).map(([campo, valor]) => (
                        <div key={campo}>
                          <span className="font-semibold text-[#525B50]">{campo}:</span>{' '}
                          <strong className="font-mono text-[#14231A]">{String(valor)}</strong>
                        </div>
                      ))}
                    </div>
                    <div className="mt-2 border-t border-[#E2E6DF] pt-2 text-xs text-[#333D32]">
                      <strong>Motivo:</strong> {sol.motivo}
                    </div>
                  </div>

                  {sol.estado === 'pendiente' ? (
                    <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
                      <input
                        type="text"
                        value={notasRespuesta[sol.id] || ''}
                        onChange={(e) =>
                          setNotasRespuesta((prev) => ({
                            ...prev,
                            [sol.id]: e.target.value,
                          }))
                        }
                        placeholder="Nota opcional para el usuario..."
                        maxLength={240}
                        className="min-h-[40px] flex-1 rounded-xl border border-[#E2E6DF] bg-white px-3 text-xs"
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          disabled={procesandoSolId === sol.id}
                          onClick={async () => {
                            setProcesandoSolId(sol.id);
                            try {
                              await adminResolverSolicitudCambio(
                                sol,
                                false,
                                notasRespuesta[sol.id]
                              );
                              setSolicitudes((prev) =>
                                prev.map((x) =>
                                  x.id === sol.id
                                    ? {
                                        ...x,
                                        estado: 'rechazada',
                                        respuestaAdmin: notasRespuesta[sol.id] || undefined,
                                      }
                                    : x
                                )
                              );
                              setResumen((r) =>
                                r
                                  ? {
                                      ...r,
                                      solicitudesPendientes: Math.max(
                                        0,
                                        r.solicitudesPendientes - 1
                                      ),
                                    }
                                  : r
                              );
                            } finally {
                              setProcesandoSolId(null);
                            }
                          }}
                          className="min-h-[40px] rounded-xl border border-[#DC2626]/30 bg-white px-3.5 text-xs font-semibold text-[#DC2626] hover:bg-[#FEF2F2] disabled:opacity-50"
                        >
                          Rechazar
                        </button>
                        <button
                          type="button"
                          disabled={procesandoSolId === sol.id}
                          onClick={async () => {
                            setProcesandoSolId(sol.id);
                            try {
                              await adminResolverSolicitudCambio(
                                sol,
                                true,
                                notasRespuesta[sol.id]
                              );
                              setSolicitudes((prev) =>
                                prev.map((x) =>
                                  x.id === sol.id
                                    ? {
                                        ...x,
                                        estado: 'aprobada',
                                        respuestaAdmin: notasRespuesta[sol.id] || undefined,
                                      }
                                    : x
                                )
                              );
                              setConductoresCargados(false);
                              setPasajerosCargados(false);
                              setResumen((r) =>
                                r
                                  ? {
                                      ...r,
                                      solicitudesPendientes: Math.max(
                                        0,
                                        r.solicitudesPendientes - 1
                                      ),
                                    }
                                  : r
                              );
                              onPushNotificacion(
                                'Petición de cambio aprobada',
                                `Se aplicaron los cambios solicitados por ${sol.nombreActual}.`,
                                'alerta'
                              );
                            } finally {
                              setProcesandoSolId(null);
                            }
                          }}
                          className="min-h-[40px] rounded-xl bg-[#15803D] px-4 text-xs font-semibold text-white hover:bg-[#166534] disabled:opacity-50"
                        >
                          {procesandoSolId === sol.id ? 'Aplicando...' : 'Aprobar y aplicar'}
                        </button>
                      </div>
                    </div>
                  ) : (
                    sol.respuestaAdmin && (
                      <div className="mt-2 text-xs text-[#525B50]">
                        <strong>Respuesta Admin:</strong> {sol.respuestaAdmin}
                      </div>
                    )
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PESTAÑA 4: ALERTAS (Tarifas Abusivas >30% + Licencias por vencer) */}
      {adminTab === 'alertas' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-[#DC2626]/30 bg-[#FEF2F2] p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-base font-bold text-[#991B1B]">
                <ShieldAlert className="h-5 w-5 text-[#DC2626]" />
                Alertas de Tarifas Abusivas (&gt;30% del promedio)
              </div>
              <span className="font-mono text-xs text-[#7F1D1D]">
                Promedio flota: {formatearColones(promedios.promedioBase)} +{' '}
                {formatearColones(promedios.promedioKm)}/km
              </span>
            </div>

            {alertasTarifa.length === 0 ? (
              <p className="mt-3 text-xs text-[#7F1D1D]">
                Sin alertas de tarifas abusivas en los conductores consultados.
              </p>
            ) : (
              <div className="mt-3 divide-y divide-[#DC2626]/20">
                {alertasTarifa.map(({ conductor, motivo }) => (
                  <button
                    key={conductor.uid}
                    type="button"
                    onClick={() => abrirModalConductor(conductor)}
                    className="flex w-full items-center justify-between gap-3 py-3 text-left hover:bg-[#DC2626]/5"
                  >
                    <div>
                      <div className="text-sm font-bold text-[#991B1B]">
                        {conductor.nombre} ({conductor.placa})
                      </div>
                      <div className="text-xs text-[#7F1D1D]">{motivo}</div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-[#991B1B]" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-[#D97706]/40 bg-[#FFFBEB] p-5">
            <div className="flex items-center gap-2 text-base font-bold text-[#92400E]">
              <AlertTriangle className="h-5 w-5 text-[#D97706]" />
              Licencias próximas a vencer / Mensualidad pendiente ({alertasLicencia.length})
            </div>
            {alertasLicencia.length === 0 ? (
              <p className="mt-2 text-xs text-[#78350F]">
                Todos los conductores consultados tienen su licencia al día.
              </p>
            ) : (
              <div className="mt-3 divide-y divide-[#D97706]/20">
                {alertasLicencia.map((c) => {
                  const infoLic = calcularDiasLicenciaRestantes(c.licenciaExp);
                  return (
                    <button
                      key={c.uid}
                      type="button"
                      onClick={() => abrirModalConductor(c)}
                      className="flex w-full items-center justify-between gap-3 py-3 text-left hover:bg-[#D97706]/5"
                    >
                      <div>
                        <div className="text-sm font-bold text-[#92400E]">
                          {c.nombre} ({c.placa})
                        </div>
                        <div className="font-mono text-xs text-[#78350F]">
                          <strong>{infoLic.etiqueta}</strong> · Vence: {infoLic.fechaTexto} · Mensualidad{' '}
                          {c.mensualidadPendiente ? 'PENDIENTE' : 'Por renovar'}
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-[#92400E]" />
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* PESTAÑA 5: DUPLICADOS (Placas, Cédulas, Teléfonos) */}
      {adminTab === 'duplicados' && (
        <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
          <div className="flex items-center gap-2 border-b border-[#E2E6DF] pb-3.5">
            <CopyCheck className="h-5 w-5 text-[#D97706]" />
            <div>
              <h3 className="text-lg font-bold text-[#14231A]">
                Verificador de Registros Duplicados
              </h3>
              <p className="text-xs text-[#525B50]">
                Revisa placas, cédulas y teléfonos repetidos entre los primeros 20 conductores.
              </p>
            </div>
          </div>

          {cargandoTab && !duplicadosCargados ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              Analizando duplicados...
            </p>
          ) : duplicados.length === 0 ? (
            <div className="mt-4 rounded-xl border border-[#15803D]/25 bg-[#F0FDF4] p-4 text-xs font-semibold text-[#15803D]">
              No se detectaron placas, cédulas ni teléfonos duplicados.
            </div>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {duplicados.map((d, i) => (
                <li
                  key={i}
                  className="rounded-xl border border-[#D97706]/40 bg-[#FFFBEB] p-3.5 text-xs text-[#78350F]"
                >
                  <strong>{d.campo}</strong> (<span className="font-mono">{d.valor}</span>):{' '}
                  {d.nombres.join(' y ')}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* PESTAÑA 6: CONFIGURACIÓN (WhatsApp 62546546, SINPE, Admin, Tipos de Vehículo, Términos) */}
      {adminTab === 'configuracion' && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setGuardandoConfig(true);
            setConfigGuardadaMsg(null);
            try {
              await adminGuardarConfiguracionGeneral({
                whatsappSoporte: cfgWhatsapp,
                sinpeNumero: cfgSinpe,
                adminNombre: cfgAdminNombre,
                adminTelefono: cfgAdminTel,
                adminEmail: cfgAdminEmail,
                adminSinpeTitular: cfgSinpeTitular,
                terminosCondiciones: cfgTerminos,
                linkDescarga: cfgLinkDescarga,
                tiposVehiculo: cfgTiposVehiculo,
              });
              setConfigGuardadaMsg(
                `Configuración guardada: Soporte WhatsApp ${cfgWhatsapp}, SINPE ${cfgSinpe}, link de descarga (${cfgLinkDescarga}), ${cfgTiposVehiculo.length} tipos de vehículo y Términos actualizados.`
              );
            } finally {
              setGuardandoConfig(false);
            }
          }}
          className="space-y-5 rounded-2xl border border-[#E2E6DF] bg-white p-5"
        >
          <div className="border-b border-[#E2E6DF] pb-3">
            <h3 className="text-lg font-bold text-[#14231A]">
              Soporte WhatsApp, SINPE Móvil, Datos Admin, Link de Descarga, Vehículos y Términos
            </h3>
            <p className="mt-0.5 text-xs text-[#525B50]">
              Edita el WhatsApp de soporte y número SINPE (
              <span className="font-mono font-semibold">62546546</span>), el enlace de descarga compartido en toda la app, agrega nuevos tipos de vehículo y actualiza los Términos.
            </p>
          </div>

          <div className="rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] p-4">
            <label className="mb-1.5 flex items-center gap-1.5 text-xs font-bold text-[#14231A]">
              <Link2 className="h-4 w-4 text-[#15803D]" />
              Enlace de Descarga de la App (usado por el botón &ldquo;Compartir App&rdquo;)
            </label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <input
                required
                type="url"
                maxLength={500}
                value={cfgLinkDescarga}
                onChange={(e) => setCfgLinkDescarga(e.target.value)}
                placeholder={DEFAULT_LINK_DESCARGA}
                className="min-h-[44px] flex-1 rounded-xl border border-[#E2E6DF] bg-white px-3 font-mono text-xs text-[#14231A]"
              />
              <button
                type="button"
                onClick={handleCopiarLinkDescarga}
                className="inline-flex min-h-[44px] items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-[#15803D] px-4 text-xs font-semibold text-white hover:bg-[#166534]"
              >
                <Copy className="h-4 w-4" />
                {linkCopiado ? '¡Copiado!' : 'Copiar enlace'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                Número WhatsApp de Soporte
              </label>
              <input
                required
                minLength={8}
                maxLength={20}
                value={cfgWhatsapp}
                onChange={(e) => setCfgWhatsapp(e.target.value)}
                placeholder="62546546"
                className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                Número para Pago SINPE Móvil
              </label>
              <input
                required
                minLength={8}
                maxLength={20}
                value={cfgSinpe}
                onChange={(e) => setCfgSinpe(e.target.value)}
                placeholder="62546546"
                className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                Titular de Cuenta SINPE
              </label>
              <input
                required
                minLength={2}
                maxLength={100}
                value={cfgSinpeTitular}
                onChange={(e) => setCfgSinpeTitular(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                Nombre del Administrador
              </label>
              <input
                required
                minLength={2}
                maxLength={100}
                value={cfgAdminNombre}
                onChange={(e) => setCfgAdminNombre(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                Teléfono del Administrador
              </label>
              <input
                required
                minLength={6}
                maxLength={30}
                value={cfgAdminTel}
                onChange={(e) => setCfgAdminTel(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#14231A]">
                Correo del Administrador
              </label>
              <input
                type="email"
                required
                value={cfgAdminEmail}
                onChange={(e) => setCfgAdminEmail(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
              />
            </div>
          </div>

          <div className="space-y-3 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4">
            <div className="text-xs font-bold text-[#14231A]">
              Tipos de Vehículos Habilitados ({cfgTiposVehiculo.length})
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {cfgTiposVehiculo.map((vt, idx) => (
                <div
                  key={`${vt.nombre}_${idx}`}
                  className="flex items-start justify-between gap-2 rounded-xl border border-[#E2E6DF] bg-white p-3"
                >
                  <div>
                    <div className="text-xs font-bold text-[#14231A]">
                      {vt.nombre}{' '}
                      <span className="font-mono font-normal text-[#15803D]">
                        (Hasta {vt.maxPasajeros} pax)
                      </span>
                    </div>
                    <div className="mt-0.5 text-[11px] text-[#525B50]">{vt.descripcion}</div>
                  </div>
                  {cfgTiposVehiculo.length > 1 && (
                    <button
                      type="button"
                      onClick={() =>
                        setCfgTiposVehiculo((prev) => prev.filter((_, i) => i !== idx))
                      }
                      className="rounded-lg px-2 py-1 text-[11px] font-semibold text-[#DC2626] hover:bg-[#FEF2F2]"
                    >
                      Quitar
                    </button>
                  )}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 gap-2 pt-1 sm:grid-cols-12">
              <input
                type="text"
                value={nuevoTipoNombre}
                onChange={(e) => setNuevoTipoNombre(e.target.value)}
                placeholder="Nuevo tipo (Ej: Moto, Cuadraciclo)"
                className="min-h-[40px] rounded-xl border border-[#E2E6DF] bg-white px-3 text-xs sm:col-span-4"
              />
              <input
                type="number"
                min={1}
                max={24}
                value={nuevoTipoPax}
                onChange={(e) => setNuevoTipoPax(Number(e.target.value))}
                placeholder="Max pax"
                className="min-h-[40px] rounded-xl border border-[#E2E6DF] bg-white px-3 font-mono text-xs sm:col-span-2"
              />
              <input
                type="text"
                value={nuevoTipoDesc}
                onChange={(e) => setNuevoTipoDesc(e.target.value)}
                placeholder="Descripción corta"
                className="min-h-[40px] rounded-xl border border-[#E2E6DF] bg-white px-3 text-xs sm:col-span-4"
              />
              <button
                type="button"
                onClick={() => {
                  const nombreLimpio = nuevoTipoNombre.trim();
                  if (!nombreLimpio) return;
                  if (
                    cfgTiposVehiculo.some(
                      (t) => t.nombre.toLowerCase() === nombreLimpio.toLowerCase()
                    )
                  ) {
                    return;
                  }
                  setCfgTiposVehiculo((prev) => [
                    ...prev,
                    {
                      nombre: nombreLimpio,
                      maxPasajeros: Math.max(1, Math.min(24, nuevoTipoPax || 1)),
                      descripcion:
                        nuevoTipoDesc.trim() ||
                        `${nombreLimpio} · Hasta ${Math.max(1, nuevoTipoPax || 1)} pax`,
                    },
                  ]);
                  setNuevoTipoNombre('');
                  setNuevoTipoPax(1);
                  setNuevoTipoDesc('');
                }}
                className="min-h-[40px] rounded-xl bg-[#14231A] px-3 text-xs font-semibold text-white hover:bg-[#1E3527] sm:col-span-2"
              >
                + Agregar tipo
              </button>
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold text-[#14231A]">
              Términos y Condiciones (editables en tiempo real)
            </label>
            <textarea
              required
              minLength={20}
              maxLength={8000}
              rows={6}
              value={cfgTerminos}
              onChange={(e) => setCfgTerminos(e.target.value)}
              className="w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 text-xs leading-relaxed text-[#14231A]"
            />
          </div>

          {configGuardadaMsg && (
            <div className="rounded-xl border border-[#15803D]/30 bg-[#15803D]/10 p-3 text-xs font-semibold text-[#15803D]">
              {configGuardadaMsg}
            </div>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={guardandoConfig}
              className="min-h-[44px] rounded-xl bg-[#15803D] px-6 text-sm font-semibold text-white hover:bg-[#166534] disabled:opacity-60"
            >
              {guardandoConfig ? 'Guardando...' : 'Guardar Configuración y Términos'}
            </button>
          </div>
        </form>
      )}

      {/* MODAL ÚNICO DE FICHA DE CONDUCTOR (Se abre al tocar en Conductores o Alertas) */}
      {fichaConductor && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-3 border-b border-[#E2E6DF] pb-4">
              <div className="flex items-center gap-3">
                <img
                  src={fichaConductor.fotoUrl || DRIVER_AVATARS['driver-carlos']}
                  alt={fichaConductor.nombre}
                  referrerPolicy="no-referrer"
                  className="h-12 w-12 rounded-full border border-[#E2E6DF] object-cover"
                />
                <div>
                  <h3 className="text-lg font-bold text-[#14231A]">
                    Ficha de Conductor — {fichaConductor.nombre}
                  </h3>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#525B50]">
                    <span className="font-mono">
                      Cobrado este mes: {formatearColones(fichaConductor.gananciasMes ?? 0)}
                    </span>
                    <span>·</span>
                    <span>★ {fichaConductor.promedioCalificacion.toFixed(1)}</span>
                    <span>·</span>
                    <span className="font-semibold uppercase">
                      {fichaConductor.estadoCuenta}
                    </span>
                    <span>·</span>
                    {(() => {
                      const licModal = calcularDiasLicenciaRestantes(fichaConductor.licenciaExp);
                      return (
                        <span
                          className={`font-mono font-bold ${
                            licModal.estado === 'vencida'
                              ? 'text-[#DC2626]'
                              : licModal.estado === 'por_vencer'
                              ? 'text-[#D97706]'
                              : 'text-[#15803D]'
                          }`}
                        >
                          Licencia: {licModal.etiqueta} ({licModal.fechaTexto})
                        </span>
                      );
                    })()}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setFichaConductor(null)}
                className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl border border-[#E2E6DF] hover:bg-[#F7F8F6]"
                aria-label="Cerrar ficha de conductor"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Acciones rápidas en modal */}
            <div className="mt-4 flex flex-wrap gap-2">
              {fichaConductor.estadoCuenta === 'pendiente' && (
                <button
                  type="button"
                  disabled={aprobandoConductor}
                  onClick={async () => {
                    setAprobandoConductor(true);
                    try {
                      const nuevaExp = await adminAprobarYActivarConductor1Mes(fichaConductor.uid);
                      const actualizado: Conductor = {
                        ...fichaConductor,
                        estadoCuenta: 'activo',
                        estadoOperativo: 'disponible',
                        licenciaExp: nuevaExp,
                        mensualidadPendiente: false,
                      };
                      setFichaConductor(actualizado);
                      setPendientes((prev) => prev.filter((x) => x.uid !== fichaConductor.uid));
                      setConductores((prev) =>
                        prev.map((x) => (x.uid === fichaConductor.uid ? actualizado : x))
                      );
                      setResumen((r) =>
                        r
                          ? {
                              ...r,
                              conductoresPendientes: Math.max(0, r.conductoresPendientes - 1),
                              conductoresActivos: r.conductoresActivos + 1,
                            }
                          : r
                      );
                      onPushNotificacion(
                        'Conductor aprobado y activado',
                        `${fichaConductor.nombre} ahora está activo con licencia vigente por 1 mes.`,
                        'aceptado'
                      );
                    } finally {
                      setAprobandoConductor(false);
                    }
                  }}
                  className="inline-flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl bg-[#15803D] px-4 text-sm font-bold text-white shadow-sm hover:bg-[#166534] disabled:opacity-60"
                >
                  <UserCheck className="h-4 w-4" />
                  {aprobandoConductor
                    ? 'Aprobando...'
                    : 'Aprobar y Activar Conductor (1 mes de licencia)'}
                </button>
              )}

              <button
                type="button"
                onClick={async () => {
                  await adminExtenderLicencia1Mes(fichaConductor);
                  const baseDate =
                    fichaConductor.licenciaExp &&
                    fichaConductor.licenciaExp.toDate().getTime() > Date.now()
                      ? fichaConductor.licenciaExp.toDate()
                      : new Date();
                  const nuevaExp = Timestamp.fromDate(
                    new Date(baseDate.getTime() + 30 * 24 * 60 * 60 * 1000)
                  );
                  setFichaConductor({
                    ...fichaConductor,
                    licenciaExp: nuevaExp,
                    mensualidadPendiente: false,
                  });
                  setConductores((prev) =>
                    prev.map((x) =>
                      x.uid === fichaConductor.uid
                        ? { ...x, licenciaExp: nuevaExp, mensualidadPendiente: false }
                        : x
                    )
                  );
                }}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[#15803D]/30 bg-[#15803D]/10 px-3.5 text-xs font-semibold text-[#15803D]"
              >
                <CalendarPlus className="h-3.5 w-3.5" />
                +1 Mes Licencia
              </button>

              <button
                type="button"
                onClick={async () => {
                  const nextOpen = !docsConductor.abierto;
                  if (!nextOpen) {
                    setDocsConductor((prev) => ({ ...prev, abierto: false }));
                    return;
                  }
                  setDocsConductor({ docs: null, cargando: true, abierto: true });
                  const docs = await adminFetchConductorDocumentos(fichaConductor.uid);
                  setDocsConductor({ docs, cargando: false, abierto: true });
                }}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 text-xs font-semibold text-[#14231A]"
              >
                <FileImage className="h-3.5 w-3.5 text-[#15803D]" />
                {docsConductor.abierto ? 'Ocultar Fotos / Docs' : 'Ver Fotos / Docs'}
              </button>

              <button
                type="button"
                onClick={async () => {
                  const next =
                    fichaConductor.estadoCuenta === 'bloqueado' ? 'activo' : 'bloqueado';
                  await adminCambiarEstadoConductor(fichaConductor.uid, next);
                  setFichaConductor({ ...fichaConductor, estadoCuenta: next });
                  setConductores((prev) =>
                    prev.map((x) =>
                      x.uid === fichaConductor.uid ? { ...x, estadoCuenta: next } : x
                    )
                  );
                }}
                className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-xl px-3.5 text-xs font-semibold ${
                  fichaConductor.estadoCuenta === 'bloqueado'
                    ? 'bg-[#14231A] text-white'
                    : 'border border-[#DC2626]/30 bg-[#DC2626]/10 text-[#DC2626]'
                }`}
              >
                {fichaConductor.estadoCuenta === 'bloqueado' ? (
                  <>
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Desbloquear
                  </>
                ) : (
                  <>
                    <Ban className="h-3.5 w-3.5" />
                    Bloquear
                  </>
                )}
              </button>
            </div>

            {/* Fotos / Docs bajo demanda dentro del modal */}
            {docsConductor.abierto && (
              <div className="mt-4 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4">
                {docsConductor.cargando ? (
                  <p className="text-center text-xs text-[#525B50]">
                    Cargando documentos desde Firestore...
                  </p>
                ) : !docsConductor.docs ? (
                  <p className="text-center text-xs text-[#525B50]">
                    Este conductor no tiene fotos de vehículo o documentos adjuntos.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {[
                      { titulo: 'Foto del Vehículo', src: docsConductor.docs.fotoVehiculo },
                      { titulo: 'Foto de Cédula', src: docsConductor.docs.fotoCedula },
                      { titulo: 'Foto de Licencia', src: docsConductor.docs.fotoLicencia },
                      {
                        titulo: 'Circulación / RTV / Marchamo',
                        src: docsConductor.docs.fotoCirculacion,
                      },
                    ].map((item) => (
                      <div key={item.titulo} className="rounded-lg bg-white p-2.5">
                        <div className="mb-1.5 text-[11px] font-bold text-[#14231A]">
                          {item.titulo}
                        </div>
                        {item.src ? (
                          <img
                            src={item.src}
                            alt={item.titulo}
                            className="h-36 w-full rounded object-cover"
                          />
                        ) : (
                          <div className="flex h-36 items-center justify-center rounded border border-dashed border-[#CBD5E1] text-[11px] text-[#525B50]">
                            Sin archivo
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Formulario de edición dentro del modal */}
            <form onSubmit={handleGuardarConductor} className="mt-5 space-y-4">
              {cargandoPiiConductor ? (
                <p className="text-xs text-[#525B50]">
                  Cargando teléfono y cédula privados...
                </p>
              ) : (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-semibold">Nombre</label>
                    <input
                      required
                      value={editNombre}
                      onChange={(e) => setEditNombre(e.target.value)}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold">
                      Teléfono (Solo Admin)
                    </label>
                    <input
                      required
                      value={editTelefono}
                      onChange={(e) => setEditTelefono(e.target.value)}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold">Cédula</label>
                    <input
                      required
                      value={editCedula}
                      onChange={(e) => setEditCedula(e.target.value)}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold">Placa</label>
                    <input
                      required
                      value={editPlaca}
                      onChange={(e) => setEditPlaca(e.target.value)}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm uppercase"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold">Vehículo</label>
                    <select
                      value={editTipo}
                      onChange={(e) => setEditTipo(e.target.value as TipoVehiculo)}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                    >
                      {cfgTiposVehiculo.map((vt) => (
                        <option key={vt.nombre} value={vt.nombre}>
                          {vt.nombre}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold">Capacidad</label>
                    <input
                      type="number"
                      min={1}
                      max={16}
                      value={editCapacidad}
                      onChange={(e) => setEditCapacidad(Number(e.target.value))}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold">Tarifa base (₡)</label>
                    <input
                      type="number"
                      min={500}
                      step={100}
                      value={editTarifaBase}
                      onChange={(e) => setEditTarifaBase(Number(e.target.value))}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold">
                      Precio por kilómetro adicional (₡)
                    </label>
                    <input
                      type="number"
                      min={100}
                      step={50}
                      value={editTarifaKm}
                      onChange={(e) => setEditTarifaKm(Number(e.target.value))}
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                    />
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setFichaConductor(null)}
                  className="min-h-[44px] rounded-xl border border-[#E2E6DF] px-4 text-sm font-semibold"
                >
                  Cerrar
                </button>
                <button
                  type="submit"
                  disabled={guardandoConductor || cargandoPiiConductor}
                  className="min-h-[44px] rounded-xl bg-[#15803D] px-5 text-sm font-semibold text-white hover:bg-[#166534]"
                >
                  {guardandoConductor ? 'Guardando...' : 'Guardar Cambios'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL ÚNICO DE FICHA COMPLETA DE PASAJERO */}
      {fichaPasajero && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleGuardarPasajero}
            className="w-full max-w-md space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl"
          >
            <div className="flex items-start justify-between gap-3 border-b border-[#E2E6DF] pb-3">
              <div className="flex items-center gap-3">
                <img
                  src={fichaPasajero.fotoUrl || PASSENGER_AVATAR}
                  alt={fichaPasajero.nombre}
                  referrerPolicy="no-referrer"
                  className="h-12 w-12 rounded-full border border-[#E2E6DF] object-cover"
                />
                <div>
                  <h3 className="text-lg font-bold text-[#14231A]">Ficha de Pasajero</h3>
                  <p className="font-mono text-xs text-[#525B50]">
                    ★ {fichaPasajero.promedioCalificacion.toFixed(2)} (
                    {fichaPasajero.totalCalificaciones} calif.) ·{' '}
                    {fichaPasajero.bloqueado ? 'BLOQUEADO' : 'ACTIVO'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setFichaPasajero(null)}
                className="flex min-h-[38px] min-w-[38px] items-center justify-center rounded-xl border border-[#E2E6DF]"
                aria-label="Cerrar ficha pasajero"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {cargandoPiiPasajero ? (
              <p className="py-4 text-xs text-[#525B50]">
                Cargando teléfono y correo privados desde Firestore...
              </p>
            ) : (
              <div className="space-y-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold">Nombre completo</label>
                  <input
                    required
                    value={pasNombre}
                    onChange={(e) => setPasNombre(e.target.value)}
                    className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold">Teléfono</label>
                  <input
                    required
                    value={pasTelefono}
                    onChange={(e) => setPasTelefono(e.target.value)}
                    placeholder="+506 8888-8888"
                    className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold">Correo electrónico</label>
                  <input
                    type="email"
                    required
                    value={pasEmail}
                    onChange={(e) => setPasEmail(e.target.value)}
                    placeholder="pasajero@correo.com"
                    className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold">Cédula</label>
                  <input
                    value={pasCedula}
                    onChange={(e) => setPasCedula(e.target.value)}
                    placeholder="1-1234-5678"
                    className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 font-mono text-sm"
                  />
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <button
                type="button"
                onClick={async () => {
                  const next = !fichaPasajero.bloqueado;
                  await adminToggleBloqueoPasajero(fichaPasajero.uid, next);
                  setFichaPasajero({ ...fichaPasajero, bloqueado: next });
                  setPasajeros((prev) =>
                    prev.map((x) =>
                      x.uid === fichaPasajero.uid ? { ...x, bloqueado: next } : x
                    )
                  );
                }}
                className="min-h-[44px] rounded-xl border border-[#DC2626]/30 bg-[#DC2626]/10 px-3.5 text-xs font-semibold text-[#DC2626]"
              >
                {fichaPasajero.bloqueado ? 'Desbloquear acceso' : 'Bloquear acceso'}
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setFichaPasajero(null)}
                  className="min-h-[44px] rounded-xl border border-[#E2E6DF] px-4 text-sm font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={guardandoPasajero || cargandoPiiPasajero}
                  className="min-h-[44px] rounded-xl bg-[#15803D] px-5 text-sm font-semibold text-white hover:bg-[#166534] disabled:opacity-60"
                >
                  {guardandoPasajero ? 'Guardando...' : 'Guardar Ficha'}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
