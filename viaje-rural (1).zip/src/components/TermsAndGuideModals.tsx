import React, { useState } from 'react';
import { Bell, BookOpen, Check, Copy, ExternalLink, FileText, Headphones, ShieldCheck, Smartphone, X } from 'lucide-react';
import {
  buildWhatsAppSupportUrl,
  calcularMensualidadActualConAjusteAnual,
  DEFAULT_CONFIGURACION_GENERAL,
  formatearColones,
} from '../lib/ruralUtils';
import { ConfiguracionGeneral } from '../types/viajeRural';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ComoSeUtilizaModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Cómo se utiliza Viaje Rural"
    >
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl">
        <div className="mb-5 flex items-center justify-between border-b border-[#E2E6DF] pb-4">
          <div className="flex items-center gap-2.5">
            <BookOpen className="h-5 w-5 text-[#15803D]" />
            <h3 className="text-xl font-bold text-[#14231A]">Cómo se utiliza Viaje Rural</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF] hover:bg-[#F7F8F6]"
            aria-label="Cerrar guía"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-5 text-sm leading-relaxed text-[#333D32]">
          <div>
            <h4 className="font-semibold text-[#14231A]">01. Ahorro extremo de datos, batería y Firebase</h4>
            <p className="mt-1">
              El mapa nunca se carga por defecto en las pantallas principales. Solo se abre cuando presionas
              <strong> Ver Mapa</strong> y se destruye al cerrarlo. Además, el conductor en espera mantiene el GPS
              apagado; solo envía un pulso de 1 segundo cuando un pasajero solicita viaje y envía ubicación cada 90
              segundos únicamente durante la recogida.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-[#14231A]">02. Flujo del Pasajero y PIN de Seguridad</h4>
            <p className="mt-1">
              Indica cantidad de pasajeros, destino rural, tu reseña exacta de ubicación (por ejemplo, pulpería o
              portón) y elige uno o más tipos de vehículo con capacidad suficiente. Verás la tarifa base, tarifa por km
              y monto aproximado antes de confirmar. Al aceptar un conductor, verás un <strong>PIN de 3 dígitos
              permanente</strong> en tu pantalla principal hasta que subas al vehículo.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-[#14231A]">03. Flujo del Conductor y Resiliencia</h4>
            <p className="mt-1">
              Recibes ofertas secuenciales por cercanía con 15 segundos para responder. Al aceptar, abres Waze para ir
              a recoger al pasajero. Si cierras la app, al volver a abrirla aparecerá el botón persistente{' '}
              <strong>Retomar recogida (Waze)</strong> o <strong>Retomar viaje al destino (Waze)</strong>. Al llegar,
              ingresa el PIN de 3 dígitos del pasajero para apagar el GPS y habilitar el viaje al destino.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-[#14231A]">04. Pago directo en efectivo</h4>
            <p className="mt-1">
              Viaje Rural es una plataforma de conexión comunitaria. El pago del viaje se realiza directamente en
              efectivo entre pasajero y conductor sin comisiones por viaje.
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] rounded-xl bg-[#15803D] px-6 py-2.5 text-sm font-medium text-white hover:bg-[#166534]"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};

export const TerminosCondicionesModal: React.FC<
  ModalProps & { configuracion?: ConfiguracionGeneral; modoInicial?: 'pasajero' | 'conductor' }
> = ({ isOpen, onClose, configuracion, modoInicial = 'pasajero' }) => {
  const [modoTab, setModoTab] = useState<'pasajero' | 'conductor'>(modoInicial);

  React.useEffect(() => {
    if (isOpen) {
      setModoTab(modoInicial);
    }
  }, [isOpen, modoInicial]);

  if (!isOpen) return null;
  const cfg = configuracion || DEFAULT_CONFIGURACION_GENERAL;
  const { montoActual, montoProximoEnero, anioActual } = calcularMensualidadActualConAjusteAnual();
  const textoPasajero =
    (cfg.terminosCondicionesPasajero && cfg.terminosCondicionesPasajero.trim().length >= 20
      ? cfg.terminosCondicionesPasajero
      : DEFAULT_CONFIGURACION_GENERAL.terminosCondicionesPasajero) || '';
  const textoConductor = cfg.terminosCondiciones || DEFAULT_CONFIGURACION_GENERAL.terminosCondiciones;
  const textoActivo = modoTab === 'pasajero' ? textoPasajero : textoConductor;
  const parrafos = textoActivo
    .split(/\n\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Términos y Condiciones de Viaje Rural"
    >
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between border-b border-[#E2E6DF] pb-4">
          <div className="flex items-center gap-2.5">
            <FileText className="h-5 w-5 text-[#15803D]" />
            <h3 className="text-xl font-bold text-[#14231A]">
              {modoTab === 'pasajero'
                ? 'Términos y Condiciones del Pasajero'
                : 'Términos y Condiciones del Conductor'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF] hover:bg-[#F7F8F6]"
            aria-label="Cerrar términos"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mb-4 grid grid-cols-2 gap-1.5 rounded-xl bg-[#E8ECE5] p-1">
          <button
            type="button"
            onClick={() => setModoTab('pasajero')}
            className={`min-h-[38px] rounded-lg px-3 text-xs font-semibold transition-colors ${
              modoTab === 'pasajero'
                ? 'bg-white text-[#15803D] shadow-sm'
                : 'text-[#525B50] hover:text-[#14231A]'
            }`}
          >
            Pasajero (Sin cobro de app)
          </button>
          <button
            type="button"
            onClick={() => setModoTab('conductor')}
            className={`min-h-[38px] rounded-lg px-3 text-xs font-semibold transition-colors ${
              modoTab === 'conductor'
                ? 'bg-white text-[#14231A] shadow-sm'
                : 'text-[#525B50] hover:text-[#14231A]'
            }`}
          >
            Conductor (Licencia SINPE)
          </button>
        </div>

        <div className="space-y-3.5 text-sm leading-relaxed text-[#333D32]">
          {modoTab === 'pasajero' && (
            <div className="rounded-xl border border-[#15803D]/35 bg-[#F0FDF4] p-3.5 text-xs text-[#14532D]">
              <div className="font-bold">
                0% cobro de app o servicio adicional para el pasajero
              </div>
              <p className="mt-0.5">
                Para el pasajero no se incluye ningún tipo de cobro por uso de la aplicación, comisiones ni cargos adicionales. Únicamente pagas al conductor en efectivo la tarifa acordada por tu viaje.
              </p>
            </div>
          )}

          {parrafos.map((bloque, idx) => (
            <p key={idx} className="whitespace-pre-line">
              {bloque}
            </p>
          ))}

          {modoTab === 'pasajero' ? (
            <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 text-xs text-[#333D32]">
              <div className="font-semibold text-[#14231A]">
                Atención y Soporte para Pasajeros
              </div>
              <div className="mt-1 space-y-0.5 font-mono">
                <div>
                  WhatsApp Soporte: <strong>{cfg.whatsappSoporte}</strong> · Admin: {cfg.adminNombre}
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 text-xs text-[#333D32]">
              <div className="font-semibold text-[#14231A]">
                Datos vigentes de administración y pago SINPE Móvil
              </div>
              <div className="mt-1 space-y-0.5 font-mono">
                <div>
                  Mensualidad {anioActual}: <strong>{formatearColones(montoActual)}</strong> (1 enero{' '}
                  {anioActual + 1}: {formatearColones(montoProximoEnero)})
                </div>
                <div>
                  SINPE Móvil: <strong>{cfg.sinpeNumero}</strong> ({cfg.adminSinpeTitular})
                </div>
                <div>
                  WhatsApp Soporte: <strong>{cfg.whatsappSoporte}</strong> · Admin: {cfg.adminNombre}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 flex items-center justify-between border-t border-[#E2E6DF] pt-4">
          <span className="inline-flex items-center gap-1.5 text-xs text-[#15803D]">
            <ShieldCheck className="h-4 w-4" />
            Vigencia obligatoria en tiempo real
          </span>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] rounded-xl bg-[#14231A] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#1E3527]"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};

export const SoporteWhatsappSinpeModal: React.FC<
  ModalProps & { configuracion?: ConfiguracionGeneral }
> = ({ isOpen, onClose, configuracion }) => {
  const [copiadoSinpe, setCopiadoSinpe] = useState(false);
  if (!isOpen) return null;
  const cfg = configuracion || DEFAULT_CONFIGURACION_GENERAL;
  const { montoActual } = calcularMensualidadActualConAjusteAnual();
  const whatsappUrl = buildWhatsAppSupportUrl(
    cfg.whatsappSoporte,
    `Hola ${cfg.adminNombre}, escribo desde Viaje Rural para soporte / comprobante SINPE.`
  );

  const copiarSinpe = async () => {
    try {
      await navigator.clipboard.writeText(cfg.sinpeNumero);
      setCopiadoSinpe(true);
      setTimeout(() => setCopiadoSinpe(false), 1800);
    } catch {
      // Ignorar si el navegador restringe portapapeles
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Soporte WhatsApp y Pago SINPE Móvil"
    >
      <div className="w-full max-w-md rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between border-b border-[#E2E6DF] pb-3">
          <div className="flex items-center gap-2.5">
            <Headphones className="h-5 w-5 text-[#15803D]" />
            <h3 className="text-lg font-bold text-[#14231A]">Soporte y Pago SINPE Móvil</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF] hover:bg-[#F7F8F6]"
            aria-label="Cerrar soporte"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="rounded-xl border border-[#15803D]/30 bg-[#15803D]/5 p-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-[#15803D]">
              <Smartphone className="h-4 w-4" />
              Número para pago SINPE Móvil
            </div>
            <div className="mt-2 flex items-center justify-between gap-3">
              <div>
                <div className="font-mono text-2xl font-bold text-[#14231A] tabular-nums">
                  {cfg.sinpeNumero}
                </div>
                <div className="text-xs text-[#525B50]">
                  Titular: <strong className="text-[#14231A]">{cfg.adminSinpeTitular}</strong>
                </div>
                <div className="mt-0.5 text-xs text-[#525B50]">
                  Mensualidad vigente: <strong className="font-mono">{formatearColones(montoActual)}</strong>
                </div>
              </div>
              <button
                type="button"
                onClick={copiarSinpe}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-white px-3 text-xs font-semibold text-[#14231A] hover:bg-[#F7F8F6]"
              >
                {copiadoSinpe ? <Check className="h-3.5 w-3.5 text-[#15803D]" /> : <Copy className="h-3.5 w-3.5" />}
                {copiadoSinpe ? 'Copiado' : 'Copiar'}
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4 text-xs text-[#333D32]">
            <div className="font-semibold text-[#14231A]">Atención y Administración</div>
            <div className="mt-1 space-y-1">
              <div>
                Encargado: <strong>{cfg.adminNombre}</strong>
              </div>
              <div>
                WhatsApp Soporte: <strong className="font-mono">{cfg.whatsappSoporte}</strong>
              </div>
              <div>
                Teléfono admin: <strong className="font-mono">{cfg.adminTelefono}</strong>
              </div>
              <div>
                Correo: <span className="font-mono">{cfg.adminEmail}</span>
              </div>
            </div>
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#15803D] px-5 text-sm font-semibold text-white transition-colors hover:bg-[#166534]"
          >
            <ExternalLink className="h-4 w-4" />
            Abrir WhatsApp de Soporte ({cfg.whatsappSoporte})
          </a>
        </div>
      </div>
    </div>
  );
};

export const NotificacionesDrawerModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  notificaciones: Array<{
    id: string;
    titulo: string;
    cuerpo: string;
    tipo: string;
    hora: string;
  }>;
}> = ({ isOpen, onClose, notificaciones }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Centro de Notificaciones FCM"
    >
      <div className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-[#E2E6DF] bg-white p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between border-b border-[#E2E6DF] pb-3">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-[#15803D]" />
            <h3 className="text-lg font-bold text-[#14231A]">Notificaciones FCM de Alta Prioridad</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF] hover:bg-[#F7F8F6]"
            aria-label="Cerrar notificaciones"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-3">
          {notificaciones.length === 0 ? (
            <p className="py-8 text-center text-sm text-[#525B50]">
              No hay notificaciones nuevas en esta sesión.
            </p>
          ) : (
            notificaciones.map((n) => (
              <div key={n.id} className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5">
                <div className="flex items-center justify-between gap-2 text-xs text-[#525B50]">
                  <span className="font-semibold text-[#15803D]">{n.tipo.toUpperCase()}</span>
                  <span className="font-mono">{n.hora}</span>
                </div>
                <div className="mt-1 text-sm font-semibold text-[#14231A]">{n.titulo}</div>
                <p className="mt-0.5 text-xs text-[#525B50]">{n.cuerpo}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

