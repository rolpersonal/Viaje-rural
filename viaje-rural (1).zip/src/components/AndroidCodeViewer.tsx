import React, { useState } from 'react';
import { Check, Copy, Download, FileCode2 } from 'lucide-react';
import rootBuildGradle from '../../android-native/build.gradle?raw';
import appBuildGradle from '../../android-native/app/build.gradle?raw';
import settingsGradle from '../../android-native/settings.gradle?raw';
import manifestXml from '../../android-native/app/src/main/AndroidManifest.xml?raw';
import viajeRuralAppKt from '../../android-native/app/src/main/java/cr/viajerural/app/ViajeRuralApp.kt?raw';
import mainActivityKt from '../../android-native/app/src/main/java/cr/viajerural/app/MainActivity.kt?raw';
import proguardRulesRaw from '../../android-native/app/proguard-rules.pro?raw';
import pickupLocationServiceKt from '../../android-native/app/src/main/java/cr/viajerural/app/service/PickupLocationService.kt?raw';
import monthlyReminderWorkerKt from '../../android-native/app/src/main/java/cr/viajerural/app/worker/MonthlyPaymentReminderWorker.kt?raw';
import viajeRepositoryKt from '../../android-native/app/src/main/java/cr/viajerural/app/data/ViajeRepository.kt?raw';
import viajeViewModelsKt from '../../android-native/app/src/main/java/cr/viajerural/app/viewmodel/ViajeRuralViewModels.kt?raw';
import authScreenKt from '../../android-native/app/src/main/java/cr/viajerural/app/ui/AuthScreen.kt?raw';
import pasajeroScreenKt from '../../android-native/app/src/main/java/cr/viajerural/app/ui/PasajeroScreen.kt?raw';
import conductorScreenKt from '../../android-native/app/src/main/java/cr/viajerural/app/ui/ConductorScreen.kt?raw';
import adminScreenKt from '../../android-native/app/src/main/java/cr/viajerural/app/ui/AdminScreen.kt?raw';
import messagingServiceKt from '../../android-native/app/src/main/java/cr/viajerural/app/messaging/ViajeRuralMessagingService.kt?raw';
import themesXml from '../../android-native/app/src/main/res/values/themes.xml?raw';
import stringsXml from '../../android-native/app/src/main/res/values/strings.xml?raw';
import colorsXml from '../../android-native/app/src/main/res/values/colors.xml?raw';
import icLauncherXml from '../../android-native/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml?raw';
import icLauncherRoundXml from '../../android-native/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml?raw';
import icLauncherBgXml from '../../android-native/app/src/main/res/drawable/ic_launcher_background.xml?raw';
import icLauncherFgXml from '../../android-native/app/src/main/res/drawable/ic_launcher_foreground.xml?raw';
import firestoreRulesRaw from '../../firestore.rules?raw';

interface AndroidFileEntry {
  id: string;
  nombre: string;
  ruta: string;
  descripcion: string;
  contenido: string;
}

const ANDROID_FILES: AndroidFileEntry[] = [
  {
    id: 'root-gradle',
    nombre: 'build.gradle (Raíz)',
    ruta: 'build.gradle',
    descripcion: 'Configuración Gradle nivel de proyecto con AGP 8.7.2, Kotlin 2.0.21, Compose Compiler y Google Services.',
    contenido: rootBuildGradle,
  },
  {
    id: 'app-gradle',
    nombre: 'app/build.gradle',
    ruta: 'app/build.gradle',
    descripcion: 'Dependencias Compose, Firebase BoM (Auth/Firestore/FCM), WorkManager 2.10.0, Location 21.3.0 y DataStore.',
    contenido: appBuildGradle,
  },
  {
    id: 'settings-gradle',
    nombre: 'settings.gradle',
    ruta: 'settings.gradle',
    descripcion: 'Repositorios Google/MavenCentral y definición del módulo :app para ViajeRural.',
    contenido: settingsGradle,
  },
  {
    id: 'viajerural-app',
    nombre: 'ViajeRuralApp.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/ViajeRuralApp.kt',
    descripcion: 'Clase Application declarada en AndroidManifest con inicialización try-catch de Firebase.',
    contenido: viajeRuralAppKt,
  },
  {
    id: 'main-activity',
    nombre: 'MainActivity.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/MainActivity.kt',
    descripcion: 'Inicio seguro con try-catch para Firebase y solicitud suave de permisos (ActivityResultLauncher) para Android 13/14.',
    contenido: mainActivityKt,
  },
  {
    id: 'proguard-rules',
    nombre: 'proguard-rules.pro',
    ruta: 'app/proguard-rules.pro',
    descripcion: 'Reglas R8/ProGuard para conservar modelos de Firestore y ViewModels en compilación release.',
    contenido: proguardRulesRaw,
  },
  {
    id: 'repository',
    nombre: 'ViajeRepository.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/data/ViajeRepository.kt',
    descripcion: 'FieldValue.increment() para finanzas, transacción atómica, calificación mutua, ficha de pasajero y recuperación.',
    contenido: viajeRepositoryKt,
  },
  {
    id: 'viewmodels',
    nombre: 'ViajeRuralViewModels.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/viewmodel/ViajeRuralViewModels.kt',
    descripcion: 'AuthViewModel, ConductorViewModel, PasajeroViewModel y AdminViewModel (alerta >30% y finanzas).',
    contenido: viajeViewModelsKt,
  },
  {
    id: 'worker',
    nombre: 'MonthlyPaymentReminderWorker.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/worker/MonthlyPaymentReminderWorker.kt',
    descripcion: 'WorkManager periódico mensual recordando el pago de ₡7,000 colones (+10% el 1 de enero).',
    contenido: monthlyReminderWorkerKt,
  },
  {
    id: 'fcm',
    nombre: 'ViajeRuralMessagingService.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/messaging/ViajeRuralMessagingService.kt',
    descripcion: 'Notificación Heads-up flotante con sonido para chat, Ping 1s por FCM y ofertas de 15s.',
    contenido: messagingServiceKt,
  },
  {
    id: 'auth-ui',
    nombre: 'AuthScreen.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/ui/AuthScreen.kt',
    descripcion: 'Login y Registro separados para Pasajero y Conductor conectados a Firebase Auth.',
    contenido: authScreenKt,
  },
  {
    id: 'pasajero',
    nombre: 'PasajeroScreen.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/ui/PasajeroScreen.kt',
    descripcion: 'PIN persistente, MapView modal bajo demanda, AlertDialog de monto a pagar y calificación 1-5 estrellas.',
    contenido: pasajeroScreenKt,
  },
  {
    id: 'conductor',
    nombre: 'ConductorScreen.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/ui/ConductorScreen.kt',
    descripcion: 'Finanzas simples (Hoy/Mes), AlertDialog de cobro, calificación mutua y botones persistentes Waze.',
    contenido: conductorScreenKt,
  },
  {
    id: 'admin',
    nombre: 'AdminScreen.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/ui/AdminScreen.kt',
    descripcion: 'Ficha editable de pasajeros, alerta de tarifas >30% y monto cobrado mensual por conductor.',
    contenido: adminScreenKt,
  },
  {
    id: 'pickup-service',
    nombre: 'PickupLocationService.kt',
    ruta: 'app/src/main/java/cr/viajerural/app/service/PickupLocationService.kt',
    descripcion: 'ForegroundService que envía GPS cada 90s SOLO en modo recogida y se autodestruye al verificar el PIN.',
    contenido: pickupLocationServiceKt,
  },
  {
    id: 'manifest',
    nombre: 'AndroidManifest.xml',
    ruta: 'app/src/main/AndroidManifest.xml',
    descripcion: 'Permisos de ubicación, notificaciones POST_NOTIFICATIONS, ForegroundService location y Waze queries.',
    contenido: manifestXml,
  },
  {
    id: 'themes-xml',
    nombre: 'res/values/themes.xml',
    ruta: 'app/src/main/res/values/themes.xml',
    descripcion: 'Tema Theme.ViajeRural compatible con Jetpack Compose sin dependencias XML externas.',
    contenido: themesXml,
  },
  {
    id: 'strings-xml',
    nombre: 'res/values/strings.xml',
    ruta: 'app/src/main/res/values/strings.xml',
    descripcion: 'Nombre oficial de la app (@string/app_name).',
    contenido: stringsXml,
  },
  {
    id: 'colors-xml',
    nombre: 'res/values/colors.xml',
    ruta: 'app/src/main/res/values/colors.xml',
    descripcion: 'Paleta base para tema e ícono adaptativo.',
    contenido: colorsXml,
  },
  {
    id: 'ic-launcher',
    nombre: 'mipmap-anydpi-v26/ic_launcher.xml',
    ruta: 'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
    descripcion: 'Ícono adaptativo principal (API 26+).',
    contenido: icLauncherXml,
  },
  {
    id: 'ic-launcher-round',
    nombre: 'mipmap-anydpi-v26/ic_launcher_round.xml',
    ruta: 'app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
    descripcion: 'Ícono adaptativo redondo (API 26+).',
    contenido: icLauncherRoundXml,
  },
  {
    id: 'ic-launcher-bg',
    nombre: 'drawable/ic_launcher_background.xml',
    ruta: 'app/src/main/res/drawable/ic_launcher_background.xml',
    descripcion: 'Fondo vectorial verde rural del ícono.',
    contenido: icLauncherBgXml,
  },
  {
    id: 'ic-launcher-fg',
    nombre: 'drawable/ic_launcher_foreground.xml',
    ruta: 'app/src/main/res/drawable/ic_launcher_foreground.xml',
    descripcion: 'Primer plano vectorial blanco (usado en ícono y notificaciones).',
    contenido: icLauncherFgXml,
  },
  {
    id: 'rules',
    nombre: 'firestore.rules',
    ruta: 'firestore.rules',
    descripcion: 'Reglas de seguridad desplegadas en Firebase con aislamiento de PII, secreto de PIN y finanzas incrementales.',
    contenido: firestoreRulesRaw,
  },
];

export const AndroidCodeViewer: React.FC = () => {
  const [selectedId, setSelectedId] = useState<string>(ANDROID_FILES[0].id);
  const [copiado, setCopiado] = useState(false);

  const archivoActivo = ANDROID_FILES.find((f) => f.id === selectedId) || ANDROID_FILES[0];

  const handleCopiar = async () => {
    await navigator.clipboard.writeText(archivoActivo.contenido);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 1800);
  };

  const handleDescargar = () => {
    const blob = new Blob([archivoActivo.contenido], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = archivoActivo.nombre;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      <div className="space-y-2 rounded-2xl border border-[#E2E6DF] bg-white p-4 lg:col-span-4">
        <div className="mb-3 border-b border-[#E2E6DF] pb-3">
          <h2 className="text-lg font-bold text-[#14231A]">
            Código Nativo Android (Kotlin + Compose)
          </h2>
          <p className="mt-0.5 text-xs text-[#525B50]">
            Archivos fuente reales generados en <span className="font-mono">/android-native</span> listos para Android Studio.
          </p>
        </div>

        {ANDROID_FILES.map((file) => {
          const active = file.id === archivoActivo.id;
          return (
            <button
              key={file.id}
              type="button"
              onClick={() => setSelectedId(file.id)}
              className={`flex w-full items-start gap-2.5 rounded-xl border p-3 text-left transition-colors ${
                active
                  ? 'border-[#15803D] bg-[#15803D]/8 text-[#14231A]'
                  : 'border-transparent hover:bg-[#F7F8F6]'
              }`}
            >
              <FileCode2
                className={`mt-0.5 h-4 w-4 shrink-0 ${
                  active ? 'text-[#15803D]' : 'text-[#525B50]'
                }`}
              />
              <div className="min-w-0">
                <div className="truncate font-mono text-xs font-bold">{file.nombre}</div>
                <div className="mt-0.5 line-clamp-2 text-[11px] text-[#525B50]">
                  {file.descripcion}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="flex flex-col overflow-hidden rounded-2xl border border-[#E2E6DF] bg-[#111A14] text-[#E6ECE8] lg:col-span-8">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-3.5">
          <div>
            <div className="font-mono text-sm font-bold text-white">
              {archivoActivo.nombre}
            </div>
            <div className="font-mono text-[11px] text-white/60">
              {archivoActivo.ruta}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopiar}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-white/15 bg-white/10 px-3 text-xs font-medium text-white hover:bg-white/20"
            >
              {copiado ? <Check className="h-3.5 w-3.5 text-[#4ADE80]" /> : <Copy className="h-3.5 w-3.5" />}
              {copiado ? 'Copiado' : 'Copiar'}
            </button>
            <button
              type="button"
              onClick={handleDescargar}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-[#15803D] px-3 text-xs font-medium text-white hover:bg-[#166534]"
            >
              <Download className="h-3.5 w-3.5" />
              Descargar
            </button>
          </div>
        </div>

        <pre className="max-h-[640px] overflow-auto p-5 font-mono text-xs leading-relaxed text-[#D8E5DC]">
          <code>{archivoActivo.contenido}</code>
        </pre>
      </div>
    </div>
  );
};
