import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bookmark,
  BookmarkPlus,
  Car,
  Check,
  Clock,
  FileText,
  Headphones,
  History,
  LocateFixed,
  Lock,
  LogOut,
  MapPin,
  MessageSquare,
  Navigation,
  Radio,
  RefreshCw,
  Search,
  Send,
  Share2,
  ShieldCheck,
  Star,
  Trash2,
  User,
  Users,
  X,
  XCircle,
} from 'lucide-react';
import {
  avanzarColaOfertaSecuencial,
  cancelarSolicitudViaje,
  cancelarViajeConMotivo,
  crearSolicitudCambioDatos,
  crearSolicitudViaje,
  ejecutarPingUnSegundo,
  eliminarRutaFavoritaPasajero,
  enviarCalificacion,
  fetchHistorialPasajero,
  fetchMiPII,
  fetchMisSolicitudesCambio,
  fetchPasajeroById,
  fetchViajeById,
  guardarRutaFavoritaPasajero,
  subscribePinSecreto,
  subscribeUltimoViajeFinalizadoPasajero,
  subscribeViajeActivoPasajero,
} from '../services/viajeService';
import {
  buildWhatsAppShareAppUrl,
  buscarUbicacionesAutocomplete,
  calcularDistanciaKm,
  calcularMontoAproximado,
  capturarUbicacionGpsPrecisa,
  compartirAppEnDispositivo,
  DEFAULT_TIPOS_VEHICULO,
  DRIVER_AVATARS,
  filtrarUbicacionesLocales,
  formatearColones,
  PASSENGER_AVATAR,
  RURAL_DESTINOS,
} from '../lib/ruralUtils';
import {
  CambiosSolicitados,
  Conductor,
  Pasajero,
  RuralDestino,
  RutaFavorita,
  SolicitudCambioDatos,
  TipoVehiculo,
  UsuarioPII,
  VehiculoTipoConfig,
  Viaje,
} from '../types/viajeRural';
import { OnDemandMapModal } from './OnDemandMapModal';
import { ViajeChatModal } from './ViajeChatModal';
import { CancelarViajeModal } from './CancelarViajeModal';

type PasajeroTab = 'viaje' | 'historial' | 'perfil';

interface PasajeroViewProps {
  userUid: string;
  userName: string;
  userPhoto?: string;
  conductoresActivos: Conductor[];
  tiposVehiculo?: VehiculoTipoConfig[];
  linkDescarga?: string;
  onAbrirSoporte?: () => void;
  onAbrirTerminos?: () => void;
  onLogout?: () => void;
  onPushNotificacion: (
    titulo: string,
    cuerpo: string,
    tipo: 'oferta' | 'aceptado' | 'proximidad' | 'mensualidad' | 'alerta'
  ) => void;
  onIncomingChatHeadsUp?: (autor: string, texto: string) => void;
}

export const PasajeroView: React.FC<PasajeroViewProps> = ({
  userUid,
  userName,
  userPhoto,
  conductoresActivos,
  tiposVehiculo,
  linkDescarga,
  onAbrirSoporte,
  onAbrirTerminos,
  onLogout,
  onPushNotificacion,
  onIncomingChatHeadsUp,
}) => {
  // BottomNavigation modular de 3 pestañas: Viaje, Historial (lazy), Perfil (lazy)
  const [activeTab, setActiveTab] = useState<PasajeroTab>('viaje');

  const [viajeActivo, setViajeActivo] = useState<Viaje | null>(null);
  const [ultimoFinalizado, setUltimoFinalizado] = useState<Viaje | null>(null);
  const [pinPersistente, setPinPersistente] = useState<string | null>(null);

  // Modales bajo demanda (Mapa, Chat y Cancelación NO se cargan siempre)
  const [mapaAbierto, setMapaAbierto] = useState(false);
  const [chatAbierto, setChatAbierto] = useState(false);
  const [cancelarModalAbierto, setCancelarModalAbierto] = useState(false);
  const [shareToast, setShareToast] = useState<string | null>(null);
  const [avisoCancelacion, setAvisoCancelacion] = useState<{ por: string; motivo: string } | null>(null);
  const lastViajeActivoIdRef = useRef<string | null>(null);
  const selfCancelledRef = useRef<boolean>(false);

  // Historial bajo demanda (limit(20) solo al tocar la pestaña 'Historial')
  const [historial, setHistorial] = useState<Viaje[]>([]);
  const [historialCargado, setHistorialCargado] = useState(false);
  const [cargandoHistorial, setCargandoHistorial] = useState(false);

  // Perfil, datos protegidos, peticiones al Admin y Rutas Favoritas
  const [pasajeroPerfil, setPasajeroPerfil] = useState<Pasajero | null>(null);
  const [cargandoPerfil, setCargandoPerfil] = useState(false);
  const [miPii, setMiPii] = useState<UsuarioPII | null>(null);
  const [misSolicitudes, setMisSolicitudes] = useState<SolicitudCambioDatos[]>([]);
  const [perfilPiiCargado, setPerfilPiiCargado] = useState(false);
  const [mostrarFormCambio, setMostrarFormCambio] = useState(false);
  const [reqNombre, setReqNombre] = useState('');
  const [reqTelefono, setReqTelefono] = useState('');
  const [reqEmail, setReqEmail] = useState('');
  const [reqCedula, setReqCedula] = useState('');
  const [reqMotivo, setReqMotivo] = useState('');
  const [enviandoSolicitud, setEnviandoSolicitud] = useState(false);
  const [solicitudFeedback, setSolicitudFeedback] = useState<string | null>(null);
  const [rutasFavoritas, setRutasFavoritas] = useState<RutaFavorita[]>([]);
  const [mostrarGuardarFavorita, setMostrarGuardarFavorita] = useState(false);
  const [aliasFavorita, setAliasFavorita] = useState('');
  const [guardandoFavorita, setGuardandoFavorita] = useState(false);

  // Formulario de solicitud (cantidadPasajeros inicia en 0 para obligar a seleccionarla)
  const [cantidadPasajeros, setCantidadPasajeros] = useState(0);
  const [origenNombre, setOrigenNombre] = useState('Santa Elena Centro');
  const [origenLat, setOrigenLat] = useState(9.3895);
  const [origenLng, setOrigenLng] = useState(-83.649);
  const [gpsCapturado, setGpsCapturado] = useState(false);
  const [gpsCalibrando, setGpsCalibrando] = useState(false);
  const [gpsPrecisionMetros, setGpsPrecisionMetros] = useState<number | null>(null);
  const [busquedaDestino, setBusquedaDestino] = useState('Centro de Pérez Zeledón (Mercado)');
  const [destinoSeleccionado, setDestinoSeleccionado] = useState<RuralDestino>(RURAL_DESTINOS[0]);
  const [resenaUbicacion, setResenaUbicacion] = useState('');

  // Autocompletado desplegable para Origen y Destino (ej. "pozuelo")
  const [mostrarSugerenciasOrigen, setMostrarSugerenciasOrigen] = useState(false);
  const [sugerenciasOrigen, setSugerenciasOrigen] = useState<RuralDestino[]>(() =>
    filtrarUbicacionesLocales('')
  );
  const [buscandoOrigen, setBuscandoOrigen] = useState(false);
  const origenBoxRef = useRef<HTMLDivElement | null>(null);

  const [mostrarSugerenciasDestino, setMostrarSugerenciasDestino] = useState(false);
  const [sugerenciasDestino, setSugerenciasDestino] = useState<RuralDestino[]>(() =>
    filtrarUbicacionesLocales('')
  );
  const [buscandoDestino, setBuscandoDestino] = useState(false);
  const destinoBoxRef = useRef<HTMLDivElement | null>(null);

  // Estado del Ping 1s + selección de vehículos
  const [pingEjecutado, setPingEjecutado] = useState(false);
  const [pingEnProgreso, setPingEnProgreso] = useState(false);
  const [conductoresOrdenados, setConductoresOrdenados] = useState<Conductor[]>([]);
  const [tiposSeleccionados, setTiposSeleccionados] = useState<TipoVehiculo[]>([
    'Pickup 4x4',
    'SUV Rural',
  ]);
  const [creandoViaje, setCreandoViaje] = useState(false);
  const [errorForm, setErrorForm] = useState<string | null>(null);

  // Temporizador 15s de oferta secuencial y calificación post-viaje
  const [segundosRestantes, setSegundosRestantes] = useState<number>(15);
  const [estrellas, setEstrellas] = useState(5);
  const [comentarioCalif, setComentarioCalif] = useState('');
  const [calificacionEnviadaIds, setCalificacionEnviadaIds] = useState<Record<string, boolean>>({});
  const [notificadoAceptadoId, setNotificadoAceptadoId] = useState<string | null>(null);
  const [notificadoProximidadId, setNotificadoProximidadId] = useState<string | null>(null);

  // Suscripción única al viaje activo y último finalizado
  useEffect(() => {
    const unsub = subscribeViajeActivoPasajero(userUid, (v) => {
      const prevId = lastViajeActivoIdRef.current;
      setViajeActivo(v);
      if (v) {
        lastViajeActivoIdRef.current = v.id;
        selfCancelledRef.current = false;
        setAvisoCancelacion(null);
      } else {
        setCancelarModalAbierto(false);
        if (prevId && !selfCancelledRef.current) {
          lastViajeActivoIdRef.current = null;
          fetchViajeById(prevId)
            .then((cerrado) => {
              if (cerrado && cerrado.estado === 'cancelado' && cerrado.canceladoPor === 'conductor') {
                const motivoTexto =
                  cerrado.motivoCancelacion || 'El conductor canceló el viaje.';
                localStorage.removeItem(`viaje_rural_pin_${prevId}`);
                setAvisoCancelacion({
                  por: cerrado.conductorNombre || 'El conductor',
                  motivo: motivoTexto,
                });
                onPushNotificacion('Viaje cancelado por el conductor', motivoTexto, 'alerta');
              }
            })
            .catch(() => {});
        } else {
          lastViajeActivoIdRef.current = null;
          selfCancelledRef.current = false;
        }
      }
    });
    const unsubFin = subscribeUltimoViajeFinalizadoPasajero(userUid, (v) => {
      setUltimoFinalizado(v);
    });
    return () => {
      unsub();
      unsubFin();
    };
  }, [userUid, onPushNotificacion]);

  // Cargar perfil ligero del pasajero (1 documento) para Rutas Favoritas y calificación
  useEffect(() => {
    let activo = true;
    const cargar = async () => {
      try {
        const p = await fetchPasajeroById(userUid);
        if (!activo || !p) return;
        setPasajeroPerfil(p);
        setRutasFavoritas(p.rutasFavoritas ?? []);
      } catch {
        // Ignorar si aún no existe el documento
      }
    };
    cargar();
    return () => {
      activo = false;
    };
  }, [userUid]);

  // Carga lazy de PII propio y peticiones al Admin solo cuando el pasajero toca la pestaña Perfil
  useEffect(() => {
    if (activeTab !== 'perfil' || perfilPiiCargado) return;
    let activo = true;
    setCargandoPerfil(true);
    Promise.all([
      fetchMiPII(userUid).catch(() => null),
      fetchMisSolicitudesCambio(userUid).catch(() => []),
    ])
      .then(([pii, sols]) => {
        if (!activo) return;
        setMiPii(pii);
        setMisSolicitudes(sols);
        setPerfilPiiCargado(true);
      })
      .finally(() => {
        if (activo) setCargandoPerfil(false);
      });
    return () => {
      activo = false;
    };
  }, [activeTab, perfilPiiCargado, userUid]);

  // Cerrar dropdowns al hacer clic fuera
  useEffect(() => {
    const onPointerDown = (e: MouseEvent) => {
      const target = e.target as Node;
      if (origenBoxRef.current && !origenBoxRef.current.contains(target)) {
        setMostrarSugerenciasOrigen(false);
      }
      if (destinoBoxRef.current && !destinoBoxRef.current.contains(target)) {
        setMostrarSugerenciasDestino(false);
      }
    };
    document.addEventListener('mousedown', onPointerDown);
    return () => document.removeEventListener('mousedown', onPointerDown);
  }, []);

  // Autocompletado con debounce para Ubicación Actual / Origen
  useEffect(() => {
    if (!mostrarSugerenciasOrigen) return;
    setSugerenciasOrigen(filtrarUbicacionesLocales(origenNombre));
    const q = origenNombre.trim();
    if (q.length < 3) {
      setBuscandoOrigen(false);
      return;
    }
    const controller = new AbortController();
    setBuscandoOrigen(true);
    const timer = setTimeout(async () => {
      const resultados = await buscarUbicacionesAutocomplete(q, controller.signal);
      if (!controller.signal.aborted) {
        setSugerenciasOrigen(resultados);
        setBuscandoOrigen(false);
      }
    }, 280);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [origenNombre, mostrarSugerenciasOrigen]);

  // Autocompletado con debounce para Destino
  useEffect(() => {
    if (!mostrarSugerenciasDestino) return;
    setSugerenciasDestino(filtrarUbicacionesLocales(busquedaDestino));
    const q = busquedaDestino.trim();
    if (q.length < 3) {
      setBuscandoDestino(false);
      return;
    }
    const controller = new AbortController();
    setBuscandoDestino(true);
    const timer = setTimeout(async () => {
      const resultados = await buscarUbicacionesAutocomplete(q, controller.signal);
      if (!controller.signal.aborted) {
        setSugerenciasDestino(resultados);
        setBuscandoDestino(false);
      }
    }, 280);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [busquedaDestino, mostrarSugerenciasDestino]);

  // Carga LAZY del historial SOLO cuando el pasajero toca la pestaña 'Historial'
  const cargarHistorialLazy = async (forzar = false) => {
    if (historialCargado && !forzar) return;
    setCargandoHistorial(true);
    try {
      const list = await fetchHistorialPasajero(userUid);
      setHistorial(list);
      setHistorialCargado(true);
    } finally {
      setCargandoHistorial(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'historial' && !historialCargado) {
      cargarHistorialLazy(false);
    }
    if (activeTab === 'perfil' && !pasajeroPerfil) {
      setCargandoPerfil(true);
      fetchPasajeroById(userUid)
        .then((p) => {
          if (p) {
            setPasajeroPerfil(p);
            setRutasFavoritas(p.rutasFavoritas ?? []);
          }
        })
        .finally(() => setCargandoPerfil(false));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, userUid]);

  // Restaurar PIN persistente desde Firestore + caché local mientras estado == aceptado
  useEffect(() => {
    if (!viajeActivo) {
      setPinPersistente(null);
      setMapaAbierto(false);
      setChatAbierto(false);
      return;
    }
    const cached = localStorage.getItem(`viaje_rural_pin_${viajeActivo.id}`);
    if (cached) setPinPersistente(cached);

    const unsubPin = subscribePinSecreto(viajeActivo.id, (pin) => {
      if (pin) setPinPersistente(pin);
    });

    if (viajeActivo.estado === 'aceptado' && notificadoAceptadoId !== viajeActivo.id) {
      setNotificadoAceptadoId(viajeActivo.id);
      onPushNotificacion(
        '¡Conductor en camino!',
        `${viajeActivo.conductorNombre || 'Tu conductor'} aceptó tu solicitud. Tu PIN es ${cached || 'visible en pantalla'}.`,
        'aceptado'
      );
    }

    if (
      viajeActivo.estado === 'aceptado' &&
      (viajeActivo.etaMinutos ?? 99) <= 3 &&
      notificadoProximidadId !== viajeActivo.id
    ) {
      setNotificadoProximidadId(viajeActivo.id);
      onPushNotificacion(
        'Conductor muy cerca',
        `Tu conductor está a ~${viajeActivo.etaMinutos} min. Ten tu PIN listo para abordar.`,
        'proximidad'
      );
    }

    return () => unsubPin();
  }, [
    viajeActivo,
    notificadoAceptadoId,
    notificadoProximidadId,
    onPushNotificacion,
  ]);

  // Countdown de 15s para cola secuencial
  useEffect(() => {
    if (!viajeActivo || viajeActivo.estado !== 'buscando' || viajeActivo.colaConductores.length === 0) {
      return;
    }
    const tick = () => {
      const expira = viajeActivo.ofertaExpiraAt ?? Date.now() + 15000;
      const diff = Math.max(0, Math.ceil((expira - Date.now()) / 1000));
      setSegundosRestantes(diff);
      if (diff === 0) {
        const idx = viajeActivo.ofertaActualIndex % viajeActivo.colaConductores.length;
        const turnoActual = viajeActivo.colaConductores[idx];
        avanzarColaOfertaSecuencial(viajeActivo.id, turnoActual, false).catch(() => {});
      }
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [viajeActivo]);

  const catalogoVehiculos = useMemo(() => {
    return tiposVehiculo && tiposVehiculo.length > 0
      ? tiposVehiculo
      : DEFAULT_TIPOS_VEHICULO;
  }, [tiposVehiculo]);

  const tiposConCapacidad = useMemo(() => {
    return catalogoVehiculos.filter((v) => v.maxPasajeros >= cantidadPasajeros);
  }, [catalogoVehiculos, cantidadPasajeros]);

  // Sincronizar tipos seleccionados cuando cambia cantidad de pasajeros
  useEffect(() => {
    const nombresValidos = tiposConCapacidad.map((v) => v.nombre);
    setTiposSeleccionados((prev) => {
      const validos = prev.filter((t) => nombresValidos.includes(t));
      return validos.length > 0 ? validos : nombresValidos.slice(0, 2);
    });
  }, [tiposConCapacidad]);

  const distanciaEstimadaKm = useMemo(() => {
    return calcularDistanciaKm(
      origenLat,
      origenLng,
      destinoSeleccionado.lat,
      destinoSeleccionado.lng
    );
  }, [origenLat, origenLng, destinoSeleccionado]);

  const conductoresCompatibles = useMemo(() => {
    const base = pingEjecutado ? conductoresOrdenados : conductoresActivos;
    return base
      .filter(
        (c) =>
          c.estadoCuenta === 'activo' &&
          c.estadoOperativo === 'disponible' &&
          c.capacidad >= cantidadPasajeros &&
          tiposSeleccionados.includes(c.vehiculoTipo)
      )
      .map((c) => {
        const distAlPasajero = calcularDistanciaKm(
          origenLat,
          origenLng,
          c.lat ?? 9.385,
          c.lng ?? -83.682
        );
        const montoAprox = calcularMontoAproximado(
          c.tarifaBase,
          c.tarifaPorKm,
          distanciaEstimadaKm
        );
        return { conductor: c, distAlPasajero, montoAprox };
      })
      .sort((a, b) => a.distAlPasajero - b.distAlPasajero);
  }, [
    pingEjecutado,
    conductoresOrdenados,
    conductoresActivos,
    cantidadPasajeros,
    tiposSeleccionados,
    origenLat,
    origenLng,
    distanciaEstimadaKm,
  ]);

  const handleCapturarGpsUnaVez = async () => {
    setErrorForm(null);
    setMostrarSugerenciasOrigen(false);
    setGpsCalibrando(true);
    try {
      const resultado = await capturarUbicacionGpsPrecisa(4500, 20);
      setOrigenLat(resultado.lat);
      setOrigenLng(resultado.lng);
      setOrigenNombre(`${resultado.nombreDireccion} (${resultado.canton})`);
      setGpsPrecisionMetros(resultado.precisionMetros);
      setGpsCapturado(true);
    } catch (err) {
      setErrorForm(
        err instanceof Error
          ? err.message
          : 'No pudimos obtener tu ubicación GPS precisa. Verifica el permiso de ubicación.'
      );
    } finally {
      setGpsCalibrando(false);
    }
  };

  const handleSeleccionarOrigen = (opcion: RuralDestino) => {
    setOrigenNombre(opcion.nombre);
    setOrigenLat(opcion.lat);
    setOrigenLng(opcion.lng);
    setGpsPrecisionMetros(null);
    setGpsCapturado(true);
    setMostrarSugerenciasOrigen(false);
  };

  const handleSeleccionarDestino = (opcion: RuralDestino) => {
    setDestinoSeleccionado(opcion);
    setBusquedaDestino(opcion.nombre);
    setMostrarSugerenciasDestino(false);
  };

  const handleAplicarRutaFavorita = (fav: RutaFavorita) => {
    setOrigenNombre(fav.origenNombre);
    setOrigenLat(fav.origenLat);
    setOrigenLng(fav.origenLng);
    setGpsCapturado(true);
    setBusquedaDestino(fav.destinoNombre);
    setDestinoSeleccionado({
      nombre: fav.destinoNombre,
      canton: fav.alias,
      lat: fav.destinoLat,
      lng: fav.destinoLng,
    });
    setMostrarSugerenciasOrigen(false);
    setMostrarSugerenciasDestino(false);
    setActiveTab('viaje');
  };

  const handleGuardarRutaFavorita = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!origenNombre.trim() || !(busquedaDestino.trim() || destinoSeleccionado.nombre)) return;
    setGuardandoFavorita(true);
    try {
      const actualizadas = await guardarRutaFavoritaPasajero(userUid, {
        alias: aliasFavorita.trim() || `${origenNombre.slice(0, 20)} → ${(busquedaDestino || destinoSeleccionado.nombre).slice(0, 20)}`,
        origenNombre: origenNombre.trim(),
        origenLat,
        origenLng,
        destinoNombre: busquedaDestino.trim() || destinoSeleccionado.nombre,
        destinoLat: destinoSeleccionado.lat,
        destinoLng: destinoSeleccionado.lng,
      });
      setRutasFavoritas(actualizadas);
      setAliasFavorita('');
      setMostrarGuardarFavorita(false);
      onPushNotificacion(
        'Ruta favorita guardada',
        'Ahora puedes seleccionarla con un toque al pedir un viaje.',
        'aceptado'
      );
    } finally {
      setGuardandoFavorita(false);
    }
  };

  const handleEliminarFavorita = async (rutaId: string) => {
    const actualizadas = await eliminarRutaFavoritaPasajero(userUid, rutaId);
    setRutasFavoritas(actualizadas);
  };

  const handleDispararPing1s = async () => {
    setErrorForm(null);
    if (cantidadPasajeros < 1) {
      setErrorForm('Debes seleccionar la cantidad de pasajeros que van a viajar (mínimo 1).');
      return;
    }
    if (resenaUbicacion.trim().length < 3) {
      setErrorForm('Por favor escribe una reseña exacta de dónde estás (mínimo 3 caracteres).');
      return;
    }
    setPingEnProgreso(true);
    try {
      const disponibles = conductoresActivos.filter(
        (c) => c.estadoCuenta === 'activo' && c.estadoOperativo === 'disponible'
      );
      const ordenados = await ejecutarPingUnSegundo(
        userUid,
        origenLat,
        origenLng,
        disponibles
      );
      setConductoresOrdenados(ordenados);
      setPingEjecutado(true);
      setGpsCapturado(true);
      onPushNotificacion(
        'Ping GPS de 1s enviado',
        `${disponibles.length} conductores activos reportaron coordenadas y apagaron su GPS.`,
        'oferta'
      );
    } finally {
      setPingEnProgreso(false);
    }
  };

  const handleConfirmarSolicitud = async () => {
    setErrorForm(null);
    if (cantidadPasajeros < 1) {
      setErrorForm('Debes seleccionar la cantidad de pasajeros que van a viajar (mínimo 1).');
      return;
    }
    if (tiposSeleccionados.length === 0) {
      setErrorForm('Selecciona al menos un tipo de vehículo con capacidad suficiente.');
      return;
    }
    if (conductoresCompatibles.length === 0) {
      setErrorForm('No hay conductores disponibles para esa combinación ahora mismo. Amplía los tipos de vehículo.');
      return;
    }
    setCreandoViaje(true);
    try {
      const cola = conductoresCompatibles.map((item) => item.conductor);
      const { pin } = await crearSolicitudViaje({
        pasajeroId: userUid,
        pasajeroNombre: userName,
        pasajeroFotoUrl: userPhoto,
        cantidadPasajeros,
        origenNombre,
        origenLat,
        origenLng,
        destinoNombre: busquedaDestino.trim() || destinoSeleccionado.nombre,
        destinoLat: destinoSeleccionado.lat,
        destinoLng: destinoSeleccionado.lng,
        resenaUbicacion,
        tiposVehiculoPermitidos: tiposSeleccionados,
        colaConductoresOrdenada: cola,
      });
      setPinPersistente(pin);
      setPingEjecutado(false);
    } finally {
      setCreandoViaje(false);
    }
  };

  const toggleTipoVehiculo = (tipo: TipoVehiculo) => {
    setTiposSeleccionados((prev) =>
      prev.includes(tipo) ? prev.filter((t) => t !== tipo) : [...prev, tipo]
    );
  };

  const mostrarModalPago =
    ultimoFinalizado &&
    ultimoFinalizado.conductorId &&
    !calificacionEnviadaIds[ultimoFinalizado.id] &&
    !localStorage.getItem(`viaje_rural_rated_driver_${ultimoFinalizado.id}`);

  const conductorEnTurnoUid =
    viajeActivo && viajeActivo.colaConductores.length > 0
      ? viajeActivo.colaConductores[
          viajeActivo.ofertaActualIndex % viajeActivo.colaConductores.length
        ]
      : null;
  const conductorEnTurno = conductoresActivos.find(
    (c) => c.uid === conductorEnTurnoUid
  );

  return (
    <div className="space-y-6">
      {/* MODAL ALERTDIALOG DE PAGO EN EFECTIVO + CALIFICACIÓN (1-5 ESTRELLAS) */}
      {mostrarModalPago && ultimoFinalizado && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Modal de Pago en Efectivo"
        >
          <div className="w-full max-w-md rounded-2xl border border-[#E2E6DF] bg-white p-6 shadow-2xl">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#15803D]">
              Viaje Finalizado — Pago Directo
            </div>
            <h3 className="mt-1 text-xl font-bold text-[#14231A]">
              Monto a Pagar en Efectivo
            </h3>
            <div className="mt-3 rounded-xl border border-[#15803D]/25 bg-[#F0FDF4] p-4 text-center">
              <div className="font-mono text-4xl font-bold tabular-nums text-[#15803D]">
                {formatearColones(ultimoFinalizado.montoAproximado)}
              </div>
              <p className="mt-1 text-xs text-[#525B50]">
                Destino: {ultimoFinalizado.destinoNombre} ({ultimoFinalizado.distanciaKm} km)
              </p>
            </div>

            <div className="mt-5 border-t border-[#E2E6DF] pt-4">
              <div className="text-sm font-semibold text-[#14231A]">
                Califica a {ultimoFinalizado.conductorNombre || 'tu conductor'}
              </div>
              <div className="mt-2.5 flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setEstrellas(n)}
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#E2E6DF] hover:bg-[#F7F8F6]"
                    aria-label={`${n} estrellas`}
                  >
                    <Star
                      className={`h-5 w-5 ${
                        n <= estrellas
                          ? 'fill-[#D97706] text-[#D97706]'
                          : 'text-[#CBD5E1]'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <input
                type="text"
                value={comentarioCalif}
                onChange={(e) => setComentarioCalif(e.target.value)}
                placeholder="Comentario breve (opcional)"
                className="mt-3 min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-sm"
              />
            </div>

            <div className="mt-5 flex gap-2.5">
              <button
                type="button"
                onClick={() => {
                  localStorage.setItem(
                    `viaje_rural_rated_driver_${ultimoFinalizado.id}`,
                    '1'
                  );
                  setCalificacionEnviadaIds((prev) => ({
                    ...prev,
                    [ultimoFinalizado.id]: true,
                  }));
                }}
                className="min-h-[44px] flex-1 rounded-xl border border-[#E2E6DF] text-sm font-semibold text-[#14231A]"
              >
                Omitir
              </button>
              <button
                type="button"
                onClick={async () => {
                  await enviarCalificacion({
                    viajeId: ultimoFinalizado.id,
                    autorUid: userUid,
                    destinatarioUid: ultimoFinalizado.conductorId!,
                    destinatarioRol: 'conductor',
                    estrellas,
                    comentario: comentarioCalif,
                  });
                  localStorage.setItem(
                    `viaje_rural_rated_driver_${ultimoFinalizado.id}`,
                    '1'
                  );
                  setCalificacionEnviadaIds((prev) => ({
                    ...prev,
                    [ultimoFinalizado.id]: true,
                  }));
                }}
                className="min-h-[44px] flex-1 whitespace-nowrap rounded-xl bg-[#15803D] px-4 text-sm font-semibold text-white hover:bg-[#166534]"
              >
                Confirmar y Calificar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* PESTAÑA 1: VIAJE (LIMPIA — SOLO FORMULARIO O VIAJE ACTIVO)            */}
      {/* ===================================================================== */}
      {activeTab === 'viaje' && (
        <>
          {avisoCancelacion && !viajeActivo && (
            <div className="flex flex-wrap items-start justify-between gap-3 rounded-2xl border border-[#DC2626]/30 bg-[#FEF2F2] p-4">
              <div className="space-y-1 text-xs text-[#991B1B]">
                <div className="font-bold">
                  {avisoCancelacion.por} canceló el viaje
                </div>
                <div>
                  Motivo indicado: &ldquo;{avisoCancelacion.motivo}&rdquo;
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAvisoCancelacion(null)}
                className="min-h-[36px] rounded-xl border border-[#DC2626]/30 bg-white px-3 text-xs font-semibold text-[#991B1B] hover:bg-[#FEF2F2]"
              >
                Entendido
              </button>
            </div>
          )}

          {viajeActivo ? (
            <div className="space-y-5">
              {/* PERSISTENCIA DEL PIN (CRÍTICO): Siempre visible en pantalla principal mientras estado == "aceptado" */}
              {viajeActivo.estado === 'aceptado' && (
                <div className="rounded-2xl border-2 border-[#D97706] bg-[#FFFBEB] p-5 shadow-sm">
                  <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                    <div className="space-y-1.5">
                      <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#92400E]">
                        <ShieldCheck className="h-4 w-4" />
                        PIN permanente de abordaje (solo visible para ti)
                      </div>
                      <div className="flex items-baseline gap-4">
                        <span
                          className="font-mono text-5xl font-bold tracking-[0.22em] text-[#14231A]"
                          data-testid="persistent-pin"
                        >
                          {pinPersistente || '---'}
                        </span>
                        <span className="text-sm text-[#78350F]">
                          Entrégalo al conductor al abordar para apagar el GPS de recogida.
                        </span>
                      </div>
                      <p className="text-xs text-[#78350F]">
                        Aunque cierres y vuelvas a abrir la aplicación, este PIN seguirá visible aquí hasta que el conductor lo ingrese.
                      </p>
                    </div>

                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                      <button
                        type="button"
                        onClick={() => setMapaAbierto(true)}
                        className="inline-flex min-h-[48px] items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-[#15803D] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#166534]"
                      >
                        <MapPin className="h-4 w-4" />
                        Ver Mapa (ETA {viajeActivo.etaMinutos ?? 5} min)
                      </button>
                      <button
                        type="button"
                        onClick={() => setChatAbierto(true)}
                        className="inline-flex min-h-[48px] items-center justify-center gap-2 whitespace-nowrap rounded-xl border border-[#E2E6DF] bg-white px-5 py-3 text-sm font-semibold text-[#14231A] hover:bg-[#F7F8F6]"
                      >
                        <MessageSquare className="h-4 w-4 text-[#15803D]" />
                        Abrir Chat
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#E2E6DF] pb-4">
                  <div>
                    <span className="text-xs font-medium text-[#525B50]">
                      Estado del viaje · {viajeActivo.distanciaKm} km · {viajeActivo.cantidadPasajeros} pasajero(s)
                    </span>
                    <h2 className="mt-0.5 text-xl font-bold text-[#14231A]">
                      {viajeActivo.estado === 'buscando' && 'Buscando conductor cercano (Cola 15s)'}
                      {viajeActivo.estado === 'aceptado' && 'Conductor en camino a recogerte'}
                      {viajeActivo.estado === 'en_curso' && 'Viaje en curso hacia tu destino'}
                    </h2>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-[#525B50]">Monto aprox. (Efectivo)</div>
                    <div className="font-mono text-2xl font-bold tabular-nums text-[#15803D]">
                      {formatearColones(viajeActivo.montoAproximado)}
                    </div>
                  </div>
                </div>

                <div className="mt-4 space-y-3 text-sm">
                  <div className="flex items-start gap-2.5">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#D97706]" />
                    <div>
                      <div className="font-medium text-[#14231A]">Origen: {viajeActivo.origenNombre}</div>
                      <div className="text-xs text-[#525B50]">Reseña: {viajeActivo.resenaUbicacion}</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Navigation className="mt-0.5 h-4 w-4 shrink-0 text-[#15803D]" />
                    <div>
                      <div className="font-medium text-[#14231A]">Destino: {viajeActivo.destinoNombre}</div>
                    </div>
                  </div>
                </div>

                {viajeActivo.estado === 'buscando' && (
                  <div className="mt-5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-sm font-medium text-[#14231A]">
                        <Clock className="h-4 w-4 text-[#D97706]" />
                        <span>
                          Ofreciendo a:{' '}
                          <strong>{conductorEnTurno?.nombre || 'Siguiente conductor'}</strong>
                        </span>
                      </div>
                      <span className="font-mono text-lg font-bold tabular-nums text-[#D97706]">
                        {segundosRestantes}s
                      </span>
                    </div>
                    <p className="mt-1.5 text-xs text-[#525B50]">
                      Si no acepta en 15 segundos, la solicitud avanza automáticamente al siguiente conductor más cercano en la cola ({viajeActivo.colaConductores.length} en fila).
                    </p>
                    <button
                      type="button"
                      onClick={() => cancelarSolicitudViaje(viajeActivo.id)}
                      className="mt-3 min-h-[44px] rounded-xl border border-[#E2E6DF] bg-white px-4 py-2 text-xs font-semibold text-[#14231A] hover:bg-neutral-50"
                    >
                      Cancelar solicitud
                    </button>
                  </div>
                )}

                {(viajeActivo.estado === 'aceptado' || viajeActivo.estado === 'en_curso') && (
                  <div className="mt-5 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4">
                    <div className="flex items-center gap-3.5">
                      <img
                        src={
                          viajeActivo.conductorFotoUrl ||
                          DRIVER_AVATARS['driver-carlos']
                        }
                        alt={viajeActivo.conductorNombre || 'Conductor'}
                        referrerPolicy="no-referrer"
                        className="h-14 w-14 rounded-full border border-[#E2E6DF] object-cover"
                      />
                      <div>
                        <div className="text-base font-bold text-[#14231A]">
                          {viajeActivo.conductorNombre}
                        </div>
                        <div className="text-xs text-[#525B50]">
                          {viajeActivo.vehiculoTipoSeleccionado} · Placa{' '}
                          <span className="font-mono font-semibold text-[#14231A]">
                            {viajeActivo.conductorPlaca}
                          </span>
                        </div>
                        <div className="mt-0.5 font-mono text-xs text-[#525B50]">
                          Base {formatearColones(viajeActivo.tarifaBaseAplicada ?? 1500)} +{' '}
                          {formatearColones(viajeActivo.tarifaKmAplicada ?? 650)}/km
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {viajeActivo.estado === 'en_curso' && (
                        <>
                          <span className="rounded-xl border border-[#15803D]/30 bg-[#15803D]/10 px-3.5 py-2 text-xs font-semibold text-[#15803D]">
                            PIN verificado · GPS apagado
                          </span>
                          <button
                            type="button"
                            onClick={() => setChatAbierto(true)}
                            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-white px-4 text-xs font-semibold text-[#14231A] hover:bg-[#F7F8F6]"
                          >
                            <MessageSquare className="h-4 w-4 text-[#15803D]" />
                            Abrir Chat
                          </button>
                        </>
                      )}
                      <button
                        type="button"
                        onClick={() => setCancelarModalAbierto(true)}
                        className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#DC2626]/35 bg-white px-4 text-xs font-semibold text-[#DC2626] transition-colors hover:bg-[#FEF2F2]"
                      >
                        <XCircle className="h-4 w-4" />
                        Cancelar viaje
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Modales bajo demanda: solo se montan al presionar Ver Mapa / Abrir Chat / Cancelar */}
              <OnDemandMapModal
                isOpen={mapaAbierto}
                onClose={() => setMapaAbierto(false)}
                viaje={viajeActivo}
              />
              <ViajeChatModal
                isOpen={chatAbierto}
                onClose={() => setChatAbierto(false)}
                viajeId={viajeActivo.id}
                autorUid={userUid}
                autorRol="pasajero"
                autorNombre={userName}
                onIncomingHeadsUp={onIncomingChatHeadsUp}
              />
              <CancelarViajeModal
                isOpen={cancelarModalAbierto}
                rol="pasajero"
                onClose={() => setCancelarModalAbierto(false)}
                onConfirm={async (motivo) => {
                  selfCancelledRef.current = true;
                  await cancelarViajeConMotivo({
                    viaje: viajeActivo,
                    canceladoPor: 'pasajero',
                    motivo,
                  });
                  setAvisoCancelacion({
                    por: 'Tú (Pasajero)',
                    motivo,
                  });
                }}
              />
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              {/* Formulario de origen, destino, rutas favoritas, pasajeros y reseña */}
              <div className="space-y-5 rounded-2xl border border-[#E2E6DF] bg-white p-5 lg:col-span-5">
                <div className="flex flex-wrap items-start justify-between gap-2 border-b border-[#E2E6DF] pb-3.5">
                  <div>
                    <h2 className="text-xl font-bold text-[#14231A]">Solicitar Viaje Rural</h2>
                    <p className="text-xs text-[#525B50]">
                      GPS de pasajero se envía una sola vez · Sin mapas pesados por defecto
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await compartirAppEnDispositivo(linkDescarga);
                      setShareToast(
                        res.status === 'shared'
                          ? 'Menú para compartir abierto.'
                          : 'Enlace copiado para enviar por WhatsApp.'
                      );
                      setTimeout(() => setShareToast(null), 4500);
                    }}
                    className="inline-flex min-h-[38px] items-center gap-1.5 whitespace-nowrap rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] px-3 text-xs font-semibold text-[#15803D] hover:bg-[#15803D]/15"
                  >
                    <Share2 className="h-3.5 w-3.5" />
                    Compartir App
                  </button>
                </div>

                {shareToast && (
                  <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] px-3 py-2 text-xs font-medium text-[#15803D]">
                    <span>{shareToast}</span>
                    <a
                      href={buildWhatsAppShareAppUrl(linkDescarga)}
                      target="_blank"
                      rel="noreferrer"
                      className="font-bold underline"
                    >
                      Enviar por WhatsApp
                    </a>
                  </div>
                )}

                {/* RUTAS FAVORITAS DEL PASAJERO */}
                <div className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#14231A]">
                      <Bookmark className="h-3.5 w-3.5 text-[#D97706]" />
                      Rutas favoritas ({rutasFavoritas.length})
                    </span>
                    <button
                      type="button"
                      onClick={() => setMostrarGuardarFavorita((v) => !v)}
                      className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-[#E2E6DF] bg-white px-2.5 text-[11px] font-semibold text-[#15803D] hover:bg-[#F0FDF4]"
                    >
                      <BookmarkPlus className="h-3.5 w-3.5" />
                      {mostrarGuardarFavorita ? 'Cerrar' : 'Guardar ruta actual'}
                    </button>
                  </div>

                  {mostrarGuardarFavorita && (
                    <form onSubmit={handleGuardarRutaFavorita} className="mt-2.5 flex gap-2">
                      <input
                        type="text"
                        value={aliasFavorita}
                        onChange={(e) => setAliasFavorita(e.target.value)}
                        placeholder="Nombre corto (ej: Casa → Pozuelo)"
                        maxLength={60}
                        className="min-h-[40px] flex-1 rounded-lg border border-[#E2E6DF] bg-white px-3 text-xs text-[#14231A] outline-none focus:border-[#15803D]"
                      />
                      <button
                        type="submit"
                        disabled={guardandoFavorita}
                        className="min-h-[40px] whitespace-nowrap rounded-lg bg-[#15803D] px-3 text-xs font-semibold text-white hover:bg-[#166534] disabled:opacity-50"
                      >
                        {guardandoFavorita ? '...' : 'Guardar'}
                      </button>
                    </form>
                  )}

                  {rutasFavoritas.length === 0 ? (
                    <p className="mt-2 text-[11px] text-[#525B50]">
                      Guarda tus trayectos frecuentes (ej. Casa → Pozuelo) para llenarlos en un toque.
                    </p>
                  ) : (
                    <div className="mt-2.5 flex flex-wrap gap-2">
                      {rutasFavoritas.map((fav) => (
                        <div
                          key={fav.id}
                          className="inline-flex items-center overflow-hidden rounded-xl border border-[#E2E6DF] bg-white"
                        >
                          <button
                            type="button"
                            onClick={() => handleAplicarRutaFavorita(fav)}
                            className="min-h-[38px] px-3 py-1.5 text-left text-xs font-semibold text-[#14231A] hover:bg-[#F0FDF4]"
                            title={`${fav.origenNombre} → ${fav.destinoNombre}`}
                          >
                            {fav.alias}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleEliminarFavorita(fav.id)}
                            className="flex min-h-[38px] min-w-[34px] items-center justify-center border-l border-[#E2E6DF] text-[#525B50] hover:bg-[#FEF2F2] hover:text-[#DC2626]"
                            aria-label={`Eliminar ruta favorita ${fav.alias}`}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Cantidad de pasajeros (obligatorio seleccionar >= 1) */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#14231A]">
                    Cantidad de pasajeros (obligatorio)
                  </label>
                  <div
                    className={`flex items-center justify-between rounded-xl border px-4 py-2 ${
                      cantidadPasajeros === 0
                        ? 'border-[#D97706]/50 bg-[#FFFBEB]'
                        : 'border-[#E2E6DF] bg-[#F7F8F6]'
                    }`}
                  >
                    <span className="inline-flex items-center gap-2 text-sm font-medium text-[#14231A]">
                      <Users
                        className={`h-4 w-4 ${
                          cantidadPasajeros === 0 ? 'text-[#D97706]' : 'text-[#15803D]'
                        }`}
                      />
                      <span className="font-mono text-base font-bold tabular-nums">
                        {cantidadPasajeros}
                      </span>{' '}
                      {cantidadPasajeros === 0
                        ? 'pasajeros — Selecciona cuántos viajan'
                        : cantidadPasajeros === 1
                        ? 'pasajero'
                        : 'pasajeros'}
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={cantidadPasajeros <= 0}
                        onClick={() => {
                          setCantidadPasajeros((v) => {
                            const next = Math.max(0, v - 1);
                            if (next === 0) setPingEjecutado(false);
                            return next;
                          });
                        }}
                        className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg border border-[#E2E6DF] bg-white font-bold hover:bg-neutral-50 disabled:cursor-not-allowed disabled:opacity-40"
                        aria-label="Disminuir pasajeros"
                      >
                        -
                      </button>
                      <button
                        type="button"
                        disabled={cantidadPasajeros >= 12}
                        onClick={() => {
                          setErrorForm(null);
                          setCantidadPasajeros((v) => Math.min(12, v + 1));
                        }}
                        className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg border border-[#E2E6DF] bg-white font-bold hover:bg-neutral-50 disabled:cursor-not-allowed disabled:opacity-40"
                        aria-label="Aumentar pasajeros"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  {cantidadPasajeros === 0 && (
                    <p className="mt-1 text-[11px] font-medium text-[#92400E]">
                      Indica al menos 1 pasajero con el botón + antes de solicitar el viaje.
                    </p>
                  )}
                </div>

                {/* Buscador desplegable de Ubicación Actual / Origen + GPS Preciso */}
                <div ref={origenBoxRef} className="relative">
                  <label className="mb-1.5 block text-xs font-semibold text-[#14231A]">
                    Ubicación actual / Origen (GPS de alta precisión o búsqueda)
                  </label>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <div className="relative flex-1">
                      <Search className="pointer-events-none absolute left-3.5 top-3.5 h-4 w-4 text-[#525B50]" />
                      <input
                        type="text"
                        value={origenNombre}
                        onFocus={() => setMostrarSugerenciasOrigen(true)}
                        onChange={(e) => {
                          setOrigenNombre(e.target.value);
                          setMostrarSugerenciasOrigen(true);
                        }}
                        placeholder="Ej: Pozuelo, Santa Elena, Hospital..."
                        className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] pl-10 pr-8 text-sm text-[#14231A] outline-none focus:border-[#15803D] focus:bg-white"
                      />
                      {origenNombre && (
                        <button
                          type="button"
                          onClick={() => {
                            setOrigenNombre('');
                            setMostrarSugerenciasOrigen(true);
                          }}
                          className="absolute right-2.5 top-3 rounded p-0.5 text-[#525B50] hover:text-[#14231A]"
                          aria-label="Limpiar origen"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={handleCapturarGpsUnaVez}
                      disabled={gpsCalibrando}
                      className={`inline-flex min-h-[44px] items-center justify-center gap-1.5 whitespace-nowrap rounded-xl border px-3.5 text-xs font-semibold transition-colors disabled:opacity-60 ${
                        gpsCapturado && gpsPrecisionMetros !== null
                          ? 'border-[#15803D]/40 bg-[#F0FDF4] text-[#15803D] hover:bg-[#DCFCE7]'
                          : 'border-[#E2E6DF] bg-white text-[#14231A] hover:bg-[#F7F8F6]'
                      }`}
                    >
                      <LocateFixed className={`h-4 w-4 text-[#15803D] ${gpsCalibrando ? 'animate-spin' : ''}`} />
                      {gpsCalibrando
                        ? 'Calibrando GPS...'
                        : gpsPrecisionMetros !== null
                        ? `Recalibrar (±${gpsPrecisionMetros} m)`
                        : 'GPS preciso'}
                    </button>
                  </div>

                  {mostrarSugerenciasOrigen && (
                    <div className="absolute left-0 right-0 z-30 mt-1.5 max-h-60 overflow-y-auto rounded-xl border border-[#E2E6DF] bg-white shadow-xl">
                      <button
                        type="button"
                        onClick={handleCapturarGpsUnaVez}
                        className="flex min-h-[44px] w-full items-center gap-2 border-b border-[#E2E6DF] bg-[#F0FDF4] px-3.5 py-2.5 text-left text-xs font-semibold text-[#15803D] hover:bg-[#DCFCE7]"
                      >
                        <LocateFixed className="h-4 w-4 shrink-0" />
                        <span>Usar mi ubicación GPS actual de alta precisión</span>
                      </button>
                      <div className="flex items-center justify-between border-b border-[#E2E6DF] bg-[#F7F8F6] px-3 py-1.5 text-[11px] font-semibold text-[#525B50]">
                        <span>
                          {buscandoOrigen
                            ? 'Buscando ubicaciones en Costa Rica...'
                            : `Opciones de origen (${sugerenciasOrigen.length})`}
                        </span>
                        <button
                          type="button"
                          onClick={() => setMostrarSugerenciasOrigen(false)}
                          className="text-[#14231A] hover:underline"
                        >
                          Cerrar
                        </button>
                      </div>
                      {sugerenciasOrigen.length === 0 ? (
                        <div className="px-3.5 py-3 text-xs text-[#525B50]">
                          Sin coincidencias exactas. Puedes conservar el texto escrito o usar GPS preciso.
                        </div>
                      ) : (
                        <div className="divide-y divide-[#E2E6DF]">
                          {sugerenciasOrigen.map((opc) => (
                            <button
                              key={`orig_${opc.nombre}_${opc.lat}`}
                              type="button"
                              onClick={() => handleSeleccionarOrigen(opc)}
                              className="flex w-full items-center justify-between gap-2 px-3.5 py-2.5 text-left text-xs hover:bg-[#F0FDF4]"
                            >
                              <div className="flex items-start gap-2 min-w-0">
                                <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#D97706]" />
                                <div className="min-w-0">
                                  <div className="truncate font-semibold text-[#14231A]">
                                    {opc.nombre}
                                  </div>
                                  <div className="truncate text-[11px] text-[#525B50]">
                                    {opc.canton}
                                  </div>
                                </div>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2 font-mono text-[11px] text-[#525B50]">
                    <span>
                      Coords: {origenLat.toFixed(6)}, {origenLng.toFixed(6)}
                    </span>
                    {gpsPrecisionMetros !== null && (
                      <span
                        className={`font-sans font-semibold ${
                          gpsPrecisionMetros <= 25
                            ? 'text-[#15803D]'
                            : gpsPrecisionMetros <= 80
                            ? 'text-[#D97706]'
                            : 'text-[#DC2626]'
                        }`}
                      >
                        {gpsPrecisionMetros <= 25
                          ? `Alta precisión (±${gpsPrecisionMetros} m)`
                          : gpsPrecisionMetros <= 80
                          ? `Precisión media (±${gpsPrecisionMetros} m)`
                          : `Señal débil (±${gpsPrecisionMetros} m · prueba recalibrar)`}
                      </span>
                    )}
                  </div>
                </div>

                {/* Buscador desplegable de Destino */}
                <div ref={destinoBoxRef} className="relative">
                  <label className="mb-1.5 block text-xs font-semibold text-[#14231A]">
                    Destino (escribe para ver opciones y seleccionar)
                  </label>
                  <div className="relative">
                    <Search className="pointer-events-none absolute left-3.5 top-3.5 h-4 w-4 text-[#525B50]" />
                    <input
                      type="text"
                      value={busquedaDestino}
                      onFocus={() => setMostrarSugerenciasDestino(true)}
                      onChange={(e) => {
                        setBusquedaDestino(e.target.value);
                        setMostrarSugerenciasDestino(true);
                      }}
                      placeholder="Ej: Pozuelo, San Isidro, EBAIS, mercado..."
                      className="min-h-[44px] w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] pl-10 pr-9 text-sm text-[#14231A] outline-none focus:border-[#15803D] focus:bg-white"
                    />
                    {busquedaDestino && (
                      <button
                        type="button"
                        onClick={() => {
                          setBusquedaDestino('');
                          setMostrarSugerenciasDestino(true);
                        }}
                        className="absolute right-2.5 top-3 rounded p-0.5 text-[#525B50] hover:text-[#14231A]"
                        aria-label="Limpiar destino"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>

                  {mostrarSugerenciasDestino && (
                    <div className="absolute left-0 right-0 z-30 mt-1.5 max-h-56 overflow-y-auto rounded-xl border border-[#E2E6DF] bg-white shadow-xl">
                      <div className="flex items-center justify-between border-b border-[#E2E6DF] bg-[#F7F8F6] px-3 py-1.5 text-[11px] font-semibold text-[#525B50]">
                        <span>
                          {buscandoDestino
                            ? 'Buscando ubicaciones en Costa Rica...'
                            : `Opciones de destino (${sugerenciasDestino.length})`}
                        </span>
                        <button
                          type="button"
                          onClick={() => setMostrarSugerenciasDestino(false)}
                          className="text-[#14231A] hover:underline"
                        >
                          Cerrar
                        </button>
                      </div>
                      {sugerenciasDestino.length === 0 ? (
                        <div className="px-3.5 py-3 text-xs text-[#525B50]">
                          Sin coincidencias para "{busquedaDestino}". Escribe otro nombre o sector.
                        </div>
                      ) : (
                        <div className="divide-y divide-[#E2E6DF]">
                          {sugerenciasDestino.map((dest) => {
                            const activo = destinoSeleccionado.nombre === dest.nombre;
                            return (
                              <button
                                key={`dest_${dest.nombre}_${dest.lat}`}
                                type="button"
                                onClick={() => handleSeleccionarDestino(dest)}
                                className={`flex w-full items-center justify-between gap-2 px-3.5 py-2.5 text-left text-xs transition-colors ${
                                  activo
                                    ? 'bg-[#15803D]/10 font-semibold text-[#15803D]'
                                    : 'hover:bg-[#F7F8F6]'
                                }`}
                              >
                                <div className="flex items-start gap-2 min-w-0">
                                  <Navigation className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#15803D]" />
                                  <div className="min-w-0">
                                    <div className="truncate font-semibold text-[#14231A]">
                                      {dest.nombre}
                                    </div>
                                    <div className="truncate text-[11px] text-[#525B50]">
                                      {dest.canton}
                                    </div>
                                  </div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="mt-1 font-mono text-[11px] text-[#525B50]">
                    Seleccionado: {destinoSeleccionado.nombre} ({destinoSeleccionado.canton})
                  </div>
                </div>

                {/* Reseña de ubicación (Texto libre) */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#14231A]">
                    Reseña de ubicación (para el conductor)
                  </label>
                  <textarea
                    rows={2}
                    maxLength={260}
                    value={resenaUbicacion}
                    onChange={(e) => setResenaUbicacion(e.target.value)}
                    placeholder="Breve referencia para encontrarme (ej: frente a la licorera, casa azul)"
                    className="w-full rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3 text-sm text-[#14231A] outline-none focus:border-[#15803D] focus:bg-white"
                  />
                </div>

                {errorForm && (
                  <div className="rounded-xl border border-[#DC2626]/30 bg-[#DC2626]/10 px-3.5 py-2.5 text-xs font-medium text-[#DC2626]">
                    {errorForm}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleDispararPing1s}
                  disabled={pingEnProgreso}
                  className="inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#14231A] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#1E3527] disabled:opacity-50"
                >
                  <Radio className="h-4 w-4" />
                  {pingEnProgreso
                    ? 'Enviando ping de 1s a conductores...'
                    : 'Solicitar viaje (Ping 1s y calcular tarifas)'}
                </button>
              </div>

              {/* Columna derecha: Selección múltiple de vehículos y Transparencia de Tarifas */}
              <div className="space-y-5 lg:col-span-7">
                <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
                  <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-[#E2E6DF] pb-3.5">
                    <div>
                      <h3 className="text-lg font-bold text-[#14231A]">
                        {cantidadPasajeros > 0
                          ? `Vehículos con capacidad suficiente (${cantidadPasajeros}+ pax)`
                          : 'Vehículos disponibles (selecciona cantidad de pasajeros)'}
                      </h3>
                      <p className="text-xs text-[#525B50]">
                        Selecciona uno o varios tipos · Distancia rural estimada:{' '}
                        <span className="font-mono font-semibold tabular-nums text-[#14231A]">
                          {distanciaEstimadaKm} km
                        </span>
                      </p>
                    </div>
                    {pingEjecutado && (
                      <span className="text-xs font-semibold text-[#15803D]">
                        Ping 1s completado · GPS conductores apagado
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {tiposConCapacidad.map((info) => {
                      const seleccionado = tiposSeleccionados.includes(info.nombre);
                      return (
                        <button
                          key={info.nombre}
                          type="button"
                          onClick={() => toggleTipoVehiculo(info.nombre)}
                          className={`flex items-start justify-between rounded-xl border p-3.5 text-left transition-colors ${
                            seleccionado
                              ? 'border-[#15803D] bg-[#15803D]/5'
                              : 'border-[#E2E6DF] bg-white hover:bg-[#F7F8F6]'
                          }`}
                        >
                          <div>
                            <div className="flex items-center gap-2 text-sm font-bold text-[#14231A]">
                              <Car className="h-4 w-4 text-[#15803D]" />
                              {info.nombre}
                            </div>
                            <p className="mt-1 text-xs text-[#525B50]">{info.descripcion}</p>
                          </div>
                          <div
                            className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                              seleccionado
                                ? 'border-[#15803D] bg-[#15803D] text-white'
                                : 'border-[#CBD5E1]'
                            }`}
                          >
                            {seleccionado && <Check className="h-3.5 w-3.5" />}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Lista de conductores cercanos con Transparencia de Tarifas */}
                <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
                  <div className="mb-3.5 flex items-center justify-between">
                    <h3 className="text-lg font-bold text-[#14231A]">
                      Transparencia de Tarifas — Conductores más cercanos
                    </h3>
                    <span className="font-mono text-xs text-[#525B50]">
                      {conductoresCompatibles.length} disponibles
                    </span>
                  </div>

                  {conductoresCompatibles.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-[#E2E6DF] py-8 text-center text-sm text-[#525B50]">
                      No hay conductores activos compatibles con la selección actual.
                    </div>
                  ) : (
                    <div className="divide-y divide-[#E2E6DF]">
                      {conductoresCompatibles.map(({ conductor, distAlPasajero, montoAprox }, idx) => (
                        <div
                          key={conductor.uid}
                          className="flex flex-col gap-3 py-3.5 sm:flex-row sm:items-center sm:justify-between"
                        >
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-xs font-bold text-[#525B50]">
                              #{idx + 1}
                            </span>
                            <img
                              src={conductor.fotoUrl || DRIVER_AVATARS['driver-carlos']}
                              alt={conductor.nombre}
                              referrerPolicy="no-referrer"
                              className="h-11 w-11 rounded-full border border-[#E2E6DF] object-cover"
                            />
                            <div>
                              <div className="text-sm font-bold text-[#14231A]">
                                {conductor.nombre}
                              </div>
                              <div className="text-xs text-[#525B50]">
                                {conductor.vehiculoTipo} · {conductor.placa} · A{' '}
                                <span className="font-mono font-semibold text-[#14231A]">
                                  {distAlPasajero} km
                                </span>{' '}
                                · ★ {conductor.promedioCalificacion.toFixed(1)}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-4 sm:justify-end">
                            <div className="text-left sm:text-right">
                              <div className="font-mono text-xs text-[#525B50]">
                                Base {formatearColones(conductor.tarifaBase)} +{' '}
                                {formatearColones(conductor.tarifaPorKm)}/km
                              </div>
                              <div className="font-mono text-base font-bold tabular-nums text-[#15803D]">
                                Aprox. {formatearColones(montoAprox)}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="mt-5 flex flex-col gap-3 border-t border-[#E2E6DF] pt-4 sm:flex-row sm:items-center sm:justify-between">
                    <p className="text-xs text-[#525B50]">
                      Pago directo en efectivo al conductor. Cola secuencial ordenada por cercanía (15s por oferta).
                    </p>
                    <button
                      type="button"
                      onClick={handleConfirmarSolicitud}
                      disabled={
                        creandoViaje ||
                        !pingEjecutado ||
                        cantidadPasajeros < 1 ||
                        conductoresCompatibles.length === 0
                      }
                      className="min-h-[48px] whitespace-nowrap rounded-xl bg-[#15803D] px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#166534] disabled:cursor-not-allowed disabled:opacity-45"
                    >
                      {creandoViaje
                        ? 'Creando solicitud...'
                        : cantidadPasajeros < 1
                        ? 'Indica cantidad de pasajeros'
                        : pingEjecutado
                        ? 'Confirmar y Enviar Oferta'
                        : 'Primero ejecuta el Ping 1s'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ===================================================================== */}
      {/* PESTAÑA 2: HISTORIAL (CARGA LAZY limit(20) SOLO AL TOCAR PESTAÑA)      */}
      {/* ===================================================================== */}
      {activeTab === 'historial' && (
        <div className="rounded-2xl border border-[#E2E6DF] bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E2E6DF] pb-4">
            <div>
              <h2 className="text-lg font-bold text-[#14231A]">
                Historial de Viajes (Máx. 20 recientes)
              </h2>
              <p className="text-xs text-[#525B50]">
                Consulta ligera bajo demanda · Puedes repetir cualquier ruta o guardarla como favorita
              </p>
            </div>
            <button
              type="button"
              onClick={() => cargarHistorialLazy(true)}
              disabled={cargandoHistorial}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3.5 text-xs font-semibold text-[#14231A] hover:bg-[#E2E6DF]/50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${cargandoHistorial ? 'animate-spin' : ''}`} />
              Actualizar
            </button>
          </div>

          {cargandoHistorial ? (
            <div className="py-10 text-center text-sm text-[#525B50]">
              Cargando historial desde Firestore...
            </div>
          ) : historial.length === 0 ? (
            <div className="py-10 text-center text-sm text-[#525B50]">
              Todavía no tienes viajes registrados en tu historial.
            </div>
          ) : (
            <div className="divide-y divide-[#E2E6DF]">
              {historial.map((v) => (
                <div
                  key={v.id}
                  className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-bold text-[#14231A]">
                        {v.origenNombre} → {v.destinoNombre}
                      </span>
                      <span className="font-mono text-[11px] font-semibold uppercase text-[#525B50]">
                        · {v.estado}
                      </span>
                    </div>
                    <div className="text-xs text-[#525B50]">
                      Conductor: {v.conductorNombre || 'Sin asignar'} · {v.distanciaKm} km ·{' '}
                      {v.updatedAt?.toDate?.()?.toLocaleDateString('es-CR') || 'Reciente'}
                    </div>
                    {v.estado === 'cancelado' && v.motivoCancelacion && (
                      <div className="text-xs text-[#991B1B]">
                        Cancelado por {v.canceladoPor || 'usuario'}: &ldquo;{v.motivoCancelacion}&rdquo;
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="font-mono text-base font-bold tabular-nums text-[#15803D]">
                      {formatearColones(v.montoAproximado)}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        handleAplicarRutaFavorita({
                          id: v.id,
                          alias: v.destinoNombre.slice(0, 25),
                          origenNombre: v.origenNombre,
                          origenLat: v.origenLat,
                          origenLng: v.origenLng,
                          destinoNombre: v.destinoNombre,
                          destinoLat: v.destinoLat,
                          destinoLng: v.destinoLng,
                        })
                      }
                      className="min-h-[38px] rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-3 text-xs font-semibold text-[#14231A] hover:bg-[#F0FDF4]"
                    >
                      Repetir viaje
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* PESTAÑA 3: PERFIL (CALIFICACIÓN, RUTAS FAVORITAS, SOPORTE Y TÉRMINOS) */}
      {/* ===================================================================== */}
      {activeTab === 'perfil' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="space-y-4 rounded-2xl border border-[#E2E6DF] bg-white p-5 lg:col-span-6">
            <div className="flex items-center gap-4 border-b border-[#E2E6DF] pb-4">
              <img
                src={userPhoto || pasajeroPerfil?.fotoUrl || PASSENGER_AVATAR}
                alt={userName}
                referrerPolicy="no-referrer"
                className="h-14 w-14 rounded-full border border-[#E2E6DF] object-cover"
              />
              <div>
                <h2 className="text-lg font-bold text-[#14231A]">
                  {pasajeroPerfil?.nombre || userName}
                </h2>
                <div className="flex items-center gap-1.5 text-xs text-[#525B50]">
                  <Star className="h-3.5 w-3.5 fill-[#D97706] text-[#D97706]" />
                  <span className="font-mono font-bold text-[#14231A]">
                    {(pasajeroPerfil?.promedioCalificacion ?? 5.0).toFixed(2)}
                  </span>
                  <span>({pasajeroPerfil?.totalCalificaciones ?? 0} calificaciones)</span>
                </div>
              </div>
            </div>

            {cargandoPerfil && (
              <p className="text-xs text-[#525B50]">Actualizando ficha del perfil...</p>
            )}

            <div className="space-y-1.5 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-3.5 text-xs text-[#333D32]">
              <div className="flex items-center justify-between gap-2 font-bold text-[#14231A]">
                <span>Datos Protegidos (Solo lectura)</span>
                <Lock className="h-3.5 w-3.5 text-[#15803D]" />
              </div>
              <div>
                Nombre: <strong>{pasajeroPerfil?.nombre || userName}</strong>
              </div>
              <div>
                Teléfono: <strong className="font-mono">{miPii?.telefono || 'No registrado'}</strong> ·
                Cédula: <strong className="font-mono">{miPii?.cedula || 'No registrada'}</strong>
              </div>
              {miPii?.email && (
                <div>
                  Correo: <strong className="font-mono">{miPii.email}</strong>
                </div>
              )}
              <p className="pt-1 text-[11px] text-[#525B50]">
                Una vez registrado, tus datos quedan protegidos para evitar manipulación. Para modificarlos debes enviar una petición al Administrador.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                if (!mostrarFormCambio) {
                  setReqNombre(pasajeroPerfil?.nombre || userName);
                  setReqTelefono(miPii?.telefono || '');
                  setReqEmail(miPii?.email || '');
                  setReqCedula(miPii?.cedula || '');
                  setReqMotivo('');
                  setSolicitudFeedback(null);
                }
                setMostrarFormCambio((v) => !v);
              }}
              className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-[#15803D]/40 bg-[#15803D]/10 px-4 text-xs font-bold text-[#15803D] hover:bg-[#15803D]/15"
            >
              <Send className="h-4 w-4" />
              {mostrarFormCambio
                ? 'Ocultar formulario de petición'
                : 'Solicitar cambio de datos al Administrador'}
            </button>

            {mostrarFormCambio && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setSolicitudFeedback(null);
                  const nombreActual = pasajeroPerfil?.nombre || userName;
                  const cambios: CambiosSolicitados = {};
                  if (reqNombre.trim() && reqNombre.trim() !== nombreActual) {
                    cambios.nombre = reqNombre.trim();
                  }
                  if (reqTelefono.trim() && reqTelefono.trim() !== (miPii?.telefono || '')) {
                    cambios.telefono = reqTelefono.trim();
                  }
                  if (reqEmail.trim() && reqEmail.trim() !== (miPii?.email || '')) {
                    cambios.email = reqEmail.trim();
                  }
                  if (reqCedula.trim() && reqCedula.trim() !== (miPii?.cedula || '')) {
                    cambios.cedula = reqCedula.trim();
                  }

                  if (Object.keys(cambios).length === 0) {
                    setSolicitudFeedback('Modifica al menos un campo antes de enviar la petición.');
                    return;
                  }
                  if (reqMotivo.trim().length < 3) {
                    setSolicitudFeedback('Indica el motivo del cambio (mínimo 3 caracteres).');
                    return;
                  }

                  setEnviandoSolicitud(true);
                  try {
                    const creada = await crearSolicitudCambioDatos({
                      solicitanteUid: userUid,
                      rol: 'pasajero',
                      nombreActual,
                      resumenActual: `Tel: ${miPii?.telefono || 'N/D'} · Cédula: ${miPii?.cedula || 'N/D'}`,
                      cambios,
                      motivo: reqMotivo,
                    });
                    setMisSolicitudes((prev) => [creada, ...prev]);
                    setMostrarFormCambio(false);
                    setSolicitudFeedback(
                      'Petición enviada al Administrador. Los cambios se aplicarán al ser aprobados.'
                    );
                  } finally {
                    setEnviandoSolicitud(false);
                  }
                }}
                className="space-y-3 rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-4"
              >
                <div className="text-xs font-bold text-[#14231A]">
                  Petición de Cambio al Administrador
                </div>
                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Nuevo nombre completo
                    </label>
                    <input
                      value={reqNombre}
                      onChange={(e) => setReqNombre(e.target.value)}
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 text-xs"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Nuevo teléfono
                    </label>
                    <input
                      value={reqTelefono}
                      onChange={(e) => setReqTelefono(e.target.value)}
                      placeholder="+506 8888-8888"
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Nuevo correo electrónico
                    </label>
                    <input
                      type="email"
                      value={reqEmail}
                      onChange={(e) => setReqEmail(e.target.value)}
                      placeholder="correo@ejemplo.com"
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 text-xs"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                      Cédula
                    </label>
                    <input
                      value={reqCedula}
                      onChange={(e) => setReqCedula(e.target.value)}
                      placeholder="1-1234-5678"
                      className="min-h-[40px] w-full rounded-lg border border-[#E2E6DF] bg-white px-2.5 font-mono text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="mb-1 block text-[11px] font-semibold text-[#525B50]">
                    Motivo del cambio (obligatorio)
                  </label>
                  <textarea
                    required
                    minLength={3}
                    maxLength={280}
                    rows={2}
                    value={reqMotivo}
                    onChange={(e) => setReqMotivo(e.target.value)}
                    placeholder="Ej: Cambié de número telefónico o corrección en mi nombre"
                    className="w-full rounded-lg border border-[#E2E6DF] bg-white p-2.5 text-xs"
                  />
                </div>
                <button
                  type="submit"
                  disabled={enviandoSolicitud}
                  className="min-h-[42px] w-full rounded-xl bg-[#15803D] px-4 text-xs font-semibold text-white hover:bg-[#166534] disabled:opacity-50"
                >
                  {enviandoSolicitud ? 'Enviando petición...' : 'Enviar petición al Administrador'}
                </button>
              </form>
            )}

            {solicitudFeedback && (
              <div className="rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] p-3 text-xs font-semibold text-[#15803D]">
                {solicitudFeedback}
              </div>
            )}

            {misSolicitudes.length > 0 && (
              <div className="space-y-2 border-t border-[#E2E6DF] pt-3">
                <div className="text-xs font-bold text-[#14231A]">
                  Mis peticiones de cambio ({misSolicitudes.length})
                </div>
                <div className="space-y-1.5">
                  {misSolicitudes.slice(0, 4).map((sol) => (
                    <div
                      key={sol.id}
                      className="rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] p-2.5 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[#14231A]">
                          {Object.keys(sol.cambios).join(', ')}
                        </span>
                        <span
                          className={`font-mono text-[11px] font-bold uppercase ${
                            sol.estado === 'aprobada'
                              ? 'text-[#15803D]'
                              : sol.estado === 'rechazada'
                              ? 'text-[#DC2626]'
                              : 'text-[#D97706]'
                          }`}
                        >
                          {sol.estado}
                        </span>
                      </div>
                      <div className="mt-0.5 text-[11px] text-[#525B50]">{sol.motivo}</div>
                      {sol.respuestaAdmin && (
                        <div className="mt-1 text-[11px] font-medium text-[#14231A]">
                          Admin: {sol.respuestaAdmin}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-2.5">
              <a
                href={buildWhatsAppShareAppUrl(linkDescarga)}
                target="_blank"
                rel="noreferrer"
                onClick={() => {
                  void compartirAppEnDispositivo(linkDescarga);
                }}
                className="flex min-h-[46px] w-full items-center justify-between rounded-xl border border-[#15803D]/30 bg-[#F0FDF4] px-4 text-sm font-semibold text-[#15803D] hover:bg-[#15803D]/15"
              >
                <span className="flex items-center gap-2.5">
                  <Share2 className="h-4 w-4" />
                  Compartir App por WhatsApp
                </span>
                <span className="text-xs font-bold">Compartir</span>
              </a>

              {onAbrirSoporte && (
                <button
                  type="button"
                  onClick={onAbrirSoporte}
                  className="flex min-h-[46px] w-full items-center justify-between rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 text-sm font-semibold text-[#14231A] hover:bg-[#F0FDF4]"
                >
                  <span className="flex items-center gap-2.5">
                    <Headphones className="h-4 w-4 text-[#15803D]" />
                    Soporte WhatsApp y SINPE
                  </span>
                  <span className="text-xs text-[#15803D]">Abrir</span>
                </button>
              )}

              {onAbrirTerminos && (
                <button
                  type="button"
                  onClick={onAbrirTerminos}
                  className="flex min-h-[46px] w-full items-center justify-between rounded-xl border border-[#E2E6DF] bg-[#F7F8F6] px-4 text-sm font-semibold text-[#14231A] hover:bg-[#F0FDF4]"
                >
                  <span className="flex items-center gap-2.5">
                    <FileText className="h-4 w-4 text-[#15803D]" />
                    Términos y Condiciones
                  </span>
                  <span className="text-xs text-[#525B50]">Leer</span>
                </button>
              )}

              {onLogout && (
                <button
                  type="button"
                  onClick={onLogout}
                  className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl border border-[#DC2626]/30 bg-[#FEF2F2] px-4 text-sm font-semibold text-[#991B1B] hover:bg-[#FEE2E2]"
                >
                  <LogOut className="h-4 w-4" />
                  Cerrar sesión
                </button>
              )}
            </div>
          </div>

          <div className="space-y-3 rounded-2xl border border-[#E2E6DF] bg-white p-5 lg:col-span-6">
            <div className="border-b border-[#E2E6DF] pb-3">
              <h3 className="text-base font-bold text-[#14231A]">
                Mis Rutas Favoritas ({rutasFavoritas.length}/15)
              </h3>
              <p className="text-xs text-[#525B50]">
                Toca una ruta para cargarla inmediatamente en la pestaña Viaje.
              </p>
            </div>

            {rutasFavoritas.length === 0 ? (
              <div className="rounded-xl border border-dashed border-[#E2E6DF] py-8 text-center text-xs text-[#525B50]">
                Aún no tienes rutas favoritas guardadas. Puedes guardarlas en la pestaña Viaje.
              </div>
            ) : (
              <div className="divide-y divide-[#E2E6DF]">
                {rutasFavoritas.map((fav) => (
                  <div
                    key={fav.id}
                    className="flex items-center justify-between gap-3 py-3"
                  >
                    <button
                      type="button"
                      onClick={() => handleAplicarRutaFavorita(fav)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <div className="text-sm font-bold text-[#14231A]">{fav.alias}</div>
                      <div className="truncate text-xs text-[#525B50]">
                        {fav.origenNombre} → {fav.destinoNombre}
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleEliminarFavorita(fav.id)}
                      className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl border border-[#E2E6DF] text-[#525B50] hover:bg-[#FEF2F2] hover:text-[#DC2626]"
                      aria-label={`Eliminar ruta ${fav.alias}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* BOTTOM NAVIGATION FIJO DEL PASAJERO (3 PESTAÑAS)                      */}
      {/* ===================================================================== */}
      <nav
        aria-label="Navegación de Pasajero"
        className="fixed bottom-0 left-0 right-0 z-30 border-t border-[#E2E6DF] bg-white/95 backdrop-blur-md"
      >
        <div className="mx-auto grid h-16 max-w-xl grid-cols-3">
          {(
            [
              { id: 'viaje', label: 'Viaje', Icon: Navigation },
              { id: 'historial', label: 'Historial', Icon: History },
              { id: 'perfil', label: 'Perfil', Icon: User },
            ] as const
          ).map(({ id, label, Icon }) => {
            const activo = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={`flex flex-col items-center justify-center gap-1 text-xs font-semibold transition-colors ${
                  activo ? 'text-[#15803D]' : 'text-[#525B50] hover:text-[#14231A]'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
