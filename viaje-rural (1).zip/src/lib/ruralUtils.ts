import {
  Conductor,
  ConfiguracionGeneral,
  RuralDestino,
  TipoVehiculo,
  VehiculoTipoConfig,
  Viaje,
} from '../types/viajeRural';

export const ADMIN_EMAIL = 'sindicatosiserge@gmail.com';

export const RURAL_DESTINOS: RuralDestino[] = [
  { nombre: 'Centro de Pérez Zeledón (Mercado)', canton: 'San Isidro, Pérez Zeledón', lat: 9.3738, lng: -83.7042 },
  { nombre: 'Santa Elena Centro', canton: 'General Viejo, Pérez Zeledón', lat: 9.3895, lng: -83.6490 },
  { nombre: 'San Gerardo de Rivas', canton: 'Rivas, Pérez Zeledón', lat: 9.4545, lng: -83.5752 },
  { nombre: 'EBAIS de Santa Elena', canton: 'General Viejo, Pérez Zeledón', lat: 9.3912, lng: -83.6358 },
  { nombre: 'Cooperativa Cafetalera El Roble', canton: 'Pejibaye, Pérez Zeledón', lat: 9.1667, lng: -83.5501 },
  { nombre: 'Terminal de Buses Quebradas', canton: 'San Isidro, Pérez Zeledón', lat: 9.4234, lng: -83.6941 },
  { nombre: 'Plaza de Deportes La Palma', canton: 'Daniel Flores, Pérez Zeledón', lat: 9.3425, lng: -83.6712 },
  { nombre: 'Escuela Rural Monte Carlo', canton: 'Rivas, Pérez Zeledón', lat: 9.4198, lng: -83.6114 },
  { nombre: 'Feria del Agricultor San Marcos', canton: 'Tarrazú, San José', lat: 9.6594, lng: -84.0205 },
  { nombre: 'Compañía de Galletas Pozuelo (La Uruca)', canton: 'La Uruca, San José', lat: 9.9562, lng: -84.1157 },
  { nombre: 'Cruce de Pozuelo (Radial Uruca - Heredia)', canton: 'La Uruca, San José', lat: 9.9585, lng: -84.1142 },
  { nombre: 'Pozuelo — Jardines del Recuerdo', canton: 'Valencia / Uruca, Heredia', lat: 9.9614, lng: -84.1135 },
  { nombre: 'Hospital México (La Uruca)', canton: 'La Uruca, San José', lat: 9.9516, lng: -84.1139 },
  { nombre: 'San José Centro (Parque Central / Avenida Segunda)', canton: 'Carmen / Catedral, San José', lat: 9.9327, lng: -84.0796 },
  { nombre: 'Heredia Centro (Parque Nicolás Ulloa)', canton: 'Heredia', lat: 9.9986, lng: -84.1165 },
  { nombre: 'Alajuela Centro (Parque Juan Santamaría)', canton: 'Alajuela', lat: 10.0162, lng: -84.2116 },
  { nombre: 'Cartago Centro (Basílica de los Ángeles)', canton: 'Cartago', lat: 9.8644, lng: -83.9135 },
  { nombre: 'Desamparados Centro', canton: 'Desamparados, San José', lat: 9.8981, lng: -84.0658 },
  { nombre: 'San Pedro de Montes de Oca (UCR)', canton: 'Montes de Oca, San José', lat: 9.9366, lng: -84.0510 },
  { nombre: 'Buenos Aires Centro (Zona Sur)', canton: 'Buenos Aires, Puntarenas', lat: 9.1725, lng: -83.3342 },
  { nombre: 'Dominical Centro (Playa / Costanera)', canton: 'Osa, Puntarenas', lat: 9.2535, lng: -83.8615 },
  { nombre: 'Uvita Centro (Bahía Ballena)', canton: 'Osa, Puntarenas', lat: 9.1628, lng: -83.7365 },
  { nombre: 'San Vito de Coto Brus', canton: 'Coto Brus, Puntarenas', lat: 8.8213, lng: -82.9711 },
  { nombre: 'Ciudad Neily Centro', canton: 'Corredores, Puntarenas', lat: 8.6489, lng: -82.9422 },
  { nombre: 'Turrialba Centro (Mercado)', canton: 'Turrialba, Cartago', lat: 9.9056, lng: -83.6833 },
  { nombre: 'San Ramón Centro', canton: 'San Ramón, Alajuela', lat: 10.0884, lng: -84.4698 },
  { nombre: 'Ciudad Quesada (Parque Central)', canton: 'San Carlos, Alajuela', lat: 10.3238, lng: -84.4271 },
  { nombre: 'Liberia Centro (Parque Mario Cañas)', canton: 'Liberia, Guanacaste', lat: 10.6346, lng: -85.4407 },
];

export function filtrarUbicacionesLocales(texto: string): RuralDestino[] {
  const q = texto.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (!q) return RURAL_DESTINOS.slice(0, 8);
  return RURAL_DESTINOS.filter((d) => {
    const nombreNorm = d.nombre.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const cantonNorm = d.canton.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return nombreNorm.includes(q) || cantonNorm.includes(q);
  }).slice(0, 8);
}

function expandirPalabrasClaveRurales(query: string): string[] {
  const norm = query
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
  const variantes = [query.trim()];
  if (norm.includes('pulperia')) variantes.push('abastecedor', 'minisuper', 'tienda');
  if (norm.includes('licorera')) variantes.push('licores', 'licoreria');
  if (norm.includes('supermercado')) variantes.push('super', 'supermarket', 'pali');
  if (norm.includes('farmacia')) variantes.push('botica');
  if (norm.includes('restaurante') || norm.includes('soda')) variantes.push('soda', 'restaurante');
  if (norm.includes('ebais') || norm.includes('clinica')) variantes.push('clinica', 'centro de salud');
  if (norm.includes('ferreteria')) variantes.push('materiales', 'ferreteria');
  if (norm.includes('panaderia')) variantes.push('reposteria', 'panaderia');
  return Array.from(new Set(variantes));
}

export async function buscarUbicacionesAutocomplete(
  texto: string,
  signal?: AbortSignal,
  cercaDe?: { lat: number; lng: number }
): Promise<RuralDestino[]> {
  const locales = filtrarUbicacionesLocales(texto);
  const q = texto.trim();
  if (q.length < 2) return locales;

  try {
    const centerLat = cercaDe?.lat ?? 9.3895;
    const centerLng = cercaDe?.lng ?? -83.6490;
    const variantes = expandirPalabrasClaveRurales(q);

    type NominatimItem = {
      display_name?: string;
      name?: string;
      namedetails?: { name?: string };
      lat?: string;
      lon?: string;
      address?: {
        shop?: string;
        amenity?: string;
        supermarket?: string;
        convenience?: string;
        building?: string;
        road?: string;
        suburb?: string;
        neighbourhood?: string;
        village?: string;
        town?: string;
        city?: string;
        county?: string;
        state?: string;
      };
    };

    const consultar = async (term: string, delta: number, bounded: 0 | 1): Promise<NominatimItem[]> => {
      const viewbox = `${(centerLng - delta).toFixed(5)},${(centerLat + delta).toFixed(5)},${(centerLng + delta).toFixed(5)},${(centerLat - delta).toFixed(5)}`;
      const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=cr&addressdetails=1&namedetails=1&limit=8&viewbox=${encodeURIComponent(viewbox)}&bounded=${bounded}&q=${encodeURIComponent(term)}`;
      const res = await fetch(url, {
        signal,
        headers: { 'Accept-Language': 'es' },
      });
      if (!res.ok) return [];
      return (await res.json()) as NominatimItem[];
    };

    const rawItems: NominatimItem[] = [];
    for (const term of variantes.slice(0, 3)) {
      rawItems.push(...(await consultar(term, 0.16, 1)));
      if (rawItems.length >= 6) break;
    }
    if (rawItems.length < 3) {
      rawItems.push(...(await consultar(q, 0.35, 1)));
    }
    if (rawItems.length === 0) {
      rawItems.push(...(await consultar(q, 0.35, 0)));
    }

    const mapped = await Promise.all(
      rawItems
        .filter((item) => item.lat && item.lon)
        .slice(0, 8)
        .map(async (item, index): Promise<RuralDestino> => {
          const lat = Number(Number(item.lat).toFixed(6));
          const lng = Number(Number(item.lon).toFixed(6));
          const parts = (item.display_name || '').split(',').map((s) => s.trim());
          const poiName =
            item.name?.trim() ||
            item.namedetails?.name?.trim() ||
            item.address?.shop?.trim() ||
            item.address?.amenity?.trim() ||
            item.address?.supermarket?.trim() ||
            item.address?.convenience?.trim() ||
            item.address?.building?.trim();
          let nombreCorto = poiName || parts.slice(0, 2).join(', ') || q;
          let canton =
            [
              item.address?.road,
              item.address?.neighbourhood || item.address?.suburb || item.address?.village,
              item.address?.town || item.address?.city || item.address?.county || item.address?.state,
            ]
              .filter(Boolean)
              .join(', ') ||
            parts.slice(1, 4).join(', ') ||
            'Costa Rica';

          // Enriquecer con búsqueda inversa si el nombre viene genérico o sin detalle de calle
          if (index < 3 && (!poiName || !item.address?.road)) {
            const rev = await reverseGeocodeUbicacion(lat, lng);
            if (!poiName && rev.nombre && !rev.nombre.startsWith('Ubicación GPS')) {
              nombreCorto = rev.nombre;
            } else if (poiName && rev.nombre && !rev.nombre.includes(poiName)) {
              canton = `${rev.nombre} · ${canton}`;
            }
          }

          const distKm = calcularDistanciaKm(centerLat, centerLng, lat, lng);
          return {
            nombre: nombreCorto.slice(0, 110),
            canton: `~${distKm.toFixed(1)} km · ${canton}`.slice(0, 95),
            lat,
            lng,
          };
        })
    );

    const vistos = new Set<string>();
    const combinados: RuralDestino[] = [];
    for (const item of [...mapped, ...locales]) {
      const key = `${item.nombre.toLowerCase()}|${item.lat.toFixed(3)}`;
      if (!vistos.has(key)) {
        vistos.add(key);
        combinados.push(item);
      }
    }
    return combinados
      .sort(
        (a, b) =>
          calcularDistanciaKm(centerLat, centerLng, a.lat, a.lng) -
          calcularDistanciaKm(centerLat, centerLng, b.lat, b.lng)
      )
      .slice(0, 8);
  } catch {
    return locales;
  }
}

export interface UbicacionPrecisaResult {
  lat: number;
  lng: number;
  precisionMetros: number | null;
  nombreDireccion: string;
  canton: string;
}

export async function reverseGeocodeUbicacion(
  lat: number,
  lng: number
): Promise<{ nombre: string; canton: string }> {
  const nearest = [...RURAL_DESTINOS]
    .map((d) => ({ d, km: calcularDistanciaKm(lat, lng, d.lat, d.lng) }))
    .sort((a, b) => a.km - b.km)[0];

  const fallbackNombre = nearest
    ? `Cerca de ${nearest.d.nombre} (~${nearest.km} km)`
    : `Ubicación GPS (${lat.toFixed(5)}, ${lng.toFixed(5)})`;
  const fallbackCanton = nearest?.d.canton || 'Costa Rica';

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3500);
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'Accept-Language': 'es' },
    });
    clearTimeout(timer);
    if (!res.ok) return { nombre: fallbackNombre, canton: fallbackCanton };

    const data = (await res.json()) as {
      name?: string;
      display_name?: string;
      address?: {
        road?: string;
        house_number?: string;
        neighbourhood?: string;
        suburb?: string;
        village?: string;
        hamlet?: string;
        town?: string;
        city_district?: string;
        city?: string;
        county?: string;
        state?: string;
      };
    };

    const addr = data.address;
    const calle = addr?.road
      ? addr.house_number
        ? `${addr.road} #${addr.house_number}`
        : addr.road
      : '';
    const sector =
      addr?.neighbourhood ||
      addr?.suburb ||
      addr?.hamlet ||
      addr?.village ||
      addr?.city_district ||
      '';
    const canton = addr?.county || addr?.town || addr?.city || addr?.state || fallbackCanton;

    const partes = [data.name, calle, sector].filter(
      (v, idx, arr) => Boolean(v) && arr.indexOf(v) === idx
    );
    const nombre =
      partes.length > 0
        ? partes.slice(0, 2).join(', ').slice(0, 120)
        : (data.display_name || fallbackNombre).split(',').slice(0, 2).join(', ').slice(0, 120);

    return { nombre: nombre || fallbackNombre, canton: canton.slice(0, 70) };
  } catch {
    return { nombre: fallbackNombre, canton: fallbackCanton };
  }
}

export function capturarUbicacionGpsPrecisa(
  maxWaitMs = 4500,
  targetAccuracyM = 20
): Promise<UbicacionPrecisaResult> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      reject(new Error('Geolocalización no disponible en este navegador.'));
      return;
    }

    let bestPos: GeolocationPosition | null = null;
    let settled = false;
    let watchId: number | null = null;
    let timerId: ReturnType<typeof setTimeout> | null = null;

    const finish = async (pos: GeolocationPosition | null, err?: GeolocationPositionError) => {
      if (settled) return;
      settled = true;
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
      if (timerId !== null) clearTimeout(timerId);

      const finalPos = pos || bestPos;
      if (!finalPos) {
        reject(
          new Error(
            err?.code === 1
              ? 'Permiso de ubicación denegado. Activa el GPS en tu navegador para obtener tu posición exacta.'
              : 'No se pudo obtener la señal GPS. Intenta en un espacio abierto o escribe tu sector.'
          )
        );
        return;
      }

      const lat = Number(finalPos.coords.latitude.toFixed(6));
      const lng = Number(finalPos.coords.longitude.toFixed(6));
      const precisionMetros =
        typeof finalPos.coords.accuracy === 'number' && Number.isFinite(finalPos.coords.accuracy)
          ? Math.max(1, Math.round(finalPos.coords.accuracy))
          : null;

      const geo = await reverseGeocodeUbicacion(lat, lng);
      resolve({
        lat,
        lng,
        precisionMetros,
        nombreDireccion: geo.nombre,
        canton: geo.canton,
      });
    };

    watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (!bestPos || pos.coords.accuracy < bestPos.coords.accuracy) {
          bestPos = pos;
        }
        if (pos.coords.accuracy <= targetAccuracyM) {
          void finish(pos);
        }
      },
      (err) => {
        if (bestPos) {
          void finish(bestPos);
        } else if (err.code === 1) {
          void finish(null, err);
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: maxWaitMs + 3000,
      }
    );

    timerId = setTimeout(() => {
      void finish(bestPos);
    }, maxWaitMs);
  });
}


export const DEFAULT_TIPOS_VEHICULO: VehiculoTipoConfig[] = [
  { nombre: 'Pickup 4x4', maxPasajeros: 5, descripcion: 'Cuesta empinada, barro y carga · Hasta 5 pax' },
  { nombre: 'SUV Rural', maxPasajeros: 5, descripcion: 'Doble tracción cómoda · Hasta 5 pax' },
  { nombre: 'Sedan', maxPasajeros: 4, descripcion: 'Camino pavimentado o lastre liviano · Hasta 4 pax' },
  { nombre: 'Microbus', maxPasajeros: 12, descripcion: 'Grupos, familias o cuadrillas · Hasta 12 pax' },
  { nombre: 'Moto', maxPasajeros: 1, descripcion: 'Moto rural ágil para 1 pasajero y caminos estrechos' },
];

export const VEHICLE_CAPACITY_MAP: Record<TipoVehiculo, { maxPasajeros: number; descripcion: string }> = {
  'Sedan': { maxPasajeros: 4, descripcion: 'Camino pavimentado o lastre liviano · Hasta 4 pax' },
  'SUV Rural': { maxPasajeros: 5, descripcion: 'Doble tracción cómoda · Hasta 5 pax' },
  'Pickup 4x4': { maxPasajeros: 5, descripcion: 'Cuesta empinada, barro y carga · Hasta 5 pax' },
  'Microbus': { maxPasajeros: 12, descripcion: 'Grupos, familias o cuadrillas · Hasta 12 pax' },
  'Moto': { maxPasajeros: 1, descripcion: 'Moto rural ágil para 1 pasajero y caminos estrechos' },
};

export const DRIVER_AVATARS: Record<string, string> = {
  'driver-carlos': '/src/assets/images/driver_avatar_carlos_1794748978515.jpg',
  'driver-maria': '/src/assets/images/driver_avatar_maria_1794748978503.jpg',
  'driver-jose': '/src/assets/images/driver_avatar_jose_1794748978779.jpg',
};

export const PASSENGER_AVATAR = '/src/assets/images/passenger_avatar_elena_1794748979532.jpg';
export const HERO_ROAD_IMAGE = '/src/assets/images/rural_hero_road_1794748979890.jpg';

export function calcularDistanciaHaversineExactaKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.max(0, R * c);
}

export function formatearDistanciaRecogida(distKm: number): string {
  const safeKm = Math.max(0, distKm);
  if (safeKm < 1) {
    return `${Math.round(safeKm * 1000)} m`;
  }
  return `${safeKm.toFixed(1)} km`;
}

export function calcularDistanciaKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const distanciaRecta = calcularDistanciaHaversineExactaKm(lat1, lng1, lat2, lng2);
  // Factor de sinuosidad rural (1.28x por curvas y pendientes de montaña)
  return Math.max(0.8, Number((distanciaRecta * 1.28).toFixed(1)));
}

export function calcularMontoAproximado(tarifaBase: number, tarifaPorKm: number, distanciaKm: number): number {
  const raw = tarifaBase + tarifaPorKm * distanciaKm;
  return Math.round(raw / 50) * 50;
}

export function formatearColones(monto: number): string {
  return `₡${Math.round(monto).toLocaleString('es-CR')}`;
}

export function generarPin3Digitos(): string {
  return String(Math.floor(100 + Math.random() * 900));
}

export async function sha256Hex(texto: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(texto);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function sanitizeChatSinTelefonos(texto: string): { limpio: string; conteniaTelefono: boolean } {
  const phoneRegex = /(\+?\d[\d\s\-()]{6,}\d)/g;
  const conteniaTelefono = phoneRegex.test(texto);
  const limpio = texto.replace(phoneRegex, '[teléfono bloqueado por seguridad]');
  return { limpio, conteniaTelefono };
}

export function calcularPromediosTarifas(conductores: Conductor[]): {
  promedioBase: number;
  promedioKm: number;
} {
  if (conductores.length === 0) {
    return { promedioBase: 1500, promedioKm: 650 };
  }
  const sumBase = conductores.reduce((acc, c) => acc + c.tarifaBase, 0);
  const sumKm = conductores.reduce((acc, c) => acc + c.tarifaPorKm, 0);
  return {
    promedioBase: Math.round(sumBase / conductores.length),
    promedioKm: Math.round(sumKm / conductores.length),
  };
}

export function esTarifaAbusiva(
  tarifaBase: number,
  tarifaPorKm: number,
  promedioBase: number,
  promedioKm: number
): { abusiva: boolean; motivo: string } {
  const umbralBase = promedioBase * 1.3;
  const umbralKm = promedioKm * 1.3;
  if (tarifaBase > umbralBase && tarifaPorKm > umbralKm) {
    return {
      abusiva: true,
      motivo: `Base (+${Math.round(((tarifaBase - promedioBase) / promedioBase) * 100)}%) y km (+${Math.round(((tarifaPorKm - promedioKm) / promedioKm) * 100)}%) superan el +30% del promedio`,
    };
  }
  if (tarifaBase > umbralBase) {
    return {
      abusiva: true,
      motivo: `Tarifa base supera en +${Math.round(((tarifaBase - promedioBase) / promedioBase) * 100)}% el promedio (${formatearColones(promedioBase)})`,
    };
  }
  if (tarifaPorKm > umbralKm) {
    return {
      abusiva: true,
      motivo: `Tarifa por km supera en +${Math.round(((tarifaPorKm - promedioKm) / promedioKm) * 100)}% el promedio (${formatearColones(promedioKm)}/km)`,
    };
  }
  return { abusiva: false, motivo: '' };
}

export const DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE = 7000;
export const DEFAULT_ANIO_BASE_MENSUALIDAD = 2026;
export const TOKEN_MONTO_CONDUCTOR_VIGENTE = '{{MONTO_CONDUCTOR_VIGENTE}}';

export function calcularMensualidadActualConAjusteAnual(
  montoBase: number = DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
  anioBase: number = DEFAULT_ANIO_BASE_MENSUALIDAD,
  fecha: Date = new Date()
): {
  montoBase: number;
  anioBase: number;
  anioActual: number;
  incrementosAplicados: number;
  porcentajeAcumulado: number;
  montoActual: number;
  montoProximoEnero: number;
} {
  const baseNormalizada = Math.round(
    Math.max(
      500,
      Math.min(
        1_000_000,
        Number.isFinite(Number(montoBase)) && Number(montoBase) > 0
          ? Number(montoBase)
          : DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE
      )
    )
  );
  const anioBaseNormalizado = Math.round(
    Math.max(
      2020,
      Math.min(
        2100,
        Number.isFinite(Number(anioBase)) && Number(anioBase) >= 2020
          ? Number(anioBase)
          : DEFAULT_ANIO_BASE_MENSUALIDAD
      )
    )
  );
  // Evaluar siempre el año actual en zona horaria local de Costa Rica (America/Costa_Rica)
  const anioActual = getMesAnioCostaRica(fecha).year;
  const incrementosAplicados = Math.max(0, anioActual - anioBaseNormalizado);
  const montoActual = Math.round(baseNormalizada * Math.pow(1.1, incrementosAplicados));
  const montoProximoEnero = Math.round(baseNormalizada * Math.pow(1.1, incrementosAplicados + 1));
  const porcentajeAcumulado = Math.round((Math.pow(1.1, incrementosAplicados) - 1) * 1000) / 10;
  return {
    montoBase: baseNormalizada,
    anioBase: anioBaseNormalizado,
    anioActual,
    incrementosAplicados,
    porcentajeAcumulado,
    montoActual,
    montoProximoEnero,
  };
}

export function calcularDiasLicenciaRestantes(
  licenciaExp?:
    | { toDate?: () => Date; seconds?: number; _seconds?: number }
    | Date
    | number
    | string
    | null
): {
  dias: number;
  fechaTexto: string;
  estado: 'vencida' | 'por_vencer' | 'vigente';
  etiqueta: string;
} {
  let fecha: Date | null = null;
  if (licenciaExp instanceof Date) {
    fecha = licenciaExp;
  } else if (typeof licenciaExp === 'number' && Number.isFinite(licenciaExp)) {
    fecha = new Date(licenciaExp < 100_000_000_000 ? licenciaExp * 1000 : licenciaExp);
  } else if (typeof licenciaExp === 'string' && licenciaExp.trim()) {
    const parsed = Date.parse(licenciaExp.trim());
    if (!Number.isNaN(parsed)) fecha = new Date(parsed);
  } else if (licenciaExp && typeof licenciaExp === 'object') {
    if (typeof licenciaExp.toDate === 'function') {
      fecha = licenciaExp.toDate();
    } else if (typeof licenciaExp.seconds === 'number') {
      fecha = new Date(licenciaExp.seconds * 1000);
    } else if (typeof licenciaExp._seconds === 'number') {
      fecha = new Date(licenciaExp._seconds * 1000);
    }
  }

  if (!fecha || Number.isNaN(fecha.getTime())) {
    return {
      dias: 0,
      fechaTexto: '--/--/----',
      estado: 'vencida',
      etiqueta: 'Licencia vencida',
    };
  }

  const diffMs = fecha.getTime() - Date.now();
  const dias = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const fechaTexto = fecha.toLocaleDateString('es-CR');
  const estado = dias <= 0 ? 'vencida' : dias <= 7 ? 'por_vencer' : 'vigente';
  const etiqueta = dias > 0 ? `Licencia vigente: ${dias} días` : 'Licencia vencida';
  return { dias, fechaTexto, estado, etiqueta };
}

export function buildWazeUrl(lat: number, lng: number): string {
  return `https://waze.com/ul?ll=${lat.toFixed(6)},${lng.toFixed(6)}&navigate=yes`;
}

export function sanitizeFirestoreId(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
}

export function playChatAlertSound(): void {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now);
    osc1.frequency.setValueAtTime(1174.66, now + 0.11);
    gain1.gain.setValueAtTime(0.08, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.33);
  } catch {
    // Ignorar si el navegador bloquea AudioContext antes de interacción
  }
}

export const DEFAULT_TERMINOS_CONDICIONES = `1. Naturaleza de la Plataforma (Solo Conexión)
Viaje Rural actúa exclusivamente como una herramienta tecnológica de conexión entre pasajeros y conductores locales independientes en zonas rurales. La plataforma no es intermediaria de cobros, no procesa pagos electrónicos ni retiene porcentajes por viaje. Todo acuerdo de transporte se liquida directamente en efectivo entre el pasajero y el conductor.

2. Licencia Mensual de Conductores y Pago SINPE Móvil
Los conductores verificados abonan una cuota fija mensual de conexión de ${TOKEN_MONTO_CONDUCTOR_VIGENTE} colones mediante SINPE Móvil al número autorizado por la administración. Esta tarifa tendrá un aumento automático del 10% anual cada 1 de enero (hora Costa Rica). El sistema enviará una notificación mensual de recordatorio antes del vencimiento de la licencia.

3. Transparencia Tarifaria y Uso Responsable
Cada conductor define libremente su tarifa base y tarifa por kilómetro, las cuales se muestran al pasajero antes de confirmar. El Administrador podrá emitir alertas por tarifas abusivas fuera del promedio local (+30%) y suspender cuentas con registros duplicados o incumplimiento de seguridad.

4. Privacidad de Teléfonos y Aceptación Obligatoria
Los números telefónicos permanecen ocultos en el chat y vistas operativas; únicamente el Administrador autorizado puede consultarlos para soporte o verificación. La aceptación expresa de estos términos es requisito obligatorio al registrarse en Viaje Rural.`;

export function resolverTerminosConductorDinamicos(
  textoBase?: string,
  config?: Partial<ConfiguracionGeneral>,
  fecha: Date = new Date()
): string {
  const fuente =
    textoBase && textoBase.trim().length >= 20 ? textoBase : DEFAULT_TERMINOS_CONDICIONES;
  const calc = calcularMensualidadActualConAjusteAnual(
    config?.montoMensualConductorBase,
    config?.anioBaseMensualidad,
    fecha
  );
  const montoVigenteStr = formatearColones(calc.montoActual);
  const montoBaseStr = formatearColones(calc.montoBase);
  const montoProximoStr = formatearColones(calc.montoProximoEnero);

  const tieneTokenVigente =
    /\{\{\s*MONTO_CONDUCTOR(?:_VIGENTE)?\s*\}\}/i.test(fuente);

  let resuelto = fuente
    .replace(/\{\{\s*MONTO_CONDUCTOR_VIGENTE\s*\}\}/gi, montoVigenteStr)
    .replace(/\{\{\s*MONTO_CONDUCTOR\s*\}\}/gi, montoVigenteStr)
    .replace(/\{\{\s*MONTO_CONDUCTOR_BASE\s*\}\}/gi, montoBaseStr)
    .replace(/\{\{\s*MONTO_PROXIMO_ENERO\s*\}\}/gi, montoProximoStr)
    .replace(/\{\{\s*ANIO_BASE\s*\}\}/gi, String(calc.anioBase))
    .replace(/\{\{\s*ANIO_VIGENTE\s*\}\}/gi, String(calc.anioActual));

  // Compatibilidad con textos guardados manualmente sin el marcador dinámico
  if (!tieneTokenVigente) {
    const patronCuota = /((?:cuota|mensualidad|licencia|tarifa)[^\n₡]{0,60}?)₡\s*[\d.,]+/gi;
    if (patronCuota.test(resuelto)) {
      resuelto = resuelto.replace(patronCuota, `$1${montoVigenteStr}`);
    } else if (/₡\s*[\d.,]+/.test(resuelto)) {
      resuelto = resuelto.replace(/₡\s*[\d.,]+/, montoVigenteStr);
    } else {
      resuelto = `${resuelto}\n\nCuota mensual vigente (${calc.anioActual}): ${montoVigenteStr} colones (+10% automático cada 1 de enero).`;
    }
  }

  return resuelto;
}

export const DEFAULT_TERMINOS_CONDICIONES_PASAJERO = `1. Uso Gratuito para el Pasajero (Sin Cobro de App ni Comisiones)
El uso de Viaje Rural es 100% gratuito para el pasajero. No se incluye ningún tipo de cobro por uso de la aplicación, suscripciones, comisiones ni cargos adicionales de plataforma sobre tus viajes.

2. Pago Directo en Efectivo al Conductor
El pasajero paga únicamente la tarifa del viaje mostrada antes de confirmar la solicitud, liquidándola directamente en efectivo al conductor al finalizar el traslado.

3. PIN de Seguridad y Uso Responsable
Cada viaje asignado genera un PIN de seguridad de 3 dígitos que debes entregar al conductor únicamente al momento de abordar el vehículo. En caso de cancelar, deberás indicar el motivo con transparencia.

4. Privacidad de Datos
Tu número telefónico y datos personales permanecen protegidos y no se muestran en el chat operativo ni a terceros; solo el Administrador autorizado puede revisarlos para soporte o verificación.`;

export const DEFAULT_LINK_DESCARGA = 'https://viajerural.com/descargar';

export const DEFAULT_CONFIGURACION_GENERAL = {
  whatsappSoporte: '62546546',
  sinpeNumero: '62546546',
  adminNombre: 'Administrador Viaje Rural',
  adminTelefono: '62546546',
  adminEmail: ADMIN_EMAIL,
  adminSinpeTitular: 'Viaje Rural CR',
  terminosCondiciones: DEFAULT_TERMINOS_CONDICIONES,
  terminosCondicionesPasajero: DEFAULT_TERMINOS_CONDICIONES_PASAJERO,
  montoMensualConductorBase: DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
  anioBaseMensualidad: DEFAULT_ANIO_BASE_MENSUALIDAD,
  linkDescarga: DEFAULT_LINK_DESCARGA,
  tiposVehiculo: DEFAULT_TIPOS_VEHICULO,
};

export function buildWhatsAppShareAppUrl(linkDescarga?: string): string {
  const enlace = (linkDescarga || DEFAULT_LINK_DESCARGA).trim() || DEFAULT_LINK_DESCARGA;
  const texto = `¡Descarga Viaje Rural! Transporte rural confiable con cobro directo en efectivo y sin comisiones por viaje: ${enlace}`;
  return `https://wa.me/?text=${encodeURIComponent(texto)}`;
}

export async function compartirAppEnDispositivo(
  linkDescarga?: string
): Promise<{ status: 'shared' | 'copied'; whatsappUrl: string; mensaje: string }> {
  const enlace = (linkDescarga || DEFAULT_LINK_DESCARGA).trim() || DEFAULT_LINK_DESCARGA;
  const mensaje = `¡Descarga Viaje Rural! Transporte rural confiable en tu comunidad: ${enlace}`;
  const whatsappUrl = buildWhatsAppShareAppUrl(enlace);

  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      await navigator.share({
        title: 'Viaje Rural',
        text: '¡Descarga Viaje Rural! Transporte rural confiable en tu comunidad:',
        url: enlace,
      });
      return { status: 'shared', whatsappUrl, mensaje };
    } catch {
      // Fallback to clipboard copy below
    }
  }

  if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(mensaje);
    } catch {
      // Ignorar si clipboard falla en contexto restringido
    }
  }
  return { status: 'copied', whatsappUrl, mensaje };
}

export function buildWhatsAppSupportUrl(numeroRaw: string, mensaje?: string): string {
  const digits = (numeroRaw || '62546546').replace(/\D/g, '');
  const fullNumber = digits.startsWith('506') ? digits : `506${digits}`;
  const text = encodeURIComponent(
    mensaje || 'Hola Soporte Viaje Rural, necesito ayuda con la plataforma / pago SINPE.'
  );
  return `https://wa.me/${fullNumber}?text=${text}`;
}

export function buildWhatsAppContactUrl(numeroRaw: string, mensaje?: string): string | null {
  const digits = (numeroRaw || '').replace(/\D/g, '');
  if (digits.length < 8) return null;
  const fullNumber = digits.length === 8 ? `506${digits}` : digits;
  if (mensaje && mensaje.trim()) {
    return `https://wa.me/${fullNumber}?text=${encodeURIComponent(mensaje.trim())}`;
  }
  return `https://wa.me/${fullNumber}`;
}

export function compressImageToDataUrl(
  file: File,
  maxWidth = 800,
  quality = 0.7,
  maxDataUrlLength = 145000
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('No se pudo leer la imagen seleccionada.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Formato de imagen inválido.'));
      img.onload = () => {
        const scale = Math.min(1, maxWidth / Math.max(1, img.width));
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result || '').slice(0, maxDataUrlLength));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        let result = canvas.toDataURL('image/jpeg', quality);
        if (result.length > maxDataUrlLength) {
          result = canvas.toDataURL('image/jpeg', 0.55);
        }
        if (result.length > maxDataUrlLength) {
          result = canvas.toDataURL('image/jpeg', 0.45);
        }
        resolve(result);
      };
      img.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
  });
}

export function extraerTimestampMs(valor: unknown): number | null {
  if (valor == null) return null;
  if (valor instanceof Date) {
    const ms = valor.getTime();
    return Number.isFinite(ms) ? ms : null;
  }
  if (typeof valor === 'number') {
    return Number.isFinite(valor) ? valor : null;
  }
  if (typeof valor === 'string') {
    const parsed = Date.parse(valor);
    return Number.isFinite(parsed) ? parsed : null;
  }
  if (typeof valor === 'object') {
    const obj = valor as {
      toMillis?: () => number;
      toDate?: () => Date;
      seconds?: number;
      nanoseconds?: number;
    };
    if (typeof obj.toMillis === 'function') {
      const ms = obj.toMillis();
      return Number.isFinite(ms) ? ms : null;
    }
    if (typeof obj.toDate === 'function') {
      const ms = obj.toDate().getTime();
      return Number.isFinite(ms) ? ms : null;
    }
    if (typeof obj.seconds === 'number') {
      const ms = obj.seconds * 1000 + Math.floor((obj.nanoseconds || 0) / 1_000_000);
      return Number.isFinite(ms) ? ms : null;
    }
  }
  return null;
}

export function getRangoCalendarioLocal(referencia: Date = new Date()): {
  inicioHoyMs: number;
  finHoyMs: number;
  inicioMesMs: number;
  finMesMs: number;
  claveDiaLocal: string;
} {
  const year = referencia.getFullYear();
  const month = referencia.getMonth();
  const day = referencia.getDate();

  const inicioHoy = new Date(year, month, day, 0, 0, 0, 0);
  const finHoy = new Date(year, month, day, 23, 59, 59, 999);
  const inicioMes = new Date(year, month, 1, 0, 0, 0, 0);
  const finMes = new Date(year, month + 1, 0, 23, 59, 59, 999);

  const mm = String(month + 1).padStart(2, '0');
  const dd = String(day).padStart(2, '0');

  return {
    inicioHoyMs: inicioHoy.getTime(),
    finHoyMs: finHoy.getTime(),
    inicioMesMs: inicioMes.getTime(),
    finMesMs: finMes.getTime(),
    claveDiaLocal: `${year}-${mm}-${dd}`,
  };
}

export function calcularFinanzasConductorLocal(
  viajes: Viaje[],
  referencia: Date = new Date(),
  excluirViajeId?: string
): { gananciasHoy: number; gananciasMes: number; viajesHoy: number; viajesMes: number } {
  const { inicioHoyMs, finHoyMs, inicioMesMs, finMesMs } = getRangoCalendarioLocal(referencia);
  let gananciasHoy = 0;
  let gananciasMes = 0;
  let viajesHoy = 0;
  let viajesMes = 0;

  for (const v of viajes) {
    if (excluirViajeId && v.id === excluirViajeId) continue;
    if (v.estado !== 'finalizado') continue;
    const fechaMs = extraerTimestampMs(v.updatedAt) ?? extraerTimestampMs(v.createdAt);
    if (fechaMs == null) continue;
    const monto = Math.max(0, Number(v.montoAproximado) || 0);
    if (fechaMs >= inicioHoyMs && fechaMs <= finHoyMs) {
      gananciasHoy += monto;
      viajesHoy += 1;
    }
    if (fechaMs >= inicioMesMs && fechaMs <= finMesMs) {
      gananciasMes += monto;
      viajesMes += 1;
    }
  }

  return {
    gananciasHoy: Math.round(gananciasHoy * 100) / 100,
    gananciasMes: Math.round(gananciasMes * 100) / 100,
    viajesHoy,
    viajesMes,
  };
}

export const TIMEZONE_COSTA_RICA = 'America/Costa_Rica';

const MESES_ES = [
  'Enero',
  'Febrero',
  'Marzo',
  'Abril',
  'Mayo',
  'Junio',
  'Julio',
  'Agosto',
  'Septiembre',
  'Octubre',
  'Noviembre',
  'Diciembre',
];

export function formatMesLabelEs(year: number, month1Based: number): string {
  const mesNombre = MESES_ES[Math.max(0, Math.min(11, month1Based - 1))] || 'Mes';
  return `${mesNombre} ${year}`;
}

export function getMesAnioCostaRica(fecha: Date | number = new Date()): {
  key: string;
  label: string;
  year: number;
  month: number;
} {
  const dateObj = typeof fecha === 'number' ? new Date(fecha) : fecha;
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: TIMEZONE_COSTA_RICA,
    year: 'numeric',
    month: '2-digit',
  }).formatToParts(dateObj);

  const year = Number(parts.find((p) => p.type === 'year')?.value || dateObj.getUTCFullYear());
  const month = Number(parts.find((p) => p.type === 'month')?.value || dateObj.getUTCMonth() + 1);
  const mm = String(month).padStart(2, '0');
  return {
    key: `${year}-${mm}`,
    label: formatMesLabelEs(year, month),
    year,
    month,
  };
}

export function parseMesKey(mesKey: string): { year: number; month: number } {
  const [yStr, mStr] = mesKey.split('-');
  const year = Number(yStr);
  const month = Number(mStr);
  if (!Number.isFinite(year) || !Number.isFinite(month) || month < 1 || month > 12) {
    const actual = getMesAnioCostaRica();
    return { year: actual.year, month: actual.month };
  }
  return { year, month };
}

export function stepMesAnioKey(mesKey: string, deltaMeses: number): string {
  const { year, month } = parseMesKey(mesKey);
  const d = new Date(Date.UTC(year, month - 1 + deltaMeses, 15, 12, 0, 0));
  const nextY = d.getUTCFullYear();
  const nextM = d.getUTCMonth() + 1;
  return `${nextY}-${String(nextM).padStart(2, '0')}`;
}

export function formatMesKeyLabel(mesKey: string): string {
  const { year, month } = parseMesKey(mesKey);
  return formatMesLabelEs(year, month);
}

export function extraerMesKeyViajeCostaRica(viaje: Viaje): string | null {
  const ms = extraerTimestampMs(viaje.updatedAt) ?? extraerTimestampMs(viaje.createdAt);
  if (ms == null) return null;
  return getMesAnioCostaRica(ms).key;
}

export function construirOpcionesMesesCostaRica(
  viajes: Viaje[],
  mesSeleccionadoKey?: string
): Array<{ key: string; label: string }> {
  const keys = new Set<string>();
  const actual = getMesAnioCostaRica();
  keys.add(actual.key);
  if (mesSeleccionadoKey) keys.add(mesSeleccionadoKey);

  for (const v of viajes) {
    const mk = extraerMesKeyViajeCostaRica(v);
    if (mk) keys.add(mk);
  }

  return Array.from(keys)
    .sort((a, b) => b.localeCompare(a))
    .map((key) => ({
      key,
      label: formatMesKeyLabel(key),
    }));
}

export function filtrarViajesPorMesCostaRica(viajes: Viaje[], mesKey: string): Viaje[] {
  return viajes.filter((v) => extraerMesKeyViajeCostaRica(v) === mesKey);
}

export function formatearFechaHoraCostaRica(
  valor: unknown,
  incluirHora = true
): string {
  const ms = extraerTimestampMs(valor);
  if (ms == null) return 'Reciente';
  const fecha = new Date(ms);
  return incluirHora
    ? fecha.toLocaleString('es-CR', {
        timeZone: TIMEZONE_COSTA_RICA,
        dateStyle: 'short',
        timeStyle: 'short',
      })
    : fecha.toLocaleDateString('es-CR', {
        timeZone: TIMEZONE_COSTA_RICA,
        dateStyle: 'short',
      });
}




