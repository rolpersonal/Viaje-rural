import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import {
  collection,
  doc,
  getCountFromServer,
  getDoc,
  getDocs,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  Unsubscribe,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  ADMIN_EMAIL,
  calcularDistanciaKm,
  calcularMontoAproximado,
  DEFAULT_CONFIGURACION_GENERAL,
  DEFAULT_LINK_DESCARGA,
  DRIVER_AVATARS,
  generarPin3Digitos,
  PASSENGER_AVATAR,
  sanitizeChatSinTelefonos,
  sanitizeFirestoreId,
  sha256Hex,
} from '../lib/ruralUtils';
import {
  Calificacion,
  CambiosSolicitados,
  Conductor,
  ConductorDocumentos,
  ConfiguracionGeneral,
  EstadoCuentaConductor,
  EstadoOperativoConductor,
  MensajeChat,
  Pasajero,
  RutaFavorita,
  SolicitudCambioDatos,
  TipoVehiculo,
  UsuarioPII,
  UsuarioPublico,
  Viaje,
} from '../types/viajeRural';

export function isCurrentUserAdmin(): boolean {
  return auth.currentUser?.email === ADMIN_EMAIL && auth.currentUser?.emailVerified === true;
}

export async function ensureUserProfile(uid: string, nombre: string, email: string | null, fotoUrl?: string): Promise<void> {
  const userPath = `usuarios/${uid}`;
  try {
    const userRef = doc(db, 'usuarios', uid);
    const snap = await getDoc(userRef);
    const esAdmin = email === ADMIN_EMAIL;
    if (!snap.exists()) {
      const payload: Record<string, unknown> = {
        uid,
        nombre: (nombre || 'Usuario Rural').slice(0, 100),
        rol: esAdmin ? 'admin' : 'pasajero',
        fotoUrl: (fotoUrl || PASSENGER_AVATAR).slice(0, 500),
        bloqueado: false,
        terminosAceptados: true,
        terminosAceptadosAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      await setDoc(userRef, payload);

      const pasajeroRef = doc(db, 'pasajeros', uid);
      await setDoc(pasajeroRef, {
        uid,
        nombre: (nombre || 'Pasajero Rural').slice(0, 100),
        fotoUrl: (fotoUrl || PASSENGER_AVATAR).slice(0, 500),
        promedioCalificacion: 5.0,
        totalCalificaciones: 0,
        favoritos: [],
        rutasFavoritas: [],
        bloqueado: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      if (esAdmin) {
        await setDoc(doc(db, 'admins', uid), {
          uid,
          email: email || ADMIN_EMAIL,
          createdAt: serverTimestamp(),
        });
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function seedInitialRuralFleetIfNeeded(): Promise<boolean> {
  if (!isCurrentUserAdmin()) return false;
  const colPath = 'conductores';
  try {
    const existing = await getDocs(query(collection(db, colPath), limit(1)));
    if (!existing.empty) return false;

    const batch = writeBatch(db);
    const in60Days = Timestamp.fromDate(new Date(Date.now() + 60 * 24 * 60 * 60 * 1000));
    const in5Days = Timestamp.fromDate(new Date(Date.now() + 5 * 24 * 60 * 60 * 1000));

    const demoDrivers: Array<{
      driver: Omit<Conductor, 'createdAt' | 'updatedAt' | 'ultimoPingAt'>;
      pii: Omit<UsuarioPII, 'updatedAt'>;
    }> = [
      {
        driver: {
          uid: 'driver-carlos',
          nombre: 'Carlos Méndez Mora',
          fotoUrl: DRIVER_AVATARS['driver-carlos'],
          vehiculoTipo: 'Pickup 4x4',
          vehiculoModelo: 'Toyota Hilux 4x4 Doble Cabina',
          placa: 'CL-408219',
          capacidad: 5,
          tarifaBase: 1500,
          tarifaPorKm: 650,
          estadoCuenta: 'activo',
          estadoOperativo: 'disponible',
          lat: 9.3812,
          lng: -83.6884,
          licenciaExp: in60Days,
          mensualidadPendiente: false,
          promedioCalificacion: 4.9,
          totalCalificaciones: 42,
          totalViajes: 128,
          gananciasHoy: 18500,
          gananciasMes: 214000,
          cedulaHash: 'CR-1-0942-0518',
          terminosAceptados: true,
        },
        pii: {
          uid: 'driver-carlos',
          telefono: '+506 8841-2390',
          email: 'carlos.mendez@viajerural.cr',
          cedula: '1-0942-0518',
        },
      },
      {
        driver: {
          uid: 'driver-maria',
          nombre: 'María Rojas Quesada',
          fotoUrl: DRIVER_AVATARS['driver-maria'],
          vehiculoTipo: 'SUV Rural',
          vehiculoModelo: 'Suzuki Grand Vitara 4WD',
          placa: 'BJK-714',
          capacidad: 5,
          tarifaBase: 1400,
          tarifaPorKm: 600,
          estadoCuenta: 'activo',
          estadoOperativo: 'disponible',
          lat: 9.3925,
          lng: -83.6542,
          licenciaExp: in5Days,
          mensualidadPendiente: true,
          promedioCalificacion: 4.95,
          totalCalificaciones: 31,
          totalViajes: 94,
          gananciasHoy: 14200,
          gananciasMes: 168500,
          cedulaHash: 'CR-1-1284-0392',
          terminosAceptados: true,
        },
        pii: {
          uid: 'driver-maria',
          telefono: '+506 8715-9942',
          email: 'maria.rojas@viajerural.cr',
          cedula: '1-1284-0392',
        },
      },
      {
        driver: {
          uid: 'driver-jose',
          nombre: 'José Vargas Picado',
          fotoUrl: DRIVER_AVATARS['driver-jose'],
          vehiculoTipo: 'Microbus',
          vehiculoModelo: 'Hyundai H-1 Rural 12 Pax',
          placa: 'PB-9204',
          capacidad: 12,
          tarifaBase: 2200,
          tarifaPorKm: 800,
          estadoCuenta: 'activo',
          estadoOperativo: 'disponible',
          lat: 9.412,
          lng: -83.631,
          licenciaExp: in60Days,
          mensualidadPendiente: false,
          promedioCalificacion: 4.8,
          totalCalificaciones: 19,
          totalViajes: 63,
          gananciasHoy: 26400,
          gananciasMes: 312000,
          cedulaHash: 'CR-1-0751-0884',
          terminosAceptados: true,
        },
        pii: {
          uid: 'driver-jose',
          telefono: '+506 8920-4411',
          email: 'jose.vargas@viajerural.cr',
          cedula: '1-0751-0884',
        },
      },
    ];

    for (const item of demoDrivers) {
      batch.set(doc(db, 'conductores', item.driver.uid), {
        ...item.driver,
        ultimoPingAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'usuarios', item.driver.uid), {
        uid: item.driver.uid,
        nombre: item.driver.nombre,
        rol: 'conductor',
        fotoUrl: item.driver.fotoUrl,
        bloqueado: false,
        terminosAceptados: true,
        terminosAceptadosAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'usuarios', item.driver.uid, 'private', 'pii'), {
        ...item.pii,
        updatedAt: serverTimestamp(),
      });
    }

    // Seed 1 pending driver for Admin verification workflow
    batch.set(doc(db, 'conductores', 'driver-pendiente-luis'), {
      uid: 'driver-pendiente-luis',
      nombre: 'Luis Solís Valverde',
      fotoUrl: DRIVER_AVATARS['driver-carlos'],
      vehiculoTipo: 'Pickup 4x4',
      vehiculoModelo: 'Mitsubishi L200 4x4',
      placa: 'CL-408219', // Duplicate plate intentionally for admin duplicate detector!
      capacidad: 5,
      tarifaBase: 2800, // Abusive fare intentionally for admin alert!
      tarifaPorKm: 1150,
      estadoCuenta: 'pendiente',
      estadoOperativo: 'offline',
      lat: 9.365,
      lng: -83.711,
      licenciaExp: in5Days,
      mensualidadPendiente: true,
      promedioCalificacion: 5.0,
      totalCalificaciones: 0,
      totalViajes: 0,
      gananciasHoy: 0,
      gananciasMes: 0,
      cedulaHash: 'CR-1-1450-0912',
      terminosAceptados: true,
      ultimoPingAt: serverTimestamp(),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'usuarios', 'driver-pendiente-luis', 'private', 'pii'), {
      uid: 'driver-pendiente-luis',
      telefono: '+506 8632-1044',
      email: 'luis.solis@viajerural.cr',
      cedula: '1-1450-0912',
      updatedAt: serverTimestamp(),
    });

    // Seed 1 sample passenger so Admin Passenger Ficha list is populated immediately
    batch.set(doc(db, 'pasajeros', 'passenger-elena'), {
      uid: 'passenger-elena',
      nombre: 'Elena Mora Chacón',
      fotoUrl: PASSENGER_AVATAR,
      promedioCalificacion: 4.92,
      totalCalificaciones: 14,
      favoritos: ['San Gerardo de Rivas'],
      bloqueado: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'usuarios', 'passenger-elena'), {
      uid: 'passenger-elena',
      nombre: 'Elena Mora Chacón',
      rol: 'pasajero',
      fotoUrl: PASSENGER_AVATAR,
      bloqueado: false,
      terminosAceptados: true,
      terminosAceptadosAt: serverTimestamp(),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'usuarios', 'passenger-elena', 'private', 'pii'), {
      uid: 'passenger-elena',
      telefono: '+506 8451-7720',
      email: 'elena.mora@viajerural.cr',
      cedula: '1-1567-0244',
      updatedAt: serverTimestamp(),
    });

    await batch.commit();
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, colPath);
  }
}

export function subscribeConductoresActivos(
  callback: (conductores: Conductor[]) => void
): Unsubscribe {
  const q = query(
    collection(db, 'conductores'),
    where('estadoCuenta', '==', 'activo'),
    limit(20)
  );
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as Conductor);
      callback(list);
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'conductores')
  );
}

export function subscribeTodosConductoresAdmin(
  callback: (conductores: Conductor[]) => void
): Unsubscribe {
  const q = query(collection(db, 'conductores'), limit(30));
  return onSnapshot(
    q,
    (snap) => {
      callback(snap.docs.map((d) => d.data() as Conductor));
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'conductores')
  );
}

export function subscribeConductorById(
  conductorId: string,
  callback: (conductor: Conductor | null) => void
): Unsubscribe {
  const path = `conductores/${conductorId}`;
  return onSnapshot(
    doc(db, 'conductores', conductorId),
    (snap) => {
      callback(snap.exists() ? (snap.data() as Conductor) : null);
    },
    (error) => handleFirestoreError(error, OperationType.GET, path)
  );
}

export async function ejecutarPingUnSegundo(
  pasajeroId: string,
  origenLat: number,
  origenLng: number,
  conductoresDisponibles: Conductor[]
): Promise<Conductor[]> {
  const pingId = sanitizeFirestoreId(`ping_${pasajeroId}_${Date.now()}`);
  const pingPath = `pingRequests/${pingId}`;
  try {
    await setDoc(doc(db, 'pingRequests', pingId), {
      pasajeroId,
      origenLat,
      origenLng,
      conductoresNotificados: conductoresDisponibles.length,
      createdAt: serverTimestamp(),
    });

    // If admin/owner, update ultimoPingAt with slight realistic 1s GPS refresh for demo drivers
    const batch = writeBatch(db);
    let hasWrites = false;
    for (const c of conductoresDisponibles) {
      if (isCurrentUserAdmin() || c.uid === auth.currentUser?.uid) {
        const jitterLat = (Math.random() - 0.5) * 0.002;
        const jitterLng = (Math.random() - 0.5) * 0.002;
        batch.update(doc(db, 'conductores', c.uid), {
          lat: Number(((c.lat ?? 9.38) + jitterLat).toFixed(6)),
          lng: Number(((c.lng ?? -83.68) + jitterLng).toFixed(6)),
          ultimoPingAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        hasWrites = true;
      }
    }
    if (hasWrites) {
      await batch.commit();
    }

    // Sort by proximity to passenger origin
    return [...conductoresDisponibles].sort((a, b) => {
      const distA = calcularDistanciaKm(origenLat, origenLng, a.lat ?? 9.38, a.lng ?? -83.68);
      const distB = calcularDistanciaKm(origenLat, origenLng, b.lat ?? 9.38, b.lng ?? -83.68);
      return distA - distB;
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, pingPath);
  }
}

export async function crearSolicitudViaje(params: {
  pasajeroId: string;
  pasajeroNombre: string;
  pasajeroFotoUrl?: string;
  cantidadPasajeros: number;
  origenNombre: string;
  origenLat: number;
  origenLng: number;
  destinoNombre: string;
  destinoLat: number;
  destinoLng: number;
  resenaUbicacion: string;
  tiposVehiculoPermitidos: TipoVehiculo[];
  colaConductoresOrdenada: Conductor[];
}): Promise<{ viajeId: string; pin: string }> {
  if (!Number.isInteger(params.cantidadPasajeros) || params.cantidadPasajeros < 1 || params.cantidadPasajeros > 16) {
    throw new Error('Debes indicar al menos 1 pasajero (máximo 16) para solicitar el viaje.');
  }
  const viajeId = sanitizeFirestoreId(`viaje_${params.pasajeroId.slice(0, 12)}_${Date.now()}`);
  const pin = generarPin3Digitos();
  const pinHash = await sha256Hex(`${viajeId}:${pin}`);
  const distanciaKm = calcularDistanciaKm(
    params.origenLat,
    params.origenLng,
    params.destinoLat,
    params.destinoLng
  );

  const primerConductor = params.colaConductoresOrdenada[0];
  const montoAproximado = primerConductor
    ? calcularMontoAproximado(primerConductor.tarifaBase, primerConductor.tarifaPorKm, distanciaKm)
    : calcularMontoAproximado(1500, 650, distanciaKm);

  const colaIds = params.colaConductoresOrdenada.map((c) => c.uid).slice(0, 20);
  const viajePath = `viajes/${viajeId}`;

  try {
    await setDoc(doc(db, 'viajes', viajeId), {
      pasajeroId: params.pasajeroId,
      pasajeroNombre: params.pasajeroNombre.slice(0, 100),
      pasajeroFotoUrl: (params.pasajeroFotoUrl || PASSENGER_AVATAR).slice(0, 500),
      conductorId: null,
      conductorNombre: null,
      conductorFotoUrl: null,
      conductorPlaca: null,
      vehiculoTipoSeleccionado: null,
      tiposVehiculoPermitidos: params.tiposVehiculoPermitidos.slice(0, 6),
      cantidadPasajeros: params.cantidadPasajeros,
      origenNombre: params.origenNombre.slice(0, 160),
      origenLat: params.origenLat,
      origenLng: params.origenLng,
      destinoNombre: params.destinoNombre.slice(0, 160),
      destinoLat: params.destinoLat,
      destinoLng: params.destinoLng,
      distanciaKm,
      resenaUbicacion: params.resenaUbicacion.trim().slice(0, 280),
      montoAproximado,
      tarifaBaseAplicada: primerConductor?.tarifaBase ?? 1500,
      tarifaKmAplicada: primerConductor?.tarifaPorKm ?? 650,
      pinHash,
      pinVerificado: false,
      gpsConductorActivo: false,
      conductorLat: null,
      conductorLng: null,
      etaMinutos: null,
      colaConductores: colaIds,
      ofertaActualIndex: 0,
      ofertaExpiraAt: Date.now() + 15000,
      estado: 'buscando',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    await setDoc(doc(db, 'viajes', viajeId, 'secreto', 'codigo'), {
      pasajeroId: params.pasajeroId,
      pin,
      createdAt: serverTimestamp(),
    });

    localStorage.setItem(`viaje_rural_pin_${viajeId}`, pin);
    return { viajeId, pin };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, viajePath);
  }
}

export function subscribeViajeActivoPasajero(
  pasajeroId: string,
  callback: (viaje: Viaje | null) => void
): Unsubscribe {
  const q = query(
    collection(db, 'viajes'),
    where('pasajeroId', '==', pasajeroId),
    where('estado', 'in', ['buscando', 'aceptado', 'en_curso']),
    limit(1)
  );
  return onSnapshot(
    q,
    (snap) => {
      if (snap.empty) {
        callback(null);
      } else {
        const d = snap.docs[0];
        callback({ ...(d.data() as Omit<Viaje, 'id'>), id: d.id });
      }
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'viajes')
  );
}

export function subscribeUltimoViajeFinalizadoPasajero(
  pasajeroId: string,
  callback: (viaje: Viaje | null) => void
): Unsubscribe {
  // Consulta sin orderBy compuesto para evitar error de índice faltante y garantizar el modal de pago
  const q = query(
    collection(db, 'viajes'),
    where('pasajeroId', '==', pasajeroId),
    where('estado', '==', 'finalizado'),
    limit(5)
  );
  return onSnapshot(
    q,
    (snap) => {
      if (snap.empty) {
        callback(null);
      } else {
        const sorted = snap.docs
          .map((d) => ({ ...(d.data() as Omit<Viaje, 'id'>), id: d.id }))
          .sort((a, b) => {
            const ta = a.updatedAt?.toMillis?.() ?? 0;
            const tb = b.updatedAt?.toMillis?.() ?? 0;
            return tb - ta;
          });
        callback(sorted[0] || null);
      }
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'viajes')
  );
}

export function subscribePinSecreto(
  viajeId: string,
  callback: (pin: string | null) => void
): Unsubscribe {
  const path = `viajes/${viajeId}/secreto/codigo`;
  return onSnapshot(
    doc(db, 'viajes', viajeId, 'secreto', 'codigo'),
    (snap) => {
      if (snap.exists()) {
        const pin = snap.data().pin as string;
        localStorage.setItem(`viaje_rural_pin_${viajeId}`, pin);
        callback(pin);
      } else {
        callback(localStorage.getItem(`viaje_rural_pin_${viajeId}`));
      }
    },
    (error) => handleFirestoreError(error, OperationType.GET, path)
  );
}

export function subscribeViajeActivoConductor(
  conductorId: string,
  callback: (viaje: Viaje | null) => void
): Unsubscribe {
  const q = query(
    collection(db, 'viajes'),
    where('conductorId', '==', conductorId),
    where('estado', 'in', ['aceptado', 'en_curso']),
    limit(1)
  );
  return onSnapshot(
    q,
    (snap) => {
      if (snap.empty) {
        callback(null);
      } else {
        const d = snap.docs[0];
        callback({ ...(d.data() as Omit<Viaje, 'id'>), id: d.id });
      }
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'viajes')
  );
}

export function subscribeOfertasParaConductor(
  conductorId: string,
  callback: (viajes: Viaje[]) => void
): Unsubscribe {
  const q = query(
    collection(db, 'viajes'),
    where('colaConductores', 'array-contains', conductorId),
    where('estado', '==', 'buscando'),
    limit(5)
  );
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => ({ ...(d.data() as Omit<Viaje, 'id'>), id: d.id }));
      callback(list);
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'viajes')
  );
}

export async function avanzarColaOfertaSecuencial(
  viajeId: string,
  conductorActualId: string,
  fueRechazoManual: boolean
): Promise<void> {
  const viajeRef = doc(db, 'viajes', viajeId);
  const path = `viajes/${viajeId}`;
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(viajeRef);
      if (!snap.exists()) return;
      const data = snap.data() as Viaje;
      if (data.estado !== 'buscando' || data.colaConductores.length === 0) return;

      const idxActual = data.ofertaActualIndex % data.colaConductores.length;
      const turnoActual = data.colaConductores[idxActual];
      if (turnoActual !== conductorActualId && !fueRechazoManual) return;

      let nuevaCola = [...data.colaConductores];
      let nuevoIdx = idxActual;

      if (fueRechazoManual) {
        // El que rechazó pasa al final de la cola
        nuevaCola = nuevaCola.filter((id) => id !== conductorActualId);
        nuevaCola.push(conductorActualId);
        if (nuevoIdx >= nuevaCola.length) nuevoIdx = 0;
      } else {
        // Timeout de 15s: pasa al siguiente en la cola
        nuevoIdx = (idxActual + 1) % nuevaCola.length;
      }

      tx.update(viajeRef, {
        colaConductores: nuevaCola,
        ofertaActualIndex: nuevoIdx,
        ofertaExpiraAt: Date.now() + 15000,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function aceptarViajeAtomicamente(
  viajeId: string,
  conductor: Conductor
): Promise<{ exito: boolean; motivo?: string }> {
  const viajeRef = doc(db, 'viajes', viajeId);
  const conductorRef = doc(db, 'conductores', conductor.uid);
  const path = `viajes/${viajeId}`;
  try {
    return await runTransaction(db, async (tx) => {
      const [viajeSnap, condSnap] = await Promise.all([
        tx.get(viajeRef),
        tx.get(conductorRef),
      ]);

      if (!viajeSnap.exists()) {
        return { exito: false, motivo: 'La solicitud de viaje ya no existe.' };
      }
      if (!condSnap.exists()) {
        return { exito: false, motivo: 'Tu perfil de conductor no fue encontrado.' };
      }

      const viajeData = viajeSnap.data() as Viaje;
      const condData = condSnap.data() as Conductor;

      if (viajeData.estado !== 'buscando') {
        return { exito: false, motivo: 'Otro conductor aceptó este viaje milisegundos antes.' };
      }
      if (condData.estadoCuenta !== 'activo') {
        return { exito: false, motivo: 'Tu cuenta de conductor no está activa.' };
      }
      if (condData.estadoOperativo !== 'disponible') {
        return { exito: false, motivo: 'Conflicto de estado: ya tienes otro viaje asignado.' };
      }

      const cLat = condData.lat ?? 9.385;
      const cLng = condData.lng ?? -83.682;
      const distRecogidaKm = calcularDistanciaKm(cLat, cLng, viajeData.origenLat, viajeData.origenLng);
      const etaMinutos = Math.max(2, Math.round((distRecogidaKm / 30) * 60));
      const montoAproximado = calcularMontoAproximado(
        condData.tarifaBase,
        condData.tarifaPorKm,
        viajeData.distanciaKm
      );

      tx.update(viajeRef, {
        estado: 'aceptado',
        conductorId: condData.uid,
        conductorNombre: condData.nombre,
        conductorFotoUrl: condData.fotoUrl || DRIVER_AVATARS['driver-carlos'],
        conductorPlaca: condData.placa,
        vehiculoTipoSeleccionado: condData.vehiculoTipo,
        tarifaBaseAplicada: condData.tarifaBase,
        tarifaKmAplicada: condData.tarifaPorKm,
        montoAproximado,
        gpsConductorActivo: true,
        conductorLat: cLat,
        conductorLng: cLng,
        etaMinutos,
        updatedAt: serverTimestamp(),
      });

      tx.update(conductorRef, {
        estadoOperativo: 'en_camino',
        updatedAt: serverTimestamp(),
      });

      return { exito: true };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function enviarPosicion90sRecogida(
  viajeId: string,
  conductorId: string,
  nuevaLat: number,
  nuevaLng: number,
  origenLat: number,
  origenLng: number
): Promise<number> {
  const distKm = calcularDistanciaKm(nuevaLat, nuevaLng, origenLat, origenLng);
  const etaMinutos = Math.max(1, Math.round((distKm / 30) * 60));
  const path = `viajes/${viajeId}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'viajes', viajeId), {
      conductorLat: nuevaLat,
      conductorLng: nuevaLng,
      etaMinutos,
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'conductores', conductorId), {
      lat: nuevaLat,
      lng: nuevaLng,
      ultimoPingAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
    return etaMinutos;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function verificarPinYComenzarViaje(
  viaje: Viaje,
  pinIngresado: string
): Promise<{ valido: boolean; mensaje: string }> {
  const hashIngresado = await sha256Hex(`${viaje.id}:${pinIngresado.trim()}`);
  if (hashIngresado !== viaje.pinHash) {
    return { valido: false, mensaje: 'El PIN de 3 dígitos no coincide. Pídelo al pasajero.' };
  }
  const path = `viajes/${viaje.id}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'viajes', viaje.id), {
      estado: 'en_curso',
      pinVerificado: true,
      gpsConductorActivo: false, // GPS se apaga por completo al confirmar PIN
      updatedAt: serverTimestamp(),
    });
    if (viaje.conductorId) {
      batch.update(doc(db, 'conductores', viaje.conductorId), {
        estadoOperativo: 'en_viaje',
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
    return { valido: true, mensaje: 'PIN confirmado. GPS apagado y viaje al destino habilitado.' };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function finalizarViaje(viaje: Viaje): Promise<void> {
  const path = `viajes/${viaje.id}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'viajes', viaje.id), {
      estado: 'finalizado',
      gpsConductorActivo: false,
      updatedAt: serverTimestamp(),
    });
    if (viaje.conductorId) {
      // Requisito 8 y 9: FieldValue.increment() en gananciasHoy y gananciasMes (sin listas de viajes)
      batch.update(doc(db, 'conductores', viaje.conductorId), {
        estadoOperativo: 'disponible',
        totalViajes: increment(1),
        gananciasHoy: increment(viaje.montoAproximado || 0),
        gananciasMes: increment(viaje.montoAproximado || 0),
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
    localStorage.removeItem(`viaje_rural_pin_${viaje.id}`);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function cancelarSolicitudViaje(
  viajeId: string,
  motivoCancelacion?: string
): Promise<void> {
  const path = `viajes/${viajeId}`;
  try {
    const motivoLimpio = (motivoCancelacion || '').trim().slice(0, 280);
    await updateDoc(doc(db, 'viajes', viajeId), {
      estado: 'cancelado',
      canceladoPor: 'pasajero',
      ...(motivoLimpio.length >= 3 ? { motivoCancelacion: motivoLimpio } : {}),
      updatedAt: serverTimestamp(),
    });
    localStorage.removeItem(`viaje_rural_pin_${viajeId}`);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function cancelarViajeConMotivo(params: {
  viaje: Viaje;
  canceladoPor: 'pasajero' | 'conductor';
  motivo: string;
}): Promise<void> {
  const path = `viajes/${params.viaje.id}`;
  const motivoLimpio = params.motivo.trim().slice(0, 280);
  if (motivoLimpio.length < 3) {
    throw new Error('Debes ingresar una nota explicando el motivo de la cancelación.');
  }

  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'viajes', params.viaje.id), {
      estado: 'cancelado',
      gpsConductorActivo: false,
      canceladoPor: params.canceladoPor,
      motivoCancelacion: motivoLimpio,
      updatedAt: serverTimestamp(),
    });

    if (params.canceladoPor === 'conductor' && params.viaje.conductorId) {
      batch.update(doc(db, 'conductores', params.viaje.conductorId), {
        estadoOperativo: 'disponible',
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
    localStorage.removeItem(`viaje_rural_pin_${params.viaje.id}`);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchViajeById(viajeId: string): Promise<Viaje | null> {
  const path = `viajes/${viajeId}`;
  try {
    const snap = await getDoc(doc(db, 'viajes', viajeId));
    return snap.exists() ? ({ ...(snap.data() as Omit<Viaje, 'id'>), id: snap.id }) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export function subscribeChatViaje(
  viajeId: string,
  callback: (mensajes: MensajeChat[]) => void
): Unsubscribe {
  const q = query(
    collection(db, 'chats', viajeId, 'mensajes'),
    orderBy('createdAt', 'asc'),
    limit(30)
  );
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => ({ ...(d.data() as Omit<MensajeChat, 'id'>), id: d.id }));
      callback(list);
    },
    (error) => handleFirestoreError(error, OperationType.LIST, `chats/${viajeId}/mensajes`)
  );
}

export async function enviarMensajeChat(params: {
  viajeId: string;
  autorUid: string;
  autorRol: 'pasajero' | 'conductor';
  autorNombre: string;
  texto: string;
}): Promise<{ conteniaTelefono: boolean }> {
  const { limpio, conteniaTelefono } = sanitizeChatSinTelefonos(params.texto.trim());
  const msgId = sanitizeFirestoreId(`msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  const path = `chats/${params.viajeId}/mensajes/${msgId}`;
  try {
    await setDoc(doc(db, 'chats', params.viajeId, 'mensajes', msgId), {
      viajeId: params.viajeId,
      autorUid: params.autorUid,
      autorRol: params.autorRol,
      autorNombre: params.autorNombre.slice(0, 80),
      texto: limpio.slice(0, 400),
      createdAt: serverTimestamp(),
    });
    return { conteniaTelefono };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function enviarCalificacion(params: {
  viajeId: string;
  autorUid: string;
  destinatarioUid: string;
  destinatarioRol: 'pasajero' | 'conductor';
  estrellas: number;
  comentario?: string;
}): Promise<void> {
  const calId = sanitizeFirestoreId(`cal_${params.viajeId}_${params.destinatarioRol}`);
  const path = `calificaciones/${calId}`;
  const targetCollection = params.destinatarioRol === 'conductor' ? 'conductores' : 'pasajeros';
  const calRef = doc(db, 'calificaciones', calId);
  const targetRef = doc(db, targetCollection, params.destinatarioUid);

  try {
    await runTransaction(db, async (tx) => {
      const targetSnap = await tx.get(targetRef);
      tx.set(calRef, {
        viajeId: params.viajeId,
        autorUid: params.autorUid,
        destinatarioUid: params.destinatarioUid,
        destinatarioRol: params.destinatarioRol,
        estrellas: params.estrellas,
        comentario: (params.comentario || '').trim().slice(0, 240),
        createdAt: serverTimestamp(),
      });

      if (targetSnap.exists()) {
        const data = targetSnap.data();
        const promedioPrevio = Number(data.promedioCalificacion ?? 5.0);
        const totalPrevio = Number(data.totalCalificaciones ?? 0);
        const nuevoTotal = totalPrevio + 1;
        const nuevoPromedio = Number(
          (((promedioPrevio * totalPrevio) + params.estrellas) / nuevoTotal).toFixed(2)
        );
        tx.update(targetRef, {
          promedioCalificacion: nuevoPromedio,
          totalCalificaciones: nuevoTotal,
          updatedAt: serverTimestamp(),
        });
      }
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function actualizarTarifasConductor(
  conductorId: string,
  tarifaBase: number,
  tarifaPorKm: number
): Promise<void> {
  const path = `conductores/${conductorId}`;
  try {
    await updateDoc(doc(db, 'conductores', conductorId), {
      tarifaBase,
      tarifaPorKm,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function cambiarEstadoOperativoConductor(
  conductorId: string,
  estadoOperativo: EstadoOperativoConductor
): Promise<void> {
  const path = `conductores/${conductorId}`;
  try {
    await updateDoc(doc(db, 'conductores', conductorId), {
      estadoOperativo,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function registrarNuevoConductor(params: {
  uid: string;
  nombre: string;
  telefono: string;
  cedula: string;
  email: string;
  fotoUrl?: string;
  fotoVehiculoUrl?: string;
  vehiculoTipo: TipoVehiculo;
  vehiculoModelo: string;
  vehiculoColor?: string;
  vehiculoAnio?: string;
  placa: string;
  capacidad: number;
  tarifaBase: number;
  tarifaPorKm: number;
  terminosAceptados: boolean;
  fotoCedula?: string;
  fotoLicencia?: string;
  fotoCirculacion?: string;
}): Promise<void> {
  const path = `conductores/${params.uid}`;
  try {
    const batch = writeBatch(db);
    const expDate = Timestamp.fromDate(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000));
    const fotoConductor = (params.fotoUrl || DRIVER_AVATARS['driver-carlos']).slice(0, 150000);
    const fotoVehiculo = (params.fotoVehiculoUrl || '').slice(0, 150000);
    batch.set(doc(db, 'conductores', params.uid), {
      uid: params.uid,
      nombre: params.nombre.slice(0, 100),
      fotoUrl: fotoConductor,
      ...(fotoVehiculo ? { fotoVehiculoUrl: fotoVehiculo } : {}),
      vehiculoTipo: params.vehiculoTipo.slice(0, 40),
      vehiculoModelo: params.vehiculoModelo.slice(0, 80),
      ...(params.vehiculoColor ? { vehiculoColor: params.vehiculoColor.slice(0, 40) } : {}),
      ...(params.vehiculoAnio ? { vehiculoAnio: params.vehiculoAnio.slice(0, 10) } : {}),
      placa: params.placa.toUpperCase().slice(0, 20),
      capacidad: params.capacidad,
      tarifaBase: params.tarifaBase,
      tarifaPorKm: params.tarifaPorKm,
      estadoCuenta: 'pendiente',
      estadoOperativo: 'offline',
      lat: 9.384,
      lng: -83.681,
      ultimoPingAt: serverTimestamp(),
      licenciaExp: expDate,
      mensualidadPendiente: false,
      promedioCalificacion: 5.0,
      totalCalificaciones: 0,
      totalViajes: 0,
      gananciasHoy: 0,
      gananciasMes: 0,
      cedulaHash: params.cedula.slice(0, 40),
      terminosAceptados: params.terminosAceptados,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'usuarios', params.uid, 'private', 'pii'), {
      uid: params.uid,
      telefono: params.telefono.slice(0, 30),
      email: params.email.slice(0, 160),
      cedula: params.cedula.slice(0, 40),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'usuarios', params.uid, 'private', 'documentos'), {
      uid: params.uid,
      fotoVehiculo: (params.fotoVehiculoUrl || '').slice(0, 220000),
      fotoCedula: (params.fotoCedula || '').slice(0, 220000),
      fotoLicencia: (params.fotoLicencia || '').slice(0, 220000),
      fotoCirculacion: (params.fotoCirculacion || '').slice(0, 220000),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// --- ADMIN ACTIONS ---
export async function adminCambiarEstadoConductor(
  conductorId: string,
  estadoCuenta: EstadoCuentaConductor
): Promise<void> {
  const path = `conductores/${conductorId}`;
  try {
    await updateDoc(doc(db, 'conductores', conductorId), {
      estadoCuenta,
      estadoOperativo: estadoCuenta === 'activo' ? 'disponible' : 'offline',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminExtenderLicencia1Mes(conductor: Conductor): Promise<void> {
  const path = `conductores/${conductor.uid}`;
  const nuevaFecha = new Date();
  nuevaFecha.setMonth(nuevaFecha.getMonth() + 1);
  try {
    await updateDoc(doc(db, 'conductores', conductor.uid), {
      licenciaExp: Timestamp.fromDate(nuevaFecha),
      mensualidadPendiente: false,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminActualizarFichaConductor(
  conductorId: string,
  cambios: {
    nombre: string;
    placa: string;
    vehiculoTipo: TipoVehiculo;
    capacidad: number;
    tarifaBase: number;
    tarifaPorKm: number;
    telefono: string;
    cedula: string;
  }
): Promise<void> {
  const path = `conductores/${conductorId}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'conductores', conductorId), {
      nombre: cambios.nombre.slice(0, 100),
      placa: cambios.placa.toUpperCase().slice(0, 20),
      vehiculoTipo: cambios.vehiculoTipo,
      capacidad: cambios.capacidad,
      tarifaBase: cambios.tarifaBase,
      tarifaPorKm: cambios.tarifaPorKm,
      cedulaHash: cambios.cedula.slice(0, 40),
      updatedAt: serverTimestamp(),
    });
    batch.set(
      doc(db, 'usuarios', conductorId, 'private', 'pii'),
      {
        uid: conductorId,
        telefono: cambios.telefono.slice(0, 30),
        cedula: cambios.cedula.slice(0, 40),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminFetchPII(uid: string): Promise<UsuarioPII | null> {
  const path = `usuarios/${uid}/private/pii`;
  try {
    const snap = await getDoc(doc(db, 'usuarios', uid, 'private', 'pii'));
    return snap.exists() ? (snap.data() as UsuarioPII) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function adminFetchConductorDocumentos(
  uid: string
): Promise<ConductorDocumentos | null> {
  const path = `usuarios/${uid}/private/documentos`;
  try {
    const snap = await getDoc(doc(db, 'usuarios', uid, 'private', 'documentos'));
    return snap.exists() ? (snap.data() as ConductorDocumentos) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export function subscribePasajerosAdmin(callback: (pasajeros: Pasajero[]) => void): Unsubscribe {
  const q = query(collection(db, 'pasajeros'), limit(30));
  return onSnapshot(
    q,
    (snap) => {
      callback(snap.docs.map((d) => d.data() as Pasajero));
    },
    (error) => handleFirestoreError(error, OperationType.LIST, 'pasajeros')
  );
}

export async function adminToggleBloqueoPasajero(
  pasajeroId: string,
  bloqueado: boolean
): Promise<void> {
  const path = `pasajeros/${pasajeroId}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'pasajeros', pasajeroId), {
      bloqueado,
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'usuarios', pasajeroId), {
      bloqueado,
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminEliminarCuentaPasajero(pasajeroId: string): Promise<void> {
  const path = `pasajeros/${pasajeroId}`;
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db, 'usuarios', pasajeroId, 'private', 'pii'));
    batch.delete(doc(db, 'pasajeros', pasajeroId));
    batch.delete(doc(db, 'usuarios', pasajeroId));
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function adminActualizarFichaPasajero(
  pasajeroId: string,
  cambios: {
    nombre: string;
    telefono: string;
    email: string;
    cedula: string;
  }
): Promise<void> {
  const path = `pasajeros/${pasajeroId}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'pasajeros', pasajeroId), {
      nombre: cambios.nombre.trim().slice(0, 100),
      updatedAt: serverTimestamp(),
    });
    batch.set(
      doc(db, 'usuarios', pasajeroId),
      {
        uid: pasajeroId,
        nombre: cambios.nombre.trim().slice(0, 100),
        rol: 'pasajero',
        bloqueado: false,
        terminosAceptados: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    batch.set(
      doc(db, 'usuarios', pasajeroId, 'private', 'pii'),
      {
        uid: pasajeroId,
        telefono: cambios.telefono.trim().slice(0, 30),
        email: cambios.email.trim().slice(0, 160),
        cedula: cambios.cedula.trim().slice(0, 40),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// --- AUTH SEPARADO (EMAIL/PASSWORD PARA PASAJERO Y CONDUCTOR) ---
export async function iniciarSesionEmail(email: string, password: string): Promise<void> {
  await signInWithEmailAndPassword(auth, email.trim(), password);
}

export async function iniciarSesionAdminEmail(email: string, password: string): Promise<void> {
  const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
  const snap = await getDoc(doc(db, 'usuarios', cred.user.uid));
  const rol = snap.exists() ? String(snap.data()?.rol || '').toLowerCase() : '';
  if (rol !== 'admin') {
    await auth.signOut();
    throw new Error('Acceso denegado: esta cuenta no tiene rol de administrador.');
  }
}

export async function registrarPasajeroEmail(params: {
  nombre: string;
  email: string;
  telefono: string;
  cedula: string;
  comunidad?: string;
  fotoUrl?: string;
  password: string;
}): Promise<void> {
  const cred = await createUserWithEmailAndPassword(auth, params.email.trim(), params.password);
  await updateProfile(cred.user, { displayName: params.nombre.trim() });
  const uid = cred.user.uid;
  const fotoFinal = (params.fotoUrl || PASSENGER_AVATAR).slice(0, 150000);
  const batch = writeBatch(db);
  batch.set(doc(db, 'usuarios', uid), {
    uid,
    nombre: params.nombre.trim().slice(0, 100),
    rol: 'pasajero',
    fotoUrl: fotoFinal,
    bloqueado: false,
    terminosAceptados: true,
    terminosAceptadosAt: serverTimestamp(),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  batch.set(doc(db, 'usuarios', uid, 'private', 'pii'), {
    uid,
    telefono: params.telefono.trim().slice(0, 30),
    email: params.email.trim().slice(0, 160),
    cedula: params.cedula.trim().slice(0, 40),
    updatedAt: serverTimestamp(),
  });
  batch.set(doc(db, 'pasajeros', uid), {
    uid,
    nombre: params.nombre.trim().slice(0, 100),
    fotoUrl: fotoFinal,
    promedioCalificacion: 5.0,
    totalCalificaciones: 0,
    favoritos: params.comunidad ? [params.comunidad.trim().slice(0, 80)] : [],
    bloqueado: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  await batch.commit();
}

export async function registrarConductorEmail(params: {
  nombre: string;
  email: string;
  telefono: string;
  cedula: string;
  password: string;
  fotoUrl?: string;
  fotoVehiculoUrl?: string;
  fotoCedula?: string;
  fotoLicencia?: string;
  fotoCirculacion?: string;
  vehiculoTipo: TipoVehiculo;
  vehiculoModelo: string;
  vehiculoColor?: string;
  vehiculoAnio?: string;
  placa: string;
  capacidad: number;
  tarifaBase: number;
  tarifaPorKm: number;
}): Promise<void> {
  const cred = await createUserWithEmailAndPassword(auth, params.email.trim(), params.password);
  await updateProfile(cred.user, { displayName: params.nombre.trim() });
  const uid = cred.user.uid;
  const expDate = Timestamp.fromDate(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000));
  const fotoConductor = (params.fotoUrl || DRIVER_AVATARS['driver-carlos']).slice(0, 150000);
  const fotoVehiculo = (params.fotoVehiculoUrl || '').slice(0, 150000);
  const batch = writeBatch(db);
  batch.set(doc(db, 'usuarios', uid), {
    uid,
    nombre: params.nombre.trim().slice(0, 100),
    rol: 'conductor',
    fotoUrl: fotoConductor,
    bloqueado: false,
    terminosAceptados: true,
    terminosAceptadosAt: serverTimestamp(),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  batch.set(doc(db, 'usuarios', uid, 'private', 'pii'), {
    uid,
    telefono: params.telefono.trim().slice(0, 30),
    email: params.email.trim().slice(0, 160),
    cedula: params.cedula.trim().slice(0, 40),
    updatedAt: serverTimestamp(),
  });
  batch.set(doc(db, 'usuarios', uid, 'private', 'documentos'), {
    uid,
    fotoVehiculo: (params.fotoVehiculoUrl || '').slice(0, 220000),
    fotoCedula: (params.fotoCedula || '').slice(0, 220000),
    fotoLicencia: (params.fotoLicencia || '').slice(0, 220000),
    fotoCirculacion: (params.fotoCirculacion || '').slice(0, 220000),
    updatedAt: serverTimestamp(),
  });
  batch.set(doc(db, 'conductores', uid), {
    uid,
    nombre: params.nombre.trim().slice(0, 100),
    fotoUrl: fotoConductor,
    ...(fotoVehiculo ? { fotoVehiculoUrl: fotoVehiculo } : {}),
    vehiculoTipo: params.vehiculoTipo.slice(0, 40),
    vehiculoModelo: params.vehiculoModelo.trim().slice(0, 80),
    ...(params.vehiculoColor ? { vehiculoColor: params.vehiculoColor.trim().slice(0, 40) } : {}),
    ...(params.vehiculoAnio ? { vehiculoAnio: params.vehiculoAnio.trim().slice(0, 10) } : {}),
    placa: params.placa.trim().toUpperCase().slice(0, 20),
    capacidad: params.capacidad,
    tarifaBase: params.tarifaBase,
    tarifaPorKm: params.tarifaPorKm,
    estadoCuenta: 'pendiente',
    estadoOperativo: 'offline',
    lat: 9.384,
    lng: -83.681,
    ultimoPingAt: serverTimestamp(),
    licenciaExp: expDate,
    mensualidadPendiente: false,
    promedioCalificacion: 5.0,
    totalCalificaciones: 0,
    totalViajes: 0,
    gananciasHoy: 0,
    gananciasMes: 0,
    cedulaHash: params.cedula.trim().slice(0, 40),
    terminosAceptados: true,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  await batch.commit();
}

// --- CONFIGURACIÓN GENERAL (SOPORTE WHATSAPP 62546546, SINPE, DATOS ADMIN, TÉRMINOS) ---
export function subscribeConfiguracionGeneral(
  callback: (config: ConfiguracionGeneral) => void
): Unsubscribe {
  const path = 'configuracion/general';
  return onSnapshot(
    doc(db, 'configuracion', 'general'),
    (snap) => {
      if (snap.exists()) {
        const data = snap.data() as Partial<ConfiguracionGeneral>;
        callback({
          ...DEFAULT_CONFIGURACION_GENERAL,
          ...data,
        });
      } else {
        callback({ ...DEFAULT_CONFIGURACION_GENERAL });
      }
    },
    (error) => handleFirestoreError(error, OperationType.GET, path)
  );
}

export async function seedConfiguracionGeneralIfNeeded(): Promise<void> {
  if (!isCurrentUserAdmin()) return;
  const path = 'configuracion/general';
  try {
    const ref = doc(db, 'configuracion', 'general');
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        ...DEFAULT_CONFIGURACION_GENERAL,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function adminGuardarConfiguracionGeneral(
  config: Omit<ConfiguracionGeneral, 'updatedAt'>
): Promise<void> {
  const path = 'configuracion/general';
  try {
    const tiposLimpios = (config.tiposVehiculo && config.tiposVehiculo.length > 0
      ? config.tiposVehiculo
      : DEFAULT_CONFIGURACION_GENERAL.tiposVehiculo
    )
      .slice(0, 20)
      .map((t) => ({
        nombre: t.nombre.trim().slice(0, 40),
        maxPasajeros: Math.max(1, Math.min(30, Number(t.maxPasajeros) || 1)),
        descripcion: t.descripcion.trim().slice(0, 120),
      }));

    await setDoc(doc(db, 'configuracion', 'general'), {
      whatsappSoporte: config.whatsappSoporte.trim().slice(0, 20),
      sinpeNumero: config.sinpeNumero.trim().slice(0, 20),
      adminNombre: config.adminNombre.trim().slice(0, 100),
      adminTelefono: config.adminTelefono.trim().slice(0, 30),
      adminEmail: config.adminEmail.trim().slice(0, 160),
      adminSinpeTitular: config.adminSinpeTitular.trim().slice(0, 100),
      terminosCondiciones: config.terminosCondiciones.trim().slice(0, 8000),
      linkDescarga: (config.linkDescarga || DEFAULT_LINK_DESCARGA).trim().slice(0, 500),
      tiposVehiculo: tiposLimpios,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// --- CONSULTAS LIGERAS BAJO DEMANDA (limit(20) + SOLO AL TOCAR PESTAÑA) ---

export interface AdminResumenTotales {
  totalConductores: number;
  conductoresActivos: number;
  conductoresPendientes: number;
  totalPasajeros: number;
  solicitudesPendientes: number;
}

export async function fetchAdminResumenTotales(): Promise<AdminResumenTotales> {
  try {
    const [condAll, condAct, condPend, pasAll, solPend] = await Promise.all([
      getCountFromServer(collection(db, 'conductores')),
      getCountFromServer(query(collection(db, 'conductores'), where('estadoCuenta', '==', 'activo'))),
      getCountFromServer(query(collection(db, 'conductores'), where('estadoCuenta', '==', 'pendiente'))),
      getCountFromServer(collection(db, 'pasajeros')),
      getCountFromServer(
        query(collection(db, 'solicitudesCambio'), where('estado', '==', 'pendiente'))
      ),
    ]);
    return {
      totalConductores: condAll.data().count,
      conductoresActivos: condAct.data().count,
      conductoresPendientes: condPend.data().count,
      totalPasajeros: pasAll.data().count,
      solicitudesPendientes: solPend.data().count,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'conductores');
  }
}

export async function fetchConductoresAdminPaginado(max = 20): Promise<Conductor[]> {
  try {
    const snap = await getDocs(query(collection(db, 'conductores'), limit(max)));
    return snap.docs.map((d) => d.data() as Conductor);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'conductores');
  }
}

export async function fetchConductoresPendientesAdmin(max = 20): Promise<Conductor[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'conductores'), where('estadoCuenta', '==', 'pendiente'), limit(max))
    );
    return snap.docs.map((d) => d.data() as Conductor);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'conductores');
  }
}

export async function adminAprobarYActivarConductor1Mes(
  conductorId: string
): Promise<Timestamp> {
  const path = `conductores/${conductorId}`;
  try {
    const hoy = new Date();
    const enUnMes = new Date(hoy);
    enUnMes.setMonth(enUnMes.getMonth() + 1);
    const nuevaExp = Timestamp.fromDate(enUnMes);

    await updateDoc(doc(db, 'conductores', conductorId), {
      estadoCuenta: 'activo',
      estadoOperativo: 'disponible',
      disponible: true,
      mensualidadPendiente: false,
      licenciaExp: nuevaExp,
      updatedAt: serverTimestamp(),
    });
    return nuevaExp;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchPasajerosAdminPaginado(max = 20): Promise<Pasajero[]> {
  try {
    const snap = await getDocs(query(collection(db, 'pasajeros'), limit(max)));
    return snap.docs.map((d) => d.data() as Pasajero);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'pasajeros');
  }
}

export async function fetchPasajeroById(pasajeroId: string): Promise<Pasajero | null> {
  const path = `pasajeros/${pasajeroId}`;
  try {
    const snap = await getDoc(doc(db, 'pasajeros', pasajeroId));
    return snap.exists() ? (snap.data() as Pasajero) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function fetchHistorialPasajero(pasajeroId: string): Promise<Viaje[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'viajes'), where('pasajeroId', '==', pasajeroId), limit(20))
    );
    return snap.docs
      .map((d) => ({ ...(d.data() as Omit<Viaje, 'id'>), id: d.id }))
      .sort((a, b) => (b.updatedAt?.toMillis?.() ?? 0) - (a.updatedAt?.toMillis?.() ?? 0));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'viajes');
  }
}

export async function fetchHistorialConductor(conductorId: string): Promise<Viaje[]> {
  try {
    const snap = await getDocs(
      query(collection(db, 'viajes'), where('conductorId', '==', conductorId), limit(20))
    );
    return snap.docs
      .map((d) => ({ ...(d.data() as Omit<Viaje, 'id'>), id: d.id }))
      .sort((a, b) => (b.updatedAt?.toMillis?.() ?? 0) - (a.updatedAt?.toMillis?.() ?? 0));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'viajes');
  }
}

export async function guardarRutaFavoritaPasajero(
  pasajeroId: string,
  ruta: Omit<RutaFavorita, 'id'>
): Promise<RutaFavorita[]> {
  const path = `pasajeros/${pasajeroId}`;
  try {
    const ref = doc(db, 'pasajeros', pasajeroId);
    const snap = await getDoc(ref);
    const actuales: RutaFavorita[] = snap.exists()
      ? ((snap.data().rutasFavoritas as RutaFavorita[] | undefined) ?? [])
      : [];

    const nuevaRuta: RutaFavorita = {
      id: sanitizeFirestoreId(`fav_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`),
      alias: ruta.alias.trim().slice(0, 60) || `${ruta.origenNombre.slice(0, 22)} → ${ruta.destinoNombre.slice(0, 22)}`,
      origenNombre: ruta.origenNombre.trim().slice(0, 160),
      origenLat: ruta.origenLat,
      origenLng: ruta.origenLng,
      destinoNombre: ruta.destinoNombre.trim().slice(0, 160),
      destinoLat: ruta.destinoLat,
      destinoLng: ruta.destinoLng,
    };

    const actualizadas = [nuevaRuta, ...actuales].slice(0, 15);
    if (snap.exists()) {
      await updateDoc(ref, {
        rutasFavoritas: actualizadas,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        uid: pasajeroId,
        nombre: 'Pasajero Rural',
        promedioCalificacion: 5.0,
        totalCalificaciones: 0,
        favoritos: [],
        rutasFavoritas: actualizadas,
        bloqueado: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    return actualizadas;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function eliminarRutaFavoritaPasajero(
  pasajeroId: string,
  rutaId: string
): Promise<RutaFavorita[]> {
  const path = `pasajeros/${pasajeroId}`;
  try {
    const ref = doc(db, 'pasajeros', pasajeroId);
    const snap = await getDoc(ref);
    if (!snap.exists()) return [];
    const actuales = (snap.data().rutasFavoritas as RutaFavorita[] | undefined) ?? [];
    const filtradas = actuales.filter((r) => r.id !== rutaId);
    await updateDoc(ref, {
      rutasFavoritas: filtradas,
      updatedAt: serverTimestamp(),
    });
    return filtradas;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// --- PETICIONES DE CAMBIO DE DATOS (PROTECCIÓN CONTRA MANIPULACIÓN) ---

export async function fetchMiPII(uid: string): Promise<UsuarioPII | null> {
  const path = `usuarios/${uid}/private/pii`;
  try {
    const snap = await getDoc(doc(db, 'usuarios', uid, 'private', 'pii'));
    return snap.exists() ? (snap.data() as UsuarioPII) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function crearSolicitudCambioDatos(params: {
  solicitanteUid: string;
  rol: 'pasajero' | 'conductor';
  nombreActual: string;
  resumenActual: string;
  cambios: CambiosSolicitados;
  motivo: string;
}): Promise<SolicitudCambioDatos> {
  const solicitudId = sanitizeFirestoreId(
    `sol_${params.solicitanteUid.slice(0, 12)}_${Date.now()}`
  );
  const path = `solicitudesCambio/${solicitudId}`;
  const cambiosLimpios: CambiosSolicitados = {};
  if (params.cambios.nombre?.trim()) {
    cambiosLimpios.nombre = params.cambios.nombre.trim().slice(0, 100);
  }
  if (params.cambios.telefono?.trim()) {
    cambiosLimpios.telefono = params.cambios.telefono.trim().slice(0, 30);
  }
  if (params.cambios.email?.trim()) {
    cambiosLimpios.email = params.cambios.email.trim().slice(0, 160);
  }
  if (params.cambios.cedula?.trim()) {
    cambiosLimpios.cedula = params.cambios.cedula.trim().slice(0, 40);
  }
  if (params.cambios.vehiculoTipo?.trim()) {
    cambiosLimpios.vehiculoTipo = params.cambios.vehiculoTipo.trim().slice(0, 40);
  }
  if (params.cambios.vehiculoModelo?.trim()) {
    cambiosLimpios.vehiculoModelo = params.cambios.vehiculoModelo.trim().slice(0, 80);
  }
  if (params.cambios.vehiculoColor?.trim()) {
    cambiosLimpios.vehiculoColor = params.cambios.vehiculoColor.trim().slice(0, 40);
  }
  if (params.cambios.vehiculoAnio?.trim()) {
    cambiosLimpios.vehiculoAnio = params.cambios.vehiculoAnio.trim().slice(0, 10);
  }
  if (params.cambios.placa?.trim()) {
    cambiosLimpios.placa = params.cambios.placa.trim().toUpperCase().slice(0, 20);
  }
  if (typeof params.cambios.capacidad === 'number' && !Number.isNaN(params.cambios.capacidad)) {
    cambiosLimpios.capacidad = Math.max(1, Math.min(24, Math.round(params.cambios.capacidad)));
  }

  try {
    const payload = {
      id: solicitudId,
      solicitanteUid: params.solicitanteUid,
      rol: params.rol,
      nombreActual: params.nombreActual.trim().slice(0, 100) || 'Usuario Rural',
      resumenActual: params.resumenActual.trim().slice(0, 240) || 'Perfil registrado',
      cambios: cambiosLimpios,
      motivo: params.motivo.trim().slice(0, 300),
      estado: 'pendiente' as const,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(doc(db, 'solicitudesCambio', solicitudId), payload);
    return {
      ...payload,
      createdAt: null,
      updatedAt: null,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function fetchMisSolicitudesCambio(uid: string): Promise<SolicitudCambioDatos[]> {
  try {
    const snap = await getDocs(
      query(
        collection(db, 'solicitudesCambio'),
        where('solicitanteUid', '==', uid),
        limit(10)
      )
    );
    return snap.docs
      .map((d) => ({ ...(d.data() as Omit<SolicitudCambioDatos, 'id'>), id: d.id }))
      .sort((a, b) => (b.updatedAt?.toMillis?.() ?? 0) - (a.updatedAt?.toMillis?.() ?? 0));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'solicitudesCambio');
  }
}

export async function fetchSolicitudesCambioAdmin(max = 20): Promise<SolicitudCambioDatos[]> {
  try {
    const snap = await getDocs(query(collection(db, 'solicitudesCambio'), limit(max)));
    return snap.docs
      .map((d) => ({ ...(d.data() as Omit<SolicitudCambioDatos, 'id'>), id: d.id }))
      .sort((a, b) => {
        if (a.estado === 'pendiente' && b.estado !== 'pendiente') return -1;
        if (a.estado !== 'pendiente' && b.estado === 'pendiente') return 1;
        return (b.updatedAt?.toMillis?.() ?? 0) - (a.updatedAt?.toMillis?.() ?? 0);
      });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'solicitudesCambio');
  }
}

export async function adminResolverSolicitudCambio(
  solicitud: SolicitudCambioDatos,
  aprobar: boolean,
  respuestaAdmin?: string
): Promise<void> {
  const path = `solicitudesCambio/${solicitud.id}`;
  try {
    const uid = solicitud.solicitanteUid;
    const c = solicitud.cambios;
    const batch = writeBatch(db);

    if (aprobar) {
      const [userSnap, piiSnap, roleSnap] = await Promise.all([
        getDoc(doc(db, 'usuarios', uid)),
        getDoc(doc(db, 'usuarios', uid, 'private', 'pii')),
        getDoc(doc(db, solicitud.rol === 'conductor' ? 'conductores' : 'pasajeros', uid)),
      ]);

      if (c.nombre && userSnap.exists()) {
        batch.update(doc(db, 'usuarios', uid), {
          nombre: c.nombre.trim().slice(0, 100),
          updatedAt: serverTimestamp(),
        });
      }

      if (c.telefono || c.email || c.cedula) {
        const piiRef = doc(db, 'usuarios', uid, 'private', 'pii');
        if (piiSnap.exists()) {
          const updates: Record<string, unknown> = { updatedAt: serverTimestamp() };
          if (c.telefono) updates.telefono = c.telefono.trim().slice(0, 30);
          if (c.email) updates.email = c.email.trim().slice(0, 160);
          if (c.cedula) updates.cedula = c.cedula.trim().slice(0, 40);
          batch.update(piiRef, updates);
        } else {
          batch.set(piiRef, {
            uid,
            telefono: (c.telefono || '00000000').trim().slice(0, 30),
            ...(c.email ? { email: c.email.trim().slice(0, 160) } : {}),
            cedula: (c.cedula || 'PENDIENTE').trim().slice(0, 40),
            updatedAt: serverTimestamp(),
          });
        }
      }

      if (solicitud.rol === 'pasajero' && roleSnap.exists() && c.nombre) {
        batch.update(doc(db, 'pasajeros', uid), {
          nombre: c.nombre.trim().slice(0, 100),
          updatedAt: serverTimestamp(),
        });
      }

      if (solicitud.rol === 'conductor' && roleSnap.exists()) {
        const condUpdates: Record<string, unknown> = { updatedAt: serverTimestamp() };
        if (c.nombre) condUpdates.nombre = c.nombre.trim().slice(0, 100);
        if (c.cedula) condUpdates.cedulaHash = c.cedula.trim().slice(0, 40);
        if (c.vehiculoTipo) condUpdates.vehiculoTipo = c.vehiculoTipo.trim().slice(0, 40);
        if (c.vehiculoModelo) condUpdates.vehiculoModelo = c.vehiculoModelo.trim().slice(0, 80);
        if (c.vehiculoColor) condUpdates.vehiculoColor = c.vehiculoColor.trim().slice(0, 40);
        if (c.vehiculoAnio) condUpdates.vehiculoAnio = c.vehiculoAnio.trim().slice(0, 10);
        if (c.placa) condUpdates.placa = c.placa.trim().toUpperCase().slice(0, 20);
        if (typeof c.capacidad === 'number') {
          condUpdates.capacidad = Math.max(1, Math.min(16, Math.round(c.capacidad)));
        }
        batch.update(doc(db, 'conductores', uid), condUpdates);
      }
    }

    const respuestaLimpia = (respuestaAdmin || '').trim().slice(0, 240);
    batch.update(doc(db, 'solicitudesCambio', solicitud.id), {
      estado: aprobar ? 'aprobada' : 'rechazada',
      ...(respuestaLimpia ? { respuestaAdmin: respuestaLimpia } : {}),
      updatedAt: serverTimestamp(),
    });

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export interface PayloadFcmOfertaViaje {
  to: string;
  priority: 'high';
  notification: {
    title: string;
    body: string;
    channel_id: 'viajes_ofertas';
    sound: 'default';
  };
  android: {
    priority: 'high';
    ttl: string;
    notification: {
      channel_id: 'viajes_ofertas';
      sound: 'default';
      notification_priority: 'PRIORITY_MAX';
      visibility: 'PUBLIC';
    };
  };
  data: {
    tipo: 'OFERTA_15S';
    viajeId: string;
    titulo: string;
    resumen: string;
    origen: string;
    destino: string;
    pasajeros: string;
    montoAproximado: string;
    resenaUbicacion: string;
  };
}

/**
 * Construye el payload FCM para notificaciones emergentes (Heads-up) al Conductor
 * garantizando entrega inmediata en Doze (`priority: "high"`) y canal `viajes_ofertas`.
 */
export function construirPayloadFcmOfertaViaje(params: {
  tokenConductor: string;
  viajeId: string;
  origen: string;
  destino: string;
  pasajeros: number;
  montoAproximado: number;
  resenaUbicacion?: string;
}): PayloadFcmOfertaViaje {
  const titulo = `🚕 Nueva oferta de viaje (${params.pasajeros} pas.)`;
  const resena = (params.resenaUbicacion || '').trim();
  const base = `${params.origen} → ${params.destino} · ₡${params.montoAproximado}`;
  const body = resena ? `${base} · Ref: ${resena}` : base;

  return {
    to: params.tokenConductor,
    priority: 'high',
    notification: {
      title: titulo,
      body,
      channel_id: 'viajes_ofertas',
      sound: 'default',
    },
    android: {
      priority: 'high',
      ttl: '15s',
      notification: {
        channel_id: 'viajes_ofertas',
        sound: 'default',
        notification_priority: 'PRIORITY_MAX',
        visibility: 'PUBLIC',
      },
    },
    data: {
      tipo: 'OFERTA_15S',
      viajeId: params.viajeId,
      titulo,
      resumen: body,
      origen: params.origen,
      destino: params.destino,
      pasajeros: String(params.pasajeros),
      montoAproximado: String(params.montoAproximado),
      resenaUbicacion: resena,
    },
  };
}






