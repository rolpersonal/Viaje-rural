# Reglas ProGuard / R8 para Viaje Rural (Firebase + Coroutines + Compose)
-keepattributes Signature,InnerClasses,EnclosingMethod
-keepattributes *Annotation*
-keepclassmembers class cr.viajerural.app.data.** { *; }
-keepclassmembers class cr.viajerural.app.viewmodel.** { *; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
