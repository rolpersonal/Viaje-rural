package cr.viajerural.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import cr.viajerural.app.R
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularMensualidadConductorActual
import cr.viajerural.app.data.formatearColonesEntero
import java.util.concurrent.TimeUnit

/**
 * Requisito 2: Recordatorio Mensual Automático con WorkManager.
 * Envía una notificación local cada 30 días recordando la mensualidad vigente del conductor
 * calculada desde la cuota base y año de referencia con +10% cada 1 de enero (America/Costa_Rica).
 */
class MonthlyPaymentReminderWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val (montoBase, anioBase) = try {
            val cfg = ViajeRepository().obtenerConfiguracionGeneral()
            val base = (cfg["montoMensualConductorBase"] as? Number)?.toInt()?.coerceIn(500, 1_000_000)
                ?: ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE
            val anio = (cfg["anioBaseMensualidad"] as? Number)?.toInt()?.coerceIn(2020, 2100)
                ?: ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD
            Pair(base, anio)
        } catch (_: Throwable) {
            Pair(ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE, ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD)
        }
        val calculo = calcularMensualidadConductorActual(montoBase, anioBase)
        mostrarNotificacionRecordatorio(calculo.montoActual, calculo.montoBase, calculo.anioBase)
        return Result.success()
    }

    private fun mostrarNotificacionRecordatorio(montoVigente: Int, montoBase: Int, anioBase: Int) {
        val manager =
            applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "viaje_rural_monthly_fee"
        val montoVigenteFmt = formatearColonesEntero(montoVigente)
        val montoBaseFmt = formatearColonesEntero(montoBase)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Recordatorio Mensualidad Conductor",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Aviso automático mensual de licencia de uso ($montoVigenteFmt vigente)."
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Recordatorio Mensual — Viaje Rural")
            .setContentText(
                "Recuerda abonar tu mensualidad de $montoVigenteFmt colones para mantener tu licencia activa."
            )
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "Tu licencia mensual de conexión tiene un costo vigente de $montoVigenteFmt colones " +
                        "(base $montoBaseFmt desde $anioBase con ajuste del 10% anual cada 1 de enero). Contacta al Administrador para renovar +1 mes."
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setAutoCancel(true)
            .build()

        manager.notify(NOTIFICATION_ID, notification)
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "viaje_rural_monthly_payment_reminder"
        private const val NOTIFICATION_ID = 7000

        /**
         * Programa el recordatorio periódico mensual al iniciar sesión como Conductor.
         */
        fun scheduleMonthlyReminder(context: Context) {
            val request = PeriodicWorkRequestBuilder<MonthlyPaymentReminderWorker>(
                30, TimeUnit.DAYS
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun cancelReminder(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }
    }
}
