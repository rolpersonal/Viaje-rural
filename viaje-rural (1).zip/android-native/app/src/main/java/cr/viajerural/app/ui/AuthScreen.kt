package cr.viajerural.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularMensualidadConductorActual
import cr.viajerural.app.data.formatearColonesEntero
import cr.viajerural.app.util.ImageCompressionUtils
import cr.viajerural.app.viewmodel.AuthViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Pantallas funcionales de Login y Registro separadas para Pasajeros y Conductores,
 * con selector de tipo de vehículo, carga comprimida (máx. 800px / JPEG 70%) de foto de perfil,
 * foto del vehículo y documentos legales, más Acceso Administrador seguro con Firebase Auth.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AuthScreen(
    viewModel: AuthViewModel,
    tiposVehiculo: List<String> = listOf("Moto", "Sedán", "Pickup 4x4", "SUV 4x4", "Microbús Rural"),
    onAuthenticated: (uid: String, esConductor: Boolean) -> Unit,
    onAdminAuthenticated: (uid: String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by viewModel.uiState.collectAsState()

    var rolTab by remember { mutableIntStateOf(0) } // 0 = Pasajero, 1 = Conductor
    var esRegistro by remember { mutableStateOf(false) }

    var nombre by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }
    var cedula by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    // Campos completos de Conductor y Vehículo
    var vehiculoTipo by remember { mutableStateOf(tiposVehiculo.firstOrNull() ?: "Pickup 4x4") }
    var vehiculoModelo by remember { mutableStateOf("") }
    var vehiculoColor by remember { mutableStateOf("") }
    var vehiculoAnio by remember { mutableStateOf("2020") }
    var placa by remember { mutableStateOf("") }
    var capacidad by remember { mutableStateOf("4") }
    var tarifaBase by remember { mutableStateOf("1500") }
    var tarifaPorKm by remember { mutableStateOf("650") }
    var tarifaBaseCarga by remember { mutableStateOf("3000") }
    var tieneCascoExtra by remember { mutableStateOf(false) }
    var tieneCapaDisponible by remember { mutableStateOf(false) }

    // Fotos comprimidas a máx. 800px JPEG 70% antes de guardar en Firestore
    var fotoPerfil by remember { mutableStateOf("") }
    var fotoVehiculo by remember { mutableStateOf("") }
    var fotoCedula by remember { mutableStateOf("") }
    var fotoLicencia by remember { mutableStateOf("") }
    var fotoCirculacion by remember { mutableStateOf("") }
    var comprimiendoFoto by remember { mutableStateOf(false) }
    var errorCompresion by remember { mutableStateOf<String?>(null) }

    var aceptoTerminos by remember { mutableStateOf(false) }
    var mostrarModalTerminosPasajero by remember { mutableStateOf(false) }
    var mostrarModalTerminosConductor by remember { mutableStateOf(false) }

    val calculoMensualidad = remember(state.montoMensualConductorBase, state.anioBaseMensualidad) {
        calcularMensualidadConductorActual(
            montoBase = state.montoMensualConductorBase,
            anioBase = state.anioBaseMensualidad
        )
    }

    // Diálogo de Acceso Administrador Seguro (Correo + Contraseña -> usuarios/{uid}.rol == "admin")
    var mostrarDialogoAdmin by remember { mutableStateOf(false) }
    var emailAdmin by remember { mutableStateOf("") }
    var passwordAdmin by remember { mutableStateOf("") }

    fun procesarImagenComprimida(uri: Uri, maxBase64Chars: Int, onResult: (String) -> Unit) {
        scope.launch {
            comprimiendoFoto = true
            errorCompresion = null
            val comprimida = withContext(Dispatchers.IO) {
                ImageCompressionUtils.comprimirImagenABase64(
                    context = context,
                    uri = uri,
                    maxAnchoPx = 800,
                    calidadJpeg = 70,
                    maxBase64Chars = maxBase64Chars
                )
            }
            comprimiendoFoto = false
            if (comprimida != null) {
                onResult(comprimida)
            } else {
                errorCompresion = "No se pudo procesar la imagen seleccionada. Intenta con otra fotografía."
            }
        }
    }

    val pickPerfil = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { procesarImagenComprimida(it, 140_000) { b64 -> fotoPerfil = b64 } }
    }
    val pickVehiculo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { procesarImagenComprimida(it, 140_000) { b64 -> fotoVehiculo = b64 } }
    }
    val pickCedula = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { procesarImagenComprimida(it, 205_000) { b64 -> fotoCedula = b64 } }
    }
    val pickLicencia = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { procesarImagenComprimida(it, 205_000) { b64 -> fotoLicencia = b64 } }
    }
    val pickCirculacion = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { procesarImagenComprimida(it, 205_000) { b64 -> fotoCirculacion = b64 } }
    }

    LaunchedEffect(state.uidAutenticado, state.rolAutenticado) {
        state.uidAutenticado?.let { uid ->
            val esCond = (state.rolAutenticado ?: if (rolTab == 1) "conductor" else "pasajero") == "conductor"
            onAuthenticated(uid, esCond)
        }
    }

    LaunchedEffect(state.uidAdminAutenticado) {
        state.uidAdminAutenticado?.let { uid ->
            mostrarDialogoAdmin = false
            emailAdmin = ""
            passwordAdmin = ""
            onAdminAuthenticated(uid)
        }
    }

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFFF7F8F6),
        contentWindowInsets = WindowInsets.statusBars
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Encabezado limpio estilo Web
        Surface(
            shape = cardShape,
            color = Color(0xFF15803D),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Viaje Rural",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Transporte comunitario confiable, directo en efectivo y sin comisiones por viaje.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f)
                )
            }
        }

        if (!esRegistro) {
            // BLOQUE 1: YA TENGO CUENTA (INICIAR SESIÓN)
            OutlinedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = cardShape,
                border = BorderStroke(1.dp, Color(0xFFD6DDD2)),
                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Ya tengo cuenta (Iniciar Sesión)",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14231A)
                    )
                    Text(
                        text = "Elige tu tipo de cuenta e ingresa tu correo y contraseña:",
                        fontSize = 13.5.sp,
                        color = Color(0xFF4B5563)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val pasajeroActivo = rolTab == 0
                        Surface(
                            onClick = {
                                if (rolTab != 0) aceptoTerminos = false
                                rolTab = 0
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (pasajeroActivo) Color(0xFFECFDF5) else Color(0xFFF8FAFC),
                            border = BorderStroke(
                                width = if (pasajeroActivo) 2.dp else 1.dp,
                                color = if (pasajeroActivo) Color(0xFF15803D) else Color(0xFFCBD5E1)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = if (pasajeroActivo) Color(0xFF15803D) else Color(0xFF475569),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Pasajero",
                                    fontSize = 15.sp,
                                    fontWeight = if (pasajeroActivo) FontWeight.Bold else FontWeight.Medium,
                                    color = if (pasajeroActivo) Color(0xFF14532D) else Color(0xFF334155),
                                    maxLines = 1
                                )
                            }
                        }

                        val conductorActivo = rolTab == 1
                        Surface(
                            onClick = {
                                if (rolTab != 1) aceptoTerminos = false
                                rolTab = 1
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (conductorActivo) Color(0xFFECFDF5) else Color(0xFFF8FAFC),
                            border = BorderStroke(
                                width = if (conductorActivo) 2.dp else 1.dp,
                                color = if (conductorActivo) Color(0xFF15803D) else Color(0xFFCBD5E1)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsCar,
                                    contentDescription = null,
                                    tint = if (conductorActivo) Color(0xFF15803D) else Color(0xFF475569),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Conductor",
                                    fontSize = 15.sp,
                                    fontWeight = if (conductorActivo) FontWeight.Bold else FontWeight.Medium,
                                    color = if (conductorActivo) Color(0xFF14532D) else Color(0xFF334155),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Correo electrónico") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth()
                    )
                    PasswordTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = "Contraseña (mín. 6 caracteres)",
                        modifier = Modifier.fillMaxWidth()
                    )

                    state.error?.let {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFEF2F2),
                            border = BorderStroke(1.dp, Color(0xFFFECACA)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = it,
                                color = Color(0xFF991B1B),
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Button(
                        onClick = { viewModel.login(email, password, rolTab == 1, context) },
                        enabled = !state.cargando && !comprimiendoFoto,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF15803D),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                    ) {
                        Text(
                            text = if (state.cargando) {
                                "Conectando..."
                            } else {
                                "Iniciar Sesión (${if (rolTab == 0) "Pasajero" else "Conductor"})"
                            },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // DIVISOR VISUAL CLARO ENTRE INICIO DE SESIÓN Y REGISTRO
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HorizontalDivider(
                    modifier = Modifier.weight(1f),
                    thickness = 1.dp,
                    color = Color(0xFFCBD5E1)
                )
                Text(
                    text = "¿Primera vez en Viaje Rural?",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF475569)
                )
                HorizontalDivider(
                    modifier = Modifier.weight(1f),
                    thickness = 1.dp,
                    color = Color(0xFFCBD5E1)
                )
            }

            // BLOQUE 2: ¿NO TIENES CUENTA? REGÍSTRATE GRATIS
            OutlinedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = cardShape,
                border = BorderStroke(1.5.dp, Color(0xFFBBF7D0)),
                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "¿No tienes cuenta? Regístrate gratis",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF14532D)
                    )
                    Text(
                        text = "Toca una de estas opciones para crear tu cuenta paso a paso:",
                        fontSize = 13.5.sp,
                        color = Color(0xFF374151)
                    )

                    // Opción 1 — Pasajero (ancho completo, fondo verde suave y borde verde marcado)
                    Surface(
                        onClick = {
                            rolTab = 0
                            aceptoTerminos = false
                            esRegistro = true
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFFECFDF5),
                        border = BorderStroke(2.dp, Color(0xFF16A34A)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 72.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF15803D),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Pasajero",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "Registrarme como Pasajero",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = "Para pedir viajes y envíos en la zona",
                                    fontSize = 13.5.sp,
                                    color = Color(0xFF166534)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Continuar",
                                tint = Color(0xFF15803D),
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    // Opción 2 — Conductor (ancho completo, fondo contrastante claro y borde marcado)
                    Surface(
                        onClick = {
                            rolTab = 1
                            aceptoTerminos = false
                            esRegistro = true
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(2.dp, Color(0xFF334155)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 72.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF1E293B),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsCar,
                                        contentDescription = "Conductor",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "Registrarme como Conductor",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "Para ofrecer viajes con mi vehículo",
                                    fontSize = 13.5.sp,
                                    color = Color(0xFF334155)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Continuar",
                                tint = Color(0xFF1E293B),
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // FORMULARIO COMPLETO DE REGISTRO (PASAJERO O CONDUCTOR)
            OutlinedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = cardShape,
                border = cardBorder,
                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(
                            onClick = { esRegistro = false },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver",
                                tint = Color(0xFF15803D),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Volver a Iniciar Sesión",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                        }

                        TextButton(
                            onClick = {
                                aceptoTerminos = false
                                rolTab = if (rolTab == 0) 1 else 0
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (rolTab == 0) "Soy Conductor" else "Soy Pasajero",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (rolTab == 0) Color(0xFFECFDF5) else Color(0xFFF1F5F9),
                        border = BorderStroke(
                            1.dp,
                            if (rolTab == 0) Color(0xFF86EFAC) else Color(0xFFCBD5E1)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = if (rolTab == 0) Icons.Default.Person else Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = if (rolTab == 0) Color(0xFF15803D) else Color(0xFF1E293B),
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = if (rolTab == 0) {
                                        "Registro de Pasajero"
                                    } else {
                                        "Registro de Conductor"
                                    },
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (rolTab == 0) Color(0xFF14532D) else Color(0xFF0F172A)
                                )
                                Text(
                                    text = if (rolTab == 0) {
                                        "Completa tus datos para pedir viajes y envíos."
                                    } else {
                                        "Completa tus datos, vehículo y documentos."
                                    },
                                    fontSize = 13.sp,
                                    color = Color(0xFF475569)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = nombre,
                        onValueChange = { nombre = it },
                        label = { Text("Nombre completo") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = telefono,
                        onValueChange = { telefono = it },
                        label = { Text("Teléfono (solo visible para Admin)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = cedula,
                        onValueChange = { cedula = it },
                        label = { Text("Cédula / Identificación") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedButton(
                        onClick = { pickPerfil.launch("image/*") },
                        enabled = !comprimiendoFoto,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val textoPerfil = if (fotoPerfil.isNotBlank()) {
                            "Foto de Perfil ✓ (~${ImageCompressionUtils.estimarPesoKbBase64(fotoPerfil)} KB)"
                        } else {
                            "Subir Foto de Perfil (opcional · máx. 800px)"
                        }
                        Text(textoPerfil)
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Correo electrónico") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth()
                    )
                    PasswordTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = "Contraseña (mín. 6 caracteres)",
                        modifier = Modifier.fillMaxWidth()
                    )

                if (esRegistro && rolTab == 1) {
                    HorizontalDivider(color = Color(0xFFE2E6DF))
                    Text(
                        text = "Datos del Vehículo y Tarifas",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        tiposVehiculo.forEach { tipo ->
                            FilterChip(
                                selected = vehiculoTipo == tipo,
                                onClick = { vehiculoTipo = tipo },
                                label = { Text(tipo) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = vehiculoModelo,
                        onValueChange = { vehiculoModelo = it },
                        label = { Text("Marca y Modelo (Ej: Honda XR150 / Hilux)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = vehiculoColor,
                            onValueChange = { vehiculoColor = it },
                            label = { Text("Color") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = vehiculoAnio,
                            onValueChange = { vehiculoAnio = it.filter(Char::isDigit).take(4) },
                            label = { Text("Año") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = placa,
                            onValueChange = { placa = it.uppercase() },
                            label = { Text("Placa") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = capacidad,
                            onValueChange = { capacidad = it.filter(Char::isDigit) },
                            label = { Text("Capacidad") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    val esCargoSeleccionado = ViajeRepository.esVehiculoCargo(vehiculoTipo)
                    val esMotoSeleccionado = ViajeRepository.esVehiculoMoto(vehiculoTipo)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF7F8F6),
                        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = buildString {
                                append("Referencia promedio: Tarifa base ~₡1,500 · Adicional ~₡650/km")
                                if (esCargoSeleccionado) {
                                    append(" · Con carga/flete ~₡3,000")
                                }
                                append(". Variaciones >30% generan alerta al administrador.")
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = tarifaBase,
                            onValueChange = { tarifaBase = it.filter(Char::isDigit) },
                            label = { Text("Tarifa base (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = tarifaPorKm,
                            onValueChange = { tarifaPorKm = it.filter(Char::isDigit) },
                            label = { Text("Precio / km (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (esCargoSeleccionado) {
                        OutlinedTextField(
                            value = tarifaBaseCarga,
                            onValueChange = { tarifaBaseCarga = it.filter(Char::isDigit) },
                            label = { Text("Tarifa base con carga / flete (₡)") },
                            placeholder = { Text("Opcional · Ej: 3000") },
                            supportingText = {
                                Text("Para traslados con ferretería, materiales o compras pesadas (ref. ~₡3,000).")
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    val tBaseVal = tarifaBase.toDoubleOrNull() ?: ViajeRepository.DEFAULT_TARIFA_BASE_NORMAL
                    val tKmVal = tarifaPorKm.toDoubleOrNull() ?: ViajeRepository.DEFAULT_TARIFA_KM
                    val tCargaVal = tarifaBaseCarga.toDoubleOrNull()
                    if (tBaseVal > ViajeRepository.DEFAULT_TARIFA_BASE_NORMAL * 1.30 ||
                        tKmVal > ViajeRepository.DEFAULT_TARIFA_KM * 1.30 ||
                        (esCargoSeleccionado && tCargaVal != null && tCargaVal > ViajeRepository.DEFAULT_TARIFA_BASE_CARGA * 1.30)
                    ) {
                        Text(
                            text = "Aviso: Una de tus tarifas supera en >30% la referencia promedio y será revisada por el Administrador.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFB45309),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (esMotoSeleccionado) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF0FDF4),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "Equipamiento de Seguridad en Moto",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = tieneCascoExtra,
                                        onCheckedChange = { tieneCascoExtra = it }
                                    )
                                    Text(
                                        text = "Cuento con casco extra para pasajero",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF14231A)
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = tieneCapaDisponible,
                                        onCheckedChange = { tieneCapaDisponible = it }
                                    )
                                    Text(
                                        text = "Cuento con capa disponible",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF14231A)
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = Color(0xFFE2E6DF))
                    Text(
                        text = "Fotos del Vehículo y Documentos (JPEG 70% · máx. 800px)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { pickVehiculo.launch("image/*") },
                            enabled = !comprimiendoFoto,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                if (fotoVehiculo.isNotBlank()) {
                                    "Vehículo ✓ (${ImageCompressionUtils.estimarPesoKbBase64(fotoVehiculo)}KB)"
                                } else {
                                    "Foto Vehículo"
                                }
                            )
                        }
                        OutlinedButton(
                            onClick = { pickCedula.launch("image/*") },
                            enabled = !comprimiendoFoto,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                if (fotoCedula.isNotBlank()) {
                                    "Cédula ✓ (${ImageCompressionUtils.estimarPesoKbBase64(fotoCedula)}KB)"
                                } else {
                                    "Foto Cédula"
                                }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { pickLicencia.launch("image/*") },
                            enabled = !comprimiendoFoto,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                if (fotoLicencia.isNotBlank()) {
                                    "Licencia ✓ (${ImageCompressionUtils.estimarPesoKbBase64(fotoLicencia)}KB)"
                                } else {
                                    "Foto Licencia"
                                }
                            )
                        }
                        OutlinedButton(
                            onClick = { pickCirculacion.launch("image/*") },
                            enabled = !comprimiendoFoto,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                if (fotoCirculacion.isNotBlank()) {
                                    "RTV ✓ (${ImageCompressionUtils.estimarPesoKbBase64(fotoCirculacion)}KB)"
                                } else {
                                    "Circulación/RTV"
                                }
                            )
                        }
                    }
                }

                if (comprimiendoFoto) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text(
                            text = "Comprimiendo imagen a 800px JPEG...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                errorCompresion?.let {
                    Text(text = it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                if (esRegistro) {
                    if (rolTab == 0) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF0FDF4),
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Uso gratuito para el pasajero (Sin cobro de app)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = "Al pasajero no se le aplica ningún tipo de cobro ni comisión por usar la plataforma. Pagas únicamente la tarifa en efectivo al conductor.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF166534)
                                )
                                TextButton(
                                    onClick = { mostrarModalTerminosPasajero = true },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = "Leer Términos y Condiciones del Pasajero",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D)
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Checkbox(
                                        checked = aceptoTerminos,
                                        onCheckedChange = { aceptoTerminos = it }
                                    )
                                    Text(
                                        text = "Acepto los términos y condiciones",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF14231A),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF0FDF4),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Cuota mensual vigente (${calculoMensualidad.anioActual}): ${formatearColonesEntero(calculoMensualidad.montoActual)}/mes",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = "Base ${calculoMensualidad.anioBase}: ${formatearColonesEntero(calculoMensualidad.montoBase)} (+10% automático cada 1 de enero).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF166534)
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Checkbox(checked = aceptoTerminos, onCheckedChange = { aceptoTerminos = it })
                                    Text(
                                        text = "Acepto Términos del Conductor (solo conexión efectivo; cuota ${formatearColonesEntero(calculoMensualidad.montoActual)}/mes + 10% cada 1 de enero).",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                TextButton(
                                    onClick = { mostrarModalTerminosConductor = true },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = "Documento Términos y Condiciones",
                                        tint = Color(0xFF15803D),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Leer Términos y Condiciones del Conductor",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D),
                                        textDecoration = TextDecoration.Underline
                                    )
                                }
                            }
                        }
                    }
                }

                    state.error?.let {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFEF2F2),
                            border = BorderStroke(1.dp, Color(0xFFFECACA)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = it,
                                color = Color(0xFF991B1B),
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (rolTab == 0) {
                                viewModel.registrarPasajero(nombre, email, telefono, cedula, password, fotoPerfil, context)
                            } else {
                                val esCargo = ViajeRepository.esVehiculoCargo(vehiculoTipo)
                                val esMoto = ViajeRepository.esVehiculoMoto(vehiculoTipo)
                                viewModel.registrarConductor(
                                    context, nombre, email, telefono, cedula, password,
                                    vehiculoTipo, vehiculoModelo, vehiculoColor, vehiculoAnio, placa,
                                    capacidad.toIntOrNull() ?: 4,
                                    tarifaBase.toDoubleOrNull() ?: 1500.0,
                                    tarifaPorKm.toDoubleOrNull() ?: 650.0,
                                    fotoVehiculo, fotoCedula, fotoLicencia, fotoCirculacion,
                                    fotoPerfil,
                                    tarifaBaseCarga = if (esCargo) tarifaBaseCarga.toDoubleOrNull() else null,
                                    tieneCascoExtra = esMoto && tieneCascoExtra,
                                    tieneCapaDisponible = esMoto && tieneCapaDisponible
                                )
                            }
                        },
                        enabled = !state.cargando && !comprimiendoFoto && aceptoTerminos,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF15803D),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                    ) {
                        Text(
                            text = when {
                                state.cargando -> "Conectando..."
                                rolTab == 0 -> "Crear cuenta Pasajero"
                                else -> "Enviar registro Conductor"
                            },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    TextButton(
                        onClick = { esRegistro = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "¿Ya tienes cuenta? Inicia sesión aquí",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }
        }

        OutlinedButton(
            onClick = {
                emailAdmin = ""
                passwordAdmin = ""
                viewModel.limpiarErrorAdmin()
                mostrarDialogoAdmin = true
            },
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFF94A3B8)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1E293B)),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
        ) {
            Text(
                text = "Acceso Administrador",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        }
    }

    if (mostrarDialogoAdmin) {
        AlertDialog(
            onDismissRequest = {
                if (!state.adminCargando) {
                    mostrarDialogoAdmin = false
                    emailAdmin = ""
                    passwordAdmin = ""
                    viewModel.limpiarErrorAdmin()
                }
            },
            title = { Text("Acceso Administrador", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Inicia sesión con tu correo y contraseña autorizados en Firestore (rol = admin).",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = emailAdmin,
                        onValueChange = {
                            emailAdmin = it
                            viewModel.limpiarErrorAdmin()
                        },
                        label = { Text("Correo de administrador") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    PasswordTextField(
                        value = passwordAdmin,
                        onValueChange = {
                            passwordAdmin = it
                            viewModel.limpiarErrorAdmin()
                        },
                        label = "Contraseña",
                        modifier = Modifier.fillMaxWidth()
                    )
                    state.adminError?.let { msg ->
                        Text(
                            text = msg,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = !state.adminCargando && emailAdmin.isNotBlank() && passwordAdmin.isNotBlank(),
                    onClick = {
                        viewModel.loginAdminSeguro(emailAdmin, passwordAdmin, context)
                    }
                ) {
                    Text(if (state.adminCargando) "Verificando..." else "Ingresar")
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !state.adminCargando,
                    onClick = {
                        mostrarDialogoAdmin = false
                        emailAdmin = ""
                        passwordAdmin = ""
                        viewModel.limpiarErrorAdmin()
                    }
                ) {
                    Text("Cancelar")
                }
            }
        )
    }

    if (mostrarModalTerminosPasajero) {
        ModalTerminosPasajeroDialog(
            terminosPasajero = state.terminosCondicionesPasajero,
            onDismiss = { mostrarModalTerminosPasajero = false }
        )
    }

    if (mostrarModalTerminosConductor) {
        ModalTerminosConductorDialog(
            terminosConductor = state.terminosCondicionesConductor,
            montoBase = state.montoMensualConductorBase,
            anioBase = state.anioBaseMensualidad,
            onAceptar = { aceptoTerminos = true },
            onDismiss = { mostrarModalTerminosConductor = false }
        )
    }
}
