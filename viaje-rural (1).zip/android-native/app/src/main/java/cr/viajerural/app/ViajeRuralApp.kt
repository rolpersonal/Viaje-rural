package cr.viajerural.app

import android.app.Application
import com.google.firebase.FirebaseApp

/**
 * Clase Application declarada en AndroidManifest.xml (android:name=".ViajeRuralApp").
 * Inicializa Firebase de forma segura dentro de un bloque try-catch para evitar cierres
 * abruptos si falta google-services.json o hay un error de configuración.
 */
class ViajeRuralApp : Application() {

    override fun onCreate() {
        super.onCreate()
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
            firebaseInitError = null
        } catch (t: Throwable) {
            firebaseInitError = t.localizedMessage
                ?: "No se pudo inicializar Firebase. Verifica google-services.json."
        }
    }

    companion object {
        @Volatile
        var firebaseInitError: String? = null
    }
}
