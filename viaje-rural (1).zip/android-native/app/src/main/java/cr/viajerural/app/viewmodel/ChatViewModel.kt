package cr.viajerural.app.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.ListenerRegistration
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.messaging.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatUiState(
    val viajeId: String? = null,
    val mensajes: List<Map<String, Any>> = emptyList(),
    val mensajesNoLeidos: Int = 0,
    val chatAbierto: Boolean = false,
    val appEnPrimerPlano: Boolean = true,
    val alertaMensajeEnApp: String? = null
)

/**
 * ViewModel dedicado al chat del viaje activo (tanto para Conductor como para Pasajero).
 * Escucha chats/{viajeId}/mensajes de forma continua durante todo el viaje activo ("aceptado" o "en_curso")
 * y dispara una notificación flotante Heads-up con sonido cuando llega un mensaje de la otra persona
 * mientras el modal de chat está cerrado o la aplicación está en segundo plano (ej. usando Waze).
 */
class ChatViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var chatListener: ListenerRegistration? = null
    private var viajeObservadoId: String? = null
    private var primerSnapshotPendiente = true
    private val mensajesNotificadosIds = HashSet<String>()

    override fun onCleared() {
        chatListener?.remove()
        chatListener = null
        super.onCleared()
    }

    fun setAppEnPrimerPlano(enPrimerPlano: Boolean) {
        _uiState.value = _uiState.value.copy(appEnPrimerPlano = enPrimerPlano)
    }

    fun setChatAbierto(abierto: Boolean) {
        _uiState.value = _uiState.value.copy(
            chatAbierto = abierto,
            mensajesNoLeidos = if (abierto) 0 else _uiState.value.mensajesNoLeidos,
            alertaMensajeEnApp = if (abierto) null else _uiState.value.alertaMensajeEnApp
        )
    }

    fun limpiarAlertaMensajeEnApp() {
        _uiState.value = _uiState.value.copy(alertaMensajeEnApp = null)
    }

    /**
     * Inicia o detiene la escucha continua de mensajes para el viaje activo.
     * Los mensajes históricos cargados en el primer snapshot no generan notificación;
     * únicamente los mensajes nuevos de la contraparte disparan notificación Heads-up.
     */
    fun sincronizarViajeChat(
        context: Context,
        viajeId: String?,
        uidActual: String?
    ) {
        if (viajeId.isNullOrBlank() || uidActual.isNullOrBlank()) {
            if (viajeObservadoId != null || chatListener != null) {
                chatListener?.remove()
                chatListener = null
                viajeObservadoId = null
                primerSnapshotPendiente = true
                mensajesNotificadosIds.clear()
                _uiState.value = ChatUiState(appEnPrimerPlano = _uiState.value.appEnPrimerPlano)
            }
            return
        }

        if (viajeObservadoId == viajeId && chatListener != null) return

        chatListener?.remove()
        viajeObservadoId = viajeId
        primerSnapshotPendiente = true
        mensajesNotificadosIds.clear()
        _uiState.value = _uiState.value.copy(
            viajeId = viajeId,
            mensajes = emptyList(),
            mensajesNoLeidos = 0,
            alertaMensajeEnApp = null
        )

        val appContext = context.applicationContext
        chatListener = repository.observarMensajesChat(viajeId) { lista ->
            if (primerSnapshotPendiente) {
                primerSnapshotPendiente = false
                lista.forEach { msg ->
                    val id = msg["id"] as? String
                    if (!id.isNullOrBlank()) mensajesNotificadosIds.add(id)
                }
                _uiState.value = _uiState.value.copy(mensajes = lista)
                return@observarMensajesChat
            }

            var nuevosDeContraparte = 0
            var ultimoTextoAlerta: String? = null

            lista.forEach { msg ->
                val id = msg["id"] as? String ?: return@forEach
                if (!mensajesNotificadosIds.add(id)) return@forEach

                val autorUid = msg["autorUid"] as? String ?: ""
                if (autorUid == uidActual) return@forEach

                val autorNombre = (msg["autorNombre"] as? String)?.trim().takeUnless { it.isNullOrBlank() }
                    ?: "Viaje Rural"
                val texto = (msg["texto"] as? String)?.trim().orEmpty()
                if (texto.isBlank()) return@forEach

                val estadoActual = _uiState.value
                val debeNotificarHeadsUp = !estadoActual.chatAbierto || !estadoActual.appEnPrimerPlano
                if (debeNotificarHeadsUp) {
                    nuevosDeContraparte++
                    ultimoTextoAlerta = "$autorNombre: $texto"
                    NotificationHelper.mostrarChatHeadsUp(
                        context = appContext,
                        viajeId = viajeId,
                        mensajeId = id,
                        autorNombre = autorNombre,
                        texto = texto
                    )
                }
            }

            val actual = _uiState.value
            _uiState.value = actual.copy(
                mensajes = lista,
                mensajesNoLeidos = if (actual.chatAbierto) 0 else actual.mensajesNoLeidos + nuevosDeContraparte,
                alertaMensajeEnApp = if (!actual.chatAbierto && ultimoTextoAlerta != null) {
                    ultimoTextoAlerta
                } else {
                    actual.alertaMensajeEnApp
                }
            )
        }
    }

    fun enviarMensaje(
        viajeId: String,
        autorUid: String,
        autorRol: String,
        autorNombre: String,
        texto: String
    ) {
        if (viajeId.isBlank() || texto.isBlank()) return
        viewModelScope.launch {
            try {
                repository.enviarMensajeChat(
                    viajeId = viajeId,
                    autorUid = autorUid,
                    autorRol = autorRol,
                    autorNombre = autorNombre,
                    texto = texto
                )
            } catch (_: Exception) {
            }
        }
    }
}
