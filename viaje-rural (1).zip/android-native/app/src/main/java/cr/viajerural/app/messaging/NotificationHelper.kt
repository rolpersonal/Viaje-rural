package cr.viajerural.app.messaging

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import cr.viajerural.app.MainActivity
import cr.viajerural.app.R

/**
 * Helper centralizado para notificaciones emergentes (Heads-up) y de pantalla completa:
 * - Canales IMPORTANCE_HIGH con sonido y vibración para ofertas de viaje y mensajes de chat.
 * - FullScreenIntent + despertar pantalla para que nuevas ofertas al conductor salten sobre Waze o pantalla bloqueada.
 * - Deduplicación por ID para evitar alertas duplicadas si coinciden FCM y Firestore listener.
 */
object NotificationHelper {

    const val CHANNEL_OFERTAS = "viajes_ofertas_v2"
    const val CHANNEL_OFERTAS_NOMBRE = "Ofertas de Viaje (Emergentes)"
    const val CHANNEL_CHAT_HEADS_UP = "viaje_rural_chat_heads_up_v2"
    const val CHANNEL_CHAT_NOMBRE = "Chat en Vivo (Emergente)"
    const val CHANNEL_HIGH_PRIORITY = "viaje_rural_high_priority_v2"
    const val CHANNEL_HIGH_PRIORITY_NOMBRE = "Alertas de Viaje Rural"
    const val CHANNEL_ADMIN_ALERTAS = "viaje_rural_admin_alertas_v1"
    const val CHANNEL_ADMIN_ALERTAS_NOMBRE = "Solicitudes y Alertas Admin"

    private val VIBRATION_PATTERN_OFERTAS = longArrayOf(0L, 500L, 220L, 500L, 220L, 500L)
    private val VIBRATION_PATTERN_CHAT = longArrayOf(0L, 250L, 120L, 250L)
    private val VIBRATION_PATTERN_ALERTA = longArrayOf(0L, 280L, 140L, 280L)

    private val eventosNotificados = LinkedHashSet<String>()

    @Synchronized
    private fun registrarEventoUnico(clave: String): Boolean {
        if (clave.isBlank()) return true
        if (eventosNotificados.contains(clave)) return false
        if (eventosNotificados.size >= 120) {
            val primero = eventosNotificados.firstOrNull()
            if (primero != null) eventosNotificados.remove(primero)
        }
        eventosNotificados.add(clave)
        return true
    }

    fun tienePermisoNotificaciones(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun puedeUsarFullScreenIntent(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.canUseFullScreenIntent()
        } else {
            true
        }
    }

    fun crearTodosLosCanales(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notifUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val ringtoneAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val chatAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val alertaAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val canalOfertas = NotificationChannel(
            CHANNEL_OFERTAS,
            CHANNEL_OFERTAS_NOMBRE,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alertas emergentes sobre Waze o pantalla bloqueada para nuevas ofertas de viaje."
            setSound(ringtoneUri, ringtoneAttrs)
            enableVibration(true)
            vibrationPattern = VIBRATION_PATTERN_OFERTAS
            enableLights(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            setBypassDnd(true)
        }

        val canalChat = NotificationChannel(
            CHANNEL_CHAT_HEADS_UP,
            CHANNEL_CHAT_NOMBRE,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notificaciones flotantes con sonido para mensajes nuevos de chat entre pasajero y conductor."
            setSound(notifUri, chatAttrs)
            enableVibration(true)
            vibrationPattern = VIBRATION_PATTERN_CHAT
            enableLights(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        }

        val canalAlertas = NotificationChannel(
            CHANNEL_HIGH_PRIORITY,
            CHANNEL_HIGH_PRIORITY_NOMBRE,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Avisos importantes de aceptación, cercanía y cancelación de viaje."
            setSound(notifUri, alertaAttrs)
            enableVibration(true)
            vibrationPattern = VIBRATION_PATTERN_ALERTA
            enableLights(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        }

        val canalAdmin = NotificationChannel(
            CHANNEL_ADMIN_ALERTAS,
            CHANNEL_ADMIN_ALERTAS_NOMBRE,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notificaciones en tiempo real para el Administrador sobre solicitudes de cambio de datos."
            setSound(notifUri, alertaAttrs)
            enableVibration(true)
            vibrationPattern = VIBRATION_PATTERN_ALERTA
            enableLights(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        }

        manager.createNotificationChannel(canalOfertas)
        manager.createNotificationChannel(canalChat)
        manager.createNotificationChannel(canalAlertas)
        manager.createNotificationChannel(canalAdmin)
    }

    @Suppress("DEPRECATION")
    @SuppressLint("WakelockTimeout")
    private fun despertarPantallaBrevemente(context: Context) {
        try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
            if (powerManager.isInteractive) return
            val wakeLock = powerManager.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "ViajeRural:OfertaViajeWakeLock"
            )
            wakeLock.acquire(4_000L)
        } catch (_: Throwable) {
        }
    }

    /**
     * Notificación emergente (Heads-up) con sonido para nuevas solicitudes del Conductor.
     * Se dispara tanto en primer plano como en segundo plano; usa FullScreenIntent cuando la app está en segundo plano.
     */
    fun mostrarOfertaViajeHeadsUp(
        context: Context,
        titulo: String,
        cuerpo: String,
        viajeId: String? = null,
        claveDeduplicacion: String? = null,
        enPrimerPlano: Boolean = false
    ) {
        val clave = claveDeduplicacion?.takeIf { it.isNotBlank() }
            ?: viajeId?.let { "oferta_$it" }
            ?: ""
        if (clave.isNotBlank() && !registrarEventoUnico(clave)) return

        if (!tienePermisoNotificaciones(context)) {
            if (enPrimerPlano) {
                reproducirAlertaOfertaSinPermiso(context)
            }
            return
        }

        crearTodosLosCanales(context)
        if (!enPrimerPlano) {
            despertarPantallaBrevemente(context)
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("tipo", "OFERTA_15S")
            if (!viajeId.isNullOrBlank()) {
                putExtra("viajeId", viajeId)
            }
        }

        val notificationId = if (!viajeId.isNullOrBlank()) {
            20_000 + (viajeId.hashCode() and 0x7FFF)
        } else {
            20_000 + ((System.currentTimeMillis() and 0x7FFF).toInt())
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_OFERTAS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(cuerpo))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_LIGHTS)
            .setSound(soundUri)
            .setVibrate(VIBRATION_PATTERN_OFERTAS)
            .setContentIntent(pendingIntent)
            .setOnlyAlertOnce(false)
            .setOngoing(false)
            .setAutoCancel(true)
            .setTimeoutAfter(16_000L)

        if (!enPrimerPlano) {
            builder.setFullScreenIntent(pendingIntent, true)
        }

        manager.notify(notificationId, builder.build())
    }

    private fun reproducirAlertaOfertaSinPermiso(context: Context) {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: return
            RingtoneManager.getRingtone(context.applicationContext, uri)?.play()
        } catch (_: Throwable) {
        }
    }

    /**
     * Notificación emergente (Heads-up) con sonido para nuevos mensajes de chat (Conductor o Pasajero).
     * Se dispara incluso si la app está en segundo plano o si la ventana de chat está cerrada.
     */
    fun mostrarChatHeadsUp(
        context: Context,
        viajeId: String?,
        mensajeId: String?,
        autorNombre: String,
        texto: String
    ) {
        if (!tienePermisoNotificaciones(context)) return
        val clave = if (!mensajeId.isNullOrBlank()) {
            "chat_${viajeId.orEmpty()}_$mensajeId"
        } else {
            ""
        }
        if (clave.isNotBlank() && !registrarEventoUnico(clave)) return

        crearTodosLosCanales(context)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("tipo", "CHAT_MENSAJE")
            putExtra("abrirChat", true)
            if (!viajeId.isNullOrBlank()) {
                putExtra("viajeId", viajeId)
            }
        }

        val notifId = 30_000 + (((mensajeId ?: texto).hashCode()) and 0x7FFF)
        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val tituloLimpio = "Mensaje de ${autorNombre.trim().ifBlank { "Viaje Rural" }}"
        val cuerpoLimpio = texto.trim().ifBlank { "Tienes un nuevo mensaje en tu viaje." }

        val notif = NotificationCompat.Builder(context, CHANNEL_CHAT_HEADS_UP)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(tituloLimpio)
            .setContentText(cuerpoLimpio)
            .setStyle(NotificationCompat.BigTextStyle().bigText(cuerpoLimpio))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_LIGHTS)
            .setSound(soundUri)
            .setVibrate(VIBRATION_PATTERN_CHAT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(notifId, notif)
    }

    /**
     * Notificación flotante de alta prioridad para eventos de viaje (aceptado, cercanía, cancelación).
     */
    fun mostrarAlertaGeneralHeadsUp(
        context: Context,
        titulo: String,
        cuerpo: String,
        viajeId: String? = null
    ) {
        if (!tienePermisoNotificaciones(context)) return
        crearTodosLosCanales(context)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (!viajeId.isNullOrBlank()) {
                putExtra("viajeId", viajeId)
            }
        }
        val notifId = 40_000 + ((System.currentTimeMillis() and 0x7FFF).toInt())
        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_HIGH_PRIORITY)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(cuerpo))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_LIGHTS)
            .setSound(soundUri)
            .setVibrate(VIBRATION_PATTERN_ALERTA)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(notifId, notif)
    }

    /**
     * Notificación flotante Heads-up de alta prioridad al pasajero cuando el conductor presiona "Ya llegué".
     */
    fun mostrarNotificacionConductorLlego(
        context: Context,
        conductorNombre: String? = null,
        placa: String? = null,
        viajeId: String? = null,
        tituloPersonalizado: String? = null,
        cuerpoPersonalizado: String? = null
    ) {
        if (!tienePermisoNotificaciones(context)) return
        crearTodosLosCanales(context)

        val nombreLimpio = conductorNombre?.trim()?.takeIf { it.isNotBlank() } ?: "Tu conductor"
        val placaSuffix = placa?.trim()?.takeIf { it.isNotBlank() }?.let { " (Placa $it)" } ?: ""
        val titulo = tituloPersonalizado?.takeIf { it.isNotBlank() } ?: "¡Tu conductor ha llegado!"
        val cuerpo = cuerpoPersonalizado?.takeIf { it.isNotBlank() }
            ?: "$nombreLimpio$placaSuffix ya está en el punto de recogida. Ten tu PIN listo para abordar."

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("tipo", "CONDUCTOR_LLEGO")
            if (!viajeId.isNullOrBlank()) {
                putExtra("viajeId", viajeId)
            }
        }
        val notifId = 45_000 + (((viajeId ?: nombreLimpio).hashCode()) and 0x7FFF)
        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_HIGH_PRIORITY)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(cuerpo))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_LIGHTS)
            .setSound(soundUri)
            .setVibrate(VIBRATION_PATTERN_ALERTA)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(notifId, notif)
    }

    /**
     * Notificación local de alta prioridad para el dispositivo del Administrador cuando llega
     * una nueva solicitud de cambio de datos de un conductor en tiempo real.
     */
    fun mostrarNotificacionAdminSolicitudCambio(
        context: Context,
        solicitudId: String,
        nombreConductor: String,
        resumenCambios: String = ""
    ) {
        if (!tienePermisoNotificaciones(context)) return
        if (solicitudId.isNotBlank() && !registrarEventoUnico("admin_sol_$solicitudId")) return
        crearTodosLosCanales(context)

        val nombreLimpio = nombreConductor.trim().ifBlank { "Conductor" }
        val titulo = "Nueva solicitud de cambio de datos de $nombreLimpio"
        val cuerpo = if (resumenCambios.isNotBlank()) {
            "Solicita actualizar: $resumenCambios. Toca para revisar."
        } else {
            "Solicita modificar datos personales o del vehículo. Toca para revisar."
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("tipo", "ADMIN_SOLICITUD_CAMBIO")
            putExtra("solicitudId", solicitudId)
        }
        val notifId = 50_000 + ((solicitudId.ifBlank { nombreLimpio }.hashCode()) and 0x7FFF)
        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_ADMIN_ALERTAS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(cuerpo))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_LIGHTS)
            .setSound(soundUri)
            .setVibrate(VIBRATION_PATTERN_ALERTA)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(notifId, notif)
    }

    private const val CHANNEL_SEGUIMIENTO_RECOGIDA = "viaje_rural_seguimiento_recogida"
    private const val NOTIF_ID_SEGUIMIENTO_RECOGIDA = 9002

    fun mostrarNotificacionSeguimientoRecogida(
        context: Context,
        distanciaTexto: String,
        etaMinutos: Int
    ) {
        if (!tienePermisoNotificaciones(context)) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CHANNEL_SEGUIMIENTO_RECOGIDA,
                "Seguimiento de recogida (90s)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Muestra distancia y tiempo estimado hasta el pasajero."
                setSound(null, null)
                enableVibration(false)
            }
            manager.createNotificationChannel(canal)
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIF_ID_SEGUIMIENTO_RECOGIDA,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_SEGUIMIENTO_RECOGIDA)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("En camino al pasajero · ETA $etaMinutos min")
            .setContentText("Distancia restante: $distanciaTexto (GPS cada 90s)")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()

        manager.notify(NOTIF_ID_SEGUIMIENTO_RECOGIDA, notif)
    }

    fun cancelarNotificacionSeguimientoRecogida(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(NOTIF_ID_SEGUIMIENTO_RECOGIDA)
    }
}
