package cr.viajerural.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.ListenerRegistration
import cr.viajerural.app.data.ConductorDisponibleCercano
import cr.viajerural.app.data.RutaFavoritaData
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.UbicacionSugerida
import cr.viajerural.app.data.ViajeRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class PasajeroTab { VIAJE, HISTORIAL, PERFIL }

data class OpcionVehiculoDisponibleUi(
    val tipoId: String,
    val nombre: String,
    val detalleCapacidad: String,
    val conductoresDisponibles: Int,
    val montoAproximado: Int,
    val distanciaConductorKm: Double
)

data class PasajeroUiState(
    val tabActual: PasajeroTab = PasajeroTab.VIAJE,
    val viajeActivo: Map<String, Any>? = null,
    val pinPersistente: String? = null,
    val mensajesChat: List<Map<String, Any>> = emptyList(),
    val nombrePasajero: String = "",
    val fotoUrl: String = "",
    val actualizandoFoto: Boolean = false,
    val misSolicitudes: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val historial: List<Map<String, Any>> = emptyList(),
    val historialCargado: Boolean = false,
    val cargandoHistorial: Boolean = false,
    val rutasFavoritas: List<RutaFavoritaData> = emptyList(),
    val sugerenciasOrigen: List<UbicacionSugerida> = emptyList(),
    val sugerenciasDestino: List<UbicacionSugerida> = emptyList(),
    val buscandoOrigen: Boolean = false,
    val buscandoDestino: Boolean = false,
    val mostrarModalPago: Boolean = false,
    val montoAPagar: Double = 0.0,
    val ultimoViajeId: String? = null,
    val ultimoConductorId: String? = null,
    val avisoCancelacion: String? = null,
    val precisionUbicacionMetros: Int? = null,
    val solicitandoViaje: Boolean = false,
    val errorSolicitud: String? = null,
    val conductoresCercanos: List<ConductorDisponibleCercano> = emptyList(),
    val opcionesVehiculosDisponibles: List<OpcionVehiculoDisponibleUi> = emptyList(),
    val buscandoConductores: Boolean = false,
    val busquedaVehiculosRealizada: Boolean = false,
    val distanciaViajeKm: Double = 0.0,
    val mensajeDisponibilidad: String? = null
)

class PasajeroViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(PasajeroUiState())
    val uiState: StateFlow<PasajeroUiState> = _uiState.asStateFlow()

    private var busquedaOrigenJob: Job? = null
    private var busquedaDestinoJob: Job? = null
    private var viajePasajeroListener: ListenerRegistration? = null
    private var viajeDocListener: ListenerRegistration? = null
    private var chatPasajeroListener: ListenerRegistration? = null
    private var pasajeroObservadoUid: String? = null
    private var viajeDocObservadoId: String? = null
    private var cancelacionPropiaViajeId: String? = null

    override fun onCleared() {
        viajePasajeroListener?.remove()
        viajePasajeroListener = null
        viajeDocListener?.remove()
        viajeDocListener = null
        viajeDocObservadoId = null
        chatPasajeroListener?.remove()
        chatPasajeroListener = null
        super.onCleared()
    }

    fun seleccionarTab(tab: PasajeroTab, pasajeroId: String) {
        _uiState.value = _uiState.value.copy(tabActual = tab)
        if (tab == PasajeroTab.HISTORIAL && !_uiState.value.historialCargado) {
            cargarHistorial(pasajeroId)
        }
        if (tab == PasajeroTab.PERFIL && !_uiState.value.solicitudesCargadas) {
            cargarMisSolicitudes(pasajeroId)
        }
    }

    fun cargarMisSolicitudes(pasajeroId: String) {
        viewModelScope.launch {
            try {
                val lista = repository.obtenerMisSolicitudesCambio(pasajeroId)
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = lista,
                    solicitudesCargadas = true
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(solicitudesCargadas = true)
            }
        }
    }

    fun enviarSolicitudCambioPasajero(
        pasajeroId: String,
        nombreActual: String,
        cambios: Map<String, Any>,
        motivo: String
    ) {
        if (cambios.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                val creada = repository.crearSolicitudCambioDatos(
                    solicitanteUid = pasajeroId,
                    rol = "pasajero",
                    nombreActual = nombreActual.ifBlank { "Pasajero Rural" },
                    resumenActual = "Pasajero registrado",
                    cambios = cambios,
                    motivo = motivo
                )
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = listOf(creada) + _uiState.value.misSolicitudes
                )
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Listener directo en tiempo real sobre viajes/{viajeId}.
     * Garantiza transición instantánea de "buscando" -> "aceptado" (conductor, ETA y PIN),
     * "finalizado" (abre modal de pago/calificación) y "cancelado" por el conductor (alerta emergente).
     */
    private fun iniciarEscuchaViajeDocumento(viajeId: String) {
        if (viajeId.isBlank()) return
        if (viajeDocObservadoId == viajeId && viajeDocListener != null) return
        viajeDocListener?.remove()
        viajeDocObservadoId = viajeId
        viajeDocListener = repository.observarViajePorId(viajeId) { viaje ->
            if (viaje == null) {
                viajeDocListener?.remove()
                viajeDocListener = null
                viajeDocObservadoId = null
                _uiState.value = _uiState.value.copy(viajeActivo = null, pinPersistente = null)
                return@observarViajePorId
            }

            val estado = viaje["estado"] as? String
            when (estado) {
                "buscando", "aceptado", "en_curso" -> {
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = viaje,
                        solicitandoViaje = false
                    )
                    if (_uiState.value.pinPersistente.isNullOrBlank()) {
                        viewModelScope.launch {
                            val pin = repository.obtenerPinSecretoViaje(viajeId)
                            if (!pin.isNullOrBlank()) {
                                _uiState.value = _uiState.value.copy(pinPersistente = pin)
                            }
                        }
                    }
                }
                "finalizado" -> {
                    viajeDocListener?.remove()
                    viajeDocListener = null
                    viajeDocObservadoId = null
                    val conductorId = viaje["conductorId"] as? String ?: ""
                    val monto = (viaje["montoAproximado"] as? Number)?.toDouble() ?: 0.0
                    onViajeFinalizado(viajeId, conductorId, monto)
                }
                "cancelado" -> {
                    viajeDocListener?.remove()
                    viajeDocListener = null
                    viajeDocObservadoId = null
                    val canceladoPor = viaje["canceladoPor"] as? String
                    if (canceladoPor == "conductor" || (viajeId != cancelacionPropiaViajeId && canceladoPor != "pasajero")) {
                        val conductorNombre = (viaje["conductorNombre"] as? String)?.takeIf { it.isNotBlank() }
                            ?: "El conductor"
                        val motivo = (viaje["motivoCancelacion"] as? String)?.takeIf { it.isNotBlank() }
                            ?: "El conductor canceló el viaje."
                        onViajeCanceladoPorConductor("$conductorNombre canceló el viaje: \"$motivo\"")
                    } else {
                        _uiState.value = _uiState.value.copy(viajeActivo = null, pinPersistente = null)
                    }
                }
            }
        }
    }

    fun restaurarViajeActivo(pasajeroId: String) {
        if (pasajeroObservadoUid != pasajeroId) {
            viajePasajeroListener?.remove()
            pasajeroObservadoUid = pasajeroId
            viajePasajeroListener = repository.observarViajeActivoPasajero(pasajeroId) { res ->
                if (res != null) {
                    val vId = res.first["id"] as? String
                    if (!vId.isNullOrBlank()) {
                        iniciarEscuchaViajeDocumento(vId)
                    }
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = res.first,
                        pinPersistente = res.second ?: _uiState.value.pinPersistente
                    )
                } else if (viajeDocListener == null) {
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = null,
                        pinPersistente = null
                    )
                }
            }
        }
        viewModelScope.launch {
            try {
                val resultado = repository.recuperarViajeActivoPasajero(pasajeroId)
                val favoritas = repository.obtenerRutasFavoritasPasajero(pasajeroId)
                val (nombre, foto) = repository.obtenerPerfilBasicoPasajero(pasajeroId)
                val vId = resultado?.first?.get("id") as? String
                if (!vId.isNullOrBlank()) {
                    iniciarEscuchaViajeDocumento(vId)
                }
                _uiState.value = _uiState.value.copy(
                    viajeActivo = resultado?.first ?: _uiState.value.viajeActivo,
                    pinPersistente = resultado?.second ?: _uiState.value.pinPersistente,
                    rutasFavoritas = favoritas,
                    nombrePasajero = if (nombre.isNotBlank()) nombre else _uiState.value.nombrePasajero,
                    fotoUrl = if (foto.isNotBlank()) foto else _uiState.value.fotoUrl
                )
            } catch (_: Exception) {
            }
        }
    }

    fun observarChat(viajeId: String) {
        chatPasajeroListener?.remove()
        chatPasajeroListener = repository.observarMensajesChat(viajeId) { msgs ->
            _uiState.value = _uiState.value.copy(mensajesChat = msgs)
        }
    }

    fun detenerChat() {
        chatPasajeroListener?.remove()
        chatPasajeroListener = null
    }

    fun enviarMensajeChat(viajeId: String, pasajeroId: String, texto: String) {
        viewModelScope.launch {
            try {
                repository.enviarMensajeChat(
                    viajeId = viajeId,
                    autorUid = pasajeroId,
                    autorRol = "pasajero",
                    autorNombre = _uiState.value.nombrePasajero.ifBlank { "Pasajero" },
                    texto = texto
                )
            } catch (_: Exception) {
            }
        }
    }

    fun actualizarFotoPerfil(pasajeroId: String, fotoUrl: String) {
        if (fotoUrl.isBlank()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(actualizandoFoto = true)
            try {
                repository.actualizarFotoPerfilPasajero(pasajeroId, fotoUrl)
                _uiState.value = _uiState.value.copy(
                    fotoUrl = fotoUrl,
                    actualizandoFoto = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(actualizandoFoto = false)
            }
        }
    }

    /**
     * Paso 1 del flujo del Pasajero ("Buscar"):
     * - Consulta conductores en Firestore con disponible == true a menos de 10 km (Haversine) y capacidad suficiente.
     * - Agrupa ÚNICAMENTE por los tipos de vehículo que realmente tienen conductores disponibles cercanos.
     * - Calcula el monto aproximado (tarifaBase + distanciaKm * tarifaPorKm) para cada tipo encontrado.
     */
    fun buscarVehiculosDisponibles(
        origenLat: Double,
        origenLng: Double,
        destinoLat: Double,
        destinoLng: Double,
        cantidadPasajeros: Int
    ) {
        val pax = cantidadPasajeros.coerceAtLeast(1)
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                buscandoConductores = true,
                errorSolicitud = null,
                mensajeDisponibilidad = null
            )
            try {
                val cercanos = repository.buscarConductoresDisponiblesCercanos(
                    origenLat = origenLat,
                    origenLng = origenLng,
                    radioMaxKm = 10.0,
                    cantidadPasajerosMin = pax,
                    tiposVehiculoPermitidos = emptyList()
                )
                val distanciaViajeKm = repository.calcularDistanciaRutaKm(
                    origenLat = origenLat,
                    origenLng = origenLng,
                    destinoLat = destinoLat,
                    destinoLng = destinoLng
                )

                val agrupados = cercanos.groupBy { repository.normalizarTipoVehiculo(it.tipoVehiculo) }
                val ordenBase = listOf("auto", "moto", "pickup", "buseta")
                val clavesOrdenadas = ordenBase.filter { agrupados.containsKey(it) } +
                    agrupados.keys.filterNot { it in ordenBase }

                val opcionesDisponibles = clavesOrdenadas.mapNotNull { tipoId ->
                    val listaTipo = agrupados[tipoId].orEmpty()
                    if (listaTipo.isEmpty()) return@mapNotNull null
                    val masCercano = listaTipo.minByOrNull { it.distanciaKm } ?: listaTipo.first()
                    val montoAprox = (masCercano.tarifaBase + (distanciaViajeKm * masCercano.tarifaPorKm))
                        .coerceIn(1500.0, 500000.0)
                        .roundToInt()

                    val (nombreLegible, detalleCapacidad) = when (tipoId) {
                        "auto" -> "Carro" to "Hasta ${masCercano.capacidad.coerceAtLeast(4)} pas."
                        "moto" -> "Moto" to "1 pasajero"
                        "pickup" -> "Pickup" to "4x4 · Hasta ${masCercano.capacidad.coerceAtLeast(5)} pas."
                        "buseta" -> "Buseta" to "Hasta ${masCercano.capacidad.coerceAtLeast(12)} pas."
                        else -> tipoId.replaceFirstChar { it.uppercase() } to "Hasta ${masCercano.capacidad} pas."
                    }

                    OpcionVehiculoDisponibleUi(
                        tipoId = tipoId,
                        nombre = nombreLegible,
                        detalleCapacidad = detalleCapacidad,
                        conductoresDisponibles = listaTipo.size,
                        montoAproximado = montoAprox,
                        distanciaConductorKm = masCercano.distanciaKm
                    )
                }

                _uiState.value = _uiState.value.copy(
                    conductoresCercanos = cercanos,
                    opcionesVehiculosDisponibles = opcionesDisponibles,
                    buscandoConductores = false,
                    busquedaVehiculosRealizada = true,
                    distanciaViajeKm = distanciaViajeKm,
                    mensajeDisponibilidad = if (opcionesDisponibles.isEmpty()) {
                        "No hay vehículos disponibles a menos de 10 km para $pax pasajero(s)."
                    } else {
                        null
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    buscandoConductores = false,
                    busquedaVehiculosRealizada = true,
                    opcionesVehiculosDisponibles = emptyList(),
                    errorSolicitud = e.localizedMessage ?: "No se pudieron consultar vehículos disponibles."
                )
            }
        }
    }

    fun limpiarBusquedaVehiculos() {
        if (!_uiState.value.busquedaVehiculosRealizada &&
            _uiState.value.opcionesVehiculosDisponibles.isEmpty() &&
            _uiState.value.mensajeDisponibilidad == null
        ) {
            return
        }
        _uiState.value = _uiState.value.copy(
            conductoresCercanos = emptyList(),
            opcionesVehiculosDisponibles = emptyList(),
            busquedaVehiculosRealizada = false,
            mensajeDisponibilidad = null
        )
    }

    fun solicitarViaje(
        pasajeroId: String,
        cantidadPasajeros: Int,
        origenNombre: String,
        origenLat: Double,
        origenLng: Double,
        destinoNombre: String,
        destinoLat: Double,
        destinoLng: Double,
        resenaUbicacion: String,
        tiposVehiculoPermitidos: List<String> = emptyList()
    ) {
        if (cantidadPasajeros < 1 || resenaUbicacion.trim().length < 3 || tiposVehiculoPermitidos.isEmpty()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(solicitandoViaje = true, errorSolicitud = null)
            try {
                val (viaje, pin) = repository.solicitarViajeConResena(
                    pasajeroId = pasajeroId,
                    pasajeroNombre = _uiState.value.nombrePasajero.ifBlank { "Pasajero Rural" },
                    cantidadPasajeros = cantidadPasajeros,
                    origenNombre = origenNombre,
                    origenLat = origenLat,
                    origenLng = origenLng,
                    destinoNombre = destinoNombre,
                    destinoLat = destinoLat,
                    destinoLng = destinoLng,
                    resenaUbicacion = resenaUbicacion,
                    tiposVehiculoPermitidos = tiposVehiculoPermitidos
                )
                val viajeId = viaje["id"] as? String
                if (!viajeId.isNullOrBlank()) {
                    iniciarEscuchaViajeDocumento(viajeId)
                }
                _uiState.value = _uiState.value.copy(
                    viajeActivo = viaje,
                    pinPersistente = pin,
                    solicitandoViaje = false,
                    errorSolicitud = null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    solicitandoViaje = false,
                    errorSolicitud = e.localizedMessage ?: "No se pudo solicitar el viaje. Intenta de nuevo."
                )
            }
        }
    }

    fun limpiarErrorSolicitud() {
        _uiState.value = _uiState.value.copy(errorSolicitud = null)
    }

    fun actualizarUbicacionGps(precisionMetros: Int?) {
        _uiState.value = _uiState.value.copy(precisionUbicacionMetros = precisionMetros)
    }

    fun buscarSugerenciasOrigen(
        query: String,
        latCercana: Double = 9.3895,
        lngCercana: Double = -83.6490
    ) {
        _uiState.value = _uiState.value.copy(
            sugerenciasOrigen = repository.buscarUbicacionesSugeridas(query),
            buscandoOrigen = query.trim().length >= 2
        )
        busquedaOrigenJob?.cancel()
        if (query.trim().length < 2) {
            _uiState.value = _uiState.value.copy(buscandoOrigen = false)
            return
        }
        busquedaOrigenJob = viewModelScope.launch {
            delay(300)
            val resultados = repository.buscarUbicacionesNominatim(query, latCercana, lngCercana)
            _uiState.value = _uiState.value.copy(
                sugerenciasOrigen = resultados,
                buscandoOrigen = false
            )
        }
    }

    fun buscarSugerenciasDestino(
        query: String,
        latCercana: Double = 9.3895,
        lngCercana: Double = -83.6490
    ) {
        _uiState.value = _uiState.value.copy(
            sugerenciasDestino = repository.buscarUbicacionesSugeridas(query),
            buscandoDestino = query.trim().length >= 2
        )
        busquedaDestinoJob?.cancel()
        if (query.trim().length < 2) {
            _uiState.value = _uiState.value.copy(buscandoDestino = false)
            return
        }
        busquedaDestinoJob = viewModelScope.launch {
            delay(300)
            val resultados = repository.buscarUbicacionesNominatim(query, latCercana, lngCercana)
            _uiState.value = _uiState.value.copy(
                sugerenciasDestino = resultados,
                buscandoDestino = false
            )
        }
    }

    fun guardarRutaFavorita(pasajeroId: String, ruta: RutaFavoritaData) {
        viewModelScope.launch {
            try {
                val actualizadas = repository.guardarRutaFavoritaPasajero(pasajeroId, ruta)
                _uiState.value = _uiState.value.copy(rutasFavoritas = actualizadas)
            } catch (_: Exception) {
            }
        }
    }

    fun eliminarRutaFavorita(pasajeroId: String, rutaId: String) {
        viewModelScope.launch {
            try {
                val actualizadas = repository.eliminarRutaFavoritaPasajero(pasajeroId, rutaId)
                _uiState.value = _uiState.value.copy(rutasFavoritas = actualizadas)
            } catch (_: Exception) {
            }
        }
    }

    fun cargarHistorial(pasajeroId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargandoHistorial = true)
            try {
                val lista = repository.obtenerHistorialPasajero(pasajeroId, 20L)
                _uiState.value = _uiState.value.copy(
                    historial = lista,
                    historialCargado = true,
                    cargandoHistorial = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(cargandoHistorial = false)
            }
        }
    }

    fun onViajeFinalizado(viajeId: String, conductorId: String, montoAPagar: Double) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            pinPersistente = null,
            mostrarModalPago = true,
            montoAPagar = montoAPagar,
            ultimoViajeId = viajeId,
            ultimoConductorId = conductorId
        )
    }

    fun calificarConductor(pasajeroId: String, estrellas: Int, comentario: String) {
        val viajeId = _uiState.value.ultimoViajeId ?: return
        val conductorId = _uiState.value.ultimoConductorId ?: return
        viewModelScope.launch {
            try {
                repository.enviarCalificacionYActualizarPromedio(
                    viajeId = viajeId,
                    autorUid = pasajeroId,
                    destinatarioUid = conductorId,
                    destinatarioRol = "conductor",
                    estrellas = estrellas,
                    comentario = comentario
                )
            } catch (_: Exception) {
            } finally {
                _uiState.value = _uiState.value.copy(mostrarModalPago = false)
            }
        }
    }

    fun cancelarViajeActivo(viajeId: String, motivo: String) {
        if (motivo.trim().length < 3) return
        cancelacionPropiaViajeId = viajeId
        viajeDocListener?.remove()
        viajeDocListener = null
        viajeDocObservadoId = null
        viewModelScope.launch {
            try {
                repository.cancelarViajeConMotivo(
                    viajeId = viajeId,
                    canceladoPor = "pasajero",
                    motivo = motivo
                )
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    pinPersistente = null,
                    errorSolicitud = null
                )
            } catch (e: Exception) {
                cancelacionPropiaViajeId = null
                iniciarEscuchaViajeDocumento(viajeId)
                _uiState.value = _uiState.value.copy(
                    errorSolicitud = e.localizedMessage ?: "No se pudo cancelar el viaje."
                )
            }
        }
    }

    fun onViajeCanceladoPorConductor(motivo: String) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            pinPersistente = null,
            avisoCancelacion = motivo
        )
    }

    fun limpiarAvisoCancelacion() {
        _uiState.value = _uiState.value.copy(avisoCancelacion = null)
    }

    fun cerrarModalPago() {
        _uiState.value = _uiState.value.copy(mostrarModalPago = false)
    }
}
