package cr.viajerural.app.messaging

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import cr.viajerural.app.MainActivity
import cr.viajerural.app.R
import cr.viajerural.app.data.ViajeRepository

/**
 * Servicio FCM principal de Viaje Rural:
 * - Garantiza canales IMPORTANCE_HIGH con sonido y vibración desde onCreate().
 * - Muestra ofertas de viaje como Heads-up + FullScreenIntent sobre cualquier app (Waze) o pantalla bloqueada.
 * - Muestra mensajes de chat entrantes como Heads-up con sonido.
 * - Atiende PING_1S capturando una lectura GPS única y apagando el receptor de inmediato.
 */
class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onCreate() {
        super.onCreate()
        crearCanalOfertasAltaPrioridad()
        NotificationHelper.crearTodosLosCanales(this)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Token renovado por Firebase Messaging para notificaciones push dirigidas.
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        crearCanalOfertasAltaPrioridad()
        NotificationHelper.crearTodosLosCanales(this)

        val data = remoteMessage.data
        val tipo = data["tipo"]
        val viajeId = data["viajeId"]

        // Leer obligatoriamente desde el payload de datos (data["title"] / data["body"])
        // para garantizar ejecución con la app minimizada, cerrada o pantalla bloqueada.
        val titleData = data["title"]?.takeIf { it.isNotBlank() }
            ?: data["titulo"]?.takeIf { it.isNotBlank() }
            ?: remoteMessage.notification?.title
        val bodyData = data["body"]?.takeIf { it.isNotBlank() }
            ?: data["resumen"]?.takeIf { it.isNotBlank() }
            ?: data["cuerpo"]?.takeIf { it.isNotBlank() }
            ?: remoteMessage.notification?.body

        when (tipo) {
            "PING_1S" -> ejecutarPingGpsDeUnSegundo()

            "OFERTA_15S", "NUEVO_VIAJE", "OFERTA_VIAJE" -> {
                mostrarNotificacionOfertaFullScreen(
                    titulo = titleData ?: "Nueva oferta de viaje",
                    cuerpo = bodyData ?: "Tienes 15 segundos para aceptar la solicitud.",
                    viajeId = viajeId
                )
            }

            "CHAT_MENSAJE" -> {
                val autorNombre = data["autorNombre"]
                    ?: titleData
                    ?: "Viaje Rural"
                val texto = data["texto"]
                    ?: bodyData
                    ?: "Tienes un nuevo mensaje en tu viaje."
                val mensajeId = data["mensajeId"] ?: remoteMessage.messageId
                NotificationHelper.mostrarChatHeadsUp(
                    context = this,
                    viajeId = viajeId,
                    mensajeId = mensajeId,
                    autorNombre = autorNombre,
                    texto = texto
                )
            }

            "ACEPTADO" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = titleData ?: "¡Conductor asignado!",
                cuerpo = bodyData ?: "Tu conductor va en camino. Revisa tu PIN de 3 dígitos.",
                viajeId = viajeId
            )

            "PROXIMIDAD" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = titleData ?: "Conductor cerca de tu ubicación",
                cuerpo = bodyData ?: "Ten a mano tu PIN de 3 dígitos para abordar.",
                viajeId = viajeId
            )

            "CONDUCTOR_LLEGO", "LLEGADA_CONDUCTOR" -> NotificationHelper.mostrarNotificacionConductorLlego(
                context = this,
                conductorNombre = data["conductorNombre"],
                placa = data["conductorPlaca"],
                viajeId = viajeId,
                tituloPersonalizado = titleData,
                cuerpoPersonalizado = bodyData
            )

            "MENSUALIDAD_7000" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = titleData ?: "Recordatorio mensual — Viaje Rural",
                cuerpo = bodyData ?: "Renueva tu licencia mensual (₡7,000 colones) para seguir recibiendo viajes.",
                viajeId = viajeId
            )

            "VIAJE_CANCELADO" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = titleData ?: "Viaje cancelado por ${data["pasajeroNombre"] ?: "el pasajero"}",
                cuerpo = data["motivoCancelacion"] ?: bodyData ?: "El pasajero canceló el viaje.",
                viajeId = viajeId
            )

            else -> {
                if (!titleData.isNullOrBlank() || !bodyData.isNullOrBlank()) {
                    mostrarNotificacionOfertaFullScreen(
                        titulo = titleData ?: "Viaje Rural",
                        cuerpo = bodyData ?: "Toca para abrir la aplicación.",
                        viajeId = viajeId
                    )
                }
            }
        }
    }

    private fun crearCanalOfertasAltaPrioridad() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val canal = NotificationChannel(
            NotificationHelper.CHANNEL_OFERTAS,
            NotificationHelper.CHANNEL_OFERTAS_NOMBRE,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alertas emergentes con pantalla completa para nuevas ofertas de viaje."
            setSound(soundUri, audioAttrs)
            enableVibration(true)
            vibrationPattern = longArrayOf(0L, 500L, 220L, 500L, 220L, 500L)
            enableLights(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            setBypassDnd(true)
        }
        manager.createNotificationChannel(canal)
    }

    @Suppress("DEPRECATION")
    @SuppressLint("WakelockTimeout")
    private fun mostrarNotificacionOfertaFullScreen(
        titulo: String,
        cuerpo: String,
        viajeId: String?
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        crearCanalOfertasAltaPrioridad()

        // Despertar la pantalla si el dispositivo está bloqueado o en reposo
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (powerManager != null && !powerManager.isInteractive) {
                val wakeLock = powerManager.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "ViajeRural:OfertaViajeWakeLock"
                )
                wakeLock.acquire(5_000L)
            }
        } catch (_: Throwable) {
        }

        val fullScreenIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("tipo", "OFERTA_15S")
            if (!viajeId.isNullOrBlank()) {
                putExtra("viajeId", viajeId)
            }
        }

        val notificationId = if (!viajeId.isNullOrBlank()) {
            20_000 + (viajeId.hashCode() and 0x7FFF)
        } else {
            20_000 + ((System.currentTimeMillis() and 0x7FFF).toInt())
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            notificationId,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val patronVibracion = longArrayOf(0L, 500L, 220L, 500L, 220L, 500L)

        val builder = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_OFERTAS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(cuerpo))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setSound(soundUri)
            .setVibrate(patronVibracion)
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setAutoCancel(true)
            .setTimeoutAfter(16_000L)

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notificationId, builder.build())
    }

    @SuppressLint("MissingPermission")
    private fun ejecutarPingGpsDeUnSegundo() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val fused = LocationServices.getFusedLocationProviderClient(this)
        val cts = CancellationTokenSource()

        val db = try {
            FirebaseFirestore.getInstance(ViajeRepository.FIRESTORE_DATABASE_ID)
        } catch (_: Throwable) {
            FirebaseFirestore.getInstance()
        }

        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    db.collection("conductores")
                        .document(uid)
                        .update(
                            mapOf(
                                "lat" to location.latitude,
                                "lng" to location.longitude,
                                "ultimoPingAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                }
                cts.cancel()
            }
            .addOnFailureListener { cts.cancel() }
    }
}
