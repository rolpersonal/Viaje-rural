package cr.viajerural.app.messaging

import android.annotation.SuppressLint
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import cr.viajerural.app.data.ViajeRepository

/**
 * Servicio FCM principal de Viaje Rural:
 * - Garantiza canales IMPORTANCE_HIGH con sonido y vibración desde onCreate().
 * - Muestra ofertas de viaje como Heads-up + FullScreenIntent sobre cualquier app (Waze) o pantalla bloqueada.
 * - Muestra mensajes de chat entrantes como Heads-up con sonido.
 * - Atiende PING_1S capturando una lectura GPS única y apagando el receptor de inmediato.
 */
class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.crearTodosLosCanales(this)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Token renovado por Firebase Messaging para notificaciones push dirigidas.
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        NotificationHelper.crearTodosLosCanales(this)

        val tipo = message.data["tipo"]
        val viajeId = message.data["viajeId"]

        when (tipo) {
            "PING_1S" -> ejecutarPingGpsDeUnSegundo()

            "OFERTA_15S", "NUEVO_VIAJE", "OFERTA_VIAJE" -> {
                val titulo = message.notification?.title
                    ?: message.data["titulo"]
                    ?: "Nueva oferta de viaje"
                val cuerpo = message.notification?.body
                    ?: message.data["resumen"]
                    ?: "Tienes 15 segundos para aceptar la solicitud."
                val turnoIdx = message.data["ofertaActualIndex"] ?: "0"
                NotificationHelper.mostrarOfertaViajeHeadsUp(
                    context = this,
                    titulo = titulo,
                    cuerpo = cuerpo,
                    viajeId = viajeId,
                    claveDeduplicacion = viajeId?.let { "oferta_${it}_$turnoIdx" }
                )
            }

            "CHAT_MENSAJE" -> {
                val autorNombre = message.data["autorNombre"]
                    ?: message.notification?.title
                    ?: "Viaje Rural"
                val texto = message.data["texto"]
                    ?: message.notification?.body
                    ?: "Tienes un nuevo mensaje en tu viaje."
                val mensajeId = message.data["mensajeId"] ?: message.messageId
                NotificationHelper.mostrarChatHeadsUp(
                    context = this,
                    viajeId = viajeId,
                    mensajeId = mensajeId,
                    autorNombre = autorNombre,
                    texto = texto
                )
            }

            "ACEPTADO" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = "¡Conductor asignado!",
                cuerpo = message.notification?.body ?: "Tu conductor va en camino. Revisa tu PIN de 3 dígitos.",
                viajeId = viajeId
            )

            "PROXIMIDAD" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = "Conductor cerca de tu ubicación",
                cuerpo = message.notification?.body ?: "Ten a mano tu PIN de 3 dígitos para abordar.",
                viajeId = viajeId
            )

            "MENSUALIDAD_7000" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = "Recordatorio mensual — Viaje Rural",
                cuerpo = "Renueva tu licencia mensual (₡7,000 colones) para seguir recibiendo viajes.",
                viajeId = viajeId
            )

            "VIAJE_CANCELADO" -> NotificationHelper.mostrarAlertaGeneralHeadsUp(
                context = this,
                titulo = "Viaje cancelado por ${message.data["pasajeroNombre"] ?: "el pasajero"}",
                cuerpo = message.data["motivoCancelacion"] ?: "El pasajero canceló el viaje.",
                viajeId = viajeId
            )

            else -> {
                val notifTitle = message.notification?.title ?: message.data["titulo"]
                val notifBody = message.notification?.body ?: message.data["cuerpo"]
                if (!notifTitle.isNullOrBlank() || !notifBody.isNullOrBlank()) {
                    NotificationHelper.mostrarOfertaViajeHeadsUp(
                        context = this,
                        titulo = notifTitle ?: "Viaje Rural",
                        cuerpo = notifBody ?: "Toca para abrir la aplicación.",
                        viajeId = viajeId
                    )
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun ejecutarPingGpsDeUnSegundo() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val fused = LocationServices.getFusedLocationProviderClient(this)
        val cts = CancellationTokenSource()

        val db = try {
            FirebaseFirestore.getInstance(ViajeRepository.FIRESTORE_DATABASE_ID)
        } catch (_: Throwable) {
            FirebaseFirestore.getInstance()
        }

        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    db.collection("conductores")
                        .document(uid)
                        .update(
                            mapOf(
                                "lat" to location.latitude,
                                "lng" to location.longitude,
                                "ultimoPingAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                }
                cts.cancel()
            }
            .addOnFailureListener { cts.cancel() }
    }
}
