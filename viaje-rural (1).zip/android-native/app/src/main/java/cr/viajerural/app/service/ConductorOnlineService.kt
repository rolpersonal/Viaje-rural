package cr.viajerural.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import cr.viajerural.app.MainActivity
import cr.viajerural.app.R
import cr.viajerural.app.ViajeRuralApp
import cr.viajerural.app.data.ViajeRepository

/**
 * Servicio persistente de presencia para el Conductor Activo:
 * - Mantiene vivo el proceso y los listeners de Firestore en segundo plano cuando el conductor
 *   minimiza la aplicación o cambia a otra app (ej. Waze, WhatsApp) o apaga la pantalla.
 * - NO desconecta al conductor en onStop()/onPause().
 * - ÚNICAMENTE desconecta al conductor (disponible = false, estadoOperativo = "inactivo")
 *   cuando el usuario cierra por completo la aplicación (onTaskRemoved al deslizar de Recientes).
 */
class ConductorOnlineService : Service() {

    private var conductorId: String? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            conductorId = null
            conductorActivoId = null
            detenerEnPrimerPlano()
            stopSelf()
            return START_NOT_STICKY
        }

        val uid = intent?.getStringExtra(EXTRA_CONDUCTOR_ID) ?: conductorActivoId
        if (uid.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        conductorId = uid
        conductorActivoId = uid
        ViajeRuralApp.conductorActivoEnProcesoUid = uid

        val tieneUbicacion = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

        if (tieneUbicacion) {
            try {
                val notification = buildNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } catch (_: Throwable) {
                // Continuar como servicio normal para conservar onTaskRemoved() si el sistema restringe FGS.
            }
        }

        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val uidCerrar = conductorId ?: conductorActivoId ?: ViajeRuralApp.conductorActivoEnProcesoUid
        ViajeRuralApp.conductorActivoEnProcesoUid = null
        conductorActivoId = null
        conductorId = null
        MainActivity.conductorActivoUidParaCierre = null
        MainActivity.onLimpiarCicloGpsConductor?.invoke()
        detenerEnPrimerPlano()

        if (!uidCerrar.isNullOrBlank()) {
            var terminado = false
            val mainHandler = Handler(Looper.getMainLooper())
            mainHandler.postDelayed({
                if (!terminado) {
                    terminado = true
                    stopSelf()
                }
            }, 2200L)

            ViajeRepository().desactivarConductorPorCierreSinBloquear(uidCerrar) {
                if (!terminado) {
                    terminado = true
                    stopSelf()
                }
            }
        } else {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        detenerEnPrimerPlano()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun detenerEnPrimerPlano() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (_: Throwable) {
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Conductor Activo (Segundo Plano)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mantiene tu estado activo y recepción de ofertas mientras usas otras apps como Waze."
                setSound(null, null)
                enableVibration(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            NOTIFICATION_ID,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Viaje Rural · Estás Activo")
            .setContentText("Disponible en segundo plano para recibir ofertas de viaje.")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "viaje_rural_conductor_online"
        const val NOTIFICATION_ID = 9003
        const val EXTRA_CONDUCTOR_ID = "extra_conductor_id"
        const val ACTION_STOP = "cr.viajerural.app.ACTION_STOP_CONDUCTOR_ONLINE"

        @Volatile
        var conductorActivoId: String? = null

        fun start(context: Context, conductorId: String) {
            if (conductorId.isBlank()) return
            conductorActivoId = conductorId
            ViajeRuralApp.conductorActivoEnProcesoUid = conductorId
            val appCtx = context.applicationContext
            val intent = Intent(appCtx, ConductorOnlineService::class.java).apply {
                putExtra(EXTRA_CONDUCTOR_ID, conductorId)
            }
            val tieneUbicacion = ContextCompat.checkSelfPermission(
                appCtx,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    appCtx,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && tieneUbicacion) {
                    appCtx.startForegroundService(intent)
                } else {
                    appCtx.startService(intent)
                }
            } catch (_: Throwable) {
                try {
                    appCtx.startService(intent)
                } catch (_: Throwable) {
                }
            }
        }

        fun stop(context: Context) {
            conductorActivoId = null
            ViajeRuralApp.conductorActivoEnProcesoUid = null
            val appCtx = context.applicationContext
            val intent = Intent(appCtx, ConductorOnlineService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                appCtx.stopService(intent)
            } catch (_: Throwable) {
            }
        }
    }
}
