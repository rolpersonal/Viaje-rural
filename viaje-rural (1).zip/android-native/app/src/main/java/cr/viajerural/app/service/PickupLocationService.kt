package cr.viajerural.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import cr.viajerural.app.MainActivity
import cr.viajerural.app.R
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.messaging.ViajeRuralMessagingService

/**
 * Servicio en primer plano (foregroundServiceType="location") optimizado para ahorro de batería y datos:
 * 1. Modo Activo (Esperando ofertas): Se inicia cuando el conductor activa el interruptor "Activo"
 *    para mantener vivo el servicio de ubicación y actualizar lat/lng cada 90s mientras espera ofertas.
 * 2. Modo Recogida (viajeId != null): Se inicia cuando el conductor acepta un viaje y envía su
 *    posición cada 90s hasta verificar el PIN de 3 dígitos del pasajero.
 */
class PickupLocationService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var locationCallback: LocationCallback? = null
    private var tripListener: ListenerRegistration? = null

    private val db: FirebaseFirestore by lazy {
        try {
            FirebaseFirestore.getInstance(ViajeRepository.FIRESTORE_DATABASE_ID)
        } catch (_: Throwable) {
            FirebaseFirestore.getInstance()
        }
    }

    private var activeViajeId: String? = null
    private var activeConductorId: String? = null

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_GPS) {
            stopTrackingAndSelf()
            return START_NOT_STICKY
        }

        val conductorId = intent?.getStringExtra(EXTRA_CONDUCTOR_ID)
        val viajeId = intent?.getStringExtra(EXTRA_VIAJE_ID)
        val esModoActivo = intent?.action == ACTION_START_ACTIVO || viajeId.isNullOrBlank()

        if (conductorId.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        val tieneUbicacion = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

        if (!tieneUbicacion) {
            stopSelf()
            return START_NOT_STICKY
        }

        activeConductorId = conductorId
        activeViajeId = if (esModoActivo) null else viajeId

        try {
            val notification = buildNotification(enRecogida = !esModoActivo)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: SecurityException) {
            stopSelf()
            return START_NOT_STICKY
        } catch (_: Throwable) {
            stopSelf()
            return START_NOT_STICKY
        }

        start90sLocationUpdates(viajeId = activeViajeId, conductorId = conductorId)
        if (!esModoActivo && !viajeId.isNullOrBlank()) {
            observePinVerificationToAutoStop(viajeId)
        } else {
            tripListener?.remove()
            tripListener = null
        }

        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun start90sLocationUpdates(viajeId: String?, conductorId: String) {
        locationCallback?.let { prev ->
            try {
                fusedLocationClient.removeLocationUpdates(prev)
            } catch (_: Throwable) {
            }
        }

        val request = LocationRequest.Builder(
            Priority.PRIORITY_BALANCED_POWER_ACCURACY,
            INTERVAL_90_SECONDS_MS
        )
            .setMinUpdateIntervalMillis(INTERVAL_90_SECONDS_MS)
            .setWaitForAccurateLocation(false)
            .build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                try {
                    if (!viajeId.isNullOrBlank()) {
                        val updates = hashMapOf<String, Any>(
                            "conductorLat" to loc.latitude,
                            "conductorLng" to loc.longitude,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                        db.collection("viajes").document(viajeId).update(updates)
                    }
                    db.collection("conductores").document(conductorId).update(
                        mapOf(
                            "lat" to loc.latitude,
                            "lng" to loc.longitude,
                            "ultimoPingAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } catch (_: Throwable) {
                }
            }
        }
        locationCallback = callback

        try {
            fusedLocationClient.requestLocationUpdates(
                request,
                callback,
                Looper.getMainLooper()
            )
        } catch (_: Throwable) {
        }
    }

    private fun observePinVerificationToAutoStop(viajeId: String) {
        tripListener?.remove()
        tripListener = db.collection("viajes").document(viajeId)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snapshot, _ ->
                if (snapshot == null || !snapshot.exists()) {
                    stopTrackingAndSelf()
                    return@addSnapshotListener
                }
                val estado = snapshot.getString("estado")
                val pinVerificado = snapshot.getBoolean("pinVerificado") ?: false
                if (pinVerificado || estado != "aceptado") {
                    // Al confirmar el PIN, el modo recogida se detiene
                    stopTrackingAndSelf()
                }
            }
    }

    private fun stopTrackingAndSelf() {
        locationCallback?.let { cb ->
            try {
                fusedLocationClient.removeLocationUpdates(cb)
            } catch (_: Throwable) {
            }
        }
        locationCallback = null
        tripListener?.remove()
        tripListener = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        locationCallback?.let { cb ->
            try {
                fusedLocationClient.removeLocationUpdates(cb)
            } catch (_: Throwable) {
            }
        }
        locationCallback = null
        tripListener?.remove()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ubicación del Conductor (Viaje Rural)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mantiene disponible tu ubicación para recibir ofertas y coordinar recogidas."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
        // Garantizar que los canales emergentes de ofertas y chat existan mientras el conductor esté Activo
        cr.viajerural.app.messaging.NotificationHelper.crearTodosLosCanales(this)
    }

    private fun buildNotification(enRecogida: Boolean): Notification {
        val titulo = if (enRecogida) {
            "Viaje Rural — En camino al pasajero"
        } else {
            "Viaje Rural — Conductor Activo"
        }
        val texto = if (enRecogida) {
            "Compartiendo posición cada 90s. Se apaga al confirmar PIN."
        } else {
            "Disponible esperando ofertas de viaje en segundo plano."
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            9001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "viaje_rural_pickup_90s"
        const val NOTIFICATION_ID = 9001
        const val INTERVAL_90_SECONDS_MS = 90_000L
        const val EXTRA_VIAJE_ID = "extra_viaje_id"
        const val EXTRA_CONDUCTOR_ID = "extra_conductor_id"
        const val ACTION_START_ACTIVO = "cr.viajerural.app.ACTION_START_ACTIVO"
        const val ACTION_STOP_GPS = "cr.viajerural.app.ACTION_STOP_GPS"

        fun startActivo(context: Context, conductorId: String) {
            val intent = Intent(context, PickupLocationService::class.java).apply {
                action = ACTION_START_ACTIVO
                putExtra(EXTRA_CONDUCTOR_ID, conductorId)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Throwable) {
            }
        }

        fun start(context: Context, viajeId: String, conductorId: String) {
            val intent = Intent(context, PickupLocationService::class.java).apply {
                putExtra(EXTRA_VIAJE_ID, viajeId)
                putExtra(EXTRA_CONDUCTOR_ID, conductorId)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Throwable) {
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, PickupLocationService::class.java).apply {
                action = ACTION_STOP_GPS
            }
            try {
                context.startService(intent)
            } catch (_: Throwable) {
            }
        }
    }
}
