package cr.viajerural.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import cr.viajerural.app.R

/**
 * Servicio en primer plano optimizado para ahorro máximo de batería y datos.
 * - Solo se inicia cuando el conductor ACEPTA un viaje (estado == "aceptado").
 * - Envía coordenadas a Firestore cada 90,000 ms (90 segundos).
 * - Se detiene y libera el GPS inmediatamente al verificar el PIN de 3 dígitos (estado == "en_curso").
 */
class PickupLocationService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var tripListener: ListenerRegistration? = null
    private val db = FirebaseFirestore.getInstance()

    private var activeViajeId: String? = null
    private var activeConductorId: String? = null

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_GPS) {
            stopTrackingAndSelf()
            return START_NOT_STICKY
        }

        val viajeId = intent?.getStringExtra(EXTRA_VIAJE_ID)
        val conductorId = intent?.getStringExtra(EXTRA_CONDUCTOR_ID)
        if (viajeId.isNullOrBlank() || conductorId.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        activeViajeId = viajeId
        activeConductorId = conductorId

        val tieneUbicacion = androidx.core.content.ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
            androidx.core.content.ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (!tieneUbicacion) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startForeground(NOTIFICATION_ID, buildNotification())
        } catch (_: SecurityException) {
            stopSelf()
            return START_NOT_STICKY
        }

        start90sLocationUpdates(viajeId, conductorId)
        observePinVerificationToAutoStop(viajeId)

        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun start90sLocationUpdates(viajeId: String, conductorId: String) {
        val request = LocationRequest.Builder(
            Priority.PRIORITY_BALANCED_POWER_ACCURACY,
            INTERVAL_90_SECONDS_MS
        )
            .setMinUpdateIntervalMillis(INTERVAL_90_SECONDS_MS)
            .setWaitForAccurateLocation(false)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val updates = hashMapOf<String, Any>(
                    "conductorLat" to loc.latitude,
                    "conductorLng" to loc.longitude,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("viajes").document(viajeId).update(updates)
                db.collection("conductores").document(conductorId).update(
                    mapOf(
                        "lat" to loc.latitude,
                        "lng" to loc.longitude,
                        "ultimoPingAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }

        fusedLocationClient.requestLocationUpdates(
            request,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    private fun observePinVerificationToAutoStop(viajeId: String) {
        tripListener?.remove()
        tripListener = db.collection("viajes").document(viajeId)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snapshot, _ ->
                if (snapshot == null || !snapshot.exists()) {
                    stopTrackingAndSelf()
                    return@addSnapshotListener
                }
                val estado = snapshot.getString("estado")
                val pinVerificado = snapshot.getBoolean("pinVerificado") ?: false
                if (pinVerificado || estado != "aceptado") {
                    // Al confirmar el PIN, el envío de GPS se detiene por completo
                    stopTrackingAndSelf()
                }
            }
    }

    private fun stopTrackingAndSelf() {
        if (::locationCallback.isInitialized) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
        tripListener?.remove()
        tripListener = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (::locationCallback.isInitialized) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
        tripListener?.remove()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Recogida en curso (Ahorro 90s)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Envía ubicación cada 90 segundos hasta ingresar el PIN del pasajero."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Viaje Rural — En camino al pasajero")
            .setContentText("Compartiendo posición cada 90s. Se apaga al confirmar PIN.")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "viaje_rural_pickup_90s"
        const val NOTIFICATION_ID = 9001
        const val INTERVAL_90_SECONDS_MS = 90_000L
        const val EXTRA_VIAJE_ID = "extra_viaje_id"
        const val EXTRA_CONDUCTOR_ID = "extra_conductor_id"
        const val ACTION_STOP_GPS = "cr.viajerural.app.ACTION_STOP_GPS"

        fun start(context: Context, viajeId: String, conductorId: String) {
            val intent = Intent(context, PickupLocationService::class.java).apply {
                putExtra(EXTRA_VIAJE_ID, viajeId)
                putExtra(EXTRA_CONDUCTOR_ID, conductorId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, PickupLocationService::class.java).apply {
                action = ACTION_STOP_GPS
            }
            context.startService(intent)
        }
    }
}
