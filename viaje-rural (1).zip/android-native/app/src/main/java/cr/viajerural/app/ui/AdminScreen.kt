package cr.viajerural.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import cr.viajerural.app.viewmodel.AdminSeccion
import cr.viajerural.app.viewmodel.AdminViewModel
import cr.viajerural.app.viewmodel.ConductorAdminItem
import cr.viajerural.app.viewmodel.ConfiguracionGeneralUi
import cr.viajerural.app.viewmodel.PasajeroAdminItem
import cr.viajerural.app.viewmodel.VehiculoTipoUi

/**
 * Panel de Administrador Modular (Jetpack Compose):
 * - Pestañas: Resumen, Conductores, Pasajeros, Alertas, Duplicados y Configuración.
 * - Resumen usa conteos en servidor; las listas usan limit(20) solo al tocar esa pestaña.
 * - Al tocar un conductor o pasajero abre su ficha en ventana modal (Dialog).
 */
@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onSalirAdmin: (() -> Unit)? = null
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.cargarResumenInicial()
    }

    val secciones = listOf(
        AdminSeccion.RESUMEN to "Resumen",
        AdminSeccion.CONDUCTORES to "Conductores",
        AdminSeccion.PASAJEROS to "Pasajeros",
        AdminSeccion.SOLICITUDES to "Peticiones",
        AdminSeccion.ALERTAS to "Alertas",
        AdminSeccion.DUPLICADOS to "Duplicados",
        AdminSeccion.CONFIGURACION to "Config."
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(
                text = "Panel Administrador",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            onSalirAdmin?.let { salir ->
                TextButton(onClick = salir) {
                    Text("Salir")
                }
            }
        }

        ScrollableTabRow(
            selectedTabIndex = secciones.indexOfFirst { it.first == state.seccionActual }.coerceAtLeast(0),
            edgePadding = 12.dp
        ) {
            secciones.forEach { (seccion, titulo) ->
                Tab(
                    selected = state.seccionActual == seccion,
                    onClick = { viewModel.seleccionarSeccion(seccion) },
                    text = { Text(titulo) }
                )
            }
        }

        if (state.cargando) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        state.errorMensaje?.let { err ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (state.seccionActual) {
                AdminSeccion.RESUMEN -> {
                    item {
                        Text(
                            text = "Resumen del Sistema (Conteo Ligero)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        ResumenCard("Total Conductores", state.resumen.totalConductores.toString())
                        Spacer(modifier = Modifier.height(8.dp))
                        ResumenCard("Conductores Activos", state.resumen.conductoresActivos.toString())
                        Spacer(modifier = Modifier.height(8.dp))
                        ResumenCard("Pendientes de Verificación", state.resumen.conductoresPendientes.toString())
                        Spacer(modifier = Modifier.height(8.dp))
                        ResumenCard("Pasajeros Registrados", state.resumen.totalPasajeros.toString())
                        Spacer(modifier = Modifier.height(8.dp))
                        ResumenCard("Peticiones de Cambio", state.resumen.solicitudesPendientes.toString())
                    }
                }

                AdminSeccion.CONDUCTORES -> {
                    item {
                        Text(
                            text = "Conductores (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.conductores) { cond ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Cobrado este mes: ₡${cond.gananciasMes.toInt()}",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Tarifa base: ₡${cond.tarifaBase.toInt()} · Adicional/km: ₡${cond.tarifaPorKm.toInt()} · ${cond.estadoCuenta}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (cond.esTarifaAbusiva) {
                                    Text(
                                        text = "ALERTA: Tarifa supera >30% el promedio.",
                                        color = MaterialTheme.colorScheme.error,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.PASAJEROS -> {
                    item {
                        Text(
                            text = "Pasajeros (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.pasajeros) { pasajero ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarPasajero(pasajero) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(pasajero.nombre, fontWeight = FontWeight.Bold)
                                    Text("★ ${pasajero.promedioCalificacion}", style = MaterialTheme.typography.bodySmall)
                                }
                                Text("Abrir Ficha", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }

                AdminSeccion.SOLICITUDES -> {
                    item {
                        Text(
                            text = "Peticiones de Cambio de Datos (limit(20))",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.solicitudesCambio) { sol ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("${sol.nombreActual} (${sol.rol.uppercase()}) · ${sol.estado.uppercase()}", fontWeight = FontWeight.Bold)
                                Text("Motivo: ${sol.motivo}", style = MaterialTheme.typography.bodySmall)
                                Text("Cambios: ${sol.cambios.entries.joinToString { "${it.key}=${it.value}" }}", style = MaterialTheme.typography.bodySmall)
                                if (sol.estado == "pendiente") {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { viewModel.resolverSolicitudCambio(sol, true, "Aprobado por Administrador") },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Aprobar y aplicar") }
                                        OutlinedButton(
                                            onClick = { viewModel.resolverSolicitudCambio(sol, false, "Rechazado por Administrador") },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Rechazar") }
                                    }
                                }
                            }
                        }
                    }
                }

                AdminSeccion.ALERTAS -> {
                    val abusivos = state.conductores.filter { it.esTarifaAbusiva }
                    val licenciasCriticas = state.conductores.filter { it.diasLicenciaRestantes <= 7 }
                    item {
                        Text(
                            text = "Alertas de Tarifas (>30%) y Licencias por Vencer",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Promedio: Tarifa base ₡${state.promedioBaseFlota.toInt()} · Adicional/km ₡${state.promedioKmFlota.toInt()}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    items(licenciasCriticas) { cond ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    items(abusivos) { cond ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Tarifa base ₡${cond.tarifaBase.toInt()} + Adicional/km ₡${cond.tarifaPorKm.toInt()}",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                AdminSeccion.DUPLICADOS -> {
                    val placasConteo = state.conductores.groupingBy { it.placa.uppercase() }.eachCount()
                    val duplicados = state.conductores.filter { (placasConteo[it.placa.uppercase()] ?: 0) > 1 }
                    item {
                        Text(
                            text = "Detector de Placas y Cédulas Duplicadas",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(duplicados) { cond ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Placa repetida: ${cond.placa}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                Text("${cond.nombre} · Cédula: ${cond.cedulaHash}")
                            }
                        }
                    }
                }

                AdminSeccion.CONFIGURACION -> {
                    item {
                        ConfiguracionAdminCard(
                            config = state.configuracion,
                            onSave = { viewModel.guardarConfiguracion(it) }
                        )
                    }
                }
            }
        }
    }

    state.conductorSeleccionado?.let { cond ->
        FichaConductorDialog(
            conductor = cond,
            onDismiss = { viewModel.cerrarFichaConductor() }
        )
    }

    state.pasajeroSeleccionado?.let { pasajero ->
        EditarPasajeroDialog(
            pasajero = pasajero,
            onDismiss = { viewModel.cerrarFichaPasajero() },
            onSave = { nombre, tel, email, cedula ->
                viewModel.guardarFichaPasajero(pasajero.uid, nombre, tel, email, cedula)
            }
        )
    }
}

@Composable
private fun ResumenCard(titulo: String, valor: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(titulo, fontWeight = FontWeight.Medium)
            Text(valor, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FichaConductorDialog(
    conductor: ConductorAdminItem,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ficha del Conductor") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(conductor.nombre, fontWeight = FontWeight.Bold)
                Text("Vehículo: ${conductor.vehiculoTipo} · Placa: ${conductor.placa}")
                Text("Estado: ${conductor.estadoCuenta}")
                Text("Licencia: ${conductor.etiquetaLicencia} (vence ${conductor.fechaLicenciaTexto})", fontFamily = FontFamily.Monospace)
                Text("Tarifa base: ₡${conductor.tarifaBase.toInt()} · Precio por km adicional: ₡${conductor.tarifaPorKm.toInt()}")
                Text("Generado en el mes: ₡${conductor.gananciasMes.toInt()}", fontFamily = FontFamily.Monospace)
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Cerrar") }
        }
    )
}

@Composable
private fun ConfiguracionAdminCard(
    config: ConfiguracionGeneralUi,
    onSave: (ConfiguracionGeneralUi) -> Unit
) {
    var whatsapp by remember(config.whatsappSoporte) { mutableStateOf(config.whatsappSoporte) }
    var sinpe by remember(config.sinpeNumero) { mutableStateOf(config.sinpeNumero) }
    var sinpeTitular by remember(config.sinpeTitular) { mutableStateOf(config.sinpeTitular) }
    var adminNombre by remember(config.adminNombre) { mutableStateOf(config.adminNombre) }
    var adminEmail by remember(config.adminEmail) { mutableStateOf(config.adminEmail) }
    var terminos by remember(config.terminosCondiciones) { mutableStateOf(config.terminosCondiciones) }
    var tipos by remember(config.tiposVehiculo) { mutableStateOf(config.tiposVehiculo) }
    var nuevoTipoNombre by remember { mutableStateOf("") }
    var nuevoTipoCap by remember { mutableStateOf("2") }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Soporte WhatsApp, SINPE, Términos y Vehículos", fontWeight = FontWeight.Bold)
            OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("WhatsApp Soporte (62546546)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpe, onValueChange = { sinpe = it }, label = { Text("Número SINPE Móvil") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpeTitular, onValueChange = { sinpeTitular = it }, label = { Text("Titular SINPE") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminNombre, onValueChange = { adminNombre = it }, label = { Text("Nombre Administrador") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminEmail, onValueChange = { adminEmail = it }, label = { Text("Correo Administrador") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = terminos, onValueChange = { terminos = it }, label = { Text("Términos y Condiciones") }, minLines = 3, modifier = Modifier.fillMaxWidth())

            Text("Tipos de Vehículo (Motos, 4x4, etc.)", fontWeight = FontWeight.SemiBold)
            tipos.forEach { t ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${t.nombre} (máx. ${t.maxPasajeros} pax)")
                    TextButton(onClick = { tipos = tipos.filterNot { it.nombre == t.nombre } }) { Text("Quitar") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nuevoTipoNombre, onValueChange = { nuevoTipoNombre = it }, label = { Text("Ej: Moto") }, modifier = Modifier.weight(2f))
                OutlinedTextField(value = nuevoTipoCap, onValueChange = { nuevoTipoCap = it.filter(Char::isDigit) }, label = { Text("Max") }, modifier = Modifier.weight(1f))
            }
            OutlinedButton(onClick = {
                if (nuevoTipoNombre.isNotBlank()) {
                    tipos = tipos + VehiculoTipoUi(nuevoTipoNombre.trim(), nuevoTipoCap.toIntOrNull() ?: 2)
                    nuevoTipoNombre = ""
                }
            }) { Text("Agregar tipo de vehículo") }

            Button(
                onClick = {
                    onSave(
                        config.copy(
                            whatsappSoporte = whatsapp,
                            sinpeNumero = sinpe,
                            sinpeTitular = sinpeTitular,
                            adminNombre = adminNombre,
                            adminEmail = adminEmail,
                            terminosCondiciones = terminos,
                            tiposVehiculo = tipos
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Guardar Configuración Global") }
        }
    }
}

@Composable
private fun EditarPasajeroDialog(
    pasajero: PasajeroAdminItem,
    onDismiss: () -> Unit,
    onSave: (nombre: String, telefono: String, email: String, cedula: String) -> Unit
) {
    var nombre by remember { mutableStateOf(pasajero.nombre) }
    var telefono by remember { mutableStateOf(pasajero.telefono) }
    var email by remember { mutableStateOf(pasajero.email) }
    var cedula by remember { mutableStateOf(pasajero.cedula) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ficha de Pasajero") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") })
                OutlinedTextField(value = telefono, onValueChange = { telefono = it }, label = { Text("Teléfono") })
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo") })
                OutlinedTextField(value = cedula, onValueChange = { cedula = it }, label = { Text("Cédula") })
            }
        },
        confirmButton = {
            Button(onClick = { onSave(nombre, telefono, email, cedula) }) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
