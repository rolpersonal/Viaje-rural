package cr.viajerural.app.ui

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import cr.viajerural.app.viewmodel.AdminSeccion
import cr.viajerural.app.viewmodel.AdminViewModel
import cr.viajerural.app.viewmodel.ConductorAdminItem
import cr.viajerural.app.viewmodel.ConductorDocumentosUi
import cr.viajerural.app.viewmodel.ConfiguracionGeneralUi
import cr.viajerural.app.viewmodel.PasajeroAdminItem
import cr.viajerural.app.viewmodel.VehiculoTipoUi

/**
 * Panel de Administrador Modular (Jetpack Compose) con diseño limpio alineado a la vista Web:
 * - Pestañas: Resumen, Pendientes, Conductores, Pasajeros, Peticiones, Alertas, Duplicados y Config.
 * - Resumen usa conteos en servidor + tarjeta con Enlace de Descarga de la App para copiar.
 * - Pendientes abre una ficha detallada con las 4 fotos de documentos y botón "Aprobar y Activar Conductor" (+1 mes licencia).
 */
@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onSalirAdmin: (() -> Unit)? = null
) {
    val state by viewModel.uiState.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    var enlaceCopiado by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.cargarResumenInicial()
    }

    val secciones = listOf(
        AdminSeccion.RESUMEN to "Resumen",
        AdminSeccion.PENDIENTES to "Pendientes",
        AdminSeccion.CONDUCTORES to "Conductores",
        AdminSeccion.PASAJEROS to "Pasajeros",
        AdminSeccion.SOLICITUDES to "Peticiones",
        AdminSeccion.ALERTAS to "Alertas",
        AdminSeccion.DUPLICADOS to "Duplicados",
        AdminSeccion.CONFIGURACION to "Config."
    )

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F8F6))
    ) {
        Surface(color = Color.White, shadowElevation = 1.dp) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Panel Administrador",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14231A)
                        )
                        Text(
                            text = "Control y verificación Viaje Rural",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                    onSalirAdmin?.let { salir ->
                        OutlinedButton(
                            onClick = salir,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Text("Cerrar Sesión", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                ScrollableTabRow(
                    selectedTabIndex = secciones.indexOfFirst { it.first == state.seccionActual }.coerceAtLeast(0),
                    containerColor = Color.White,
                    edgePadding = 14.dp
                ) {
                    secciones.forEach { (seccion, titulo) ->
                        Tab(
                            selected = state.seccionActual == seccion,
                            onClick = { viewModel.seleccionarSeccion(seccion) },
                            text = {
                                if (seccion == AdminSeccion.PENDIENTES && state.resumen.conductoresPendientes > 0) {
                                    Text("$titulo (${state.resumen.conductoresPendientes})", fontWeight = FontWeight.SemiBold)
                                } else {
                                    Text(titulo)
                                }
                            }
                        )
                    }
                }
            }
        }

        if (state.cargando) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        state.accionMensaje?.let { msg ->
            OutlinedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                shape = cardShape,
                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF14532D),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { viewModel.limpiarAccionMensaje() }) {
                        Text("OK")
                    }
                }
            }
        }

        state.errorMensaje?.let { err ->
            OutlinedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                shape = cardShape,
                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
            ) {
                Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF991B1B),
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (state.seccionActual) {
                AdminSeccion.RESUMEN -> {
                    item {
                        Text(
                            text = "Resumen del Sistema (Conteo Ligero)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ResumenCard("Total Conductores", state.resumen.totalConductores.toString(), Modifier.weight(1f))
                            ResumenCard("Activos", state.resumen.conductoresActivos.toString(), Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ResumenCard("Pendientes", state.resumen.conductoresPendientes.toString(), Modifier.weight(1f))
                            ResumenCard("Pasajeros", state.resumen.totalPasajeros.toString(), Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        ResumenCard("Peticiones de Cambio Pendientes", state.resumen.solicitudesPendientes.toString(), Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Enlace de Descarga de la App",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = "Este mismo enlace se usa en el botón Compartir App de Pasajeros y Conductores. Puedes editarlo en Config.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF3F5243)
                                )
                                Surface(
                                    color = Color.White,
                                    shape = RoundedCornerShape(10.dp),
                                    border = cardBorder,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = state.configuracion.linkDescarga,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                                Button(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(state.configuracion.linkDescarga))
                                        enlaceCopiado = true
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(if (enlaceCopiado) "Enlace copiado al portapapeles" else "Copiar enlace de descarga")
                                }
                            }
                        }
                    }
                }

                AdminSeccion.PENDIENTES -> {
                    item {
                        Text(
                            text = "Conductores Pendientes de Verificación",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Toca una ficha para revisar sus documentos (Vehículo, Cédula, Licencia y RTV) y aprobar al conductor.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                    if (state.pendientes.isEmpty() && !state.cargando) {
                        item {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "No hay conductores pendientes por verificar.",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        }
                    } else {
                        items(state.pendientes) { cond ->
                            OutlinedCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.seleccionarConductor(cond) },
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFFFBEB))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${cond.vehiculoTipo} · Tarifa base: ₡${cond.tarifaBase.toInt()} · Adicional/km: ₡${cond.tarifaPorKm.toInt()}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Text(
                                        text = "Toca para ver fotos de documentos y aprobar",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.CONDUCTORES -> {
                    item {
                        Text(
                            text = "Conductores (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.conductores) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Cobrado este mes: ₡${cond.gananciasMes.toInt()}",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Tarifa base: ₡${cond.tarifaBase.toInt()} · Adicional/km: ₡${cond.tarifaPorKm.toInt()} · ${cond.estadoCuenta}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (cond.esTarifaAbusiva) {
                                    Text(
                                        text = "ALERTA: Tarifa supera >30% el promedio.",
                                        color = MaterialTheme.colorScheme.error,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.PASAJEROS -> {
                    item {
                        Text(
                            text = "Pasajeros (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.pasajeros) { pasajero ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarPasajero(pasajero) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(pasajero.nombre, fontWeight = FontWeight.Bold)
                                    Text("★ ${pasajero.promedioCalificacion}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                }
                                Text("Abrir Ficha", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                AdminSeccion.SOLICITUDES -> {
                    item {
                        Text(
                            text = "Peticiones de Cambio de Datos (limit(20))",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.solicitudesCambio) { sol ->
                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("${sol.nombreActual} (${sol.rol.uppercase()}) · ${sol.estado.uppercase()}", fontWeight = FontWeight.Bold)
                                Text("Motivo: ${sol.motivo}", style = MaterialTheme.typography.bodySmall)
                                Text("Cambios: ${sol.cambios.entries.joinToString { "${it.key}=${it.value}" }}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                if (sol.estado == "pendiente") {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { viewModel.resolverSolicitudCambio(sol, true, "Aprobado por Administrador") },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Aprobar y aplicar") }
                                        OutlinedButton(
                                            onClick = { viewModel.resolverSolicitudCambio(sol, false, "Rechazado por Administrador") },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Rechazar") }
                                    }
                                }
                            }
                        }
                    }
                }

                AdminSeccion.ALERTAS -> {
                    val abusivos = state.conductores.filter { it.esTarifaAbusiva }
                    val licenciasCriticas = state.conductores.filter { it.diasLicenciaRestantes <= 7 }
                    item {
                        Text(
                            text = "Alertas de Tarifas (>30%) y Licencias por Vencer",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Promedio: Tarifa base ₡${state.promedioBaseFlota.toInt()} · Adicional/km ₡${state.promedioKmFlota.toInt()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                    items(licenciasCriticas) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    items(abusivos) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Tarifa base ₡${cond.tarifaBase.toInt()} + Adicional/km ₡${cond.tarifaPorKm.toInt()}",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                AdminSeccion.DUPLICADOS -> {
                    val placasConteo = state.conductores.groupingBy { it.placa.uppercase() }.eachCount()
                    val duplicados = state.conductores.filter { (placasConteo[it.placa.uppercase()] ?: 0) > 1 }
                    item {
                        Text(
                            text = "Detector de Placas y Cédulas Duplicadas",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(duplicados) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Placa repetida: ${cond.placa}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                Text("${cond.nombre} · Cédula: ${cond.cedulaHash}")
                            }
                        }
                    }
                }

                AdminSeccion.CONFIGURACION -> {
                    item {
                        ConfiguracionAdminCard(
                            config = state.configuracion,
                            onSave = { viewModel.guardarConfiguracion(it) }
                        )
                    }
                }
            }
        }
    }

    state.conductorSeleccionado?.let { cond ->
        FichaConductorDialog(
            conductor = cond,
            documentos = state.documentosConductorSeleccionado,
            cargandoDocumentos = state.cargandoDocumentos,
            aprobando = state.aprobandoConductor,
            onAprobarYActivar = { viewModel.aprobarYActivarConductor(cond.uid) },
            onDismiss = { viewModel.cerrarFichaConductor() }
        )
    }

    state.pasajeroSeleccionado?.let { pasajero ->
        EditarPasajeroDialog(
            pasajero = pasajero,
            onDismiss = { viewModel.cerrarFichaPasajero() },
            onSave = { nombre, tel, email, cedula ->
                viewModel.guardarFichaPasajero(pasajero.uid, nombre, tel, email, cedula)
            }
        )
    }
}

@Composable
private fun ResumenCard(titulo: String, valor: String, modifier: Modifier = Modifier) {
    OutlinedCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(titulo, style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
            Text(
                text = valor,
                style = MaterialTheme.typography.headlineSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF14231A)
            )
        }
    }
}

@Composable
private fun FichaConductorDialog(
    conductor: ConductorAdminItem,
    documentos: ConductorDocumentosUi?,
    cargandoDocumentos: Boolean,
    aprobando: Boolean,
    onAprobarYActivar: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Verificación y Ficha del Conductor", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(conductor.nombre, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Vehículo: ${conductor.vehiculoTipo} · Placa: ${conductor.placa}")
                Text("Estado de cuenta: ${conductor.estadoCuenta.uppercase()}", fontWeight = FontWeight.SemiBold)
                Text("Cédula: ${conductor.cedulaHash.ifBlank { "No registrada" }}")
                Text("Licencia: ${conductor.etiquetaLicencia} (vence ${conductor.fechaLicenciaTexto})", fontFamily = FontFamily.Monospace)
                Text("Tarifa base: ₡${conductor.tarifaBase.toInt()} · Precio/km: ₡${conductor.tarifaPorKm.toInt()}")
                Text("Generado en el mes: ₡${conductor.gananciasMes.toInt()}", fontFamily = FontFamily.Monospace)

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Text("Documentos Adjuntos", fontWeight = FontWeight.Bold)

                if (cargandoDocumentos) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text("Cargando fotografías...", style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    DocumentoFotoCard("Vehículo", documentos?.fotoVehiculo.orEmpty())
                    DocumentoFotoCard("Cédula", documentos?.fotoCedula.orEmpty())
                    DocumentoFotoCard("Licencia de Conducir", documentos?.fotoLicencia.orEmpty())
                    DocumentoFotoCard("RTV / Circulación / Marchamo", documentos?.fotoCirculacion.orEmpty())
                }

                if (conductor.estadoCuenta == "pendiente") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = onAprobarYActivar,
                        enabled = !aprobando,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF15803D),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text(
                            text = if (aprobando) "Aprobando..." else "Aprobar y Activar Conductor",
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Al aprobar, pasará a estado activo con licencia vigente por 1 mes desde hoy.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    )
}

@Composable
private fun DocumentoFotoCard(titulo: String, dataUrl: String) {
    val bitmap: ImageBitmap? = remember(dataUrl) {
        decodificarDataUrlBitmap(dataUrl)
    }
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF7F8F6))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(titulo, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = titulo,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(10.dp))
                )
            } else {
                Text("Sin documento adjunto", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
            }
        }
    }
}

private fun decodificarDataUrlBitmap(raw: String): ImageBitmap? {
    if (raw.isBlank()) return null
    return try {
        val base64Part = raw.substringAfter("base64,", raw).trim()
        if (base64Part.isBlank()) return null
        val bytes = Base64.decode(base64Part, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

@Composable
private fun ConfiguracionAdminCard(
    config: ConfiguracionGeneralUi,
    onSave: (ConfiguracionGeneralUi) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var linkDescarga by remember(config.linkDescarga) { mutableStateOf(config.linkDescarga) }
    var copiado by remember { mutableStateOf(false) }
    var whatsapp by remember(config.whatsappSoporte) { mutableStateOf(config.whatsappSoporte) }
    var sinpe by remember(config.sinpeNumero) { mutableStateOf(config.sinpeNumero) }
    var sinpeTitular by remember(config.sinpeTitular) { mutableStateOf(config.sinpeTitular) }
    var adminNombre by remember(config.adminNombre) { mutableStateOf(config.adminNombre) }
    var adminEmail by remember(config.adminEmail) { mutableStateOf(config.adminEmail) }
    var terminos by remember(config.terminosCondiciones) { mutableStateOf(config.terminosCondiciones) }
    var tipos by remember(config.tiposVehiculo) { mutableStateOf(config.tiposVehiculo) }
    var nuevoTipoNombre by remember { mutableStateOf("") }
    var nuevoTipoCap by remember { mutableStateOf("2") }

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Enlace de Descarga, Soporte, SINPE, Términos y Vehículos", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = linkDescarga,
                onValueChange = {
                    linkDescarga = it
                    copiado = false
                },
                label = { Text("Enlace de descarga de la App (Compartir)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(
                onClick = {
                    clipboardManager.setText(AnnotatedString(linkDescarga.trim()))
                    copiado = true
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (copiado) "Enlace copiado" else "Copiar enlace de descarga")
            }
            OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("WhatsApp Soporte (62546546)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpe, onValueChange = { sinpe = it }, label = { Text("Número SINPE Móvil") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpeTitular, onValueChange = { sinpeTitular = it }, label = { Text("Titular SINPE") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminNombre, onValueChange = { adminNombre = it }, label = { Text("Nombre Administrador") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminEmail, onValueChange = { adminEmail = it }, label = { Text("Correo Administrador") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = terminos, onValueChange = { terminos = it }, label = { Text("Términos y Condiciones") }, minLines = 3, modifier = Modifier.fillMaxWidth())

            Text("Tipos de Vehículo (Motos, 4x4, etc.)", fontWeight = FontWeight.SemiBold)
            tipos.forEach { t ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${t.nombre} (máx. ${t.maxPasajeros} pax)")
                    TextButton(onClick = { tipos = tipos.filterNot { it.nombre == t.nombre } }) { Text("Quitar") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nuevoTipoNombre, onValueChange = { nuevoTipoNombre = it }, label = { Text("Ej: Moto") }, modifier = Modifier.weight(2f))
                OutlinedTextField(value = nuevoTipoCap, onValueChange = { nuevoTipoCap = it.filter(Char::isDigit) }, label = { Text("Max") }, modifier = Modifier.weight(1f))
            }
            OutlinedButton(
                onClick = {
                    if (nuevoTipoNombre.isNotBlank()) {
                        tipos = tipos + VehiculoTipoUi(nuevoTipoNombre.trim(), nuevoTipoCap.toIntOrNull() ?: 2)
                        nuevoTipoNombre = ""
                    }
                },
                shape = RoundedCornerShape(12.dp)
            ) { Text("Agregar tipo de vehículo") }

            Button(
                onClick = {
                    onSave(
                        config.copy(
                            linkDescarga = linkDescarga.trim(),
                            whatsappSoporte = whatsapp,
                            sinpeNumero = sinpe,
                            sinpeTitular = sinpeTitular,
                            adminNombre = adminNombre,
                            adminEmail = adminEmail,
                            terminosCondiciones = terminos,
                            tiposVehiculo = tipos
                        )
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) { Text("Guardar Configuración Global", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun EditarPasajeroDialog(
    pasajero: PasajeroAdminItem,
    onDismiss: () -> Unit,
    onSave: (nombre: String, telefono: String, email: String, cedula: String) -> Unit
) {
    var nombre by remember { mutableStateOf(pasajero.nombre) }
    var telefono by remember { mutableStateOf(pasajero.telefono) }
    var email by remember { mutableStateOf(pasajero.email) }
    var cedula by remember { mutableStateOf(pasajero.cedula) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ficha de Pasajero") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") })
                OutlinedTextField(value = telefono, onValueChange = { telefono = it }, label = { Text("Teléfono") })
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo") })
                OutlinedTextField(value = cedula, onValueChange = { cedula = it }, label = { Text("Cédula") })
            }
        },
        confirmButton = {
            Button(onClick = { onSave(nombre, telefono, email, cedula) }) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
