package cr.viajerural.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularMensualidadConductorActual
import cr.viajerural.app.data.formatearColonesEntero
import cr.viajerural.app.data.resolverTerminosConductorDinamicos
import cr.viajerural.app.viewmodel.AdminSeccion
import cr.viajerural.app.viewmodel.AdminViewModel
import cr.viajerural.app.viewmodel.ConductorAdminItem
import cr.viajerural.app.viewmodel.ConductorDocumentosUi
import cr.viajerural.app.viewmodel.ConfiguracionGeneralUi
import cr.viajerural.app.viewmodel.PasajeroAdminItem
import cr.viajerural.app.viewmodel.VehiculoTipoUi

/**
 * Panel de Administrador Modular (Jetpack Compose) con diseño limpio alineado a la vista Web:
 * - Pestañas: Resumen, Pendientes, Conductores, Pasajeros, Peticiones, Alertas, Duplicados y Config.
 * - Resumen usa conteos en servidor + tarjeta con Enlace de Descarga de la App para copiar.
 * - Pendientes abre una ficha detallada con las 4 fotos de documentos y botón "Aprobar y Activar Conductor" (+1 mes licencia).
 */
@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onSalirAdmin: (() -> Unit)? = null
) {
    val state by viewModel.uiState.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    var enlaceCopiado by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.cargarResumenInicial()
    }

    val secciones = listOf(
        AdminSeccion.RESUMEN to "Resumen",
        AdminSeccion.PENDIENTES to "Pendientes",
        AdminSeccion.CONDUCTORES to "Conductores",
        AdminSeccion.PASAJEROS to "Pasajeros",
        AdminSeccion.SOLICITUDES to "Peticiones",
        AdminSeccion.ALERTAS to "Alertas",
        AdminSeccion.DUPLICADOS to "Duplicados",
        AdminSeccion.CONFIGURACION to "Config."
    )

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F8F6))
    ) {
        Surface(color = Color.White, shadowElevation = 1.dp) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Panel Administrador",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14231A)
                        )
                        Text(
                            text = "Control y verificación Viaje Rural",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                    onSalirAdmin?.let { salir ->
                        OutlinedButton(
                            onClick = salir,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Text("Cerrar Sesión", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                ScrollableTabRow(
                    selectedTabIndex = secciones.indexOfFirst { it.first == state.seccionActual }.coerceAtLeast(0),
                    containerColor = Color.White,
                    edgePadding = 14.dp
                ) {
                    secciones.forEach { (seccion, titulo) ->
                        Tab(
                            selected = state.seccionActual == seccion,
                            onClick = { viewModel.seleccionarSeccion(seccion) },
                            text = {
                                if (seccion == AdminSeccion.PENDIENTES && state.resumen.conductoresPendientes > 0) {
                                    Text("$titulo (${state.resumen.conductoresPendientes})", fontWeight = FontWeight.SemiBold)
                                } else {
                                    Text(titulo)
                                }
                            }
                        )
                    }
                }
            }
        }

        if (state.cargando) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        state.accionMensaje?.let { msg ->
            OutlinedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                shape = cardShape,
                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF14532D),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { viewModel.limpiarAccionMensaje() }) {
                        Text("OK")
                    }
                }
            }
        }

        state.errorMensaje?.let { err ->
            OutlinedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                shape = cardShape,
                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
            ) {
                Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF991B1B),
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (state.seccionActual) {
                AdminSeccion.RESUMEN -> {
                    item {
                        Text(
                            text = "Resumen del Sistema (Conteo Ligero)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ResumenCard("Total Conductores", state.resumen.totalConductores.toString(), Modifier.weight(1f))
                            ResumenCard("Activos", state.resumen.conductoresActivos.toString(), Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ResumenCard("Pendientes", state.resumen.conductoresPendientes.toString(), Modifier.weight(1f))
                            ResumenCard("Pasajeros", state.resumen.totalPasajeros.toString(), Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        ResumenCard("Peticiones de Cambio Pendientes", state.resumen.solicitudesPendientes.toString(), Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(10.dp))

                        val calcResumen = remember(
                            state.configuracion.montoMensualConductorBase,
                            state.configuracion.anioBaseMensualidad
                        ) {
                            calcularMensualidadConductorActual(
                                montoBase = state.configuracion.montoMensualConductorBase,
                                anioBase = state.configuracion.anioBaseMensualidad
                            )
                        }
                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Mensualidad Vigente Conductor (${calcResumen.anioActual})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                                Text(
                                    text = formatearColonesEntero(calcResumen.montoActual),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                                Text(
                                    text = "Base ${calcResumen.anioBase}: ${formatearColonesEntero(calcResumen.montoBase)} · ${calcResumen.incrementosAplicados} incremento(s) (+10% c/1 ene) · Próx. 1 ene: ${formatearColonesEntero(calcResumen.montoProximoEnero)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF3F5243)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Enlace de Descarga de la App",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = "Este mismo enlace se usa en el botón Compartir App de Pasajeros y Conductores. Puedes editarlo en Config.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF3F5243)
                                )
                                Surface(
                                    color = Color.White,
                                    shape = RoundedCornerShape(10.dp),
                                    border = cardBorder,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = state.configuracion.linkDescarga,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                                Button(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(state.configuracion.linkDescarga))
                                        enlaceCopiado = true
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(if (enlaceCopiado) "Enlace copiado al portapapeles" else "Copiar enlace de descarga")
                                }
                            }
                        }
                    }
                }

                AdminSeccion.PENDIENTES -> {
                    item {
                        Text(
                            text = "Conductores Pendientes de Verificación",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Toca una ficha para revisar sus documentos (Vehículo, Cédula, Licencia y RTV) y aprobar al conductor.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                    if (state.pendientes.isEmpty() && !state.cargando) {
                        item {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "No hay conductores pendientes por verificar.",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        }
                    } else {
                        items(state.pendientes) { cond ->
                            OutlinedCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.seleccionarConductor(cond) },
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFFFBEB))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${cond.vehiculoTipo} · Tarifa base: ₡${cond.tarifaBase.toInt()} · Adicional/km: ₡${cond.tarifaPorKm.toInt()}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Text(
                                        text = "Toca para ver fotos de documentos y aprobar",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.CONDUCTORES -> {
                    item {
                        Text(
                            text = "Conductores (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.conductores) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Cobrado este mes: ₡${cond.gananciasMes.toInt()}",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Tarifa base: ₡${cond.tarifaBase.toInt()} · Adicional/km: ₡${cond.tarifaPorKm.toInt()} · ${cond.estadoCuenta}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (cond.esTarifaAbusiva) {
                                    Text(
                                        text = "ALERTA: Tarifa supera >30% el promedio.",
                                        color = MaterialTheme.colorScheme.error,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.PASAJEROS -> {
                    item {
                        Text(
                            text = "Pasajeros (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.pasajeros) { pasajero ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarPasajero(pasajero) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(pasajero.nombre, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "★ ${pasajero.promedioCalificacion} · ${if (pasajero.bloqueado) "BLOQUEADO" else "ACTIVO"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (pasajero.bloqueado) MaterialTheme.colorScheme.error else Color(0xFF15803D),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text("Abrir Ficha", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                AdminSeccion.SOLICITUDES -> {
                    item {
                        Text(
                            text = "Peticiones de Cambio de Datos (limit(20))",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.solicitudesCambio) { sol ->
                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("${sol.nombreActual} (${sol.rol.uppercase()}) · ${sol.estado.uppercase()}", fontWeight = FontWeight.Bold)
                                Text("Motivo: ${sol.motivo}", style = MaterialTheme.typography.bodySmall)
                                Text("Cambios: ${sol.cambios.entries.joinToString { "${it.key}=${it.value}" }}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                if (sol.estado == "pendiente") {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { viewModel.resolverSolicitudCambio(sol, true, "Aprobado por Administrador") },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Aprobar y aplicar") }
                                        OutlinedButton(
                                            onClick = { viewModel.resolverSolicitudCambio(sol, false, "Rechazado por Administrador") },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Rechazar") }
                                    }
                                }
                            }
                        }
                    }
                }

                AdminSeccion.ALERTAS -> {
                    val abusivos = state.conductores.filter { it.esTarifaAbusiva }
                    val licenciasCriticas = state.conductores.filter { it.diasLicenciaRestantes <= 7 }
                    item {
                        Text(
                            text = "Alertas de Tarifas (>30%) y Licencias por Vencer",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Promedio: Tarifa base ₡${state.promedioBaseFlota.toInt()} · Adicional/km ₡${state.promedioKmFlota.toInt()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                    items(licenciasCriticas) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    items(abusivos) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Tarifa base ₡${cond.tarifaBase.toInt()} + Adicional/km ₡${cond.tarifaPorKm.toInt()}",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                AdminSeccion.DUPLICADOS -> {
                    val placasConteo = state.conductores.groupingBy { it.placa.uppercase() }.eachCount()
                    val duplicados = state.conductores.filter { (placasConteo[it.placa.uppercase()] ?: 0) > 1 }
                    item {
                        Text(
                            text = "Detector de Placas y Cédulas Duplicadas",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(duplicados) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Placa repetida: ${cond.placa}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                Text("${cond.nombre} · Cédula: ${cond.cedulaHash}")
                            }
                        }
                    }
                }

                AdminSeccion.CONFIGURACION -> {
                    item {
                        ConfiguracionAdminCard(
                            config = state.configuracion,
                            onSave = { viewModel.guardarConfiguracion(it) }
                        )
                    }
                }
            }
        }
    }

    state.conductorSeleccionado?.let { cond ->
        FichaConductorDialog(
            conductor = cond,
            documentos = state.documentosConductorSeleccionado,
            cargandoDocumentos = state.cargandoDocumentos,
            aprobando = state.aprobandoConductor,
            renovandoLicencia = state.renovandoLicencia,
            accionMensaje = state.accionMensaje,
            onAprobarYActivar = { viewModel.aprobarYActivarConductor(cond.uid) },
            onRenovarLicencia = { viewModel.renovarLicenciaUnMes(cond.uid) },
            onDismiss = { viewModel.cerrarFichaConductor() }
        )
    }

    state.pasajeroSeleccionado?.let { pasajero ->
        EditarPasajeroDialog(
            pasajero = pasajero,
            gestionando = state.gestionandoPasajero,
            onToggleBloqueo = { viewModel.toggleBloqueoPasajero(pasajero) },
            onEliminarCuenta = { viewModel.eliminarCuentaPasajero(pasajero.uid) },
            onDismiss = { viewModel.cerrarFichaPasajero() },
            onSave = { nombre, tel, email, cedula ->
                viewModel.guardarFichaPasajero(pasajero.uid, nombre, tel, email, cedula)
            }
        )
    }
}

@Composable
private fun ResumenCard(titulo: String, valor: String, modifier: Modifier = Modifier) {
    OutlinedCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(titulo, style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
            Text(
                text = valor,
                style = MaterialTheme.typography.headlineSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF14231A)
            )
        }
    }
}

private fun abrirWhatsAppContacto(context: Context, telefonoRaw: String, nombre: String): Boolean {
    val digits = telefonoRaw.filter { it.isDigit() }
    if (digits.length < 8) return false
    val fullNumber = if (digits.length == 8) "506$digits" else digits
    val mensaje = Uri.encode("Hola ${nombre.trim()}, te contactamos de la Administración de Viaje Rural.")
    val uri = Uri.parse("https://wa.me/$fullNumber?text=$mensaje")
    return try {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
    } catch (_: Throwable) {
        false
    }
}

@Composable
private fun FichaConductorDialog(
    conductor: ConductorAdminItem,
    documentos: ConductorDocumentosUi?,
    cargandoDocumentos: Boolean,
    aprobando: Boolean,
    renovandoLicencia: Boolean,
    accionMensaje: String?,
    onAprobarYActivar: () -> Unit,
    onRenovarLicencia: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val tieneTelefonoValido = conductor.telefono.count { it.isDigit() } >= 8
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Verificación y Ficha del Conductor", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(conductor.nombre, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Vehículo: ${conductor.vehiculoTipo} · Placa: ${conductor.placa}")

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF7F8F6),
                    border = BorderStroke(1.dp, Color(0xFFE2E6DF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Estado: ${conductor.estadoCuenta.uppercase()}",
                                fontWeight = FontWeight.Bold,
                                color = if (conductor.estadoCuenta == "activo") Color(0xFF15803D) else Color(0xFF92400E),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "${conductor.etiquetaLicencia} (${conductor.fechaLicenciaTexto})",
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (conductor.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else Color(0xFF525B50)
                            )
                        }
                        Button(
                            onClick = onRenovarLicencia,
                            enabled = !renovandoLicencia,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF15803D),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = if (renovandoLicencia) "Renovando..." else "Renovar Licencia (+1 Mes)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }

                if (!accionMensaje.isNullOrBlank()) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF0FDF4),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC))
                    ) {
                        Text(
                            text = accionMensaje,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF14532D),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Text("Cédula: ${conductor.cedulaHash.ifBlank { "No registrada" }}")
                Text(
                    text = "Teléfono: ${conductor.telefono.ifBlank { if (cargandoDocumentos) "Cargando..." else "No registrado" }}",
                    fontFamily = FontFamily.Monospace
                )
                Text("Licencia: ${conductor.etiquetaLicencia} (vence ${conductor.fechaLicenciaTexto})", fontFamily = FontFamily.Monospace)
                Text("Tarifa base: ₡${conductor.tarifaBase.toInt()} · Precio/km: ₡${conductor.tarifaPorKm.toInt()}")
                Text("Generado en el mes: ₡${conductor.gananciasMes.toInt()}", fontFamily = FontFamily.Monospace)

                Button(
                    onClick = { abrirWhatsAppContacto(context, conductor.telefono, conductor.nombre) },
                    enabled = tieneTelefonoValido && !cargandoDocumentos,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF16A34A),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text(
                        text = when {
                            cargandoDocumentos -> "Cargando teléfono..."
                            tieneTelefonoValido -> "Contactar por WhatsApp"
                            else -> "WhatsApp no disponible (sin teléfono)"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Text("Documentos Adjuntos", fontWeight = FontWeight.Bold)

                if (cargandoDocumentos) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text("Cargando fotografías...", style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    DocumentoFotoCard("Vehículo", documentos?.fotoVehiculo.orEmpty())
                    DocumentoFotoCard("Cédula", documentos?.fotoCedula.orEmpty())
                    DocumentoFotoCard("Licencia de Conducir", documentos?.fotoLicencia.orEmpty())
                    DocumentoFotoCard("RTV / Circulación / Marchamo", documentos?.fotoCirculacion.orEmpty())
                }

                if (conductor.estadoCuenta == "pendiente") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = onAprobarYActivar,
                        enabled = !aprobando,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF15803D),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text(
                            text = if (aprobando) "Aprobando..." else "Aprobar y Activar Conductor",
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Al aprobar, pasará a estado activo con licencia vigente por 1 mes desde hoy.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    )
}

@Composable
private fun DocumentoFotoCard(titulo: String, dataUrl: String) {
    val bitmap: ImageBitmap? = remember(dataUrl) {
        decodificarDataUrlBitmap(dataUrl)
    }
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF7F8F6))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(titulo, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = titulo,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(10.dp))
                )
            } else {
                Text("Sin documento adjunto", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
            }
        }
    }
}

private fun decodificarDataUrlBitmap(raw: String): ImageBitmap? {
    if (raw.isBlank()) return null
    return try {
        val base64Part = raw.substringAfter("base64,", raw).trim()
        if (base64Part.isBlank()) return null
        val bytes = Base64.decode(base64Part, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

@Composable
private fun ConfiguracionAdminCard(
    config: ConfiguracionGeneralUi,
    onSave: (ConfiguracionGeneralUi) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var linkDescarga by remember(config.linkDescarga) { mutableStateOf(config.linkDescarga) }
    var copiado by remember { mutableStateOf(false) }
    var whatsapp by remember(config.whatsappSoporte) { mutableStateOf(config.whatsappSoporte) }
    var sinpe by remember(config.sinpeNumero) { mutableStateOf(config.sinpeNumero) }
    var sinpeTitular by remember(config.sinpeTitular) { mutableStateOf(config.sinpeTitular) }
    var adminNombre by remember(config.adminNombre) { mutableStateOf(config.adminNombre) }
    var adminEmail by remember(config.adminEmail) { mutableStateOf(config.adminEmail) }
    var montoBaseConductorText by remember(config.montoMensualConductorBase) {
        mutableStateOf(config.montoMensualConductorBase.toString())
    }
    var anioBaseMensualidadText by remember(config.anioBaseMensualidad) {
        mutableStateOf(config.anioBaseMensualidad.toString())
    }
    var terminos by remember(config.terminosCondiciones) {
        mutableStateOf(
            config.terminosCondiciones.ifBlank {
                ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
            }
        )
    }
    var terminosPasajero by remember(config.terminosCondicionesPasajero) {
        mutableStateOf(
            config.terminosCondicionesPasajero.ifBlank {
                ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO
            }
        )
    }
    var tipos by remember(config.tiposVehiculo) { mutableStateOf(config.tiposVehiculo) }
    var nuevoTipoNombre by remember { mutableStateOf("") }
    var nuevoTipoCap by remember { mutableStateOf("2") }

    val montoBaseCalc = (montoBaseConductorText.toIntOrNull() ?: ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE)
        .coerceIn(500, 1_000_000)
    val anioBaseCalc = (anioBaseMensualidadText.toIntOrNull() ?: ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD)
        .coerceIn(2020, 2100)
    val calculoMensualidad = remember(montoBaseCalc, anioBaseCalc) {
        calcularMensualidadConductorActual(montoBase = montoBaseCalc, anioBase = anioBaseCalc)
    }
    val terminosConductorPreview = remember(terminos, montoBaseCalc, anioBaseCalc) {
        resolverTerminosConductorDinamicos(
            textoBase = terminos,
            montoBase = montoBaseCalc,
            anioBase = anioBaseCalc
        )
    }

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Enlace de Descarga, Soporte, SINPE, Términos y Vehículos", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = linkDescarga,
                onValueChange = {
                    linkDescarga = it
                    copiado = false
                },
                label = { Text("Enlace de descarga de la App (Compartir)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(
                onClick = {
                    clipboardManager.setText(AnnotatedString(linkDescarga.trim()))
                    copiado = true
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (copiado) "Enlace copiado" else "Copiar enlace de descarga")
            }
            OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("WhatsApp Soporte (62546546)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpe, onValueChange = { sinpe = it }, label = { Text("Número SINPE Móvil") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpeTitular, onValueChange = { sinpeTitular = it }, label = { Text("Titular SINPE") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminNombre, onValueChange = { adminNombre = it }, label = { Text("Nombre Administrador") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminEmail, onValueChange = { adminEmail = it }, label = { Text("Correo Administrador") }, modifier = Modifier.fillMaxWidth())

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF0FDF4),
                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Términos y Condiciones del Pasajero (Exclusivos)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14532D)
                    )
                    Text(
                        text = "Regla base: Para el pasajero no se incluye ningún tipo de cobro de app, comisión ni cargo adicional.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF166534)
                    )
                    OutlinedTextField(
                        value = terminosPasajero,
                        onValueChange = { terminosPasajero = it },
                        label = { Text("Términos del Pasajero (Tiempo real)") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = {
                            terminosPasajero =
                                cr.viajerural.app.data.ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Restaurar texto base sin cobro")
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF0FDF4),
                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Mensualidad del Conductor (+10% automático cada 1 de enero)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14532D)
                    )
                    Text(
                        text = "Fórmula en zona horaria America/Costa_Rica: montoVigente = montoBase * (1.10 ^ n), donde n = añoActual - añoBase.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF166534)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = montoBaseConductorText,
                            onValueChange = { montoBaseConductorText = it.filter(Char::isDigit) },
                            label = { Text("Monto base (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = anioBaseMensualidadText,
                            onValueChange = { anioBaseMensualidadText = it.filter(Char::isDigit).take(4) },
                            label = { Text("Año base") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                text = "Monto vigente (${calculoMensualidad.anioActual}): ${formatearColonesEntero(calculoMensualidad.montoActual)}/mes",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                            Text(
                                text = "Base (${calculoMensualidad.anioBase}): ${formatearColonesEntero(calculoMensualidad.montoBase)} · Incrementos anuales aplicados: ${calculoMensualidad.incrementosAplicados} (+${calculoMensualidad.porcentajeAcumulado}%)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF3F5243)
                            )
                            Text(
                                text = "Próximo 1 de enero (${calculoMensualidad.anioActual + 1}): ${formatearColonesEntero(calculoMensualidad.montoProximoEnero)}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF525B50)
                            )
                        }
                    }

                    Text(
                        text = "Términos y Condiciones del Conductor (Cuota SINPE dinámica)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14532D)
                    )
                    OutlinedTextField(
                        value = terminos,
                        onValueChange = { terminos = it },
                        label = { Text("Texto base (usa {{MONTO_CONDUCTOR_VIGENTE}})") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val token = ViajeRepository.TOKEN_MONTO_CONDUCTOR_VIGENTE
                                if (!terminos.contains(token)) {
                                    terminos = if (terminos.isBlank()) {
                                        ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
                                    } else {
                                        "$terminos\nCuota mensual vigente: $token"
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Insertar variable", style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(
                            onClick = { terminos = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Plantilla base", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF7F8F6),
                        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Vista previa para el conductor:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF525B50)
                            )
                            Text(
                                text = terminosConductorPreview,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF14231A)
                            )
                        }
                    }
                }
            }

            Text("Tipos de Vehículo (Motos, 4x4, etc.)", fontWeight = FontWeight.SemiBold)
            tipos.forEach { t ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${t.nombre} (máx. ${t.maxPasajeros} pax)")
                    TextButton(onClick = { tipos = tipos.filterNot { it.nombre == t.nombre } }) { Text("Quitar") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nuevoTipoNombre, onValueChange = { nuevoTipoNombre = it }, label = { Text("Ej: Moto") }, modifier = Modifier.weight(2f))
                OutlinedTextField(value = nuevoTipoCap, onValueChange = { nuevoTipoCap = it.filter(Char::isDigit) }, label = { Text("Max") }, modifier = Modifier.weight(1f))
            }
            OutlinedButton(
                onClick = {
                    if (nuevoTipoNombre.isNotBlank()) {
                        tipos = tipos + VehiculoTipoUi(nuevoTipoNombre.trim(), nuevoTipoCap.toIntOrNull() ?: 2)
                        nuevoTipoNombre = ""
                    }
                },
                shape = RoundedCornerShape(12.dp)
            ) { Text("Agregar tipo de vehículo") }

            Button(
                onClick = {
                    onSave(
                        config.copy(
                            linkDescarga = linkDescarga.trim(),
                            whatsappSoporte = whatsapp,
                            sinpeNumero = sinpe,
                            sinpeTitular = sinpeTitular,
                            adminNombre = adminNombre,
                            adminEmail = adminEmail,
                            terminosCondiciones = terminos,
                            terminosCondicionesPasajero = terminosPasajero,
                            montoMensualConductorBase = montoBaseCalc,
                            anioBaseMensualidad = anioBaseCalc,
                            tiposVehiculo = tipos
                        )
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) { Text("Guardar Configuración Global", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun EditarPasajeroDialog(
    pasajero: PasajeroAdminItem,
    gestionando: Boolean,
    onToggleBloqueo: () -> Unit,
    onEliminarCuenta: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (nombre: String, telefono: String, email: String, cedula: String) -> Unit
) {
    val context = LocalContext.current
    var nombre by remember(pasajero.uid) { mutableStateOf(pasajero.nombre) }
    var telefono by remember(pasajero.uid) { mutableStateOf(pasajero.telefono) }
    var email by remember(pasajero.uid) { mutableStateOf(pasajero.email) }
    var cedula by remember(pasajero.uid) { mutableStateOf(pasajero.cedula) }
    var confirmarEliminacion by remember(pasajero.uid) { mutableStateOf(false) }
    val tieneTelefonoValido = telefono.count { it.isDigit() } >= 8

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Ficha de Pasajero", fontWeight = FontWeight.Bold)
                Text(
                    text = "Estado: ${if (pasajero.bloqueado) "BLOQUEADO" else "ACTIVO"}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (pasajero.bloqueado) MaterialTheme.colorScheme.error else Color(0xFF15803D),
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = telefono, onValueChange = { telefono = it }, label = { Text("Teléfono") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = cedula, onValueChange = { cedula = it }, label = { Text("Cédula") }, modifier = Modifier.fillMaxWidth())

                Button(
                    onClick = { abrirWhatsAppContacto(context, telefono, nombre) },
                    enabled = tieneTelefonoValido,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF16A34A),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text(
                        text = if (tieneTelefonoValido) "Contactar por WhatsApp" else "WhatsApp no disponible (sin teléfono)",
                        fontWeight = FontWeight.Bold
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Text("Gestión de Cuenta", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)

                OutlinedButton(
                    onClick = onToggleBloqueo,
                    enabled = !gestionando,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (pasajero.bloqueado) Color(0xFF15803D) else Color(0xFFB45309)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (pasajero.bloqueado) "Desbloquear Cuenta" else "Bloquear Cuenta",
                        fontWeight = FontWeight.Bold
                    )
                }

                if (!confirmarEliminacion) {
                    OutlinedButton(
                        onClick = { confirmarEliminacion = true },
                        enabled = !gestionando,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Eliminar Cuenta", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Surface(
                        color = Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "¿Eliminar la cuenta de ${pasajero.nombre} en Firestore? Esta acción no se puede deshacer.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF991B1B),
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = onEliminarCuenta,
                                    enabled = !gestionando,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.error,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(if (gestionando) "Eliminando..." else "Confirmar")
                                }
                                OutlinedButton(
                                    onClick = { confirmarEliminacion = false },
                                    enabled = !gestionando,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Volver")
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(nombre, telefono, email, cedula) },
                enabled = !gestionando
            ) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    )
}
