package cr.viajerural.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import cr.viajerural.app.data.CambioItemData
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularMensualidadConductorActual
import cr.viajerural.app.data.formatearColones
import cr.viajerural.app.data.formatearColonesEntero
import cr.viajerural.app.data.resolverTerminosConductorDinamicos
import cr.viajerural.app.messaging.NotificationHelper
import cr.viajerural.app.viewmodel.AdminSeccion
import cr.viajerural.app.viewmodel.AdminViewModel
import cr.viajerural.app.viewmodel.ConductorAdminItem
import cr.viajerural.app.viewmodel.ConductorDocumentosUi
import cr.viajerural.app.viewmodel.ConfiguracionGeneralUi
import cr.viajerural.app.viewmodel.PasajeroAdminItem
import cr.viajerural.app.viewmodel.VehiculoTipoUi
import cr.viajerural.app.viewmodel.ViajeAlertaCobroUi
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Panel de Administrador Modular (Jetpack Compose) con diseño limpio alineado a la vista Web:
 * - Pestañas: Resumen, Pendientes, Conductores, Pasajeros, Peticiones, Alertas, Duplicados y Config.
 * - Resumen usa conteos en servidor + tarjeta con Enlace de Descarga de la App para copiar.
 * - Pendientes abre una ficha detallada con las 4 fotos de documentos y botón "Aprobar y Activar Conductor" (+1 mes licencia).
 */
@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onSalirAdmin: (() -> Unit)? = null
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    var enlaceCopiado by remember { mutableStateOf(false) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        NotificationHelper.crearTodosLosCanales(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !NotificationHelper.tienePermisoNotificaciones(context)
        ) {
            try {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } catch (_: Throwable) {
            }
        }
        viewModel.cargarResumenInicial()
        viewModel.iniciarEscuchaSolicitudesTiempoReal(context)
    }

    LaunchedEffect(state.accionMensaje) {
        val msg = state.accionMensaje
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
        }
    }

    val pendientesSolicitudes = if (state.solicitudesCargadas) {
        maxOf(
            state.solicitudesPendientesCount,
            state.solicitudesCambio.count { it.tienePendientes }
        )
    } else {
        maxOf(
            state.solicitudesPendientesCount,
            state.resumen.solicitudesPendientes.toInt()
        )
    }

    val secciones = listOf(
        AdminSeccion.RESUMEN to "Resumen",
        AdminSeccion.PENDIENTES to "Pendientes",
        AdminSeccion.CONDUCTORES to "Conductores",
        AdminSeccion.PASAJEROS to "Pasajeros",
        AdminSeccion.SOLICITUDES to "Solicitudes de cambio",
        AdminSeccion.ALERTAS to "Alertas",
        AdminSeccion.DUPLICADOS to "Duplicados",
        AdminSeccion.CONFIGURACION to "Config."
    )

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        containerColor = Color(0xFFF7F8F6)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF7F8F6))
        ) {
            Surface(color = Color.White, shadowElevation = 1.dp) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Panel Administrador",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF14231A)
                            )
                            Text(
                                text = "Control y verificación Viaje Rural",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF525B50)
                            )
                        }
                        onSalirAdmin?.let { salir ->
                            OutlinedButton(
                                onClick = salir,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("Cerrar Sesión", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    ScrollableTabRow(
                        selectedTabIndex = secciones.indexOfFirst { it.first == state.seccionActual }.coerceAtLeast(0),
                        containerColor = Color.White,
                        edgePadding = 14.dp
                    ) {
                        secciones.forEach { (seccion, titulo) ->
                            Tab(
                                selected = state.seccionActual == seccion,
                                onClick = { viewModel.seleccionarSeccion(seccion) },
                                text = {
                                    when {
                                        seccion == AdminSeccion.SOLICITUDES && pendientesSolicitudes > 0 -> {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(titulo, fontWeight = FontWeight.SemiBold)
                                                Badge(
                                                    containerColor = Color(0xFFDC2626),
                                                    contentColor = Color.White
                                                ) {
                                                    Text(
                                                        text = pendientesSolicitudes.toString(),
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                        seccion == AdminSeccion.PENDIENTES && state.resumen.conductoresPendientes > 0 -> {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(titulo, fontWeight = FontWeight.SemiBold)
                                                Badge(
                                                    containerColor = Color(0xFFD97706),
                                                    contentColor = Color.White
                                                ) {
                                                    Text(state.resumen.conductoresPendientes.toString())
                                                }
                                            }
                                        }
                                        else -> Text(titulo)
                                    }
                                }
                            )
                        }
                    }
                }
            }

            if (state.cargando) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            state.accionMensaje?.let { msg ->
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                    shape = cardShape,
                    border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF14532D),
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.limpiarAccionMensaje() }) {
                            Text("OK")
                        }
                    }
                }
            }

            state.errorMensaje?.let { err ->
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                    shape = cardShape,
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
                ) {
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF991B1B),
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
            when (state.seccionActual) {
                AdminSeccion.RESUMEN -> {
                    item {
                        Text(
                            text = "Resumen del Sistema (Conteo Ligero)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ResumenCard("Total Conductores", state.resumen.totalConductores.toString(), Modifier.weight(1f))
                            ResumenCard("Activos", state.resumen.conductoresActivos.toString(), Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ResumenCard("Pendientes", state.resumen.conductoresPendientes.toString(), Modifier.weight(1f))
                            ResumenCard("Pasajeros", state.resumen.totalPasajeros.toString(), Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        ResumenCard("Peticiones de Cambio Pendientes", state.resumen.solicitudesPendientes.toString(), Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(10.dp))

                        val calcResumen = remember(
                            state.configuracion.montoMensualConductorBase,
                            state.configuracion.anioBaseMensualidad
                        ) {
                            calcularMensualidadConductorActual(
                                montoBase = state.configuracion.montoMensualConductorBase,
                                anioBase = state.configuracion.anioBaseMensualidad
                            )
                        }
                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Mensualidad Vigente Conductor (${calcResumen.anioActual})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                                Text(
                                    text = formatearColonesEntero(calcResumen.montoActual),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                                Text(
                                    text = "Base ${calcResumen.anioBase}: ${formatearColonesEntero(calcResumen.montoBase)} · ${calcResumen.incrementosAplicados} incremento(s) (+10% c/1 ene) · Próx. 1 ene: ${formatearColonesEntero(calcResumen.montoProximoEnero)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF3F5243)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Enlace de Descarga de la App",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = "Este mismo enlace se usa en el botón Compartir App de Pasajeros y Conductores. Puedes editarlo en Config.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF3F5243)
                                )
                                Surface(
                                    color = Color.White,
                                    shape = RoundedCornerShape(10.dp),
                                    border = cardBorder,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = state.configuracion.linkDescarga,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                                Button(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(state.configuracion.linkDescarga))
                                        enlaceCopiado = true
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(if (enlaceCopiado) "Enlace copiado al portapapeles" else "Copiar enlace de descarga")
                                }
                            }
                        }
                    }
                }

                AdminSeccion.PENDIENTES -> {
                    item {
                        Text(
                            text = "Conductores Pendientes de Verificación",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Toca una ficha para revisar sus documentos (Vehículo, Cédula, Licencia y RTV) y aprobar al conductor.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                    if (state.pendientes.isEmpty() && !state.cargando) {
                        item {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "No hay conductores pendientes por verificar.",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        }
                    } else {
                        items(state.pendientes) { cond ->
                            OutlinedCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.seleccionarConductor(cond) },
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFFFBEB))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${cond.vehiculoTipo} · Tarifa base: ${formatearColones(cond.tarifaBase)} · Adicional/km: ${formatearColones(cond.tarifaPorKm)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Text(
                                        text = "Toca para ver fotos de documentos y aprobar",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.CONDUCTORES -> {
                    item {
                        Text(
                            text = "Conductores (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.conductores) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Cobrado este mes: ${formatearColones(cond.gananciasMes)}",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = buildString {
                                        append("Tarifa base: ${formatearColones(cond.tarifaBase)} · Adicional/km: ${formatearColones(cond.tarifaPorKm)}")
                                        cond.tarifaBaseCarga?.let { append(" · Carga/flete: ${formatearColones(it)}") }
                                        append(" · ${cond.estadoCuenta}")
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                                if (ViajeRepository.esVehiculoMoto(cond.vehiculoTipo)) {
                                    Text(
                                        text = "Moto · Casco extra: ${if (cond.tieneCascoExtra) "Sí" else "No"} · Capa: ${if (cond.tieneCapaDisponible) "Sí" else "No"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF166534)
                                    )
                                }
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (cond.esTarifaAbusiva) {
                                    Text(
                                        text = if (cond.esTarifaCargaAbusiva) {
                                            "ALERTA: Tarifa o tarifa de carga supera >30% el promedio."
                                        } else {
                                            "ALERTA: Tarifa supera >30% el promedio."
                                        },
                                        color = MaterialTheme.colorScheme.error,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.PASAJEROS -> {
                    item {
                        Text(
                            text = "Pasajeros (limit(20)) · Toca para abrir ficha",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(state.pasajeros) { pasajero ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarPasajero(pasajero) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(pasajero.nombre, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "★ ${pasajero.promedioCalificacion} · ${if (pasajero.bloqueado) "BLOQUEADO" else "ACTIVO"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (pasajero.bloqueado) MaterialTheme.colorScheme.error else Color(0xFF15803D),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text("Abrir Ficha", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                AdminSeccion.SOLICITUDES -> {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Solicitudes de cambio de datos",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (pendientesSolicitudes > 0) {
                                    "$pendientesSolicitudes pendiente(s) en tiempo real · Compara dato anterior vs. solicitado antes de aprobar."
                                } else {
                                    "Escucha en tiempo real activa · Compara dato anterior vs. solicitado."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF525B50)
                            )
                        }
                    }
                    if (state.solicitudesCambio.isEmpty() && !state.cargando) {
                        item {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "No hay solicitudes de cambio de datos registradas.",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        }
                    } else {
                        items(state.solicitudesCambio, key = { it.id }) { sol ->
                            SolicitudCambioAdminCard(
                                sol = sol,
                                onAprobarLinea = { claveItem ->
                                    viewModel.resolverLineaSolicitudCambio(sol, claveItem, true)
                                },
                                onRechazarLinea = { claveItem, motivo ->
                                    viewModel.resolverLineaSolicitudCambio(sol, claveItem, false, motivo)
                                },
                                onAprobar = { viewModel.resolverSolicitudCambio(sol, true, "Aprobado por Administrador") },
                                onRechazar = { viewModel.resolverSolicitudCambio(sol, false, "Rechazado por Administrador") }
                            )
                        }
                    }
                }

                AdminSeccion.ALERTAS -> {
                    val abusivos = state.conductores.filter { it.esTarifaAbusiva }
                    val licenciasCriticas = state.conductores.filter { it.diasLicenciaRestantes <= 7 }
                    item {
                        Text(
                            text = "Alertas de Tarifas (>30%), Cobros Excesivos y Licencias",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Promedio normal: Base ${formatearColones(state.promedioBaseFlota)} · Adicional/km ${formatearColones(state.promedioKmFlota)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                        Text(
                            text = "Promedio Pickup carga/flete: Base ${formatearColones(state.promedioBaseCargaFlota)} · Topes cobro: ${state.configuracion.multiplicadorTopeNormal}x normal / ${state.configuracion.multiplicadorTopeCarga}x carga",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF92400E),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    items(licenciasCriticas) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("${cond.nombre} (${cond.placa})", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Licencia: ${cond.etiquetaLicencia} (vence ${cond.fechaLicenciaTexto})",
                                    color = if (cond.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    items(abusivos) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("${cond.nombre} (${cond.placa}) · ${cond.vehiculoTipo}", fontWeight = FontWeight.Bold)
                                Text(
                                    text = buildString {
                                        append("Tarifa base ${formatearColones(cond.tarifaBase)} + Adicional/km ${formatearColones(cond.tarifaPorKm)}")
                                        cond.tarifaBaseCarga?.let { append(" · Carga/flete ${formatearColones(it)}") }
                                    },
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (cond.esTarifaCargaAbusiva) {
                                    Text(
                                        text = "Tarifa de carga supera >30% el promedio de flota Pickup",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFFB45309),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                    if (state.viajesCobroExcesivo.isNotEmpty()) {
                        item {
                            Text(
                                text = "Cobros excesivos en viajes finalizados (${state.viajesCobroExcesivo.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        items(state.viajesCobroExcesivo, key = { it.id }) { alerta ->
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Cobro excesivo: ${formatearColones(alerta.montoCobrado)} (Tope: ${formatearColones(alerta.limiteMaximoPermitido)})",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF991B1B)
                                    )
                                    Text(
                                        text = "Conductor: ${alerta.conductorNombre} (${alerta.vehiculoTipo})${if (alerta.esCargaFlete) " · CON CARGA" else ""}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Pasajero: ${alerta.pasajeroNombre} · ${alerta.origenNombre} → ${alerta.destinoNombre}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Text(
                                        text = "Estimado: ${formatearColones(alerta.montoAproximado)} · Ref. promedio: ${formatearColones(alerta.montoReferenciaPromedio)} · ${formatearFechaHoraSolicitud(alerta.updatedAtMillis)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFF7F1D1D)
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSeccion.DUPLICADOS -> {
                    val placasConteo = state.conductores.groupingBy { it.placa.uppercase() }.eachCount()
                    val duplicados = state.conductores.filter { (placasConteo[it.placa.uppercase()] ?: 0) > 1 }
                    item {
                        Text(
                            text = "Detector de Placas y Cédulas Duplicadas",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(duplicados) { cond ->
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.seleccionarConductor(cond) },
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Placa repetida: ${cond.placa}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                Text("${cond.nombre} · Cédula: ${cond.cedulaHash}")
                            }
                        }
                    }
                }

                AdminSeccion.CONFIGURACION -> {
                    item {
                        ConfiguracionAdminCard(
                            config = state.configuracion,
                            onSave = { viewModel.guardarConfiguracion(it) }
                        )
                    }
                }
            }
        }
    }
    }

    val tiposDisponibles = state.configuracion.tiposVehiculo
        .map { it.nombre }
        .filter { it.isNotBlank() }
        .ifEmpty { listOf("Moto", "Sedan", "Pickup 4x4", "SUV Rural", "Microbus") }

    state.conductorSeleccionado?.let { cond ->
        FichaConductorDialog(
            conductor = cond,
            documentos = state.documentosConductorSeleccionado,
            tiposVehiculoDisponibles = tiposDisponibles,
            cargandoDocumentos = state.cargandoDocumentos,
            aprobando = state.aprobandoConductor,
            renovandoLicencia = state.renovandoLicencia,
            guardandoFicha = state.guardandoFichaConductor,
            accionMensaje = state.accionMensaje,
            onAprobarYActivar = { viewModel.aprobarYActivarConductor(cond.uid) },
            onRenovarLicencia = { viewModel.renovarLicenciaUnMes(cond.uid) },
            onGuardarFicha = { nombre, telefono, vehiculoTipo, vehiculoMarca, vehiculoModelo, vehiculoColor, vehiculoAnio, placa, capacidad, tarifaBase, tarifaPorKm, tarifaBaseCarga, tieneCascoExtra, tieneCapaDisponible, estadoCuenta, mensualidadPendiente, licenciaExpMillis, docVehiculoAprobado, docCedulaAprobado, docLicenciaAprobado, docCirculacionAprobado, onListo ->
                viewModel.guardarFichaConductor(
                    conductorId = cond.uid,
                    nombre = nombre,
                    telefono = telefono,
                    cedula = cond.cedulaHash,
                    vehiculoTipo = vehiculoTipo,
                    vehiculoMarca = vehiculoMarca,
                    vehiculoModelo = vehiculoModelo,
                    vehiculoColor = vehiculoColor,
                    vehiculoAnio = vehiculoAnio,
                    placa = placa,
                    capacidad = capacidad,
                    tarifaBase = tarifaBase,
                    tarifaPorKm = tarifaPorKm,
                    estadoCuenta = estadoCuenta,
                    mensualidadPendiente = mensualidadPendiente,
                    licenciaExpMillis = licenciaExpMillis,
                    docVehiculoAprobado = docVehiculoAprobado,
                    docCedulaAprobado = docCedulaAprobado,
                    docLicenciaAprobado = docLicenciaAprobado,
                    docCirculacionAprobado = docCirculacionAprobado,
                    tarifaBaseCarga = tarifaBaseCarga,
                    tieneCascoExtra = tieneCascoExtra,
                    tieneCapaDisponible = tieneCapaDisponible,
                    onExito = { msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        onListo()
                    }
                )
            },
            onDismiss = { viewModel.cerrarFichaConductor() }
        )
    }

    state.pasajeroSeleccionado?.let { pasajero ->
        EditarPasajeroDialog(
            pasajero = pasajero,
            gestionando = state.gestionandoPasajero,
            onToggleBloqueo = { viewModel.toggleBloqueoPasajero(pasajero) },
            onEliminarCuenta = { viewModel.eliminarCuentaPasajero(pasajero.uid) },
            onDismiss = { viewModel.cerrarFichaPasajero() },
            onSave = { nombre, tel, email, cedula ->
                viewModel.guardarFichaPasajero(pasajero.uid, nombre, tel, email, cedula)
            }
        )
    }
}

@Composable
private fun ResumenCard(titulo: String, valor: String, modifier: Modifier = Modifier) {
    OutlinedCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(titulo, style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
            Text(
                text = valor,
                style = MaterialTheme.typography.headlineSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF14231A)
            )
        }
    }
}

private fun abrirWhatsAppContacto(context: Context, telefonoRaw: String, nombre: String): Boolean {
    val digits = telefonoRaw.filter { it.isDigit() }
    if (digits.length < 8) return false
    val fullNumber = if (digits.length == 8) "506$digits" else digits
    val mensaje = Uri.encode("Hola ${nombre.trim()}, te contactamos de la Administración de Viaje Rural.")
    val uri = Uri.parse("https://wa.me/$fullNumber?text=$mensaje")
    return try {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
    } catch (_: Throwable) {
        false
    }
}

private fun etiquetaCampoSolicitudAdmin(clave: String): String = when (clave) {
    "nombre" -> "Nombre completo"
    "telefono" -> "Teléfono"
    "email" -> "Correo"
    "cedula" -> "Cédula"
    "vehiculoTipo" -> "Tipo de vehículo"
    "vehiculoMarca" -> "Marca"
    "vehiculoModelo" -> "Modelo"
    "color", "vehiculoColor" -> "Color"
    "vehiculoAnio", "anio" -> "Año"
    "placa" -> "Placa"
    "capacidad" -> "Capacidad (pax)"
    "tarifaBase" -> "Tarifa base (₡)"
    "tarifaBaseCarga" -> "Tarifa base con carga / flete (₡)"
    "precioKm", "tarifaPorKm" -> "Precio por km (₡)"
    "tieneCascoExtra" -> "Casco extra para pasajero"
    "tieneCapaDisponible" -> "Capa impermeable disponible"
    "fotoVehiculo" -> "Foto del vehículo"
    "fotoCedula" -> "Foto de Cédula"
    "fotoLicencia" -> "Foto de Licencia"
    "fotoMarchamoRtv", "fotoCirculacion" -> "Foto Marchamo / RTV"
    else -> clave
}

private fun formatearFechaHoraSolicitud(millis: Long): String {
    if (millis <= 0L) return "Reciente"
    val fmt = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale("es", "CR"))
    fmt.timeZone = TimeZone.getTimeZone("America/Costa_Rica")
    return fmt.format(Date(millis))
}

@Composable
private fun SolicitudCambioAdminCard(
    sol: SolicitudCambioData,
    onAprobarLinea: (claveItem: String) -> Unit,
    onRechazarLinea: (claveItem: String, motivoRechazo: String) -> Unit,
    onAprobar: () -> Unit,
    onRechazar: () -> Unit
) {
    val esPendiente = sol.tienePendientes
    val cardBorderColor = when {
        esPendiente -> Color(0xFFF59E0B)
        sol.estadoGeneral == "completada" || sol.estado == "aprobada" -> Color(0xFF86EFAC)
        else -> Color(0xFFE2E6DF)
    }
    val cardBgColor = if (esPendiente) Color(0xFFFFFBEB) else Color.White
    val badgeBgColor = if (esPendiente) Color(0xFFDC2626) else Color(0xFF15803D)
    val badgeTexto = if (esPendiente) {
        if (sol.esGranular) "PENDIENTE (${sol.cantidadPendientes}/${sol.items.size})" else "PENDIENTE"
    } else {
        sol.estadoGeneral.uppercase()
    }

    var itemParaRechazar by remember(sol.id) { mutableStateOf<CambioItemData?>(null) }
    var motivoRechazoInput by remember(sol.id) { mutableStateOf("") }
    var imagenAmpliada by remember(sol.id) { mutableStateOf<Pair<String, String>?>(null) }

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, cardBorderColor),
        colors = CardDefaults.outlinedCardColors(containerColor = cardBgColor)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${sol.nombreActual} (${sol.rol.uppercase()})",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14231A)
                    )
                    Text(
                        text = "Recibida: ${formatearFechaHoraSolicitud(sol.createdAtMillis)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF525B50)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeBgColor
                ) {
                    Text(
                        text = badgeTexto,
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = "Perfil actual: ${sol.resumenActual}",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF525B50)
            )
            Text(
                text = "Motivo: ${sol.motivo}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF14231A)
            )

            if (sol.esGranular) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Revisión línea por línea (${sol.items.size} cambio(s)):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14231A)
                    )
                    sol.items.forEach { item ->
                        val itemBorder = when (item.estado) {
                            "aprobado" -> Color(0xFF86EFAC)
                            "rechazado" -> Color(0xFFFCA5A5)
                            else -> Color(0xFFE2E6DF)
                        }
                        val (chipBg, chipFg, chipText) = when (item.estado) {
                            "aprobado" -> Triple(Color(0xFFDCFCE7), Color(0xFF166534), "Aprobado")
                            "rechazado" -> Triple(Color(0xFFFEE2E2), Color(0xFF991B1B), "Rechazado")
                            else -> Triple(Color(0xFFFEF3C7), Color(0xFF92400E), "Pendiente")
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, itemBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.etiqueta,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14231A),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = chipBg
                                    ) {
                                        Text(
                                            text = chipText,
                                            color = chipFg,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                if (item.tipo == "imagen") {
                                    val bmpAnt = remember(item.valorAnterior) { decodificarDataUrlBitmap(item.valorAnterior) }
                                    val bmpNuevo = remember(item.valorNuevo) { decodificarDataUrlBitmap(item.valorNuevo) }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                text = "Anterior",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF6B7280),
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            if (bmpAnt != null) {
                                                Image(
                                                    bitmap = bmpAnt,
                                                    contentDescription = "Imagen anterior ${item.etiqueta}",
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(96.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            imagenAmpliada = "${item.etiqueta} (Anterior)" to item.valorAnterior
                                                        }
                                                )
                                            } else {
                                                Surface(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(96.dp),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = Color(0xFFF3F4F6)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = "Sin imagen previa",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = Color(0xFF6B7280)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                text = "Solicitada (toca para ampliar)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF15803D),
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            if (bmpNuevo != null) {
                                                Image(
                                                    bitmap = bmpNuevo,
                                                    contentDescription = "Imagen nueva ${item.etiqueta}",
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(96.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            imagenAmpliada = "${item.etiqueta} (Nueva solicitada)" to item.valorNuevo
                                                        }
                                                )
                                            } else {
                                                Surface(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(96.dp),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = Color(0xFFF3F4F6)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text("Imagen no disponible", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(
                                            text = "Anterior: ${item.valorAnterior.ifBlank { "No registrado" }}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF6B7280)
                                        )
                                        Text(
                                            text = "Solicitado: ${item.valorNuevo}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF14231A)
                                        )
                                    }
                                }

                                if (item.estado == "pendiente") {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { onAprobarLinea(item.clave) },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFF15803D),
                                                contentColor = Color.White
                                            ),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Aprobar", fontWeight = FontWeight.Bold)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                motivoRechazoInput = ""
                                                itemParaRechazar = item
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                contentColor = MaterialTheme.colorScheme.error
                                            ),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Rechazar", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                } else if (item.estado == "aprobado") {
                                    Text(
                                        text = "✓ Aprobado y aplicado en la ficha del conductor",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF15803D)
                                    )
                                } else if (item.estado == "rechazado") {
                                    Text(
                                        text = buildString {
                                            append("✕ Rechazado (se conserva dato anterior)")
                                            if (item.motivoRechazo.isNotBlank()) {
                                                append(" · Motivo: ${item.motivoRechazo}")
                                            }
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF991B1B)
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E6DF))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Comparación: Valor anterior vs. Solicitado",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14231A)
                        )
                        sol.cambios.forEach { (clave, valorNuevo) ->
                            val valorAnterior = sol.datosAnteriores[clave]?.toString()?.trim()?.takeIf { it.isNotBlank() }
                                ?: "No registrado"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = etiquetaCampoSolicitudAdmin(clave),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF525B50)
                                    )
                                    Text(
                                        text = "Anterior: $valorAnterior",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF6B7280)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Nuevo solicitado",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF15803D)
                                    )
                                    Text(
                                        text = valorNuevo.toString(),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D)
                                    )
                                }
                            }
                            HorizontalDivider(color = Color(0xFFF1F4EE))
                        }
                    }
                }
                if (esPendiente) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onAprobar,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF15803D),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        ) { Text("Aprobar y aplicar", fontWeight = FontWeight.Bold) }
                        OutlinedButton(
                            onClick = onRechazar,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier.weight(1f)
                        ) { Text("Rechazar", fontWeight = FontWeight.SemiBold) }
                    }
                }
            }

            if (!esPendiente && sol.respuestaAdmin.isNotBlank()) {
                Text(
                    text = "Resolución: ${sol.respuestaAdmin}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF525B50)
                )
            }
        }
    }

    itemParaRechazar?.let { itemRech ->
        val sugerenciasRechazo = listOf("Foto borrosa o ilegible", "Documento vencido", "Dato no coincide")
        AlertDialog(
            onDismissRequest = { itemParaRechazar = null },
            title = { Text("Rechazar: ${itemRech.etiqueta}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Puedes indicar opcionalmente una razón breve para que el conductor sepa qué corregir (o confirmar directamente).",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF525B50)
                    )
                    sugerenciasRechazo.forEach { sug ->
                        OutlinedButton(
                            onClick = { motivoRechazoInput = sug },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(sug, style = MaterialTheme.typography.labelMedium) }
                    }
                    OutlinedTextField(
                        value = motivoRechazoInput,
                        onValueChange = { if (it.length <= 240) motivoRechazoInput = it },
                        label = { Text("Motivo de rechazo (opcional)") },
                        placeholder = { Text("Ej. Foto borrosa") },
                        singleLine = false,
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRechazarLinea(itemRech.clave, motivoRechazoInput.trim())
                        itemParaRechazar = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = Color.White
                    )
                ) { Text("Confirmar rechazo") }
            },
            dismissButton = {
                TextButton(onClick = { itemParaRechazar = null }) { Text("Cancelar") }
            }
        )
    }

    imagenAmpliada?.let { (tituloImg, rawImg) ->
        val bmpFull = remember(rawImg) { decodificarDataUrlBitmap(rawImg) }
        Dialog(onDismissRequest = { imagenAmpliada = null }) {
            Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(tituloImg, fontWeight = FontWeight.Bold, color = Color(0xFF14231A))
                    if (bmpFull != null) {
                        Image(
                            bitmap = bmpFull,
                            contentDescription = tituloImg,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 380.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                    } else {
                        Text("No se pudo decodificar la imagen.", color = MaterialTheme.colorScheme.error)
                    }
                    Button(
                        onClick = { imagenAmpliada = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Cerrar") }
                }
            }
        }
    }
}

private fun formatearFechaDdMmYyyy(millis: Long): String {
    val fmt = SimpleDateFormat("dd/MM/yyyy", Locale("es", "CR"))
    fmt.timeZone = TimeZone.getTimeZone("America/Costa_Rica")
    return fmt.format(Date(millis))
}

private fun parseFechaVencimientoAdminMillis(raw: String): Long? {
    val limpio = raw.trim()
    if (limpio.isEmpty()) return null
    val tz = TimeZone.getTimeZone("America/Costa_Rica")
    for (patron in listOf("dd/MM/yyyy", "yyyy-MM-dd")) {
        try {
            val fmt = SimpleDateFormat(patron, Locale.US).apply {
                isLenient = false
                timeZone = tz
            }
            val parsed = fmt.parse(limpio) ?: continue
            val cal = Calendar.getInstance(tz).apply {
                time = parsed
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
                set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        } catch (_: Throwable) {
        }
    }
    return null
}

@Composable
private fun FichaConductorDialog(
    conductor: ConductorAdminItem,
    documentos: ConductorDocumentosUi?,
    tiposVehiculoDisponibles: List<String>,
    cargandoDocumentos: Boolean,
    aprobando: Boolean,
    renovandoLicencia: Boolean,
    guardandoFicha: Boolean,
    accionMensaje: String?,
    onAprobarYActivar: () -> Unit,
    onRenovarLicencia: () -> Unit,
    onGuardarFicha: (
        nombre: String,
        telefono: String,
        vehiculoTipo: String,
        vehiculoMarca: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        tarifaBaseCarga: Double?,
        tieneCascoExtra: Boolean,
        tieneCapaDisponible: Boolean,
        estadoCuenta: String,
        mensualidadPendiente: Boolean,
        licenciaExpMillis: Long,
        docVehiculoAprobado: Boolean,
        docCedulaAprobado: Boolean,
        docLicenciaAprobado: Boolean,
        docCirculacionAprobado: Boolean,
        onExitoLocal: () -> Unit
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var modoEdicion by remember(conductor.uid) { mutableStateOf(false) }

    var nombreEdit by remember(conductor.uid) { mutableStateOf(conductor.nombre) }
    var telefonoEdit by remember(conductor.uid) { mutableStateOf(conductor.telefono) }
    var vehiculoTipoEdit by remember(conductor.uid) { mutableStateOf(conductor.vehiculoTipo) }
    var vehiculoMarcaEdit by remember(conductor.uid) { mutableStateOf(conductor.vehiculoMarca) }
    var vehiculoModeloEdit by remember(conductor.uid) { mutableStateOf(conductor.vehiculoModelo) }
    var vehiculoColorEdit by remember(conductor.uid) { mutableStateOf(conductor.vehiculoColor) }
    var vehiculoAnioEdit by remember(conductor.uid) { mutableStateOf(conductor.vehiculoAnio) }
    var placaEdit by remember(conductor.uid) { mutableStateOf(conductor.placa) }
    var capacidadEdit by remember(conductor.uid) { mutableStateOf(conductor.capacidad.toString()) }
    var tarifaBaseEdit by remember(conductor.uid) { mutableStateOf(conductor.tarifaBase.toInt().toString()) }
    var tarifaKmEdit by remember(conductor.uid) { mutableStateOf(conductor.tarifaPorKm.toInt().toString()) }
    var tarifaBaseCargaEdit by remember(conductor.uid) {
        mutableStateOf(conductor.tarifaBaseCarga?.toInt()?.toString() ?: "")
    }
    var tieneCascoExtraEdit by remember(conductor.uid) { mutableStateOf(conductor.tieneCascoExtra) }
    var tieneCapaDisponibleEdit by remember(conductor.uid) { mutableStateOf(conductor.tieneCapaDisponible) }
    var estadoCuentaEdit by remember(conductor.uid) { mutableStateOf(conductor.estadoCuenta) }
    var mensualidadPendienteEdit by remember(conductor.uid) { mutableStateOf(conductor.mensualidadPendiente) }
    var fechaLicenciaEdit by remember(conductor.uid) {
        mutableStateOf(
            conductor.licenciaExpMillis?.let { formatearFechaDdMmYyyy(it) }
                ?: conductor.fechaLicenciaTexto.takeIf { it.contains("/") && !it.startsWith("--") }
                ?: formatearFechaDdMmYyyy(System.currentTimeMillis() + 30L * 86_400_000L)
        )
    }
    var docVehiculoOkEdit by remember(conductor.uid) { mutableStateOf(conductor.docVehiculoAprobado) }
    var docCedulaOkEdit by remember(conductor.uid) { mutableStateOf(conductor.docCedulaAprobado) }
    var docLicenciaOkEdit by remember(conductor.uid) { mutableStateOf(conductor.docLicenciaAprobado) }
    var docCirculacionOkEdit by remember(conductor.uid) { mutableStateOf(conductor.docCirculacionAprobado) }
    var errorValidacion by remember(conductor.uid, modoEdicion) { mutableStateOf<String?>(null) }

    LaunchedEffect(conductor.telefono, modoEdicion) {
        if (!modoEdicion && conductor.telefono.isNotBlank()) {
            telefonoEdit = conductor.telefono
        }
    }

    fun restablecerCamposDesdeConductor() {
        nombreEdit = conductor.nombre
        telefonoEdit = conductor.telefono
        vehiculoTipoEdit = conductor.vehiculoTipo
        vehiculoMarcaEdit = conductor.vehiculoMarca
        vehiculoModeloEdit = conductor.vehiculoModelo
        vehiculoColorEdit = conductor.vehiculoColor
        vehiculoAnioEdit = conductor.vehiculoAnio
        placaEdit = conductor.placa
        capacidadEdit = conductor.capacidad.toString()
        tarifaBaseEdit = conductor.tarifaBase.toInt().toString()
        tarifaKmEdit = conductor.tarifaPorKm.toInt().toString()
        tarifaBaseCargaEdit = conductor.tarifaBaseCarga?.toInt()?.toString() ?: ""
        tieneCascoExtraEdit = conductor.tieneCascoExtra
        tieneCapaDisponibleEdit = conductor.tieneCapaDisponible
        estadoCuentaEdit = conductor.estadoCuenta
        mensualidadPendienteEdit = conductor.mensualidadPendiente
        fechaLicenciaEdit = conductor.licenciaExpMillis?.let { formatearFechaDdMmYyyy(it) }
            ?: conductor.fechaLicenciaTexto.takeIf { it.contains("/") && !it.startsWith("--") }
            ?: formatearFechaDdMmYyyy(System.currentTimeMillis() + 30L * 86_400_000L)
        docVehiculoOkEdit = conductor.docVehiculoAprobado
        docCedulaOkEdit = conductor.docCedulaAprobado
        docLicenciaOkEdit = conductor.docLicenciaAprobado
        docCirculacionOkEdit = conductor.docCirculacionAprobado
        errorValidacion = null
    }

    val tieneTelefonoValido = conductor.telefono.count { it.isDigit() } >= 8

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (modoEdicion) "Editar Ficha Conductor" else "Ficha del Conductor",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                if (!modoEdicion) {
                    FilledTonalButton(
                        onClick = {
                            restablecerCamposDesdeConductor()
                            modoEdicion = true
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Editar ficha",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Editar ficha", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 490.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!accionMensaje.isNullOrBlank()) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF0FDF4),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC))
                    ) {
                        Text(
                            text = accionMensaje,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF14532D),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                if (modoEdicion) {
                    errorValidacion?.let { err ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFEF2F2),
                            border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                        ) {
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF991B1B),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Text("Datos Personales y Contacto", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                    OutlinedTextField(
                        value = nombreEdit,
                        onValueChange = { nombreEdit = it },
                        label = { Text("Nombre completo") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = telefonoEdit,
                        onValueChange = { telefonoEdit = it },
                        label = { Text("Teléfono") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                    Text("Datos del Vehículo", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                    Text("Tipo de vehículo:", style = MaterialTheme.typography.labelMedium, color = Color(0xFF525B50))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        tiposVehiculoDisponibles.chunked(3).forEach { fila ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                fila.forEach { tipo ->
                                    FilterChip(
                                        selected = vehiculoTipoEdit.equals(tipo, ignoreCase = true),
                                        onClick = { vehiculoTipoEdit = tipo },
                                        label = { Text(tipo, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }
                    OutlinedTextField(
                        value = vehiculoTipoEdit,
                        onValueChange = { vehiculoTipoEdit = it },
                        label = { Text("Tipo de vehículo (texto)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = vehiculoMarcaEdit,
                            onValueChange = { vehiculoMarcaEdit = it },
                            label = { Text("Marca") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = vehiculoModeloEdit,
                            onValueChange = { vehiculoModeloEdit = it },
                            label = { Text("Modelo") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = vehiculoColorEdit,
                            onValueChange = { vehiculoColorEdit = it },
                            label = { Text("Color") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = vehiculoAnioEdit,
                            onValueChange = { vehiculoAnioEdit = it.filter(Char::isDigit).take(4) },
                            label = { Text("Año") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = placaEdit,
                            onValueChange = { placaEdit = it.uppercase() },
                            label = { Text("Placa") },
                            singleLine = true,
                            modifier = Modifier.weight(1.2f)
                        )
                        OutlinedTextField(
                            value = capacidadEdit,
                            onValueChange = { capacidadEdit = it.filter(Char::isDigit).take(2) },
                            label = { Text("Cap. pax") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f)
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                    Text("Tarifas del Conductor (₡)", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = tarifaBaseEdit,
                            onValueChange = { tarifaBaseEdit = it.filter(Char::isDigit) },
                            label = { Text("Tarifa base (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = tarifaKmEdit,
                            onValueChange = { tarifaKmEdit = it.filter(Char::isDigit) },
                            label = { Text("Precio / km (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (ViajeRepository.esVehiculoCargo(vehiculoTipoEdit)) {
                        OutlinedTextField(
                            value = tarifaBaseCargaEdit,
                            onValueChange = { tarifaBaseCargaEdit = it.filter(Char::isDigit) },
                            label = { Text("Tarifa base con carga / flete (₡)") },
                            placeholder = { Text("Opcional · Ej: 3000") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (ViajeRepository.esVehiculoMoto(vehiculoTipoEdit)) {
                        Text("Equipamiento en Moto", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = tieneCascoExtraEdit,
                                onCheckedChange = { tieneCascoExtraEdit = it }
                            )
                            Text("Cuento con casco extra para pasajero", style = MaterialTheme.typography.bodySmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = tieneCapaDisponibleEdit,
                                onCheckedChange = { tieneCapaDisponibleEdit = it }
                            )
                            Text("Cuento con capa disponible", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                    Text("Licencia y Suscripción Mensual", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                    Text("Estado de la licencia/cuenta:", style = MaterialTheme.typography.labelMedium, color = Color(0xFF525B50))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("activo" to "Activo", "inactivo" to "Inactivo").forEach { (valor, etiqueta) ->
                            FilterChip(
                                selected = estadoCuentaEdit == valor,
                                onClick = { estadoCuentaEdit = valor },
                                label = { Text(etiqueta) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("pendiente" to "Pendiente", "bloqueado" to "Bloqueado").forEach { (valor, etiqueta) ->
                            FilterChip(
                                selected = estadoCuentaEdit == valor,
                                onClick = { estadoCuentaEdit = valor },
                                label = { Text(etiqueta) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Pago mensual al día", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = if (mensualidadPendienteEdit) "Estado actual: Pago pendiente" else "Estado actual: Suscripción pagada",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (mensualidadPendienteEdit) Color(0xFFB45309) else Color(0xFF15803D)
                            )
                        }
                        Switch(
                            checked = !mensualidadPendienteEdit,
                            onCheckedChange = { mensualidadPendienteEdit = !it }
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = fechaLicenciaEdit,
                            onValueChange = { fechaLicenciaEdit = it },
                            label = { Text("Vencimiento (dd/MM/yyyy)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = {
                                val cal = Calendar.getInstance(TimeZone.getTimeZone("America/Costa_Rica"))
                                cal.add(Calendar.MONTH, 1)
                                fechaLicenciaEdit = formatearFechaDdMmYyyy(cal.timeInMillis)
                                mensualidadPendienteEdit = false
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("+1 mes", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                    Text("Aprobación de Documentos", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                    DocumentoAprobacionToggleRow("Foto Vehículo", docVehiculoOkEdit) { docVehiculoOkEdit = it }
                    DocumentoAprobacionToggleRow("Foto Cédula", docCedulaOkEdit) { docCedulaOkEdit = it }
                    DocumentoAprobacionToggleRow("Foto Licencia", docLicenciaOkEdit) { docLicenciaOkEdit = it }
                    DocumentoAprobacionToggleRow("Marchamo / RTV", docCirculacionOkEdit) { docCirculacionOkEdit = it }
                } else {
                    Text(conductor.nombre, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    val detalleVehiculo = listOf(
                        conductor.vehiculoTipo,
                        conductor.vehiculoMarca,
                        conductor.vehiculoModelo,
                        conductor.vehiculoColor,
                        conductor.vehiculoAnio
                    ).filter { it.isNotBlank() }.joinToString(" · ")
                    Text("Vehículo: ${detalleVehiculo.ifBlank { conductor.vehiculoTipo }} · Placa: ${conductor.placa}")
                    Text("Capacidad: ${conductor.capacidad} pasajeros", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF7F8F6),
                        border = BorderStroke(1.dp, Color(0xFFE2E6DF))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Estado: ${conductor.estadoCuenta.uppercase()}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (conductor.estadoCuenta == "activo") Color(0xFF15803D) else Color(0xFF92400E),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "${conductor.etiquetaLicencia} (${conductor.fechaLicenciaTexto})",
                                    fontFamily = FontFamily.Monospace,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (conductor.estadoLicencia == "vencida") MaterialTheme.colorScheme.error else Color(0xFF525B50)
                                )
                                Text(
                                    text = if (conductor.mensualidadPendiente) "Suscripción: Pago pendiente" else "Suscripción: Al día",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (conductor.mensualidadPendiente) Color(0xFFB45309) else Color(0xFF15803D)
                                )
                            }
                            Button(
                                onClick = onRenovarLicencia,
                                enabled = !renovandoLicencia,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF15803D),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = if (renovandoLicencia) "Renovando..." else "Renovar +1 Mes",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    Text("Cédula: ${conductor.cedulaHash.ifBlank { "No registrada" }}")
                    Text(
                        text = "Teléfono: ${conductor.telefono.ifBlank { if (cargandoDocumentos) "Cargando..." else "No registrado" }}",
                        fontFamily = FontFamily.Monospace
                    )
                    Text("Licencia: ${conductor.etiquetaLicencia} (vence ${conductor.fechaLicenciaTexto})", fontFamily = FontFamily.Monospace)
                    Text("Tarifa base: ${formatearColones(conductor.tarifaBase)} · Precio/km: ${formatearColones(conductor.tarifaPorKm)}")
                    conductor.tarifaBaseCarga?.let {
                        Text("Tarifa base con carga / flete: ${formatearColones(it)}", fontWeight = FontWeight.SemiBold, color = Color(0xFF92400E))
                    }
                    if (ViajeRepository.esVehiculoMoto(conductor.vehiculoTipo)) {
                        Text(
                            text = "Moto · Casco extra: ${if (conductor.tieneCascoExtra) "Sí" else "No"} · Capa impermeable: ${if (conductor.tieneCapaDisponible) "Sí" else "No"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF166534)
                        )
                    }
                    Text("Generado en el mes: ${formatearColones(conductor.gananciasMes)}", fontFamily = FontFamily.Monospace)

                    Button(
                        onClick = { abrirWhatsAppContacto(context, conductor.telefono, conductor.nombre) },
                        enabled = tieneTelefonoValido && !cargandoDocumentos,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF16A34A),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        Text(
                            text = when {
                                cargandoDocumentos -> "Cargando teléfono..."
                                tieneTelefonoValido -> "Contactar por WhatsApp"
                                else -> "WhatsApp no disponible (sin teléfono)"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Text("Documentos Adjuntos", fontWeight = FontWeight.Bold)

                if (cargandoDocumentos) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text("Cargando fotografías...", style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    DocumentoFotoCard("Vehículo", documentos?.fotoVehiculo.orEmpty(), if (modoEdicion) docVehiculoOkEdit else conductor.docVehiculoAprobado)
                    DocumentoFotoCard("Cédula", documentos?.fotoCedula.orEmpty(), if (modoEdicion) docCedulaOkEdit else conductor.docCedulaAprobado)
                    DocumentoFotoCard("Licencia de Conducir", documentos?.fotoLicencia.orEmpty(), if (modoEdicion) docLicenciaOkEdit else conductor.docLicenciaAprobado)
                    DocumentoFotoCard("RTV / Circulación / Marchamo", documentos?.fotoCirculacion.orEmpty(), if (modoEdicion) docCirculacionOkEdit else conductor.docCirculacionAprobado)
                }

                if (!modoEdicion && conductor.estadoCuenta == "pendiente") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = onAprobarYActivar,
                        enabled = !aprobando,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF15803D),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text(
                            text = if (aprobando) "Aprobando..." else "Aprobar y Activar Conductor",
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Al aprobar, pasará a estado activo con licencia vigente por 1 mes desde hoy.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            if (modoEdicion) {
                Button(
                    enabled = !guardandoFicha,
                    onClick = {
                        val nombreLimpio = nombreEdit.trim()
                        val placaLimpia = placaEdit.trim().uppercase()
                        val cap = capacidadEdit.toIntOrNull()
                        val tBase = tarifaBaseEdit.toDoubleOrNull()
                        val tKm = tarifaKmEdit.toDoubleOrNull()
                        val esCargoEdit = ViajeRepository.esVehiculoCargo(vehiculoTipoEdit)
                        val tCarga = if (esCargoEdit && tarifaBaseCargaEdit.isNotBlank()) tarifaBaseCargaEdit.toDoubleOrNull() else null
                        val expMs = parseFechaVencimientoAdminMillis(fechaLicenciaEdit)
                        when {
                            nombreLimpio.length < 2 -> errorValidacion = "El nombre debe tener al menos 2 caracteres."
                            telefonoEdit.trim().isNotEmpty() && telefonoEdit.trim().length < 6 -> errorValidacion = "El teléfono debe tener al menos 6 dígitos."
                            vehiculoTipoEdit.trim().length < 2 -> errorValidacion = "Indica un tipo de vehículo válido."
                            placaLimpia.length < 3 -> errorValidacion = "La placa debe tener al menos 3 caracteres."
                            cap == null || cap !in 1..24 -> errorValidacion = "La capacidad debe estar entre 1 y 24 pasajeros."
                            tBase == null || tBase < 500.0 || tBase > 50000.0 -> errorValidacion = "La tarifa base debe estar entre ₡500 y ₡50,000."
                            tKm == null || tKm < 100.0 || tKm > 10000.0 -> errorValidacion = "El precio por km debe estar entre ₡100 y ₡10,000."
                            esCargoEdit && tarifaBaseCargaEdit.isNotBlank() && (tCarga == null || tCarga < 500.0 || tCarga > 150000.0) -> errorValidacion = "La tarifa con carga debe estar entre ₡500 y ₡150,000."
                            expMs == null -> errorValidacion = "Formato de fecha inválido. Usa dd/MM/yyyy (ej. 24/12/2026)."
                            else -> {
                                errorValidacion = null
                                onGuardarFicha(
                                    nombreLimpio,
                                    telefonoEdit.trim(),
                                    vehiculoTipoEdit.trim(),
                                    vehiculoMarcaEdit.trim(),
                                    vehiculoModeloEdit.trim(),
                                    vehiculoColorEdit.trim(),
                                    vehiculoAnioEdit.trim(),
                                    placaLimpia,
                                    cap,
                                    tBase,
                                    tKm,
                                    tCarga,
                                    ViajeRepository.esVehiculoMoto(vehiculoTipoEdit) && tieneCascoExtraEdit,
                                    ViajeRepository.esVehiculoMoto(vehiculoTipoEdit) && tieneCapaDisponibleEdit,
                                    estadoCuentaEdit,
                                    mensualidadPendienteEdit,
                                    expMs,
                                    docVehiculoOkEdit,
                                    docCedulaOkEdit,
                                    docLicenciaOkEdit,
                                    docCirculacionOkEdit
                                ) {
                                    modoEdicion = false
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF15803D),
                        contentColor = Color.White
                    )
                ) {
                    Text(if (guardandoFicha) "Guardando..." else "Guardar cambios", fontWeight = FontWeight.Bold)
                }
            } else {
                TextButton(onClick = onDismiss) { Text("Cerrar") }
            }
        },
        dismissButton = {
            if (modoEdicion) {
                TextButton(
                    enabled = !guardandoFicha,
                    onClick = {
                        restablecerCamposDesdeConductor()
                        modoEdicion = false
                    }
                ) { Text("Cancelar") }
            }
        }
    )
}

@Composable
private fun DocumentoAprobacionToggleRow(
    titulo: String,
    aprobado: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(titulo, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            Text(
                text = if (aprobado) "Aprobado" else "Pendiente de aprobación",
                style = MaterialTheme.typography.labelSmall,
                color = if (aprobado) Color(0xFF15803D) else Color(0xFFB45309)
            )
        }
        Switch(
            checked = aprobado,
            onCheckedChange = onToggle
        )
    }
}

@Composable
private fun DocumentoFotoCard(titulo: String, dataUrl: String, aprobado: Boolean? = null) {
    val bitmap: ImageBitmap? = remember(dataUrl) {
        decodificarDataUrlBitmap(dataUrl)
    }
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF7F8F6))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(titulo, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
                aprobado?.let { ok ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (ok) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                    ) {
                        Text(
                            text = if (ok) "Aprobado" else "Pendiente",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (ok) Color(0xFF15803D) else Color(0xFF92400E),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = titulo,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(10.dp))
                )
            } else {
                Text("Sin documento adjunto", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
            }
        }
    }
}

private fun decodificarDataUrlBitmap(raw: String): ImageBitmap? {
    if (raw.isBlank()) return null
    return try {
        val base64Part = raw.substringAfter("base64,", raw).trim()
        if (base64Part.isBlank()) return null
        val bytes = Base64.decode(base64Part, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

@Composable
private fun ConfiguracionAdminCard(
    config: ConfiguracionGeneralUi,
    onSave: (ConfiguracionGeneralUi) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var linkDescarga by remember(config.linkDescarga) { mutableStateOf(config.linkDescarga) }
    var copiado by remember { mutableStateOf(false) }
    var whatsapp by remember(config.whatsappSoporte) { mutableStateOf(config.whatsappSoporte) }
    var sinpe by remember(config.sinpeNumero) { mutableStateOf(config.sinpeNumero) }
    var sinpeTitular by remember(config.sinpeTitular) { mutableStateOf(config.sinpeTitular) }
    var adminNombre by remember(config.adminNombre) { mutableStateOf(config.adminNombre) }
    var adminEmail by remember(config.adminEmail) { mutableStateOf(config.adminEmail) }
    var montoBaseConductorText by remember(config.montoMensualConductorBase) {
        mutableStateOf(config.montoMensualConductorBase.toString())
    }
    var anioBaseMensualidadText by remember(config.anioBaseMensualidad) {
        mutableStateOf(config.anioBaseMensualidad.toString())
    }
    var terminos by remember(config.terminosCondiciones) {
        mutableStateOf(
            config.terminosCondiciones.ifBlank {
                ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
            }
        )
    }
    var terminosPasajero by remember(config.terminosCondicionesPasajero) {
        mutableStateOf(
            config.terminosCondicionesPasajero.ifBlank {
                ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO
            }
        )
    }
    var tipos by remember(config.tiposVehiculo) { mutableStateOf(config.tiposVehiculo) }
    var nuevoTipoNombre by remember { mutableStateOf("") }
    var nuevoTipoCap by remember { mutableStateOf("2") }
    var multNormalText by remember(config.multiplicadorTopeNormal) {
        mutableStateOf(config.multiplicadorTopeNormal.toString())
    }
    var multCargaText by remember(config.multiplicadorTopeCarga) {
        mutableStateOf(config.multiplicadorTopeCarga.toString())
    }

    val montoBaseCalc = (montoBaseConductorText.toIntOrNull() ?: ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE)
        .coerceIn(500, 1_000_000)
    val anioBaseCalc = (anioBaseMensualidadText.toIntOrNull() ?: ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD)
        .coerceIn(2020, 2100)
    val calculoMensualidad = remember(montoBaseCalc, anioBaseCalc) {
        calcularMensualidadConductorActual(montoBase = montoBaseCalc, anioBase = anioBaseCalc)
    }
    val terminosConductorPreview = remember(terminos, montoBaseCalc, anioBaseCalc) {
        resolverTerminosConductorDinamicos(
            textoBase = terminos,
            montoBase = montoBaseCalc,
            anioBase = anioBaseCalc
        )
    }

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Enlace de Descarga, Soporte, SINPE, Términos y Vehículos", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = linkDescarga,
                onValueChange = {
                    linkDescarga = it
                    copiado = false
                },
                label = { Text("Enlace de descarga de la App (Compartir)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(
                onClick = {
                    clipboardManager.setText(AnnotatedString(linkDescarga.trim()))
                    copiado = true
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (copiado) "Enlace copiado" else "Copiar enlace de descarga")
            }
            OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("WhatsApp Soporte (62546546)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpe, onValueChange = { sinpe = it }, label = { Text("Número SINPE Móvil") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sinpeTitular, onValueChange = { sinpeTitular = it }, label = { Text("Titular SINPE") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminNombre, onValueChange = { adminNombre = it }, label = { Text("Nombre Administrador") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = adminEmail, onValueChange = { adminEmail = it }, label = { Text("Correo Administrador") }, modifier = Modifier.fillMaxWidth())

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF0FDF4),
                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Términos y Condiciones del Pasajero (Exclusivos)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14532D)
                    )
                    Text(
                        text = "Regla base: Para el pasajero no se incluye ningún tipo de cobro de app, comisión ni cargo adicional.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF166534)
                    )
                    OutlinedTextField(
                        value = terminosPasajero,
                        onValueChange = { terminosPasajero = it },
                        label = { Text("Términos del Pasajero (Tiempo real)") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = {
                            terminosPasajero =
                                cr.viajerural.app.data.ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Restaurar texto base sin cobro")
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF0FDF4),
                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Mensualidad del Conductor (+10% automático cada 1 de enero)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14532D)
                    )
                    Text(
                        text = "Fórmula en zona horaria America/Costa_Rica: montoVigente = montoBase * (1.10 ^ n), donde n = añoActual - añoBase.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF166534)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = montoBaseConductorText,
                            onValueChange = { montoBaseConductorText = it.filter(Char::isDigit) },
                            label = { Text("Monto base (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = anioBaseMensualidadText,
                            onValueChange = { anioBaseMensualidadText = it.filter(Char::isDigit).take(4) },
                            label = { Text("Año base") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                text = "Monto vigente (${calculoMensualidad.anioActual}): ${formatearColonesEntero(calculoMensualidad.montoActual)}/mes",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                            Text(
                                text = "Base (${calculoMensualidad.anioBase}): ${formatearColonesEntero(calculoMensualidad.montoBase)} · Incrementos anuales aplicados: ${calculoMensualidad.incrementosAplicados} (+${calculoMensualidad.porcentajeAcumulado}%)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF3F5243)
                            )
                            Text(
                                text = "Próximo 1 de enero (${calculoMensualidad.anioActual + 1}): ${formatearColonesEntero(calculoMensualidad.montoProximoEnero)}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF525B50)
                            )
                        }
                    }

                    Text(
                        text = "Términos y Condiciones del Conductor (Cuota SINPE dinámica)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14532D)
                    )
                    OutlinedTextField(
                        value = terminos,
                        onValueChange = { terminos = it },
                        label = { Text("Texto base (usa {{MONTO_CONDUCTOR_VIGENTE}})") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val token = ViajeRepository.TOKEN_MONTO_CONDUCTOR_VIGENTE
                                if (!terminos.contains(token)) {
                                    terminos = if (terminos.isBlank()) {
                                        ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
                                    } else {
                                        "$terminos\nCuota mensual vigente: $token"
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Insertar variable", style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(
                            onClick = { terminos = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Plantilla base", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF7F8F6),
                        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Vista previa para el conductor:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF525B50)
                            )
                            Text(
                                text = terminosConductorPreview,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF14231A)
                            )
                        }
                    }
                }
            }

            Text("Tipos de Vehículo (Motos, 4x4, etc.)", fontWeight = FontWeight.SemiBold)
            tipos.forEach { t ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${t.nombre} (máx. ${t.maxPasajeros} pax)")
                    TextButton(onClick = { tipos = tipos.filterNot { it.nombre == t.nombre } }) { Text("Quitar") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nuevoTipoNombre, onValueChange = { nuevoTipoNombre = it }, label = { Text("Ej: Moto") }, modifier = Modifier.weight(2f))
                OutlinedTextField(value = nuevoTipoCap, onValueChange = { nuevoTipoCap = it.filter(Char::isDigit) }, label = { Text("Max") }, modifier = Modifier.weight(1f))
            }
            OutlinedButton(
                onClick = {
                    if (nuevoTipoNombre.isNotBlank()) {
                        tipos = tipos + VehiculoTipoUi(nuevoTipoNombre.trim(), nuevoTipoCap.toIntOrNull() ?: 2)
                        nuevoTipoNombre = ""
                    }
                },
                shape = RoundedCornerShape(12.dp)
            ) { Text("Agregar tipo de vehículo") }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFFFBEB),
                border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Topes Máximos y Alerta de Cobro Abusivo",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF92400E)
                    )
                    Text(
                        text = "Límite máximo permitido respecto al monto promedio de referencia (ej. 1.6x normal, 2.2x carga/flete).",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF78350F)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = multNormalText,
                            onValueChange = { txt ->
                                multNormalText = txt.filter { it.isDigit() || it == '.' }
                            },
                            label = { Text("Tope normal (x)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = multCargaText,
                            onValueChange = { txt ->
                                multCargaText = txt.filter { it.isDigit() || it == '.' }
                            },
                            label = { Text("Tope carga Pickup (x)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Button(
                onClick = {
                    val multNormalVal = (multNormalText.toDoubleOrNull() ?: ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_NORMAL)
                        .coerceIn(1.1, 5.0)
                    val multCargaVal = (multCargaText.toDoubleOrNull() ?: ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_CARGA)
                        .coerceIn(1.1, 5.0)
                    onSave(
                        config.copy(
                            linkDescarga = linkDescarga.trim(),
                            whatsappSoporte = whatsapp,
                            sinpeNumero = sinpe,
                            sinpeTitular = sinpeTitular,
                            adminNombre = adminNombre,
                            adminEmail = adminEmail,
                            terminosCondiciones = terminos,
                            terminosCondicionesPasajero = terminosPasajero,
                            montoMensualConductorBase = montoBaseCalc,
                            anioBaseMensualidad = anioBaseCalc,
                            multiplicadorTopeNormal = multNormalVal,
                            multiplicadorTopeCarga = multCargaVal,
                            tiposVehiculo = tipos
                        )
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) { Text("Guardar Configuración Global", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun EditarPasajeroDialog(
    pasajero: PasajeroAdminItem,
    gestionando: Boolean,
    onToggleBloqueo: () -> Unit,
    onEliminarCuenta: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (nombre: String, telefono: String, email: String, cedula: String) -> Unit
) {
    val context = LocalContext.current
    var nombre by remember(pasajero.uid) { mutableStateOf(pasajero.nombre) }
    var telefono by remember(pasajero.uid) { mutableStateOf(pasajero.telefono) }
    var email by remember(pasajero.uid) { mutableStateOf(pasajero.email) }
    var cedula by remember(pasajero.uid) { mutableStateOf(pasajero.cedula) }
    var confirmarEliminacion by remember(pasajero.uid) { mutableStateOf(false) }
    val tieneTelefonoValido = telefono.count { it.isDigit() } >= 8

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Ficha de Pasajero", fontWeight = FontWeight.Bold)
                Text(
                    text = "Estado: ${if (pasajero.bloqueado) "BLOQUEADO" else "ACTIVO"}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (pasajero.bloqueado) MaterialTheme.colorScheme.error else Color(0xFF15803D),
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = telefono, onValueChange = { telefono = it }, label = { Text("Teléfono") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = cedula, onValueChange = { cedula = it }, label = { Text("Cédula") }, modifier = Modifier.fillMaxWidth())

                Button(
                    onClick = { abrirWhatsAppContacto(context, telefono, nombre) },
                    enabled = tieneTelefonoValido,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF16A34A),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text(
                        text = if (tieneTelefonoValido) "Contactar por WhatsApp" else "WhatsApp no disponible (sin teléfono)",
                        fontWeight = FontWeight.Bold
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Text("Gestión de Cuenta", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)

                OutlinedButton(
                    onClick = onToggleBloqueo,
                    enabled = !gestionando,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (pasajero.bloqueado) Color(0xFF15803D) else Color(0xFFB45309)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (pasajero.bloqueado) "Desbloquear Cuenta" else "Bloquear Cuenta",
                        fontWeight = FontWeight.Bold
                    )
                }

                if (!confirmarEliminacion) {
                    OutlinedButton(
                        onClick = { confirmarEliminacion = true },
                        enabled = !gestionando,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Eliminar Cuenta", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Surface(
                        color = Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "¿Eliminar la cuenta de ${pasajero.nombre} en Firestore? Esta acción no se puede deshacer.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF991B1B),
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = onEliminarCuenta,
                                    enabled = !gestionando,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.error,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(if (gestionando) "Eliminando..." else "Confirmar")
                                }
                                OutlinedButton(
                                    onClick = { confirmarEliminacion = false },
                                    enabled = !gestionando,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Volver")
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(nombre, telefono, email, cedula) },
                enabled = !gestionando
            ) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    )
}
