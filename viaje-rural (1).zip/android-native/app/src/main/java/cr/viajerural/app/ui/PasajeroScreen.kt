package cr.viajerural.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.Timestamp
import cr.viajerural.app.data.RutaFavoritaData
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.UbicacionSugerida
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.util.ImageCompressionUtils
import cr.viajerural.app.viewmodel.OpcionVehiculoDisponibleUi
import cr.viajerural.app.viewmodel.PasajeroTab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Pantalla Principal del Pasajero (Jetpack Compose) con BottomNavigation (3 pestañas):
 * - Viaje: Rutas favoritas, autocompletado de ubicación actual y destino, GPS de alta precisión, selección de vehículo, PIN persistente y modales Mapa/Chat.
 * - Historial: Carga lazy limit(20) solo al tocar la pestaña.
 * - Perfil: Foto de perfil comprimida (máx. 800px / JPEG 70%), datos bloqueados, rutas favoritas, compartir app y cerrar sesión.
 */
@Composable
fun PasajeroScreen(
    tabActual: PasajeroTab,
    onSelectTab: (PasajeroTab) -> Unit,
    estadoViaje: String,
    pinPersistente: String?,
    conductorNombre: String?,
    conductorPlaca: String?,
    etaMinutos: Int?,
    montoAproximado: Int,
    rutasFavoritas: List<RutaFavoritaData>,
    sugerenciasOrigen: List<UbicacionSugerida>,
    sugerenciasDestino: List<UbicacionSugerida>,
    buscandoDestino: Boolean = false,
    historial: List<Map<String, Any>>,
    cargandoHistorial: Boolean,
    mostrarModalPago: Boolean,
    onBuscarOrigen: (String, Double, Double) -> Unit,
    onBuscarDestino: (String, Double, Double) -> Unit,
    onGuardarFavorita: (RutaFavoritaData) -> Unit,
    onEliminarFavorita: (String) -> Unit,
    onSolicitarViaje: (
        pasajeros: Int,
        origen: String,
        origenLat: Double,
        origenLng: Double,
        destino: String,
        destinoLat: Double,
        destinoLng: Double,
        resenaUbicacion: String,
        tiposVehiculoPermitidos: List<String>,
        esCargaFlete: Boolean
    ) -> Unit,
    onCalificarConductor: (estrellas: Int, comentario: String) -> Unit,
    onDismissModalPago: () -> Unit,
    nombrePasajero: String = "",
    fotoUrl: String = "",
    actualizandoFoto: Boolean = false,
    onActualizarFotoPerfil: (String) -> Unit = {},
    misSolicitudes: List<SolicitudCambioData> = emptyList(),
    onEnviarSolicitudCambio: (cambios: Map<String, Any>, motivo: String) -> Unit = { _, _ -> },
    avisoCancelacion: String? = null,
    onDismissAvisoCancelacion: () -> Unit = {},
    onCancelarViaje: (motivo: String) -> Unit = {},
    precisionUbicacionMetros: Int? = null,
    onUsarGpsPreciso: () -> Unit = {},
    onPrecisionActualizada: (Int?) -> Unit = {},
    linkDescarga: String = "https://viajerural.com/descargar",
    onCerrarSesion: () -> Unit = {},
    solicitandoViaje: Boolean = false,
    errorSolicitud: String? = null,
    onDismissErrorSolicitud: () -> Unit = {},
    origenViajeActivo: String? = null,
    destinoViajeActivo: String? = null,
    pasajerosViajeActivo: Int? = null,
    resenaViajeActivo: String? = null,
    mensajesChat: List<Map<String, Any>> = emptyList(),
    onAbrirChat: () -> Unit = {},
    onCerrarChat: () -> Unit = {},
    onEnviarMensajeChat: (String) -> Unit = {},
    opcionesVehiculosDisponibles: List<OpcionVehiculoDisponibleUi> = emptyList(),
    buscandoConductores: Boolean = false,
    busquedaVehiculosRealizada: Boolean = false,
    distanciaViajeKm: Double = 0.0,
    mensajeDisponibilidad: String? = null,
    onBuscarVehiculosDisponibles: (
        origenLat: Double,
        origenLng: Double,
        destinoLat: Double,
        destinoLng: Double,
        cantidadPasajeros: Int
    ) -> Unit = { _, _, _, _, _ -> },
    onLimpiarBusquedaVehiculos: () -> Unit = {},
    chatNoLeidos: Int = 0,
    alertaChatFlotante: String? = null,
    onDismissAlertaChat: () -> Unit = {},
    montoAPagar: Int = 0,
    conductorLat: Double? = null,
    conductorLng: Double? = null,
    viajeActivoId: String? = null,
    conductorLlego: Boolean = false,
    distanciaTexto: String? = null,
    distanciaInicialRecogidaKm: Double? = null,
    origenViajeLat: Double? = null,
    origenViajeLng: Double? = null,
    terminosCondicionesPasajero: String = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO,
    viajeActivoEsCargaFlete: Boolean = false
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    @Suppress("DEPRECATION")
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var mostrarMapaModal by remember { mutableStateOf(false) }
    var mostrarChatModal by remember { mutableStateOf(false) }
    var mostrarModalSolicitud by remember { mutableStateOf(false) }
    var mostrarModalCancelar by remember { mutableStateOf(false) }
    var mostrarModalPermisos by remember { mutableStateOf(false) }
    var mostrarModalTerminosPasajero by remember { mutableStateOf(false) }
    var aceptoTerminosPasajero by remember { mutableStateOf(false) }
    var mesHistorial by remember { mutableStateOf(obtenerMesActualCostaRicaKey()) }
    var motivoCancelacionInput by remember { mutableStateOf("") }
    // Se conserva en la raíz de PasajeroScreen para que no se reinicie al cambiar de pestaña ni al enviar la solicitud
    var cantidadPasajeros by remember { mutableStateOf(0) }
    var tiposVehiculoSeleccionados by remember { mutableStateOf(emptySet<String>()) }
    var esCargaFleteSeleccionado by remember { mutableStateOf(false) }
    var gpsActualLat by remember { mutableDoubleStateOf(9.3895) }
    var gpsActualLng by remember { mutableDoubleStateOf(-83.6490) }
    var origen by remember { mutableStateOf("") }
    var origenLat by remember { mutableDoubleStateOf(9.3895) }
    var origenLng by remember { mutableDoubleStateOf(-83.6490) }
    var cargandoGpsOrigen by remember { mutableStateOf(false) }
    var mensajeGpsOrigen by remember { mutableStateOf<String?>(null) }
    var ubicacionInicialCargada by remember { mutableStateOf(false) }
    var destino by remember { mutableStateOf("") }
    var destinoLat by remember { mutableDoubleStateOf(9.3738) }
    var destinoLng by remember { mutableDoubleStateOf(-83.7042) }
    var mostrarListaOrigen by remember { mutableStateOf(false) }
    var mostrarListaDestino by remember { mutableStateOf(false) }
    var resenaUbicacion by remember { mutableStateOf("") }
    var estrellas by remember { mutableIntStateOf(5) }
    var comentario by remember { mutableStateOf("") }
    var comprimiendoFoto by remember { mutableStateOf(false) }

    LaunchedEffect(mostrarModalPago) {
        if (mostrarModalPago) {
            estrellas = 5
            comentario = ""
            mostrarModalCancelar = false
            mostrarChatModal = false
            mostrarMapaModal = false
        }
    }

    fun tienePermisoUbicacion(): Boolean {
        val permisoFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val permisoCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return permisoFine || permisoCoarse
    }

    suspend fun capturarGpsYGeocodificar(actualizarOrigenTexto: Boolean) {
        if (!tienePermisoUbicacion()) return
        cargandoGpsOrigen = true
        mensajeGpsOrigen = null
        try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val ctsAlta = CancellationTokenSource()
            var loc = try {
                client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, ctsAlta.token).await()
            } catch (_: Throwable) {
                null
            } finally {
                ctsAlta.cancel()
            }

            if (loc == null) {
                val ctsBalanceada = CancellationTokenSource()
                loc = try {
                    client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, ctsBalanceada.token).await()
                } catch (_: Throwable) {
                    null
                } finally {
                    ctsBalanceada.cancel()
                }
            }

            if (loc == null) {
                loc = try {
                    client.lastLocation.await()
                } catch (_: Throwable) {
                    null
                }
            }

            if (loc != null) {
                gpsActualLat = loc.latitude
                gpsActualLng = loc.longitude
                origenLat = loc.latitude
                origenLng = loc.longitude
                onPrecisionActualizada(if (loc.hasAccuracy()) loc.accuracy.toInt() else null)
                if (actualizarOrigenTexto) {
                    val direccionLegible = ViajeRepository.reverseGeocodificarUbicacion(
                        context = context,
                        lat = loc.latitude,
                        lng = loc.longitude
                    )
                    origen = direccionLegible
                    mostrarListaOrigen = false
                    tiposVehiculoSeleccionados = emptySet()
                    onLimpiarBusquedaVehiculos()
                }
            } else {
                mensajeGpsOrigen = "Activa el GPS del teléfono e intenta de nuevo."
            }
        } catch (_: Throwable) {
            mensajeGpsOrigen = "No se pudo obtener la ubicación GPS actual."
        } finally {
            cargandoGpsOrigen = false
        }
    }

    val launcherPermisoUbicacionOrigen = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { resultados ->
        val concedido = resultados[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            resultados[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            tienePermisoUbicacion()
        if (concedido) {
            scope.launch {
                capturarGpsYGeocodificar(actualizarOrigenTexto = true)
                onUsarGpsPreciso()
            }
        } else {
            mensajeGpsOrigen = "Permiso de ubicación necesario para detectar tu dirección."
        }
    }

    fun solicitarGpsYGeocodificar() {
        if (tienePermisoUbicacion()) {
            scope.launch {
                capturarGpsYGeocodificar(actualizarOrigenTexto = true)
                onUsarGpsPreciso()
            }
        } else {
            launcherPermisoUbicacionOrigen.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    // Al entrar por primera vez, si el permiso ya está concedido, llenar "Ubicación actual" automáticamente
    LaunchedEffect(Unit) {
        if (!ubicacionInicialCargada) {
            ubicacionInicialCargada = true
            if (tienePermisoUbicacion()) {
                capturarGpsYGeocodificar(actualizarOrigenTexto = true)
            }
        }
    }

    // Si el usuario concede el permiso en Ajustes o en el banner inicial mientras origen está vacío, autocompletar
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && origen.isBlank() && tienePermisoUbicacion() && !cargandoGpsOrigen) {
                scope.launch {
                    capturarGpsYGeocodificar(actualizarOrigenTexto = true)
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val pickFotoPerfil = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { selectedUri ->
            scope.launch {
                comprimiendoFoto = true
                val comprimida = withContext(Dispatchers.IO) {
                    ImageCompressionUtils.comprimirImagenABase64(
                        context = context,
                        uri = selectedUri,
                        maxAnchoPx = 800,
                        calidadJpeg = 70,
                        maxBase64Chars = 140_000
                    )
                }
                comprimiendoFoto = false
                if (!comprimida.isNullOrBlank()) {
                    onActualizarFotoPerfil(comprimida)
                }
            }
        }
    }

    LaunchedEffect(estadoViaje) {
        if (estadoViaje != "aceptado" && mostrarMapaModal) mostrarMapaModal = false
        if (estadoViaje != "aceptado" && estadoViaje != "en_curso") mostrarChatModal = false
    }

    LaunchedEffect(avisoCancelacion) {
        if (!avisoCancelacion.isNullOrBlank()) {
            mostrarMapaModal = false
            mostrarChatModal = false
            mostrarModalCancelar = false
        }
    }

    // Mantener seleccionados solo los tipos de vehículo que siguen disponibles tras la búsqueda
    LaunchedEffect(opcionesVehiculosDisponibles) {
        val idsDisponibles = opcionesVehiculosDisponibles.map { it.tipoId }.toSet()
        tiposVehiculoSeleccionados = tiposVehiculoSeleccionados.intersect(idsDisponibles)
    }

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Scaffold(
        containerColor = Color(0xFFF7F8F6),
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.VIAJE,
                    onClick = { onSelectTab(PasajeroTab.VIAJE) },
                    icon = { Text("🚗") },
                    label = { Text("Viaje") }
                )
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.HISTORIAL,
                    onClick = { onSelectTab(PasajeroTab.HISTORIAL) },
                    icon = { Text("📜") },
                    label = { Text("Historial") }
                )
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.PERFIL,
                    onClick = { onSelectTab(PasajeroTab.PERFIL) },
                    icon = { Text("👤") },
                    label = { Text("Perfil") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            when (tabActual) {
                PasajeroTab.VIAJE -> {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Viaje Rural",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14231A)
                                )
                                Text(
                                    text = "Solicita transporte local en efectivo",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedIconButton(
                                    onClick = { mostrarModalPermisos = true }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Permisos y Configuración",
                                        tint = Color(0xFF15803D)
                                    )
                                }
                                OutlinedButton(
                                    onClick = { compartirAppPasajero(context, linkDescarga) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Compartir App")
                                }
                            }
                        }

                        if (!avisoCancelacion.isNullOrBlank()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Viaje cancelado", fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                        Text(avisoCancelacion, style = MaterialTheme.typography.bodySmall, color = Color(0xFF7F1D1D))
                                    }
                                    TextButton(onClick = onDismissAvisoCancelacion) { Text("Cerrar") }
                                }
                            }
                        }

                        if ((estadoViaje == "aceptado" || estadoViaje == "en_curso") && !alertaChatFlotante.isNullOrBlank()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFF15803D)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFDCFCE7))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Nuevo mensaje en el chat", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                                        Text(alertaChatFlotante, style = MaterialTheme.typography.bodySmall, color = Color(0xFF14231A))
                                    }
                                    Row {
                                        TextButton(
                                            onClick = {
                                                onDismissAlertaChat()
                                                onAbrirChat()
                                                mostrarChatModal = true
                                            }
                                        ) { Text("Ver") }
                                        TextButton(onClick = onDismissAlertaChat) { Text("✕") }
                                    }
                                }
                            }
                        }

                        if (estadoViaje == "aceptado") {
                            var distanciaInicialFallbackKm by remember(viajeActivoId) {
                                mutableStateOf<Double?>(null)
                            }
                            val distActualKm = remember(conductorLlego, conductorLat, conductorLng, origenViajeLat, origenViajeLng) {
                                when {
                                    conductorLlego -> 0.0
                                    conductorLat != null && conductorLng != null && origenViajeLat != null && origenViajeLng != null -> {
                                        val res = FloatArray(1)
                                        Location.distanceBetween(conductorLat, conductorLng, origenViajeLat, origenViajeLng, res)
                                        (res[0].coerceAtLeast(0f) / 1000.0)
                                    }
                                    else -> null
                                }
                            }
                            LaunchedEffect(viajeActivoId, distActualKm, distanciaInicialRecogidaKm) {
                                if ((distanciaInicialRecogidaKm == null || distanciaInicialRecogidaKm <= 0.0) &&
                                    distanciaInicialFallbackKm == null &&
                                    distActualKm != null
                                ) {
                                    distanciaInicialFallbackKm = distActualKm
                                }
                            }
                            val distInicialKm = when {
                                distanciaInicialRecogidaKm != null && distanciaInicialRecogidaKm > 0.0 -> distanciaInicialRecogidaKm
                                distanciaInicialFallbackKm != null -> distanciaInicialFallbackKm!!
                                distActualKm != null -> distActualKm
                                else -> 0.0
                            }
                            val progresoObjetivo = when {
                                conductorLlego -> 1f
                                distActualKm == null -> 0f
                                distInicialKm <= 0.03 -> if (distActualKm <= 0.03) 1f else 0.9f
                                else -> ((distInicialKm - distActualKm) / distInicialKm).toFloat().coerceIn(0f, 1f)
                            }
                            val progresoAnimado by animateFloatAsState(
                                targetValue = progresoObjetivo,
                                animationSpec = tween(durationMillis = 700),
                                label = "carritoRecogidaProgreso"
                            )
                            val progresoPct = (progresoAnimado * 100f).roundToInt().coerceIn(0, 100)
                            val distanciaLabel = when {
                                conductorLlego -> "El conductor ha llegado"
                                distActualKm != null -> if (distActualKm < 1.0) {
                                    "${(distActualKm * 1000.0).roundToInt()} m"
                                } else {
                                    String.format(Locale.US, "%.1f km", distActualKm)
                                }
                                !distanciaTexto.isNullOrBlank() -> distanciaTexto
                                else -> "Calculando..."
                            }
                            val distanciaInicialLabel = if (distInicialKm > 0.0) {
                                if (distInicialKm < 1.0) "${(distInicialKm * 1000.0).roundToInt()} m"
                                else String.format(Locale.US, "%.1f km", distInicialKm)
                            } else {
                                "--"
                            }

                            if (conductorLlego) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(2.dp, Color(0xFF15803D)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFECFDF5))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF15803D)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "¡Tu conductor ha llegado!",
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color(0xFF14532D),
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                            Text(
                                                text = "${conductorNombre.orEmpty().ifBlank { "Tu conductor" }} ya te espera en el punto de recogida. Entrega tu PIN ${pinPersistente ?: "---"} al abordar.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF166534)
                                            )
                                        }
                                    }
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "PROGRESO DE RECOGIDA",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF525B50)
                                            )
                                            Text(
                                                text = if (conductorLlego) "En tu punto de recogida" else "Conductor en camino",
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF14231A)
                                            )
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (conductorLlego) Color(0xFFECFDF5) else Color(0xFFF7F8F6),
                                            border = BorderStroke(
                                                1.dp,
                                                if (conductorLlego) Color(0xFF15803D) else Color(0xFFE2E6DF)
                                            )
                                        ) {
                                            Text(
                                                text = if (conductorLlego) distanciaLabel else "$distanciaLabel · ~${etaMinutos ?: "--"} min",
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.labelMedium,
                                                color = if (conductorLlego) Color(0xFF15803D) else Color(0xFF14231A)
                                            )
                                        }
                                    }

                                    BoxWithConstraints(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        val density = LocalDensity.current
                                        val badgeSizeDp = 36.dp
                                        val maxTrackPx = with(density) { (maxWidth - badgeSizeDp).coerceAtLeast(0.dp).toPx() }

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp)
                                                .height(10.dp)
                                                .clip(RoundedCornerShape(5.dp))
                                                .background(Color(0xFFE2E6DF))
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth(progresoAnimado)
                                                    .fillMaxHeight()
                                                    .clip(RoundedCornerShape(5.dp))
                                                    .background(Color(0xFF15803D))
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.CenterEnd)
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(if (conductorLlego) Color(0xFF15803D) else Color(0xFFFFFBEB))
                                                .border(
                                                    2.dp,
                                                    if (conductorLlego) Color(0xFF15803D) else Color(0xFFD97706),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Place,
                                                contentDescription = "Punto de recogida",
                                                tint = if (conductorLlego) Color.White else Color(0xFFD97706),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .offset {
                                                    IntOffset(
                                                        x = (maxTrackPx * progresoAnimado).roundToInt(),
                                                        y = 0
                                                    )
                                                }
                                                .size(badgeSizeDp)
                                                .clip(CircleShape)
                                                .background(Color.White)
                                                .border(2.dp, Color(0xFF15803D), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DirectionsCar,
                                                contentDescription = "Vehículo en camino",
                                                tint = Color(0xFF15803D),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Inicio ($distanciaInicialLabel)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF525B50)
                                        )
                                        Text(
                                            text = "$progresoPct%",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF15803D)
                                        )
                                        Text(
                                            text = "Tu punto",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "TU PIN DE SEGURIDAD (ENTREGAR AL SUBIR)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14532D)
                                    )
                                    Text(
                                        text = pinPersistente?.takeIf { it.isNotBlank() } ?: "...",
                                        fontSize = 42.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 8.sp,
                                        color = Color(0xFF15803D)
                                    )
                                    Text(
                                        text = "Conductor: ${conductorNombre.orEmpty().ifBlank { "Asignado" }} · Placa: ${conductorPlaca.orEmpty().ifBlank { "--" }}",
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF14231A)
                                    )
                                    Text(
                                        text = if (conductorLlego) {
                                            "Distancia: El conductor ha llegado · Tarifa aprox: ₡$montoAproximado"
                                        } else {
                                            "ETA: ${etaMinutos ?: "--"} min · Distancia: $distanciaLabel · Tarifa aprox: ₡$montoAproximado"
                                        }
                                    )
                                    if (viajeActivoEsCargaFlete) {
                                        Text(
                                            text = "Modalidad: Pickup con carga / flete",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { mostrarMapaModal = true },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Ver Mapa") }
                                        OutlinedButton(
                                            onClick = {
                                                onAbrirChat()
                                                mostrarChatModal = true
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text(if (chatNoLeidos > 0) "Chat ($chatNoLeidos)" else "Abrir Chat") }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            motivoCancelacionInput = ""
                                            mostrarModalCancelar = true
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Cancelar viaje (ingresar nota)") }
                                }
                            }
                        } else if (estadoViaje == "en_curso") {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Viaje en curso con ${conductorNombre.orEmpty()}", fontWeight = FontWeight.Bold)
                                    Text("Tarifa estimada: ₡$montoAproximado", color = Color(0xFF15803D), fontWeight = FontWeight.SemiBold)
                                    if (viajeActivoEsCargaFlete) {
                                        Text(
                                            text = "Modalidad: Pickup con carga / flete",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = {
                                                onAbrirChat()
                                                mostrarChatModal = true
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text(if (chatNoLeidos > 0) "Chat ($chatNoLeidos)" else "Abrir Chat") }
                                        OutlinedButton(
                                            onClick = {
                                                motivoCancelacionInput = ""
                                                mostrarModalCancelar = true
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Cancelar viaje") }
                                    }
                                }
                            }
                        } else if (estadoViaje == "buscando") {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "Buscando conductor disponible...",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14532D)
                                    )
                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                    Text(
                                        text = "Ruta: ${origenViajeActivo ?: origen} → ${destinoViajeActivo ?: destino}",
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF14231A)
                                    )
                                    Text(
                                        text = "Pasajeros: ${pasajerosViajeActivo ?: cantidadPasajeros}",
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFF15803D),
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (viajeActivoEsCargaFlete) {
                                        Text(
                                            text = "Modalidad solicitada: Pickup con carga / flete",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                    val resenaMostrada = resenaViajeActivo ?: resenaUbicacion
                                    if (resenaMostrada.isNotBlank()) {
                                        Text(
                                            text = "Referencia: $resenaMostrada",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            motivoCancelacionInput = ""
                                            mostrarModalCancelar = true
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Cancelar solicitud") }
                                }
                            }
                        } else if (estadoViaje == "idle") {
                            if (rutasFavoritas.isNotEmpty()) {
                                Text(
                                    text = "Rutas favoritas",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14231A)
                                )
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(rutasFavoritas) { fav ->
                                        AssistChip(
                                            onClick = {
                                                origen = fav.origenNombre
                                                origenLat = fav.origenLat
                                                origenLng = fav.origenLng
                                                destino = fav.destinoNombre
                                                destinoLat = fav.destinoLat
                                                destinoLng = fav.destinoLng
                                                tiposVehiculoSeleccionados = emptySet()
                                                onLimpiarBusquedaVehiculos()
                                            },
                                            label = { Text(fav.alias) }
                                        )
                                    }
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = "¿A dónde vas hoy?",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = origen,
                                            onValueChange = {
                                                origen = it
                                                mostrarListaOrigen = true
                                                tiposVehiculoSeleccionados = emptySet()
                                                onLimpiarBusquedaVehiculos()
                                                onBuscarOrigen(it, gpsActualLat, gpsActualLng)
                                            },
                                            label = { Text("Ubicación actual") },
                                            placeholder = { Text("Ej: Hospital México, La Uruca (o toca 📍)") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        FilledTonalIconButton(
                                            onClick = { solicitarGpsYGeocodificar() },
                                            enabled = !cargandoGpsOrigen,
                                            modifier = Modifier
                                                .padding(top = 4.dp)
                                                .size(52.dp),
                                            shape = RoundedCornerShape(14.dp),
                                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                containerColor = Color(0xFFDCFCE7),
                                                contentColor = Color(0xFF15803D)
                                            )
                                        ) {
                                            if (cargandoGpsOrigen) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(20.dp),
                                                    strokeWidth = 2.dp,
                                                    color = Color(0xFF15803D)
                                                )
                                            } else {
                                                Text("📍", fontSize = 20.sp)
                                            }
                                        }
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { solicitarGpsYGeocodificar() },
                                            enabled = !cargandoGpsOrigen,
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(
                                                if (cargandoGpsOrigen) {
                                                    "Obteniendo dirección..."
                                                } else {
                                                    "📍 Mi Ubicación Actual"
                                                }
                                            )
                                        }
                                        if (precisionUbicacionMetros != null) {
                                            Text(
                                                text = "±${precisionUbicacionMetros} m · " +
                                                    if (precisionUbicacionMetros <= 25) "Alta precisión" else "Precisión media",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    if (!mensajeGpsOrigen.isNullOrBlank()) {
                                        Text(
                                            text = mensajeGpsOrigen.orEmpty(),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                    if (mostrarListaOrigen && sugerenciasOrigen.isNotEmpty()) {
                                        OutlinedCard(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            border = cardBorder
                                        ) {
                                            Column {
                                                sugerenciasOrigen.take(6).forEach { opc ->
                                                    ListItem(
                                                        headlineContent = { Text(opc.nombre) },
                                                        supportingContent = { Text(opc.canton) },
                                                        modifier = Modifier.clickable {
                                                            origen = opc.nombre
                                                            origenLat = opc.lat
                                                            origenLng = opc.lng
                                                            gpsActualLat = opc.lat
                                                            gpsActualLng = opc.lng
                                                            mostrarListaOrigen = false
                                                            tiposVehiculoSeleccionados = emptySet()
                                                            onLimpiarBusquedaVehiculos()
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = destino,
                                        onValueChange = {
                                            destino = it
                                            mostrarListaDestino = true
                                            tiposVehiculoSeleccionados = emptySet()
                                            onLimpiarBusquedaVehiculos()
                                            onBuscarDestino(it, gpsActualLat, gpsActualLng)
                                        },
                                        label = { Text("Destino (ej. pulpería, licorera o supermercado)") },
                                        placeholder = { Text("Busca comercios, barrios o puntos cercanos...") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    if (mostrarListaDestino && (buscandoDestino || sugerenciasDestino.isNotEmpty() || destino.trim().length >= 2)) {
                                        OutlinedCard(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            border = cardBorder
                                        ) {
                                            Column {
                                                if (buscandoDestino) {
                                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                                    Text(
                                                        text = "Buscando lugares cercanos...",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFF525B50),
                                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                                    )
                                                }
                                                if (sugerenciasDestino.isNotEmpty()) {
                                                    sugerenciasDestino.take(6).forEach { opc ->
                                                        ListItem(
                                                            headlineContent = { Text(opc.nombre) },
                                                            supportingContent = { Text(opc.canton) },
                                                            modifier = Modifier.clickable {
                                                                destino = opc.nombre
                                                                destinoLat = opc.lat
                                                                destinoLng = opc.lng
                                                                mostrarListaDestino = false
                                                                tiposVehiculoSeleccionados = emptySet()
                                                                onLimpiarBusquedaVehiculos()
                                                            }
                                                        )
                                                    }
                                                } else if (!buscandoDestino && destino.trim().length >= 2) {
                                                    Text(
                                                        text = "Sin coincidencias cercanas para \"$destino\". Prueba otra palabra clave.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFF525B50),
                                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    TextButton(
                                        onClick = {
                                            if (origen.isNotBlank() && destino.isNotBlank()) {
                                                onGuardarFavorita(
                                                    RutaFavoritaData(
                                                        id = "fav_${System.currentTimeMillis()}",
                                                        alias = "${origen.take(15)} → ${destino.take(15)}",
                                                        origenNombre = origen,
                                                        origenLat = origenLat,
                                                        origenLng = origenLng,
                                                        destinoNombre = destino,
                                                        destinoLat = destinoLat,
                                                        destinoLng = destinoLng
                                                    )
                                                )
                                            }
                                        }
                                    ) {
                                        Text("★ Guardar ruta actual como favorita")
                                    }

                                    OutlinedTextField(
                                        value = resenaUbicacion,
                                        onValueChange = {
                                            resenaUbicacion = it
                                            onDismissErrorSolicitud()
                                        },
                                        label = { Text("Breve referencia para encontrarme (ej: frente a la licorera, casa azul)") },
                                        placeholder = { Text("Ej: frente a la licorera, casa azul") },
                                        minLines = 2,
                                        supportingText = {
                                            if (resenaUbicacion.trim().length < 3) {
                                                Text(
                                                    text = "Obligatorio (mínimo 3 caracteres) para habilitar Solicitar Viaje.",
                                                    color = if (resenaUbicacion.isBlank()) Color(0xFF525B50) else MaterialTheme.colorScheme.error
                                                )
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Color(0xFFF7F8F6),
                                        border = cardBorder,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = if (cantidadPasajeros == 0) {
                                                    "Pasajeros: 0 (obligatorio)"
                                                } else {
                                                    "Pasajeros: $cantidadPasajeros"
                                                },
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                FilledTonalButton(
                                                    onClick = {
                                                        if (cantidadPasajeros > 0) {
                                                            cantidadPasajeros--
                                                            tiposVehiculoSeleccionados = emptySet()
                                                            esCargaFleteSeleccionado = false
                                                            onLimpiarBusquedaVehiculos()
                                                        }
                                                    },
                                                    enabled = cantidadPasajeros > 0
                                                ) { Text("-") }
                                                FilledTonalButton(
                                                    onClick = {
                                                        if (cantidadPasajeros < 12) {
                                                            cantidadPasajeros++
                                                            tiposVehiculoSeleccionados = emptySet()
                                                            esCargaFleteSeleccionado = false
                                                            onLimpiarBusquedaVehiculos()
                                                        }
                                                    },
                                                    enabled = cantidadPasajeros < 12
                                                ) { Text("+") }
                                            }
                                        }
                                    }

                                    if (cantidadPasajeros < 1) {
                                        Text(
                                            text = "Indica al menos 1 pasajero para buscar vehículos disponibles.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            tiposVehiculoSeleccionados = emptySet()
                                            esCargaFleteSeleccionado = false
                                            onBuscarVehiculosDisponibles(
                                                origenLat,
                                                origenLng,
                                                destinoLat,
                                                destinoLng,
                                                cantidadPasajeros
                                            )
                                        },
                                        enabled = !buscandoConductores &&
                                            origen.isNotBlank() &&
                                            destino.isNotBlank() &&
                                            cantidadPasajeros >= 1,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                    ) {
                                        Text(
                                            text = if (buscandoConductores) {
                                                "Buscando vehículos cercanos (<10 km)..."
                                            } else {
                                                "Buscar"
                                            },
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    if (buscandoConductores) {
                                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                    } else if (busquedaVehiculosRealizada) {
                                        if (opcionesVehiculosDisponibles.isEmpty()) {
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = Color(0xFFFEF2F2),
                                                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(
                                                    text = mensajeDisponibilidad
                                                        ?: "No hay vehículos disponibles a menos de 10 km en este momento.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = Color(0xFF991B1B),
                                                    modifier = Modifier.padding(12.dp)
                                                )
                                            }
                                        } else {
                                            val pickupSeleccionado = tiposVehiculoSeleccionados.any { ViajeRepository.esVehiculoCargo(it) }
                                            val motoSeleccionada = tiposVehiculoSeleccionados.any { ViajeRepository.esVehiculoMoto(it) }
                                            LaunchedEffect(pickupSeleccionado) {
                                                if (!pickupSeleccionado) {
                                                    esCargaFleteSeleccionado = false
                                                }
                                            }
                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text(
                                                    text = "Vehículos disponibles (<10 km) · Ruta aprox. $distanciaViajeKm km:",
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF14231A)
                                                )
                                                opcionesVehiculosDisponibles.forEach { opcion ->
                                                    val seleccionado = opcion.tipoId in tiposVehiculoSeleccionados
                                                    val esCargoOpcion = ViajeRepository.esVehiculoCargo(opcion.tipoId)
                                                    val esMotoOpcion = ViajeRepository.esVehiculoMoto(opcion.tipoId)
                                                    val montoOpcion = if (esCargoOpcion && esCargaFleteSeleccionado && opcion.montoAproximadoCarga != null) {
                                                        opcion.montoAproximadoCarga
                                                    } else {
                                                        opcion.montoAproximado
                                                    }
                                                    Surface(
                                                        onClick = {
                                                            val siguiente = if (seleccionado) {
                                                                tiposVehiculoSeleccionados - opcion.tipoId
                                                            } else {
                                                                tiposVehiculoSeleccionados + opcion.tipoId
                                                            }
                                                            tiposVehiculoSeleccionados = siguiente
                                                            if (siguiente.none { ViajeRepository.esVehiculoCargo(it) }) {
                                                                esCargaFleteSeleccionado = false
                                                            }
                                                        },
                                                        shape = RoundedCornerShape(12.dp),
                                                        color = if (seleccionado) Color(0xFFDCFCE7) else Color(0xFFF7F8F6),
                                                        border = BorderStroke(
                                                            width = if (seleccionado) 1.5.dp else 1.dp,
                                                            color = if (seleccionado) Color(0xFF15803D) else Color(0xFFE2E6DF)
                                                        ),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Row(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Column(
                                                                modifier = Modifier.weight(1f),
                                                                verticalArrangement = Arrangement.spacedBy(2.dp)
                                                            ) {
                                                                Text(
                                                                    text = (if (seleccionado) "✓ " else "") + opcion.nombre,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = if (seleccionado) Color(0xFF14532D) else Color(0xFF14231A)
                                                                )
                                                                Text(
                                                                    text = "${opcion.detalleCapacidad} · ${opcion.conductoresDisponibles} disp.",
                                                                    style = MaterialTheme.typography.bodySmall,
                                                                    color = Color(0xFF525B50)
                                                                )
                                                                if (esMotoOpcion && (opcion.conductoresConCascoExtra > 0 || opcion.conductoresConCapa > 0)) {
                                                                    Text(
                                                                        text = "Equipamiento cercano · Casco extra: ${opcion.conductoresConCascoExtra} · Capa: ${opcion.conductoresConCapa}",
                                                                        style = MaterialTheme.typography.labelSmall,
                                                                        color = Color(0xFF166534),
                                                                        fontWeight = FontWeight.SemiBold
                                                                    )
                                                                }
                                                            }
                                                            Column(
                                                                horizontalAlignment = Alignment.End,
                                                                verticalArrangement = Arrangement.spacedBy(1.dp)
                                                            ) {
                                                                Text(
                                                                    text = "₡$montoOpcion",
                                                                    fontFamily = FontFamily.Monospace,
                                                                    fontWeight = FontWeight.ExtraBold,
                                                                    color = Color(0xFF15803D)
                                                                )
                                                                Text(
                                                                    text = if (esCargoOpcion && esCargaFleteSeleccionado) {
                                                                        "Estimado carga / flete"
                                                                    } else {
                                                                        "Tarifa promedio aprox."
                                                                    },
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = Color(0xFF525B50)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                                if (pickupSeleccionado) {
                                                    Surface(
                                                        shape = RoundedCornerShape(12.dp),
                                                        color = Color(0xFFFFFBEB),
                                                        border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Column(
                                                            modifier = Modifier.padding(12.dp),
                                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Text(
                                                                text = "Modalidad de viaje en Pickup",
                                                                style = MaterialTheme.typography.labelLarge,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color(0xFF92400E)
                                                            )
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                            ) {
                                                                FilterChip(
                                                                    selected = !esCargaFleteSeleccionado,
                                                                    onClick = { esCargaFleteSeleccionado = false },
                                                                    label = { Text("Solo pasajeros", style = MaterialTheme.typography.labelSmall) },
                                                                    modifier = Modifier.weight(1f)
                                                                )
                                                                FilterChip(
                                                                    selected = esCargaFleteSeleccionado,
                                                                    onClick = { esCargaFleteSeleccionado = true },
                                                                    label = { Text("Con carga / flete", style = MaterialTheme.typography.labelSmall) },
                                                                    modifier = Modifier.weight(1f)
                                                                )
                                                            }
                                                            Text(
                                                                text = if (esCargaFleteSeleccionado) {
                                                                    "Con carga / flete (ferretería, materiales, compras pesadas): Traslado con carga: tarifa especial según peso y volumen."
                                                                } else {
                                                                    "Solo pasajeros: se calcula con la tarifa base normal."
                                                                },
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = Color(0xFF78350F)
                                                            )
                                                        }
                                                    }
                                                }
                                                if (motoSeleccionada || opcionesVehiculosDisponibles.any { ViajeRepository.esVehiculoMoto(it.tipoId) }) {
                                                    Surface(
                                                        shape = RoundedCornerShape(12.dp),
                                                        color = if (motoSeleccionada) Color(0xFFEFF6FF) else Color(0xFFF7F8F6),
                                                        border = BorderStroke(
                                                            1.dp,
                                                            if (motoSeleccionada) Color(0xFF93C5FD) else Color(0xFFE2E6DF)
                                                        ),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Text(
                                                            text = "Viaje en Moto: Recuerda usar el casco de seguridad para pasajero y llevar capa impermeable en caso de lluvia.",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            fontWeight = if (motoSeleccionada) FontWeight.SemiBold else FontWeight.Normal,
                                                            color = Color(0xFF1E3A8A),
                                                            modifier = Modifier.padding(10.dp)
                                                        )
                                                    }
                                                }
                                                if (tiposVehiculoSeleccionados.isEmpty()) {
                                                    Text(
                                                        text = "Elige uno o más tipos de vehículo disponibles antes de solicitar.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.error
                                                    )
                                                }
                                            }
                                        }
                                    } else if (origen.isNotBlank() && destino.isNotBlank() && cantidadPasajeros >= 1) {
                                        Text(
                                            text = "Presiona \"Buscar\" para ver qué vehículos hay disponibles cerca y su monto aproximado.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }

                                    if (!errorSolicitud.isNullOrBlank()) {
                                        OutlinedCard(
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                            colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .padding(end = 8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                                ) {
                                                    Text(
                                                        text = "No se pudo enviar la solicitud",
                                                        style = MaterialTheme.typography.labelLarge,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF991B1B)
                                                    )
                                                    Text(
                                                        text = errorSolicitud,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color(0xFF7F1D1D)
                                                    )
                                                }
                                                TextButton(onClick = onDismissErrorSolicitud) {
                                                    Text("Cerrar")
                                                }
                                            }
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Color(0xFFF0FDF4),
                                        border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "Sin cobro de app para el pasajero",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF14532D)
                                            )
                                            Text(
                                                text = "No se incluye ningún cobro de plataforma ni comisiones adicionales. Solo pagas la tarifa directa en efectivo al conductor.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF166534)
                                            )
                                            TextButton(
                                                onClick = { mostrarModalTerminosPasajero = true },
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text(
                                                    text = "Ver Términos y Condiciones del Pasajero",
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF15803D)
                                                )
                                            }
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { aceptoTerminosPasajero = !aceptoTerminosPasajero }
                                            ) {
                                                Checkbox(
                                                    checked = aceptoTerminosPasajero,
                                                    onCheckedChange = { aceptoTerminosPasajero = it }
                                                )
                                                Text(
                                                    text = "Acepto los términos y condiciones",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = Color(0xFF14231A),
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            val tieneCargo = tiposVehiculoSeleccionados.any { ViajeRepository.esVehiculoCargo(it) }
                                            onSolicitarViaje(
                                                cantidadPasajeros,
                                                origen,
                                                origenLat,
                                                origenLng,
                                                destino,
                                                destinoLat,
                                                destinoLng,
                                                resenaUbicacion.trim(),
                                                tiposVehiculoSeleccionados.toList(),
                                                tieneCargo && esCargaFleteSeleccionado
                                            )
                                        },
                                        enabled = !solicitandoViaje &&
                                            busquedaVehiculosRealizada &&
                                            cantidadPasajeros >= 1 &&
                                            tiposVehiculoSeleccionados.isNotEmpty() &&
                                            origen.isNotBlank() &&
                                            destino.isNotBlank() &&
                                            resenaUbicacion.trim().length >= 3 &&
                                            aceptoTerminosPasajero,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                    ) {
                                        Text(
                                            text = when {
                                                solicitandoViaje -> "Buscando conductores..."
                                                !aceptoTerminosPasajero -> "Acepta los términos para solicitar"
                                                else -> "Solicitar Viaje"
                                            },
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                PasajeroTab.HISTORIAL -> {
                    val historialMes = remember(historial, mesHistorial) {
                        filtrarViajesPorMesCostaRica(historial, mesHistorial)
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Historial de Viajes",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        SelectorMesHistorialCard(
                            viajes = historial,
                            viajesFiltrados = historialMes,
                            mesSeleccionado = mesHistorial,
                            onSelectMes = { mesHistorial = it },
                            etiquetaTotal = "Total del mes"
                        )
                        if (cargandoHistorial) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                        if (!cargandoHistorial && historialMes.isEmpty()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "No hay viajes registrados en este mes",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(historialMes) { v ->
                                    OutlinedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = cardShape,
                                        border = cardBorder,
                                        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            val fechaHoraTexto = formatearFechaHoraCostaRica(v)
                                            val conductorHist = (v["conductorNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "Sin asignar"
                                            val montoHist = (v["montoAproximado"] as? Number)?.toInt() ?: 0
                                            Text("${v["origenNombre"] ?: ""} → ${v["destinoNombre"] ?: ""}", fontWeight = FontWeight.Bold)
                                            Text(
                                                text = "$fechaHoraTexto · Conductor: $conductorHist",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF525B50)
                                            )
                                            Text(
                                                text = "Estado: ${v["estado"] ?: ""} · Monto: ₡$montoHist",
                                                fontFamily = FontFamily.Monospace,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF15803D)
                                            )
                                            val motivoHist = v["motivoCancelacion"] as? String
                                            if (!motivoHist.isNullOrBlank()) {
                                                val por = if (v["canceladoPor"] == "conductor") "conductor" else "pasajero"
                                                Text(
                                                    text = "Cancelado por $por: \"$motivoHist\"",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                PasajeroTab.PERFIL -> {
                    val avatarBitmap = remember(fotoUrl) { decodificarBase64Bitmap(fotoUrl) }
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Mi Perfil y Rutas",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    if (avatarBitmap != null) {
                                        Image(
                                            bitmap = avatarBitmap,
                                            contentDescription = "Foto de perfil",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFDCFCE7)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = nombrePasajero.take(1).uppercase().ifBlank { "P" },
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF15803D)
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = nombrePasajero.ifBlank { "Pasajero Viaje Rural" },
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (fotoUrl.isNotBlank()) {
                                                "Foto comprimida (~${ImageCompressionUtils.estimarPesoKbBase64(fotoUrl)} KB)"
                                            } else {
                                                "Sin foto de perfil"
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = { pickFotoPerfil.launch("image/*") },
                                    enabled = !comprimiendoFoto && !actualizandoFoto,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        when {
                                            comprimiendoFoto -> "Comprimiendo imagen (800px · 70%)..."
                                            actualizandoFoto -> "Guardando foto..."
                                            fotoUrl.isNotBlank() -> "Cambiar Foto de Perfil"
                                            else -> "Subir Foto de Perfil"
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Datos Personales (Bloqueados)", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Para evitar manipulación de datos después del registro, cualquier cambio debe aprobarlo el Administrador.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                                if (nombrePasajero.isNotBlank()) {
                                    Text("Nombre: $nombrePasajero", fontWeight = FontWeight.Medium)
                                }
                                OutlinedButton(
                                    onClick = { mostrarModalSolicitud = true },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Solicitar cambio de datos al Administrador")
                                }
                            }
                        }

                        if (misSolicitudes.isNotEmpty()) {
                            Text("Mis Peticiones de Cambio", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            misSolicitudes.forEach { sol ->
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text("${sol.estado.uppercase()} · ${sol.motivo}", fontWeight = FontWeight.SemiBold)
                                        if (sol.respuestaAdmin.isNotBlank()) {
                                            Text("Admin: ${sol.respuestaAdmin}", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }

                        rutasFavoritas.forEach { fav ->
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(fav.alias, fontWeight = FontWeight.Bold)
                                        Text("${fav.origenNombre} → ${fav.destinoNombre}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                    }
                                    TextButton(onClick = { onEliminarFavorita(fav.id) }) { Text("Quitar") }
                                }
                            }
                        }

                        PanelPermisosConfiguracionCard(rol = "pasajero")

                        OutlinedButton(
                            onClick = { mostrarModalTerminosPasajero = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Términos y Condiciones del Pasajero", fontWeight = FontWeight.SemiBold)
                        }

                        HorizontalDivider(color = Color(0xFFE2E6DF), modifier = Modifier.padding(vertical = 4.dp))

                        OutlinedButton(
                            onClick = { compartirAppPasajero(context, linkDescarga) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Compartir App", fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = onCerrarSesion,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Cerrar Sesión", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (mostrarModalPago) {
        val montoFinalModal = if (montoAPagar > 0) montoAPagar else montoAproximado
        AlertDialog(
            onDismissRequest = onDismissModalPago,
            title = { Text("Viaje Finalizado — Pago en Efectivo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Monto a pagar al conductor:")
                    Text(
                        text = "₡$montoFinalModal",
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text("Califica a ${conductorNombre ?: "tu conductor"} ($estrellas/5 ★):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { n ->
                            FilledTonalButton(onClick = { estrellas = n }) {
                                Text(if (n <= estrellas) "★" else "☆")
                            }
                        }
                    }
                    OutlinedTextField(
                        value = comentario,
                        onValueChange = { comentario = it },
                        label = { Text("Comentario opcional") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = { onCalificarConductor(estrellas, comentario) }) {
                    Text("Confirmar y Calificar")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissModalPago) { Text("Cerrar") }
            }
        )
    }

    if (mostrarMapaModal) {
        val latMapa = conductorLat ?: origenViajeLat ?: origenLat
        val lngMapa = conductorLng ?: origenViajeLng ?: origenLng
        Dialog(
            onDismissRequest = { mostrarMapaModal = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            OnDemandMapModalContent(
                etaMinutos = etaMinutos,
                latEstatica = latMapa,
                lngEstatica = lngMapa,
                onClose = { mostrarMapaModal = false }
            )
        }
    }

    if (mostrarChatModal) {
        var textoChat by remember { mutableStateOf("") }
        Dialog(
            onDismissRequest = {
                onCerrarChat()
                mostrarChatModal = false
            }
        ) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Chat Privado (Bajo Demanda)", fontWeight = FontWeight.Bold)
                    Text("Notificaciones flotantes activas sin exponer números telefónicos.", style = MaterialTheme.typography.bodySmall)
                    Surface(
                        color = Color(0xFFF7F8F6),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp, max = 220.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(10.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (mensajesChat.isEmpty()) {
                                Text(
                                    text = "Aún no hay mensajes. Escribe a tu conductor aquí.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                            } else {
                                mensajesChat.forEach { msg ->
                                    val autor = msg["autorNombre"] as? String ?: "Usuario"
                                    val contenido = msg["texto"] as? String ?: ""
                                    Text(
                                        text = "$autor: $contenido",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF14231A)
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textoChat,
                            onValueChange = { if (it.length <= 400) textoChat = it },
                            placeholder = { Text("Escribe un mensaje...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            enabled = textoChat.isNotBlank(),
                            onClick = {
                                onEnviarMensajeChat(textoChat)
                                textoChat = ""
                            }
                        ) { Text("Enviar") }
                    }
                    OutlinedButton(
                        onClick = {
                            onCerrarChat()
                            mostrarChatModal = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Cerrar Chat") }
                }
            }
        }
    }

    if (mostrarModalSolicitud) {
        var reqNombre by remember { mutableStateOf("") }
        var reqTelefono by remember { mutableStateOf("") }
        var reqCorreo by remember { mutableStateOf("") }
        var reqCedula by remember { mutableStateOf("") }
        var reqMotivo by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { mostrarModalSolicitud = false },
            title = { Text("Solicitar Cambio de Datos") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Indica únicamente los campos que necesitas corregir.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = reqNombre, onValueChange = { reqNombre = it }, label = { Text("Nuevo nombre (opcional)") })
                    OutlinedTextField(value = reqTelefono, onValueChange = { reqTelefono = it }, label = { Text("Nuevo teléfono (opcional)") })
                    OutlinedTextField(value = reqCorreo, onValueChange = { reqCorreo = it }, label = { Text("Nuevo correo (opcional)") })
                    OutlinedTextField(value = reqCedula, onValueChange = { reqCedula = it }, label = { Text("Nueva cédula (opcional)") })
                    OutlinedTextField(value = reqMotivo, onValueChange = { reqMotivo = it }, label = { Text("Motivo del cambio (obligatorio)") })
                }
            },
            confirmButton = {
                Button(
                    enabled = reqMotivo.trim().length >= 3 && (reqNombre.isNotBlank() || reqTelefono.isNotBlank() || reqCorreo.isNotBlank() || reqCedula.isNotBlank()),
                    onClick = {
                        val cambios = mutableMapOf<String, Any>()
                        if (reqNombre.isNotBlank()) cambios["nombre"] = reqNombre.trim()
                        if (reqTelefono.isNotBlank()) cambios["telefono"] = reqTelefono.trim()
                        if (reqCorreo.isNotBlank()) cambios["email"] = reqCorreo.trim()
                        if (reqCedula.isNotBlank()) cambios["cedula"] = reqCedula.trim()
                        onEnviarSolicitudCambio(cambios, reqMotivo.trim())
                        mostrarModalSolicitud = false
                    }
                ) { Text("Enviar Petición") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalSolicitud = false }) { Text("Cancelar") }
            }
        )
    }

    if (mostrarModalCancelar) {
        val sugerenciasPasajero = listOf(
            "El conductor no puede llegar hasta mi ubicación",
            "Cambio de planes / ya no necesito el viaje",
            "Emergencia personal"
        )
        AlertDialog(
            onDismissRequest = { mostrarModalCancelar = false },
            title = { Text("Cancelar viaje") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Indica en una nota por qué deseas cancelar el viaje. El conductor recibirá este motivo.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    sugerenciasPasajero.forEach { opc ->
                        OutlinedButton(
                            onClick = { motivoCancelacionInput = opc },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(opc) }
                    }
                    OutlinedTextField(
                        value = motivoCancelacionInput,
                        onValueChange = { if (it.length <= 280) motivoCancelacionInput = it },
                        label = { Text("Nota de cancelación (obligatoria)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = motivoCancelacionInput.trim().length >= 3,
                    onClick = {
                        onCancelarViaje(motivoCancelacionInput.trim())
                        mostrarModalCancelar = false
                    }
                ) { Text("Confirmar cancelación") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalCancelar = false }) { Text("Volver") }
            }
        )
    }

    if (!avisoCancelacion.isNullOrBlank()) {
        AlertDialog(
            onDismissRequest = onDismissAvisoCancelacion,
            title = {
                Text(
                    text = "Viaje cancelado por el conductor",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF991B1B)
                )
            },
            text = {
                Text(
                    text = avisoCancelacion,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF14231A)
                )
            },
            confirmButton = {
                Button(onClick = onDismissAvisoCancelacion) {
                    Text("Entendido")
                }
            }
        )
    }

    if (mostrarModalPermisos) {
        ModalPermisosConfiguracion(
            rol = "pasajero",
            onDismiss = { mostrarModalPermisos = false }
        )
    }

    if (mostrarModalTerminosPasajero) {
        ModalTerminosPasajeroDialog(
            terminosPasajero = terminosCondicionesPasajero,
            onDismiss = { mostrarModalTerminosPasajero = false }
        )
    }
}

@Composable
private fun OnDemandMapModalContent(
    etaMinutos: Int?,
    latEstatica: Double?,
    lngEstatica: Double?,
    onClose: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current

    DisposableEffect(Unit) {
        onDispose {
            // Liberación al cerrar ventana modal sin rastreo GPS continuo
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Mapa Bajo Demanda · ETA ${etaMinutos ?: "--"} min", fontWeight = FontWeight.Bold)
                TextButton(onClick = onClose) { Text("Cerrar") }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (latEstatica != null && lngEstatica != null) {
                    Text(
                        text = "Última ubicación guardada en Firestore:",
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF14231A)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "%.5f, %.5f".format(latEstatica, lngEstatica),
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF15803D),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { abrirGoogleMapsEstaticoPasajero(context, latEstatica, lngEstatica) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Abrir en Google Maps (caché nativa)")
                    }
                } else {
                    Text("Aún no hay coordenada estática disponible en Firestore.")
                }
            }
            OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
                Text("Cerrar Mapa")
            }
        }
    }
}

private fun abrirGoogleMapsEstaticoPasajero(context: Context, lat: Double, lng: Double) {
    val geoUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(Conductor Viaje Rural)")
    val mapsIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
        setPackage("com.google.android.apps.maps")
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    try {
        context.startActivity(mapsIntent)
    } catch (_: Throwable) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, geoUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
        } catch (_: Throwable) {
        }
    }
}

private fun decodificarBase64Bitmap(raw: String): ImageBitmap? {
    if (raw.isBlank()) return null
    return try {
        val base64Part = raw.substringAfter("base64,", raw).trim()
        if (base64Part.isBlank()) return null
        val bytes = Base64.decode(base64Part, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

private fun compartirAppPasajero(context: Context, linkDescarga: String) {
    try {
        val urlLimpia = linkDescarga.trim().ifBlank { "https://viajerural.com/descargar" }
        val mensaje = "¡Viaja seguro en zonas rurales con Viaje Rural! Descarga la app aquí: $urlLimpia"
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Viaje Rural App")
            putExtra(Intent.EXTRA_TEXT, mensaje)
        }
        val chooser = Intent.createChooser(sendIntent, "Compartir Viaje Rural")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (_: Throwable) {
    }
}
