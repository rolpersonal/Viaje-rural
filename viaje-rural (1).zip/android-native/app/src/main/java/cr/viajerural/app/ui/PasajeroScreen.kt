package cr.viajerural.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import cr.viajerural.app.data.RutaFavoritaData
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.UbicacionSugerida
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.util.ImageCompressionUtils
import cr.viajerural.app.viewmodel.PasajeroTab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Pantalla Principal del Pasajero (Jetpack Compose) con BottomNavigation (3 pestañas):
 * - Viaje: Rutas favoritas, autocompletado de ubicación actual y destino, GPS de alta precisión, PIN persistente y modales Mapa/Chat.
 * - Historial: Carga lazy limit(20) solo al tocar la pestaña.
 * - Perfil: Foto de perfil comprimida (máx. 800px / JPEG 70%), datos bloqueados, rutas favoritas, compartir app y cerrar sesión.
 */
@Composable
fun PasajeroScreen(
    tabActual: PasajeroTab,
    onSelectTab: (PasajeroTab) -> Unit,
    estadoViaje: String,
    pinPersistente: String?,
    conductorNombre: String?,
    conductorPlaca: String?,
    etaMinutos: Int?,
    montoAproximado: Int,
    rutasFavoritas: List<RutaFavoritaData>,
    sugerenciasOrigen: List<UbicacionSugerida>,
    sugerenciasDestino: List<UbicacionSugerida>,
    historial: List<Map<String, Any>>,
    cargandoHistorial: Boolean,
    mostrarModalPago: Boolean,
    onBuscarOrigen: (String, Double, Double) -> Unit,
    onBuscarDestino: (String, Double, Double) -> Unit,
    onGuardarFavorita: (RutaFavoritaData) -> Unit,
    onEliminarFavorita: (String) -> Unit,
    onSolicitarViaje: (
        pasajeros: Int,
        origen: String,
        origenLat: Double,
        origenLng: Double,
        destino: String,
        destinoLat: Double,
        destinoLng: Double,
        resenaUbicacion: String
    ) -> Unit,
    onCalificarConductor: (estrellas: Int, comentario: String) -> Unit,
    onDismissModalPago: () -> Unit,
    nombrePasajero: String = "",
    fotoUrl: String = "",
    actualizandoFoto: Boolean = false,
    onActualizarFotoPerfil: (String) -> Unit = {},
    misSolicitudes: List<SolicitudCambioData> = emptyList(),
    onEnviarSolicitudCambio: (cambios: Map<String, Any>, motivo: String) -> Unit = { _, _ -> },
    avisoCancelacion: String? = null,
    onDismissAvisoCancelacion: () -> Unit = {},
    onCancelarViaje: (motivo: String) -> Unit = {},
    precisionUbicacionMetros: Int? = null,
    onUsarGpsPreciso: () -> Unit = {},
    onPrecisionActualizada: (Int?) -> Unit = {},
    linkDescarga: String = "https://viajerural.com/descargar",
    onCerrarSesion: () -> Unit = {},
    solicitandoViaje: Boolean = false,
    errorSolicitud: String? = null,
    origenViajeActivo: String? = null,
    destinoViajeActivo: String? = null,
    pasajerosViajeActivo: Int? = null,
    resenaViajeActivo: String? = null
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var mostrarMapaModal by remember { mutableStateOf(false) }
    var mostrarChatModal by remember { mutableStateOf(false) }
    var mostrarModalSolicitud by remember { mutableStateOf(false) }
    var mostrarModalCancelar by remember { mutableStateOf(false) }
    var motivoCancelacionInput by remember { mutableStateOf("") }
    // Se conserva en la raíz de PasajeroScreen para que no se reinicie al cambiar de pestaña ni al enviar la solicitud
    var cantidadPasajeros by remember { mutableStateOf(0) }
    var gpsActualLat by remember { mutableDoubleStateOf(9.3895) }
    var gpsActualLng by remember { mutableDoubleStateOf(-83.6490) }
    var origen by remember { mutableStateOf("") }
    var origenLat by remember { mutableDoubleStateOf(9.3895) }
    var origenLng by remember { mutableDoubleStateOf(-83.6490) }
    var cargandoGpsOrigen by remember { mutableStateOf(false) }
    var ubicacionInicialCargada by remember { mutableStateOf(false) }
    var destino by remember { mutableStateOf("") }
    var destinoLat by remember { mutableDoubleStateOf(9.3738) }
    var destinoLng by remember { mutableDoubleStateOf(-83.7042) }
    var mostrarListaOrigen by remember { mutableStateOf(false) }
    var mostrarListaDestino by remember { mutableStateOf(false) }
    var resenaUbicacion by remember { mutableStateOf("") }
    var estrellas by remember { mutableIntStateOf(5) }
    var comentario by remember { mutableStateOf("") }
    var comprimiendoFoto by remember { mutableStateOf(false) }

    fun tienePermisoUbicacion(): Boolean {
        val permisoFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val permisoCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return permisoFine || permisoCoarse
    }

    suspend fun capturarGpsYGeocodificar(actualizarOrigenTexto: Boolean) {
        if (!tienePermisoUbicacion()) return
        cargandoGpsOrigen = true
        try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val loc = client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                ?: client.lastLocation.await()
            if (loc != null) {
                gpsActualLat = loc.latitude
                gpsActualLng = loc.longitude
                origenLat = loc.latitude
                origenLng = loc.longitude
                onPrecisionActualizada(if (loc.hasAccuracy()) loc.accuracy.toInt() else null)
                if (actualizarOrigenTexto) {
                    val direccionLegible = ViajeRepository.reverseGeocodificarUbicacion(
                        context = context,
                        lat = loc.latitude,
                        lng = loc.longitude
                    )
                    origen = direccionLegible
                    mostrarListaOrigen = false
                }
            }
        } catch (_: Throwable) {
        } finally {
            cargandoGpsOrigen = false
        }
    }

    val launcherPermisoUbicacionOrigen = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { resultados ->
        val concedido = resultados[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            resultados[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            tienePermisoUbicacion()
        if (concedido) {
            scope.launch {
                capturarGpsYGeocodificar(actualizarOrigenTexto = true)
                onUsarGpsPreciso()
            }
        }
    }

    fun solicitarGpsYGeocodificar() {
        if (tienePermisoUbicacion()) {
            scope.launch {
                capturarGpsYGeocodificar(actualizarOrigenTexto = true)
                onUsarGpsPreciso()
            }
        } else {
            launcherPermisoUbicacionOrigen.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    LaunchedEffect(Unit) {
        if (!ubicacionInicialCargada) {
            ubicacionInicialCargada = true
            if (tienePermisoUbicacion()) {
                capturarGpsYGeocodificar(actualizarOrigenTexto = true)
            }
        }
    }

    val pickFotoPerfil = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { selectedUri ->
            scope.launch {
                comprimiendoFoto = true
                val comprimida = withContext(Dispatchers.IO) {
                    ImageCompressionUtils.comprimirImagenABase64(
                        context = context,
                        uri = selectedUri,
                        maxAnchoPx = 800,
                        calidadJpeg = 70,
                        maxBase64Chars = 140_000
                    )
                }
                comprimiendoFoto = false
                if (!comprimida.isNullOrBlank()) {
                    onActualizarFotoPerfil(comprimida)
                }
            }
        }
    }

    LaunchedEffect(estadoViaje) {
        if (estadoViaje != "aceptado" && mostrarMapaModal) mostrarMapaModal = false
        if (estadoViaje != "aceptado" && estadoViaje != "en_curso") mostrarChatModal = false
    }

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Scaffold(
        containerColor = Color(0xFFF7F8F6),
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.VIAJE,
                    onClick = { onSelectTab(PasajeroTab.VIAJE) },
                    icon = { Text("🚗") },
                    label = { Text("Viaje") }
                )
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.HISTORIAL,
                    onClick = { onSelectTab(PasajeroTab.HISTORIAL) },
                    icon = { Text("📜") },
                    label = { Text("Historial") }
                )
                NavigationBarItem(
                    selected = tabActual == PasajeroTab.PERFIL,
                    onClick = { onSelectTab(PasajeroTab.PERFIL) },
                    icon = { Text("👤") },
                    label = { Text("Perfil") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            when (tabActual) {
                PasajeroTab.VIAJE -> {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Viaje Rural",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14231A)
                                )
                                Text(
                                    text = "Solicita transporte local en efectivo",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                            }
                            OutlinedButton(
                                onClick = { compartirAppPasajero(context, linkDescarga) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Compartir App")
                            }
                        }

                        if (!avisoCancelacion.isNullOrBlank()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Viaje cancelado", fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                        Text(avisoCancelacion, style = MaterialTheme.typography.bodySmall, color = Color(0xFF7F1D1D))
                                    }
                                    TextButton(onClick = onDismissAvisoCancelacion) { Text("Cerrar") }
                                }
                            }
                        }

                        if (estadoViaje == "aceptado" && !pinPersistente.isNullOrBlank()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "TU PIN DE SEGURIDAD (ENTREGAR AL SUBIR)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14532D)
                                    )
                                    Text(
                                        text = pinPersistente,
                                        fontSize = 42.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 8.sp,
                                        color = Color(0xFF15803D)
                                    )
                                    Text("Conductor: ${conductorNombre.orEmpty()} · Placa: ${conductorPlaca.orEmpty()}")
                                    Text("ETA aproximado: ${etaMinutos ?: "--"} min · Tarifa aprox: ₡$montoAproximado")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { mostrarMapaModal = true },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Ver Mapa") }
                                        OutlinedButton(
                                            onClick = { mostrarChatModal = true },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Abrir Chat") }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            motivoCancelacionInput = ""
                                            mostrarModalCancelar = true
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Cancelar viaje (ingresar nota)") }
                                }
                            }
                        } else if (estadoViaje == "en_curso") {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Viaje en curso con ${conductorNombre.orEmpty()}", fontWeight = FontWeight.Bold)
                                    Text("Tarifa estimada: ₡$montoAproximado", color = Color(0xFF15803D), fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { mostrarChatModal = true },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Abrir Chat") }
                                        OutlinedButton(
                                            onClick = {
                                                motivoCancelacionInput = ""
                                                mostrarModalCancelar = true
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Cancelar viaje") }
                                    }
                                }
                            }
                        } else if (estadoViaje == "buscando") {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFF0FDF4))
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "Buscando conductor disponible...",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14532D)
                                    )
                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                    Text(
                                        text = "Ruta: ${origenViajeActivo ?: origen} → ${destinoViajeActivo ?: destino}",
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF14231A)
                                    )
                                    Text(
                                        text = "Pasajeros: ${pasajerosViajeActivo ?: cantidadPasajeros}",
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFF15803D),
                                        fontWeight = FontWeight.Bold
                                    )
                                    val resenaMostrada = resenaViajeActivo ?: resenaUbicacion
                                    if (resenaMostrada.isNotBlank()) {
                                        Text(
                                            text = "Referencia: $resenaMostrada",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            motivoCancelacionInput = ""
                                            mostrarModalCancelar = true
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Cancelar solicitud") }
                                }
                            }
                        } else if (estadoViaje == "idle") {
                            if (rutasFavoritas.isNotEmpty()) {
                                Text(
                                    text = "Rutas favoritas",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14231A)
                                )
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(rutasFavoritas) { fav ->
                                        AssistChip(
                                            onClick = {
                                                origen = fav.origenNombre
                                                origenLat = fav.origenLat
                                                origenLng = fav.origenLng
                                                destino = fav.destinoNombre
                                                destinoLat = fav.destinoLat
                                                destinoLng = fav.destinoLng
                                            },
                                            label = { Text(fav.alias) }
                                        )
                                    }
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = "¿A dónde vas hoy?",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = origen,
                                            onValueChange = {
                                                origen = it
                                                mostrarListaOrigen = true
                                                onBuscarOrigen(it, gpsActualLat, gpsActualLng)
                                            },
                                            label = { Text("Ubicación actual") },
                                            placeholder = { Text("Ej: Hospital México, La Uruca (o toca 📍)") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        FilledTonalIconButton(
                                            onClick = { solicitarGpsYGeocodificar() },
                                            enabled = !cargandoGpsOrigen,
                                            modifier = Modifier
                                                .padding(top = 4.dp)
                                                .size(52.dp),
                                            shape = RoundedCornerShape(14.dp),
                                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                containerColor = Color(0xFFDCFCE7),
                                                contentColor = Color(0xFF15803D)
                                            )
                                        ) {
                                            if (cargandoGpsOrigen) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(20.dp),
                                                    strokeWidth = 2.dp,
                                                    color = Color(0xFF15803D)
                                                )
                                            } else {
                                                Text("📍", fontSize = 20.sp)
                                            }
                                        }
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { solicitarGpsYGeocodificar() },
                                            enabled = !cargandoGpsOrigen,
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(
                                                when {
                                                    cargandoGpsOrigen -> "Obteniendo dirección GPS..."
                                                    precisionUbicacionMetros != null -> "📍 Recalibrar GPS (±${precisionUbicacionMetros} m)"
                                                    else -> "📍 Cargar ubicación GPS actual"
                                                }
                                            )
                                        }
                                        if (precisionUbicacionMetros != null) {
                                            Text(
                                                text = if (precisionUbicacionMetros <= 25) "Alta precisión" else "Precisión media",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    if (mostrarListaOrigen && sugerenciasOrigen.isNotEmpty()) {
                                        OutlinedCard(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            border = cardBorder
                                        ) {
                                            Column {
                                                sugerenciasOrigen.take(6).forEach { opc ->
                                                    ListItem(
                                                        headlineContent = { Text(opc.nombre) },
                                                        supportingContent = { Text(opc.canton) },
                                                        modifier = Modifier.clickable {
                                                            origen = opc.nombre
                                                            origenLat = opc.lat
                                                            origenLng = opc.lng
                                                            gpsActualLat = opc.lat
                                                            gpsActualLng = opc.lng
                                                            mostrarListaOrigen = false
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = destino,
                                        onValueChange = {
                                            destino = it
                                            mostrarListaDestino = true
                                            onBuscarDestino(it, gpsActualLat, gpsActualLng)
                                        },
                                        label = { Text("Destino (ej. pulpería, licorera o lugar)") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    if (mostrarListaDestino && sugerenciasDestino.isNotEmpty()) {
                                        OutlinedCard(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            border = cardBorder
                                        ) {
                                            Column {
                                                sugerenciasDestino.take(6).forEach { opc ->
                                                    ListItem(
                                                        headlineContent = { Text(opc.nombre) },
                                                        supportingContent = { Text(opc.canton) },
                                                        modifier = Modifier.clickable {
                                                            destino = opc.nombre
                                                            destinoLat = opc.lat
                                                            destinoLng = opc.lng
                                                            mostrarListaDestino = false
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    TextButton(
                                        onClick = {
                                            if (origen.isNotBlank() && destino.isNotBlank()) {
                                                onGuardarFavorita(
                                                    RutaFavoritaData(
                                                        id = "fav_${System.currentTimeMillis()}",
                                                        alias = "${origen.take(15)} → ${destino.take(15)}",
                                                        origenNombre = origen,
                                                        origenLat = origenLat,
                                                        origenLng = origenLng,
                                                        destinoNombre = destino,
                                                        destinoLat = destinoLat,
                                                        destinoLng = destinoLng
                                                    )
                                                )
                                            }
                                        }
                                    ) {
                                        Text("★ Guardar ruta actual como favorita")
                                    }

                                    OutlinedTextField(
                                        value = resenaUbicacion,
                                        onValueChange = { resenaUbicacion = it },
                                        label = { Text("Breve referencia para encontrarme (ej: frente a la licorera, casa azul)") },
                                        placeholder = { Text("Ej: frente a la licorera, casa azul") },
                                        minLines = 2,
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Color(0xFFF7F8F6),
                                        border = cardBorder,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = if (cantidadPasajeros == 0) {
                                                    "Pasajeros: 0 (obligatorio)"
                                                } else {
                                                    "Pasajeros: $cantidadPasajeros"
                                                },
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                FilledTonalButton(
                                                    onClick = { if (cantidadPasajeros > 0) cantidadPasajeros-- },
                                                    enabled = cantidadPasajeros > 0
                                                ) { Text("-") }
                                                FilledTonalButton(
                                                    onClick = { if (cantidadPasajeros < 12) cantidadPasajeros++ },
                                                    enabled = cantidadPasajeros < 12
                                                ) { Text("+") }
                                            }
                                        }
                                    }

                                    if (cantidadPasajeros < 1) {
                                        Text(
                                            text = "Indica al menos 1 pasajero para poder solicitar el viaje.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }

                                    if (!errorSolicitud.isNullOrBlank()) {
                                        Text(
                                            text = errorSolicitud,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            onSolicitarViaje(
                                                cantidadPasajeros,
                                                origen,
                                                origenLat,
                                                origenLng,
                                                destino,
                                                destinoLat,
                                                destinoLng,
                                                resenaUbicacion.trim()
                                            )
                                        },
                                        enabled = !solicitandoViaje &&
                                            cantidadPasajeros >= 1 &&
                                            origen.isNotBlank() &&
                                            destino.isNotBlank() &&
                                            resenaUbicacion.trim().length >= 3,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                    ) {
                                        Text(
                                            text = if (solicitandoViaje) "Enviando solicitud..." else "Solicitar viaje (Dispara Ping 1s)",
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                PasajeroTab.HISTORIAL -> {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Historial de Viajes",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (cargandoHistorial) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                        if (!cargandoHistorial && historial.isEmpty()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "Aún no tienes viajes registrados en tu historial.",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(historial) { v ->
                                    OutlinedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = cardShape,
                                        border = cardBorder,
                                        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text("${v["origenNombre"] ?: ""} → ${v["destinoNombre"] ?: ""}", fontWeight = FontWeight.Bold)
                                            Text(
                                                text = "Estado: ${v["estado"] ?: ""} · ₡${v["montoAproximado"] ?: 0}",
                                                fontFamily = FontFamily.Monospace,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF15803D)
                                            )
                                            val motivoHist = v["motivoCancelacion"] as? String
                                            if (!motivoHist.isNullOrBlank()) {
                                                val por = if (v["canceladoPor"] == "conductor") "conductor" else "pasajero"
                                                Text(
                                                    text = "Cancelado por $por: \"$motivoHist\"",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                PasajeroTab.PERFIL -> {
                    val avatarBitmap = remember(fotoUrl) { decodificarBase64Bitmap(fotoUrl) }
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Mi Perfil y Rutas",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    if (avatarBitmap != null) {
                                        Image(
                                            bitmap = avatarBitmap,
                                            contentDescription = "Foto de perfil",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFDCFCE7)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = nombrePasajero.take(1).uppercase().ifBlank { "P" },
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF15803D)
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = nombrePasajero.ifBlank { "Pasajero Viaje Rural" },
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (fotoUrl.isNotBlank()) {
                                                "Foto comprimida (~${ImageCompressionUtils.estimarPesoKbBase64(fotoUrl)} KB)"
                                            } else {
                                                "Sin foto de perfil"
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = { pickFotoPerfil.launch("image/*") },
                                    enabled = !comprimiendoFoto && !actualizandoFoto,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        when {
                                            comprimiendoFoto -> "Comprimiendo imagen (800px · 70%)..."
                                            actualizandoFoto -> "Guardando foto..."
                                            fotoUrl.isNotBlank() -> "Cambiar Foto de Perfil"
                                            else -> "Subir Foto de Perfil"
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = cardShape,
                            border = cardBorder,
                            colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Datos Personales (Bloqueados)", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Para evitar manipulación de datos después del registro, cualquier cambio debe aprobarlo el Administrador.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                                if (nombrePasajero.isNotBlank()) {
                                    Text("Nombre: $nombrePasajero", fontWeight = FontWeight.Medium)
                                }
                                OutlinedButton(
                                    onClick = { mostrarModalSolicitud = true },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Solicitar cambio de datos al Administrador")
                                }
                            }
                        }

                        if (misSolicitudes.isNotEmpty()) {
                            Text("Mis Peticiones de Cambio", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            misSolicitudes.forEach { sol ->
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text("${sol.estado.uppercase()} · ${sol.motivo}", fontWeight = FontWeight.SemiBold)
                                        if (sol.respuestaAdmin.isNotBlank()) {
                                            Text("Admin: ${sol.respuestaAdmin}", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }

                        rutasFavoritas.forEach { fav ->
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(fav.alias, fontWeight = FontWeight.Bold)
                                        Text("${fav.origenNombre} → ${fav.destinoNombre}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                    }
                                    TextButton(onClick = { onEliminarFavorita(fav.id) }) { Text("Quitar") }
                                }
                            }
                        }

                        HorizontalDivider(color = Color(0xFFE2E6DF), modifier = Modifier.padding(vertical = 4.dp))

                        OutlinedButton(
                            onClick = { compartirAppPasajero(context, linkDescarga) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Compartir App", fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = onCerrarSesion,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Cerrar Sesión", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (mostrarModalPago) {
        AlertDialog(
            onDismissRequest = onDismissModalPago,
            title = { Text("Viaje Finalizado — Pago en Efectivo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Monto a pagar al conductor:")
                    Text(
                        text = "₡$montoAproximado",
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text("Califica a ${conductorNombre ?: "tu conductor"} ($estrellas/5 ★):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { n ->
                            FilledTonalButton(onClick = { estrellas = n }) {
                                Text(if (n <= estrellas) "★" else "☆")
                            }
                        }
                    }
                    OutlinedTextField(
                        value = comentario,
                        onValueChange = { comentario = it },
                        label = { Text("Comentario opcional") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = { onCalificarConductor(estrellas, comentario) }) {
                    Text("Confirmar y Calificar")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissModalPago) { Text("Cerrar") }
            }
        )
    }

    if (mostrarMapaModal) {
        Dialog(
            onDismissRequest = { mostrarMapaModal = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            OnDemandMapModalContent(
                etaMinutos = etaMinutos,
                onClose = { mostrarMapaModal = false }
            )
        }
    }

    if (mostrarChatModal) {
        Dialog(onDismissRequest = { mostrarChatModal = false }) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Chat Privado (Bajo Demanda)", fontWeight = FontWeight.Bold)
                    Text("Sin exposición de números telefónicos.", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { mostrarChatModal = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cerrar Chat")
                    }
                }
            }
        }
    }

    if (mostrarModalSolicitud) {
        var reqNombre by remember { mutableStateOf("") }
        var reqTelefono by remember { mutableStateOf("") }
        var reqCorreo by remember { mutableStateOf("") }
        var reqCedula by remember { mutableStateOf("") }
        var reqMotivo by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { mostrarModalSolicitud = false },
            title = { Text("Solicitar Cambio de Datos") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Indica únicamente los campos que necesitas corregir.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = reqNombre, onValueChange = { reqNombre = it }, label = { Text("Nuevo nombre (opcional)") })
                    OutlinedTextField(value = reqTelefono, onValueChange = { reqTelefono = it }, label = { Text("Nuevo teléfono (opcional)") })
                    OutlinedTextField(value = reqCorreo, onValueChange = { reqCorreo = it }, label = { Text("Nuevo correo (opcional)") })
                    OutlinedTextField(value = reqCedula, onValueChange = { reqCedula = it }, label = { Text("Nueva cédula (opcional)") })
                    OutlinedTextField(value = reqMotivo, onValueChange = { reqMotivo = it }, label = { Text("Motivo del cambio (obligatorio)") })
                }
            },
            confirmButton = {
                Button(
                    enabled = reqMotivo.trim().length >= 3 && (reqNombre.isNotBlank() || reqTelefono.isNotBlank() || reqCorreo.isNotBlank() || reqCedula.isNotBlank()),
                    onClick = {
                        val cambios = mutableMapOf<String, Any>()
                        if (reqNombre.isNotBlank()) cambios["nombre"] = reqNombre.trim()
                        if (reqTelefono.isNotBlank()) cambios["telefono"] = reqTelefono.trim()
                        if (reqCorreo.isNotBlank()) cambios["email"] = reqCorreo.trim()
                        if (reqCedula.isNotBlank()) cambios["cedula"] = reqCedula.trim()
                        onEnviarSolicitudCambio(cambios, reqMotivo.trim())
                        mostrarModalSolicitud = false
                    }
                ) { Text("Enviar Petición") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalSolicitud = false }) { Text("Cancelar") }
            }
        )
    }

    if (mostrarModalCancelar) {
        val sugerenciasPasajero = listOf(
            "El conductor no puede llegar hasta mi ubicación",
            "Cambio de planes / ya no necesito el viaje",
            "Emergencia personal"
        )
        AlertDialog(
            onDismissRequest = { mostrarModalCancelar = false },
            title = { Text("Cancelar viaje") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Indica en una nota por qué deseas cancelar el viaje. El conductor recibirá este motivo.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    sugerenciasPasajero.forEach { opc ->
                        OutlinedButton(
                            onClick = { motivoCancelacionInput = opc },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(opc) }
                    }
                    OutlinedTextField(
                        value = motivoCancelacionInput,
                        onValueChange = { if (it.length <= 280) motivoCancelacionInput = it },
                        label = { Text("Nota de cancelación (obligatoria)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = motivoCancelacionInput.trim().length >= 3,
                    onClick = {
                        onCancelarViaje(motivoCancelacionInput.trim())
                        mostrarModalCancelar = false
                    }
                ) { Text("Confirmar cancelación") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalCancelar = false }) { Text("Volver") }
            }
        )
    }
}

@Composable
private fun OnDemandMapModalContent(
    etaMinutos: Int?,
    onClose: () -> Unit
) {
    DisposableEffect(Unit) {
        onDispose {
            // Liberación de MapView al cerrar ventana modal
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Mapa de Acercamiento · ETA ${etaMinutos ?: "--"} min", fontWeight = FontWeight.Bold)
                TextButton(onClick = onClose) { Text("Cerrar y liberar") }
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("AndroidView { MapView } inicializado bajo demanda (actualización cada 90s)")
            }
            Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
                Text("Cerrar Mapa")
            }
        }
    }
}

private fun decodificarBase64Bitmap(raw: String): ImageBitmap? {
    if (raw.isBlank()) return null
    return try {
        val base64Part = raw.substringAfter("base64,", raw).trim()
        if (base64Part.isBlank()) return null
        val bytes = Base64.decode(base64Part, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

private fun compartirAppPasajero(context: Context, linkDescarga: String) {
    try {
        val urlLimpia = linkDescarga.trim().ifBlank { "https://viajerural.com/descargar" }
        val mensaje = "¡Viaja seguro en zonas rurales con Viaje Rural! Descarga la app aquí: $urlLimpia"
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Viaje Rural App")
            putExtra(Intent.EXTRA_TEXT, mensaje)
        }
        val chooser = Intent.createChooser(sendIntent, "Compartir Viaje Rural")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (_: Throwable) {
    }
}
