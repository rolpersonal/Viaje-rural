package cr.viajerural.app.messaging

import android.content.Context

/**
 * Wrapper de compatibilidad: la recepción FCM fue consolidada en MyFirebaseMessagingService
 * y la creación de canales/alertas Heads-up en NotificationHelper.
 */
object ViajeRuralMessagingService {
    const val CHANNEL_OFERTAS = NotificationHelper.CHANNEL_OFERTAS
    const val CHANNEL_OFERTAS_NOMBRE = NotificationHelper.CHANNEL_OFERTAS_NOMBRE
    const val CHANNEL_HIGH_PRIORITY = NotificationHelper.CHANNEL_HIGH_PRIORITY
    const val CHANNEL_CHAT_HEADS_UP = NotificationHelper.CHANNEL_CHAT_HEADS_UP

    fun createOfertasChannel(context: Context) {
        NotificationHelper.crearTodosLosCanales(context)
    }
}
