package cr.viajerural.app.messaging

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import cr.viajerural.app.MainActivity
import cr.viajerural.app.R
import cr.viajerural.app.data.ViajeRepository

/**
 * Receptor FCM de alta prioridad para Viaje Rural:
 * - Canal "viajes_ofertas" ("Ofertas de Viaje", IMPORTANCE_HIGH) con sonido por defecto y vibración.
 * - FullScreenIntent para encender la pantalla y mostrar la oferta de viaje al instante (como llamada entrante).
 * - PING_1S: Enciende el GPS 1 segundo, envía coordenadas y lo apaga.
 * - OFERTA_15S / NUEVO_VIAJE / CHAT_MENSAJE / ACEPTADO / PROXIMIDAD / MENSUALIDAD_7000 / VIAJE_CANCELADO.
 */
class ViajeRuralMessagingService : FirebaseMessagingService() {

    override fun onCreate() {
        super.onCreate()
        createOfertasChannel(this)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // El token FCM se renueva automáticamente; el backend/cloud function usa topics o tokens registrados.
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        createOfertasChannel(this)

        val tipo = message.data["tipo"]
        when (tipo) {
            "PING_1S" -> ejecutarPingGpsDeUnSegundo()
            "OFERTA_15S", "NUEVO_VIAJE", "OFERTA_VIAJE" -> {
                val titulo = message.notification?.title
                    ?: message.data["titulo"]
                    ?: "Nueva solicitud de viaje"
                val cuerpo = message.notification?.body
                    ?: message.data["resumen"]
                    ?: "Tienes 15 segundos para aceptar la oferta."
                mostrarOfertaFullScreenHeadsUp(
                    titulo = titulo,
                    cuerpo = cuerpo,
                    viajeId = message.data["viajeId"]
                )
            }
            "CHAT_MENSAJE" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_CHAT_HEADS_UP,
                channelName = "Chat en Vivo (Heads-up con Sonido)",
                titulo = "Nuevo mensaje de ${message.data["autorNombre"] ?: "Viaje Rural"}",
                cuerpo = message.data["texto"] ?: "Tienes un mensaje nuevo en el viaje."
            )
            "ACEPTADO" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "¡Conductor asignado!",
                cuerpo = "Tu conductor va en camino. Revisa tu PIN de 3 dígitos."
            )
            "PROXIMIDAD" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "Conductor cerca de tu ubicación",
                cuerpo = "Ten a mano tu PIN de 3 dígitos para abordar."
            )
            "MENSUALIDAD_7000" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "Recordatorio mensual — Viaje Rural",
                cuerpo = "Renueva tu licencia mensual (₡7,000 colones) para seguir recibiendo viajes."
            )
            "VIAJE_CANCELADO" -> mostrarNotificacionFlotanteConSonido(
                channelId = CHANNEL_HIGH_PRIORITY,
                channelName = "Alertas Viaje Rural",
                titulo = "Viaje cancelado por ${message.data["pasajeroNombre"] ?: "el pasajero"}",
                cuerpo = message.data["motivoCancelacion"] ?: "El pasajero canceló el viaje."
            )
            else -> {
                // Si llega un mensaje con notification payload genérico mientras la app está en primer plano
                val notifTitle = message.notification?.title
                val notifBody = message.notification?.body
                if (!notifTitle.isNullOrBlank() || !notifBody.isNullOrBlank()) {
                    mostrarOfertaFullScreenHeadsUp(
                        titulo = notifTitle ?: "Oferta de Viaje Rural",
                        cuerpo = notifBody ?: "Toca para abrir la solicitud de viaje.",
                        viajeId = message.data["viajeId"]
                    )
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun ejecutarPingGpsDeUnSegundo() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val fused = LocationServices.getFusedLocationProviderClient(this)
        val cts = CancellationTokenSource()

        val db = try {
            FirebaseFirestore.getInstance(ViajeRepository.FIRESTORE_DATABASE_ID)
        } catch (_: Throwable) {
            FirebaseFirestore.getInstance()
        }

        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    db.collection("conductores")
                        .document(uid)
                        .update(
                            mapOf(
                                "lat" to location.latitude,
                                "lng" to location.longitude,
                                "ultimoPingAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                }
                cts.cancel()
            }
            .addOnFailureListener { cts.cancel() }
    }

    /**
     * Notificación emergente (Heads-up) + FullScreenIntent en el canal "viajes_ofertas"
     * con sonido por defecto y patrón de vibración para que aparezca sobre otras apps o con pantalla apagada.
     */
    private fun mostrarOfertaFullScreenHeadsUp(
        titulo: String,
        cuerpo: String,
        viajeId: String?
    ) {
        createOfertasChannel(this)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val fullScreenIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("tipo", "OFERTA_15S")
            if (!viajeId.isNullOrBlank()) {
                putExtra("viajeId", viajeId)
            }
        }

        val requestCode = (System.currentTimeMillis() and 0xFFFFFF).toInt()
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            requestCode,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, CHANNEL_OFERTAS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setStyle(NotificationCompat.BigTextStyle().bigText(cuerpo))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setSound(soundUri)
            .setVibrate(VIBRATION_PATTERN_OFERTAS)
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setAutoCancel(true)
            .setTimeoutAfter(16_000L)
            .build()

        manager.notify(requestCode, notif)
    }

    private fun mostrarNotificacionFlotanteConSonido(
        channelId: String,
        channelName: String,
        titulo: String,
        cuerpo: String
    ) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val audioAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound(soundUri, audioAttrs)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 220, 120, 220)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(channel)
        }

        val tapIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val tapPendingIntent = PendingIntent.getActivity(
            this,
            0,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setSound(soundUri)
            .setContentIntent(tapPendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notif)
    }

    companion object {
        const val CHANNEL_OFERTAS = "viajes_ofertas"
        const val CHANNEL_OFERTAS_NOMBRE = "Ofertas de Viaje"
        const val CHANNEL_HIGH_PRIORITY = "viaje_rural_high_priority"
        const val CHANNEL_CHAT_HEADS_UP = "viaje_rural_chat_heads_up"
        val VIBRATION_PATTERN_OFERTAS = longArrayOf(0, 500, 200, 500, 200, 500)

        fun createOfertasChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()

                val channel = NotificationChannel(
                    CHANNEL_OFERTAS,
                    CHANNEL_OFERTAS_NOMBRE,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Notificaciones emergentes para ofertas de viaje entrantes al conductor."
                    setSound(soundUri, audioAttrs)
                    enableVibration(true)
                    vibrationPattern = VIBRATION_PATTERN_OFERTAS
                    enableLights(true)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                    setBypassDnd(true)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }
}
