package cr.viajerural.app.data

import android.content.Context
import android.location.Geocoder
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

data class AdminResumenLigero(
    val totalConductores: Long = 0L,
    val conductoresActivos: Long = 0L,
    val conductoresPendientes: Long = 0L,
    val totalPasajeros: Long = 0L,
    val solicitudesPendientes: Long = 0L
)

data class LicenciaRestanteInfo(
    val dias: Int,
    val fechaTexto: String,
    val estado: String, // "vencida" | "por_vencer" | "vigente"
    val etiqueta: String
)

data class SolicitudCambioData(
    val id: String,
    val solicitanteUid: String,
    val rol: String,
    val nombreActual: String,
    val resumenActual: String,
    val cambios: Map<String, Any>,
    val motivo: String,
    val estado: String,
    val respuestaAdmin: String = ""
)

fun parseLicenciaExpMillis(licenciaExp: Any?): Long? {
    return when (licenciaExp) {
        is Timestamp -> licenciaExp.toDate().time
        is Date -> licenciaExp.time
        is Number -> {
            val raw = licenciaExp.toLong()
            if (raw in 1L..99_999_999_999L) raw * 1000L else raw
        }
        is Map<*, *> -> {
            val sec = (licenciaExp["seconds"] as? Number)?.toLong()
                ?: (licenciaExp["_seconds"] as? Number)?.toLong()
            sec?.times(1000L)
        }
        is String -> {
            val limpio = licenciaExp.trim()
            if (limpio.isEmpty()) return null
            limpio.toLongOrNull()?.let { n ->
                return if (n in 1L..99_999_999_999L) n * 1000L else n
            }
            val patrones = listOf(
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd",
                "dd/MM/yyyy"
            )
            for (patron in patrones) {
                try {
                    val fmt = SimpleDateFormat(patron, Locale.US).apply { isLenient = false }
                    val parsed = fmt.parse(limpio)
                    if (parsed != null) return parsed.time
                } catch (_: Throwable) {
                }
            }
            null
        }
        else -> null
    }
}

fun calcularDiasLicenciaRestantes(licenciaExp: Any?): LicenciaRestanteInfo {
    val expMillis = parseLicenciaExpMillis(licenciaExp)
    if (expMillis == null) {
        return LicenciaRestanteInfo(
            dias = 0,
            fechaTexto = "--/--/----",
            estado = "vencida",
            etiqueta = "Licencia vencida"
        )
    }
    val diffMs = expMillis - System.currentTimeMillis()
    val dias = (diffMs / (1000L * 60L * 60L * 24L)).toInt()
    val formatter = SimpleDateFormat("dd/MM/yyyy", Locale("es", "CR"))
    val fechaTexto = formatter.format(Date(expMillis))
    val estado = when {
        dias <= 0 -> "vencida"
        dias <= 7 -> "por_vencer"
        else -> "vigente"
    }
    val etiqueta = if (dias > 0) {
        "Licencia vigente: $dias días"
    } else {
        "Licencia vencida"
    }
    return LicenciaRestanteInfo(dias = dias, fechaTexto = fechaTexto, estado = estado, etiqueta = etiqueta)
}

data class UbicacionSugerida(
    val nombre: String,
    val canton: String,
    val lat: Double,
    val lng: Double
)

data class RutaFavoritaData(
    val id: String,
    val alias: String,
    val origenNombre: String,
    val origenLat: Double,
    val origenLng: Double,
    val destinoNombre: String,
    val destinoLat: Double,
    val destinoLng: Double
)

/**
 * Repositorio principal de Viaje Rural optimizado para ahorro de datos y costos de Firebase:
 * - Consultas ligeras bajo demanda con limit(20) solo al abrir cada pestaña.
 * - Conteos en servidor (AggregateSource.SERVER) para Resumen Admin sin descargar documentos.
 * - Transacción atómica para ofertas secuenciales (evita conflicto de listas).
 * - FieldValue.increment() en gananciasHoy y gananciasMes para evitar lecturas de historial.
 * - Rutas Favoritas y catálogo de ubicaciones (ej. Pozuelo, La Uruca, Pérez Zeledón) para autocompletado.
 */
class ViajeRepository {

    companion object {
        const val FIRESTORE_DATABASE_ID = "ai-studio-63fccfd3-d2c4-45bd-a1c6-d9b0d1e46b20"
        const val DEFAULT_LINK_DESCARGA = "https://viajerural.com/descargar"
        const val FCM_CHANNEL_OFERTAS = "viajes_ofertas"

        /**
         * Geocodificación inversa para convertir coordenadas GPS en dirección legible
         * (ej: "Hospital México, La Uruca") usando Nominatim OpenStreetMap y fallback a Android Geocoder.
         */
        suspend fun reverseGeocodificarUbicacion(
            context: Context?,
            lat: Double,
            lng: Double
        ): String = withContext(Dispatchers.IO) {
            // 1) Intentar Nominatim Reverse API para formato de POI + distrito en Costa Rica
            var conn: HttpURLConnection? = null
            try {
                val urlStr = String.format(
                    Locale.US,
                    "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=%.6f&lon=%.6f&zoom=18&addressdetails=1",
                    lat,
                    lng
                )
                conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 4000
                    readTimeout = 4000
                    setRequestProperty("User-Agent", "ViajeRuralAndroid/1.0")
                    setRequestProperty("Accept-Language", "es")
                }
                if (conn.responseCode in 200..299) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    val addr = json.optJSONObject("address")
                    val punto = listOf(
                        json.optString("name"),
                        addr?.optString("amenity"),
                        addr?.optString("shop"),
                        addr?.optString("building"),
                        addr?.optString("road"),
                        json.optString("display_name").split(",").firstOrNull()
                    ).firstOrNull { !it.isNullOrBlank() }?.trim()

                    val localidad = listOf(
                        addr?.optString("suburb"),
                        addr?.optString("neighbourhood"),
                        addr?.optString("village"),
                        addr?.optString("city_district"),
                        addr?.optString("town"),
                        addr?.optString("city"),
                        addr?.optString("county")
                    ).firstOrNull {
                        !it.isNullOrBlank() && !it.equals(punto, ignoreCase = true)
                    }?.trim()

                    val combinada = listOfNotNull(punto, localidad)
                        .distinct()
                        .joinToString(", ")
                        .take(110)

                    if (combinada.isNotBlank()) {
                        return@withContext combinada
                    }
                }
            } catch (_: Throwable) {
            } finally {
                conn?.disconnect()
            }

            // 2) Fallback nativo con Android Geocoder si no hubo red o falló Nominatim
            if (context != null && Geocoder.isPresent()) {
                try {
                    val geocoder = Geocoder(context, Locale("es", "CR"))
                    @Suppress("DEPRECATION")
                    val direcciones = geocoder.getFromLocation(lat, lng, 1)
                    val dir = direcciones?.firstOrNull()
                    if (dir != null) {
                        val lineaPrincipal = dir.featureName?.takeIf {
                            it.isNotBlank() && !it.all { ch -> ch.isDigit() }
                        } ?: dir.thoroughfare
                        val zona = dir.subLocality ?: dir.locality ?: dir.subAdminArea
                        val texto = listOfNotNull(lineaPrincipal, zona)
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                            .distinct()
                            .joinToString(", ")
                            .take(110)
                        if (texto.isNotBlank()) {
                            return@withContext texto
                        }
                    }
                } catch (_: Throwable) {
                }
            }

            // 3) Fallback seguro de coordenadas legibles
            "Mi ubicación GPS (${String.format(Locale.US, "%.4f, %.4f", lat, lng)})"
        }

        /**
         * Construye el payload FCM de alta prioridad para enviar ofertas de viaje (15s) al Conductor
         * asegurando entrega inmediata en Doze/bloqueo (`priority = "high"`) y canal `viajes_ofertas`.
         */
        fun construirPayloadFcmOferta(
            tokenConductor: String,
            viajeId: String,
            origen: String,
            destino: String,
            pasajeros: Int,
            montoAproximado: Int,
            resenaUbicacion: String = ""
        ): Map<String, Any> {
            val titulo = "🚕 Nueva oferta de viaje ($pasajeros pas.)"
            val cuerpoBase = "$origen → $destino · ₡$montoAproximado"
            val cuerpo = if (resenaUbicacion.isNotBlank()) {
                "$cuerpoBase · Ref: $resenaUbicacion"
            } else {
                cuerpoBase
            }
            return mapOf(
                "to" to tokenConductor,
                "priority" to "high",
                "notification" to mapOf(
                    "title" to titulo,
                    "body" to cuerpo,
                    "channel_id" to FCM_CHANNEL_OFERTAS,
                    "sound" to "default"
                ),
                "android" to mapOf(
                    "priority" to "high",
                    "ttl" to "15s",
                    "notification" to mapOf(
                        "channel_id" to FCM_CHANNEL_OFERTAS,
                        "sound" to "default",
                        "notification_priority" to "PRIORITY_MAX",
                        "visibility" to "PUBLIC"
                    )
                ),
                "data" to mapOf(
                    "tipo" to "OFERTA_15S",
                    "viajeId" to viajeId,
                    "titulo" to titulo,
                    "resumen" to cuerpo,
                    "origen" to origen,
                    "destino" to destino,
                    "pasajeros" to pasajeros.toString(),
                    "montoAproximado" to montoAproximado.toString(),
                    "resenaUbicacion" to resenaUbicacion
                )
            )
        }
    }

    private val db: FirebaseFirestore by lazy {
        try {
            FirebaseFirestore.getInstance(FIRESTORE_DATABASE_ID)
        } catch (_: Throwable) {
            FirebaseFirestore.getInstance()
        }
    }

    private val auth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    // -------------------------------------------------------------------------
    // REQUISITO 5: AUTENTICACIÓN SEPARADA (PASAJERO, CONDUCTOR Y ADMIN SEGURO)
    // -------------------------------------------------------------------------
    suspend fun iniciarSesion(email: String, password: String): Result<String> {
        return try {
            val res = auth.signInWithEmailAndPassword(email.trim(), password).await()
            Result.success(res.user?.uid ?: throw IllegalStateException("UID nulo"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Login de Administrador Seguro:
     * 1. Autentica con FirebaseAuth.signInWithEmailAndPassword.
     * 2. Consulta usuarios/{uid} en Firestore y valida que rol == "admin".
     * 3. Si no es "admin", cierra sesión de inmediato y deniega el acceso.
     */
    suspend fun iniciarSesionAdmin(email: String, password: String): Result<String> {
        return try {
            val res = auth.signInWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: throw IllegalStateException("No se pudo obtener el UID del usuario.")
            val userSnap = db.collection("usuarios").document(uid).get().await()
            val rol = userSnap.getString("rol")?.trim()?.lowercase()
            if (rol != "admin") {
                auth.signOut()
                return Result.failure(SecurityException("Acceso denegado: tu cuenta no tiene rol de administrador."))
            }
            Result.success(uid)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun verificarRolAdminActual(uid: String): Boolean {
        return obtenerRolUsuarioActual(uid) == "admin"
    }

    /**
     * Lee únicamente el documento usuarios/{uid} (dentro de try-catch) para determinar
     * el rol actual ("admin", "conductor" o "pasajero") al restaurar sesión (Autologin).
     */
    suspend fun obtenerRolUsuarioActual(uid: String): String {
        return try {
            val snap = db.collection("usuarios").document(uid).get().await()
            when (snap.getString("rol")?.trim()?.lowercase()) {
                "admin" -> "admin"
                "conductor" -> "conductor"
                else -> "pasajero"
            }
        } catch (_: Exception) {
            "pasajero"
        }
    }

    fun cerrarSesion() {
        try {
            auth.signOut()
        } catch (_: Throwable) {
        }
    }

    suspend fun registrarPasajero(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        fotoUrl: String = ""
    ): Result<String> {
        return try {
            val res = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: throw IllegalStateException("No se pudo crear usuario")
            val fotoLimpia = fotoUrl.trim().take(148_000)
            val batch = db.batch()

            val usuarioMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "rol" to "pasajero",
                "bloqueado" to false,
                "terminosAceptados" to true,
                "terminosAceptadosAt" to FieldValue.serverTimestamp(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (fotoLimpia.isNotEmpty()) {
                usuarioMap["fotoUrl"] = fotoLimpia
            }
            batch.set(db.collection("usuarios").document(uid), usuarioMap)

            batch.set(
                db.collection("usuarios").document(uid).collection("private").document("pii"),
                mapOf(
                    "uid" to uid,
                    "telefono" to telefono.trim(),
                    "email" to email.trim(),
                    "cedula" to cedula.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            val pasajeroMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "promedioCalificacion" to 5.0,
                "totalCalificaciones" to 0,
                "favoritos" to emptyList<String>(),
                "rutasFavoritas" to emptyList<Map<String, Any>>(),
                "bloqueado" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (fotoLimpia.isNotEmpty()) {
                pasajeroMap["fotoUrl"] = fotoLimpia
            }
            batch.set(db.collection("pasajeros").document(uid), pasajeroMap)

            batch.commit().await()
            Result.success(uid)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registrarConductor(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        vehiculoTipo: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        fotoVehiculoDataUrl: String = "",
        fotoCedulaDataUrl: String = "",
        fotoLicenciaDataUrl: String = "",
        fotoCirculacionDataUrl: String = "",
        fotoPerfilDataUrl: String = ""
    ): Result<String> {
        return try {
            val res = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: throw IllegalStateException("No se pudo crear conductor")
            val expDate = Timestamp(Date(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000))
            val fotoPerfilLimpia = fotoPerfilDataUrl.trim().take(148_000)
            val fotoVehiculoLimpia = fotoVehiculoDataUrl.trim().take(148_000)
            val batch = db.batch()

            val usuarioMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "rol" to "conductor",
                "bloqueado" to false,
                "terminosAceptados" to true,
                "terminosAceptadosAt" to FieldValue.serverTimestamp(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (fotoPerfilLimpia.isNotEmpty()) {
                usuarioMap["fotoUrl"] = fotoPerfilLimpia
            }
            batch.set(db.collection("usuarios").document(uid), usuarioMap)

            batch.set(
                db.collection("usuarios").document(uid).collection("private").document("pii"),
                mapOf(
                    "uid" to uid,
                    "telefono" to telefono.trim(),
                    "email" to email.trim(),
                    "cedula" to cedula.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                db.collection("usuarios").document(uid).collection("private").document("documentos"),
                mapOf(
                    "uid" to uid,
                    "fotoVehiculo" to fotoVehiculoDataUrl.trim().take(218_000),
                    "fotoCedula" to fotoCedulaDataUrl.trim().take(218_000),
                    "fotoLicencia" to fotoLicenciaDataUrl.trim().take(218_000),
                    "fotoCirculacion" to fotoCirculacionDataUrl.trim().take(218_000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            val conductorMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "vehiculoTipo" to vehiculoTipo,
                "vehiculoModelo" to vehiculoModelo.trim(),
                "vehiculoColor" to vehiculoColor.trim(),
                "vehiculoAnio" to vehiculoAnio.trim(),
                "fotoVehiculoUrl" to fotoVehiculoLimpia,
                "placa" to placa.trim().uppercase(),
                "capacidad" to capacidad,
                "tarifaBase" to tarifaBase,
                "tarifaPorKm" to tarifaPorKm,
                "estadoCuenta" to "pendiente",
                "estadoOperativo" to "offline",
                "disponible" to false,
                "licenciaExp" to expDate,
                "mensualidadPendiente" to false,
                "promedioCalificacion" to 5.0,
                "totalCalificaciones" to 0,
                "totalViajes" to 0,
                "gananciasHoy" to 0.0,
                "gananciasMes" to 0.0,
                "cedulaHash" to cedula.trim(),
                "terminosAceptados" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (fotoPerfilLimpia.isNotEmpty()) {
                conductorMap["fotoUrl"] = fotoPerfilLimpia
            }
            batch.set(db.collection("conductores").document(uid), conductorMap)

            batch.commit().await()
            Result.success(uid)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun obtenerPerfilBasicoPasajero(pasajeroId: String): Pair<String, String> {
        return try {
            val snap = db.collection("pasajeros").document(pasajeroId).get().await()
            val nombre = snap.getString("nombre").orEmpty()
            val fotoUrl = snap.getString("fotoUrl").orEmpty()
            Pair(nombre, fotoUrl)
        } catch (_: Exception) {
            Pair("", "")
        }
    }

    suspend fun actualizarFotoPerfilPasajero(pasajeroId: String, fotoUrl: String) {
        val fotoLimpia = fotoUrl.trim().take(148_000)
        if (fotoLimpia.isEmpty()) return
        val batch = db.batch()
        batch.update(
            db.collection("usuarios").document(pasajeroId),
            mapOf(
                "fotoUrl" to fotoLimpia,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("pasajeros").document(pasajeroId),
            mapOf(
                "fotoUrl" to fotoLimpia,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
    }

    // -------------------------------------------------------------------------
    // RUTAS FAVORITAS Y AUTOCOMPLETADO DE UBICACIÓN ACTUAL / DESTINO
    // -------------------------------------------------------------------------
    private fun normalizarTexto(texto: String): String {
        val decomposed = Normalizer.normalize(texto.trim().lowercase(Locale.getDefault()), Normalizer.Form.NFD)
        return decomposed.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
    }

    fun buscarUbicacionesSugeridas(queryTexto: String): List<UbicacionSugerida> {
        val catalogo = listOf(
            UbicacionSugerida("Centro de Pérez Zeledón (Mercado)", "San Isidro, Pérez Zeledón", 9.3738, -83.7042),
            UbicacionSugerida("Santa Elena Centro", "General Viejo, Pérez Zeledón", 9.3895, -83.6490),
            UbicacionSugerida("San Gerardo de Rivas", "Rivas, Pérez Zeledón", 9.4545, -83.5752),
            UbicacionSugerida("EBAIS de Santa Elena", "General Viejo, Pérez Zeledón", 9.3912, -83.6358),
            UbicacionSugerida("Compañía de Galletas Pozuelo (La Uruca)", "La Uruca, San José", 9.9562, -84.1157),
            UbicacionSugerida("Cruce de Pozuelo (Radial Uruca - Heredia)", "La Uruca, San José", 9.9585, -84.1142),
            UbicacionSugerida("Pozuelo — Jardines del Recuerdo", "Valencia / Uruca, Heredia", 9.9614, -84.1135),
            UbicacionSugerida("Hospital México (La Uruca)", "La Uruca, San José", 9.9516, -84.1139),
            UbicacionSugerida("San José Centro (Parque Central)", "San José", 9.9327, -84.0796),
            UbicacionSugerida("Heredia Centro (Parque Nicolás Ulloa)", "Heredia", 9.9986, -84.1165),
            UbicacionSugerida("Alajuela Centro (Parque Juan Santamaría)", "Alajuela", 10.0162, -84.2116),
            UbicacionSugerida("Cartago Centro (Basílica de los Ángeles)", "Cartago", 9.8644, -83.9135),
            UbicacionSugerida("Terminal de Buses Quebradas", "San Isidro, Pérez Zeledón", 9.4234, -83.6941),
            UbicacionSugerida("Feria del Agricultor San Marcos", "Tarrazú, San José", 9.6594, -84.0205)
        )
        val q = normalizarTexto(queryTexto)
        if (q.isEmpty()) return catalogo.take(8)
        return catalogo.filter {
            normalizarTexto(it.nombre).contains(q) || normalizarTexto(it.canton).contains(q)
        }.take(8)
    }

    /**
     * Búsqueda cercana en Nominatim (OpenStreetMap) usando el GPS actual con parámetros viewbox y bounded.
     * Permite encontrar coincidencias parciales como "pulpería" -> "Pulpería La Esquina" o
     * "licorera" -> "Licorera El Barrio" cerca de las coordenadas del pasajero.
     */
    suspend fun buscarUbicacionesNominatim(
        queryTexto: String,
        latCercana: Double = 9.3895,
        lngCercana: Double = -83.6490
    ): List<UbicacionSugerida> {
        val locales = buscarUbicacionesSugeridas(queryTexto)
        val q = queryTexto.trim()
        if (q.length < 2) return locales

        val remotos = withContext(Dispatchers.IO) {
            val resultados = mutableListOf<UbicacionSugerida>()
            val delta = 0.14 // ~15 km alrededor del GPS actual
            val left = String.format(Locale.US, "%.5f", lngCercana - delta)
            val top = String.format(Locale.US, "%.5f", latCercana + delta)
            val right = String.format(Locale.US, "%.5f", lngCercana + delta)
            val bottom = String.format(Locale.US, "%.5f", latCercana - delta)
            val viewbox = "$left,$top,$right,$bottom"
            val encodedQ = URLEncoder.encode(q, "UTF-8")

            fun consultarNominatim(boundedFlag: Int): List<UbicacionSugerida> {
                val lista = mutableListOf<UbicacionSugerida>()
                val urlStr =
                    "https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=cr" +
                        "&addressdetails=1&namedetails=1&limit=8&viewbox=$viewbox&bounded=$boundedFlag&q=$encodedQ"
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 4500
                        readTimeout = 4500
                        setRequestProperty("Accept-Language", "es")
                        setRequestProperty("User-Agent", "ViajeRuralAndroid/1.0 (contact@viajerural.app)")
                    }
                    if (conn.responseCode in 200..299) {
                        val body = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i) ?: continue
                            val lat = obj.optString("lat").toDoubleOrNull() ?: continue
                            val lon = obj.optString("lon").toDoubleOrNull() ?: continue
                            val displayName = obj.optString("display_name")
                            val partes = displayName.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val nameDetails = obj.optJSONObject("namedetails")
                            val address = obj.optJSONObject("address")

                            val nombrePrincipal = obj.optString("name").trim()
                                .ifBlank { nameDetails?.optString("name")?.trim().orEmpty() }
                                .ifBlank { partes.take(2).joinToString(", ") }
                                .ifBlank { q }

                            val detalleZona = listOfNotNull(
                                address?.optString("road")?.takeIf { it.isNotBlank() },
                                address?.optString("neighbourhood")?.takeIf { it.isNotBlank() }
                                    ?: address?.optString("suburb")?.takeIf { it.isNotBlank() },
                                address?.optString("town")?.takeIf { it.isNotBlank() }
                                    ?: address?.optString("city")?.takeIf { it.isNotBlank() }
                                    ?: address?.optString("county")?.takeIf { it.isNotBlank() }
                            ).distinct().joinToString(", ")
                                .ifBlank { partes.drop(1).take(3).joinToString(", ") }
                                .ifBlank { "Costa Rica" }

                            lista.add(
                                UbicacionSugerida(
                                    nombre = nombrePrincipal.take(110),
                                    canton = detalleZona.take(90),
                                    lat = lat,
                                    lng = lon
                                )
                            )
                        }
                    }
                } catch (_: Throwable) {
                } finally {
                    conn?.disconnect()
                }
                return lista
            }

            // 1) Búsqueda estrictamente acotada al viewbox GPS (bounded=1)
            resultados.addAll(consultarNominatim(1))
            // 2) Si hay pocos resultados en 15km, amplía con viewbox priorizado (bounded=0)
            if (resultados.size < 3) {
                resultados.addAll(consultarNominatim(0))
            }
            resultados
        }

        val vistos = HashSet<String>()
        val combinados = mutableListOf<UbicacionSugerida>()
        for (item in remotos + locales) {
            val key = "${item.nombre.lowercase(Locale.getDefault())}|${"%.3f".format(Locale.US, item.lat)}"
            if (vistos.add(key)) {
                combinados.add(item)
            }
        }
        return combinados.take(8)
    }

    private fun calcularDistanciaKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLng / 2) * sin(dLng / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        val km = (r * c * 10.0).roundToInt() / 10.0
        return km.coerceIn(0.5, 500.0)
    }

    @Suppress("UNCHECKED_CAST")
    suspend fun obtenerRutasFavoritasPasajero(pasajeroId: String): List<RutaFavoritaData> {
        val snap = db.collection("pasajeros").document(pasajeroId).get().await()
        if (!snap.exists()) return emptyList()
        val raw = snap.get("rutasFavoritas") as? List<Map<String, Any>> ?: return emptyList()
        return raw.map { m ->
            RutaFavoritaData(
                id = m["id"] as? String ?: "",
                alias = m["alias"] as? String ?: "",
                origenNombre = m["origenNombre"] as? String ?: "",
                origenLat = (m["origenLat"] as? Number)?.toDouble() ?: 0.0,
                origenLng = (m["origenLng"] as? Number)?.toDouble() ?: 0.0,
                destinoNombre = m["destinoNombre"] as? String ?: "",
                destinoLat = (m["destinoLat"] as? Number)?.toDouble() ?: 0.0,
                destinoLng = (m["destinoLng"] as? Number)?.toDouble() ?: 0.0
            )
        }
    }

    suspend fun guardarRutaFavoritaPasajero(
        pasajeroId: String,
        nuevaRuta: RutaFavoritaData
    ): List<RutaFavoritaData> {
        val actuales = obtenerRutasFavoritasPasajero(pasajeroId)
        val actualizadas = (listOf(nuevaRuta) + actuales).take(15)
        val payload = actualizadas.map {
            mapOf(
                "id" to it.id,
                "alias" to it.alias,
                "origenNombre" to it.origenNombre,
                "origenLat" to it.origenLat,
                "origenLng" to it.origenLng,
                "destinoNombre" to it.destinoNombre,
                "destinoLat" to it.destinoLat,
                "destinoLng" to it.destinoLng
            )
        }
        db.collection("pasajeros").document(pasajeroId).update(
            mapOf(
                "rutasFavoritas" to payload,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return actualizadas
    }

    suspend fun eliminarRutaFavoritaPasajero(
        pasajeroId: String,
        rutaId: String
    ): List<RutaFavoritaData> {
        val filtradas = obtenerRutasFavoritasPasajero(pasajeroId).filterNot { it.id == rutaId }
        val payload = filtradas.map {
            mapOf(
                "id" to it.id,
                "alias" to it.alias,
                "origenNombre" to it.origenNombre,
                "origenLat" to it.origenLat,
                "origenLng" to it.origenLng,
                "destinoNombre" to it.destinoNombre,
                "destinoLat" to it.destinoLat,
                "destinoLng" to it.destinoLng
            )
        }
        db.collection("pasajeros").document(pasajeroId).update(
            mapOf(
                "rutasFavoritas" to payload,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return filtradas
    }

    // -------------------------------------------------------------------------
    // RECUPERACIÓN DE ESTADO E HISTORIAL BAJO DEMANDA (limit(20))
    // -------------------------------------------------------------------------
    suspend fun recuperarViajeActivoConductor(conductorId: String): Map<String, Any>? {
        val snap = db.collection("viajes")
            .whereEqualTo("conductorId", conductorId)
            .whereIn("estado", listOf("aceptado", "en_curso"))
            .limit(1)
            .get()
            .await()

        val doc = snap.documents.firstOrNull()
        if (doc == null) {
            val condRef = db.collection("conductores").document(conductorId)
            val condSnap = condRef.get().await()
            val op = condSnap.getString("estadoOperativo")
            if (op == "en_camino" || op == "en_viaje") {
                condRef.update(
                    mapOf(
                        "estadoOperativo" to "disponible",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            return null
        }
        return doc.data?.plus("id" to doc.id)
    }

    suspend fun recuperarViajeActivoPasajero(pasajeroId: String): Pair<Map<String, Any>, String?>? {
        val snap = db.collection("viajes")
            .whereEqualTo("pasajeroId", pasajeroId)
            .whereIn("estado", listOf("buscando", "aceptado", "en_curso"))
            .limit(1)
            .get()
            .await()

        val doc = snap.documents.firstOrNull() ?: return null
        val secretoSnap = db.collection("viajes")
            .document(doc.id)
            .collection("secreto")
            .document("codigo")
            .get()
            .await()

        val pin = secretoSnap.getString("pin")
        return Pair(doc.data.orEmpty().plus("id" to doc.id), pin)
    }

    suspend fun obtenerHistorialPasajero(pasajeroId: String, limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("viajes")
            .whereEqualTo("pasajeroId", pasajeroId)
            .limit(limite)
            .get()
            .await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("id" to doc.id) }
    }

    suspend fun obtenerHistorialConductor(conductorId: String, limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("viajes")
            .whereEqualTo("conductorId", conductorId)
            .limit(limite)
            .get()
            .await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("id" to doc.id) }
    }

    // -------------------------------------------------------------------------
    // TRANSACCIÓN ATÓMICA Y COLA SECUENCIAL DE 15 SEGUNDOS
    // -------------------------------------------------------------------------
    suspend fun aceptarOfertaAtomicamente(viajeId: String, conductorId: String): Result<Unit> {
        val viajeRef = db.collection("viajes").document(viajeId)
        val conductorRef = db.collection("conductores").document(conductorId)

        return try {
            db.runTransaction { tx ->
                val viajeSnap = tx.get(viajeRef)
                val condSnap = tx.get(conductorRef)

                require(viajeSnap.getString("estado") == "buscando") {
                    "Otro conductor aceptó este viaje primero."
                }
                require(condSnap.getString("estadoCuenta") == "activo") {
                    "Tu cuenta debe estar verificada por un administrador."
                }
                require(condSnap.getString("estadoOperativo") == "disponible") {
                    "Conflicto de estado: ya tienes otro viaje activo."
                }

                tx.update(
                    viajeRef,
                    mapOf(
                        "estado" to "aceptado",
                        "conductorId" to conductorId,
                        "conductorNombre" to (condSnap.getString("nombre") ?: "Conductor"),
                        "conductorPlaca" to (condSnap.getString("placa") ?: ""),
                        "vehiculoTipoSeleccionado" to (condSnap.getString("vehiculoTipo") ?: ""),
                        "gpsConductorActivo" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(
                    conductorRef,
                    mapOf(
                        "estadoOperativo" to "en_camino",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun rechazarOfertaSecuencial(viajeId: String, conductorId: String) {
        val viajeRef = db.collection("viajes").document(viajeId)
        db.runTransaction { tx ->
            val snap = tx.get(viajeRef)
            if (snap.getString("estado") != "buscando") return@runTransaction

            @Suppress("UNCHECKED_CAST")
            val cola = (snap.get("colaConductores") as? List<String>).orEmpty().toMutableList()
            cola.remove(conductorId)
            cola.add(conductorId)

            tx.update(
                viajeRef,
                mapOf(
                    "colaConductores" to cola,
                    "ofertaActualIndex" to 0,
                    "ofertaExpiraAt" to (System.currentTimeMillis() + 15_000L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    suspend fun confirmarPinYDetenerGps(
        viajeId: String,
        conductorId: String,
        pinIngresado: String,
        pinHashEsperado: String
    ): Boolean {
        val hash = sha256("$viajeId:${pinIngresado.trim()}")
        if (hash != pinHashEsperado) return false

        val batch = db.batch()
        batch.update(
            db.collection("viajes").document(viajeId),
            mapOf(
                "estado" to "en_curso",
                "pinVerificado" to true,
                "gpsConductorActivo" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("conductores").document(conductorId),
            mapOf(
                "estadoOperativo" to "en_viaje",
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
        return true
    }

    // -------------------------------------------------------------------------
    // REQUISITO 8 Y 9: FINALIZAR VIAJE CON FieldValue.increment() EN FINANZAS
    // -------------------------------------------------------------------------
    suspend fun finalizarViajeConFinanzas(
        viajeId: String,
        conductorId: String,
        montoCobrado: Double
    ) {
        val batch = db.batch()
        batch.update(
            db.collection("viajes").document(viajeId),
            mapOf(
                "estado" to "finalizado",
                "gpsConductorActivo" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("conductores").document(conductorId),
            mapOf(
                "estadoOperativo" to "disponible",
                "totalViajes" to FieldValue.increment(1L),
                "gananciasHoy" to FieldValue.increment(montoCobrado),
                "gananciasMes" to FieldValue.increment(montoCobrado),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
    }

    suspend fun cancelarViajeConMotivo(
        viajeId: String,
        canceladoPor: String,
        motivo: String,
        conductorId: String? = null
    ) {
        val nota = motivo.trim().take(280)
        require(nota.length >= 3) {
            "Debes ingresar una nota explicando el motivo de la cancelación (mínimo 3 caracteres)."
        }

        val batch = db.batch()
        batch.update(
            db.collection("viajes").document(viajeId),
            mapOf(
                "estado" to "cancelado",
                "gpsConductorActivo" to false,
                "canceladoPor" to canceladoPor,
                "motivoCancelacion" to nota,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        if (canceladoPor == "conductor" && !conductorId.isNullOrBlank()) {
            batch.update(
                db.collection("conductores").document(conductorId),
                mapOf(
                    "estadoOperativo" to "disponible",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.commit().await()
    }

    /**
     * Consulta mínima de finanzas del conductor: lee SOLO 1 documento (el suyo)
     * para obtener gananciasHoy y gananciasMes.
     */
    suspend fun obtenerFinanzasConductor(conductorId: String): Pair<Double, Double> {
        val snap = db.collection("conductores").document(conductorId).get().await()
        val hoy = snap.getDouble("gananciasHoy") ?: 0.0
        val mes = snap.getDouble("gananciasMes") ?: 0.0
        return Pair(hoy, mes)
    }

    suspend fun obtenerPerfilYLicenciaConductor(conductorId: String): Map<String, Any>? {
        val docRef = db.collection("conductores").document(conductorId)
        val snap = try {
            docRef.get(Source.SERVER).await()
        } catch (_: Throwable) {
            docRef.get().await()
        }
        return snap.data?.plus("uid" to snap.id)
    }

    fun observarPerfilConductor(
        conductorId: String,
        onUpdate: (Map<String, Any>) -> Unit
    ): ListenerRegistration {
        return db.collection("conductores").document(conductorId)
            .addSnapshotListener { snap, _ ->
                val data = snap?.data ?: return@addSnapshotListener
                onUpdate(data + ("uid" to snap.id))
            }
    }

    suspend fun actualizarDisponibilidadConductor(conductorId: String, disponible: Boolean) {
        db.collection("conductores").document(conductorId).update(
            mapOf(
                "disponible" to disponible,
                "estadoOperativo" to if (disponible) "disponible" else "offline",
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun solicitarViajeConResena(
        pasajeroId: String,
        pasajeroNombre: String,
        cantidadPasajeros: Int,
        origenNombre: String,
        origenLat: Double,
        origenLng: Double,
        destinoNombre: String,
        destinoLat: Double,
        destinoLng: Double,
        resenaUbicacion: String
    ): Pair<Map<String, Any>, String> {
        // Garantizar que FirebaseAuth tenga sesión activa y token válido antes de escribir en Firestore
        val currentUser = auth.currentUser
            ?: throw SecurityException("Tu sesión expiró. Inicia sesión nuevamente para solicitar un viaje.")
        currentUser.getIdToken(false).await()
        val uidAutenticado = currentUser.uid

        val viajeRef = db.collection("viajes").document()
        val viajeId = viajeRef.id
        val pin = (100..999).random().toString()
        val pinHash = sha256("$viajeId:$pin")

        val origenLimpio = origenNombre.trim().let { if (it.length < 2) "Ubicación actual" else it }.take(160)
        val destinoLimpio = destinoNombre.trim().let { if (it.length < 2) "Destino rural" else it }.take(160)
        val resenaLimpia = resenaUbicacion.trim().let { if (it.length < 3) "Punto de encuentro" else it }.take(280)
        val nombreLimpio = pasajeroNombre.trim().let { if (it.length < 2) "Pasajero Rural" else it }.take(100)
        val distanciaKm = calcularDistanciaKm(origenLat, origenLng, destinoLat, destinoLng)
        val montoAproximado = (1500.0 + distanciaKm * 650.0).coerceIn(1500.0, 500000.0)

        val payload = mapOf(
            "pasajeroId" to uidAutenticado,
            "pasajeroNombre" to nombreLimpio,
            "cantidadPasajeros" to cantidadPasajeros.coerceIn(1, 16),
            "origenNombre" to origenLimpio,
            "origenLat" to origenLat,
            "origenLng" to origenLng,
            "destinoNombre" to destinoLimpio,
            "destinoLat" to destinoLat,
            "destinoLng" to destinoLng,
            "distanciaKm" to distanciaKm,
            "resenaUbicacion" to resenaLimpia,
            "montoAproximado" to montoAproximado,
            "pinHash" to pinHash,
            "pinVerificado" to false,
            "gpsConductorActivo" to false,
            "colaConductores" to emptyList<String>(),
            "ofertaActualIndex" to 0,
            "ofertaExpiraAt" to (System.currentTimeMillis() + 15_000L),
            "estado" to "buscando",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        // ESCRITURA SECUENCIAL OBLIGATORIA:
        // Las reglas de /viajes/{viajeId}/secreto/{docId} verifican exists(.../viajes/{viajeId}).
        // Si se envían ambos documentos en un WriteBatch, exists() evalúa falso y Firestore devuelve PERMISSION_DENIED.
        viajeRef.set(payload).await()
        viajeRef.collection("secreto").document("codigo").set(
            mapOf(
                "pasajeroId" to uidAutenticado,
                "pin" to pin,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()

        return Pair(payload + ("id" to viajeId), pin)
    }

    // -------------------------------------------------------------------------
    // REQUISITO 6: CALIFICACIÓN MUTUA Y PROMEDIO GUARDADO EN FIRESTORE
    // -------------------------------------------------------------------------
    suspend fun enviarCalificacionYActualizarPromedio(
        viajeId: String,
        autorUid: String,
        destinatarioUid: String,
        destinatarioRol: String,
        estrellas: Int,
        comentario: String = ""
    ) {
        val calId = "cal_${viajeId}_$destinatarioRol"
        val calRef = db.collection("calificaciones").document(calId)
        val targetCollection = if (destinatarioRol == "conductor") "conductores" else "pasajeros"
        val targetRef = db.collection(targetCollection).document(destinatarioUid)

        db.runTransaction { tx ->
            val targetSnap = tx.get(targetRef)
            val promedioPrevio = targetSnap.getDouble("promedioCalificacion") ?: 5.0
            val totalPrevio = (targetSnap.getLong("totalCalificaciones") ?: 0L).toInt()
            val nuevoTotal = totalPrevio + 1
            val nuevoPromedio = ((promedioPrevio * totalPrevio) + estrellas) / nuevoTotal

            tx.set(
                calRef,
                mapOf(
                    "viajeId" to viajeId,
                    "autorUid" to autorUid,
                    "destinatarioUid" to destinatarioUid,
                    "destinatarioRol" to destinatarioRol,
                    "estrellas" to estrellas,
                    "comentario" to comentario.take(240),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            tx.update(
                targetRef,
                mapOf(
                    "promedioCalificacion" to Math.round(nuevoPromedio * 100.0) / 100.0,
                    "totalCalificaciones" to nuevoTotal,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    // -------------------------------------------------------------------------
    // PANEL ADMIN MODULAR: RESUMEN (COUNT) + CONSULTAS LAZY CON limit(20)
    // -------------------------------------------------------------------------
    suspend fun obtenerResumenAdminLigero(): AdminResumenLigero {
        val condTotal = db.collection("conductores").count().get(AggregateSource.SERVER).await().count
        val condActivos = db.collection("conductores")
            .whereEqualTo("estadoCuenta", "activo")
            .count().get(AggregateSource.SERVER).await().count
        val condPendientes = db.collection("conductores")
            .whereEqualTo("estadoCuenta", "pendiente")
            .count().get(AggregateSource.SERVER).await().count
        val pasTotal = db.collection("pasajeros").count().get(AggregateSource.SERVER).await().count
        val solPendientes = db.collection("solicitudesCambio")
            .whereEqualTo("estado", "pendiente")
            .count().get(AggregateSource.SERVER).await().count

        return AdminResumenLigero(
            totalConductores = condTotal,
            conductoresActivos = condActivos,
            conductoresPendientes = condPendientes,
            totalPasajeros = pasTotal,
            solicitudesPendientes = solPendientes
        )
    }

    suspend fun obtenerPasajerosAdmin(limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("pasajeros").limit(limite).get().await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("uid" to doc.id) }
    }

    suspend fun obtenerConductoresAdmin(limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("conductores").limit(limite).get().await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("uid" to doc.id) }
    }

    suspend fun obtenerConductoresPendientesAdmin(limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("conductores")
            .whereEqualTo("estadoCuenta", "pendiente")
            .limit(limite)
            .get()
            .await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("uid" to doc.id) }
    }

    /**
     * Aprueba y activa un conductor pendiente y establece su fecha de licencia
     * exactamente a 1 mes a partir de la fecha de hoy.
     */
    suspend fun aprobarYActivarConductorAdmin(conductorId: String): Timestamp {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        val nuevaLicenciaExp = Timestamp(cal.time)
        db.collection("conductores").document(conductorId).update(
            mapOf(
                "estadoCuenta" to "activo",
                "estadoOperativo" to "disponible",
                "disponible" to true,
                "mensualidadPendiente" to false,
                "licenciaExp" to nuevaLicenciaExp,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return nuevaLicenciaExp
    }

    /**
     * Renueva la licencia del conductor en Firestore sumando exactamente 1 mes
     * a la fecha actual en el campo licenciaExp.
     */
    suspend fun renovarLicenciaConductorAdmin(conductorId: String): Timestamp {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        val nuevaLicenciaExp = Timestamp(cal.time)
        db.collection("conductores").document(conductorId).update(
            mapOf(
                "licenciaExp" to nuevaLicenciaExp,
                "mensualidadPendiente" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return nuevaLicenciaExp
    }

    suspend fun obtenerPiiUsuarioAdmin(uid: String): Map<String, Any>? {
        val snap = db.collection("usuarios").document(uid)
            .collection("private").document("pii").get().await()
        return snap.data
    }

    suspend fun actualizarFichaPasajeroAdmin(
        pasajeroId: String,
        nombre: String,
        telefono: String,
        email: String,
        cedula: String
    ) {
        val batch = db.batch()
        batch.update(
            db.collection("pasajeros").document(pasajeroId),
            mapOf(
                "nombre" to nombre.trim().take(100),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("usuarios").document(pasajeroId),
            mapOf(
                "nombre" to nombre.trim().take(100),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("usuarios").document(pasajeroId)
                .collection("private").document("pii"),
            mapOf(
                "uid" to pasajeroId,
                "telefono" to telefono.trim().take(30),
                "email" to email.trim().take(160),
                "cedula" to cedula.trim().take(40),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
        batch.commit().await()
    }

    suspend fun toggleBloqueoPasajeroAdmin(pasajeroId: String, bloquear: Boolean) {
        val batch = db.batch()
        batch.update(
            db.collection("pasajeros").document(pasajeroId),
            mapOf(
                "bloqueado" to bloquear,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("usuarios").document(pasajeroId),
            mapOf(
                "bloqueado" to bloquear,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
    }

    suspend fun eliminarCuentaPasajeroAdmin(pasajeroId: String) {
        val batch = db.batch()
        batch.delete(
            db.collection("usuarios").document(pasajeroId)
                .collection("private").document("pii")
        )
        batch.delete(db.collection("pasajeros").document(pasajeroId))
        batch.delete(db.collection("usuarios").document(pasajeroId))
        batch.commit().await()
    }

    // -------------------------------------------------------------------------
    // PETICIONES DE CAMBIO DE DATOS (PASAJERO / CONDUCTOR -> ADMIN)
    // -------------------------------------------------------------------------
    suspend fun crearSolicitudCambioDatos(
        solicitanteUid: String,
        rol: String,
        nombreActual: String,
        resumenActual: String,
        cambios: Map<String, Any>,
        motivo: String
    ): SolicitudCambioData {
        val solicitudId = "sol_${solicitanteUid.take(12)}_${System.currentTimeMillis()}"
        val payload = mapOf(
            "id" to solicitudId,
            "solicitanteUid" to solicitanteUid,
            "rol" to rol,
            "nombreActual" to nombreActual.trim().take(100),
            "resumenActual" to resumenActual.trim().take(240),
            "cambios" to cambios,
            "motivo" to motivo.trim().take(300),
            "estado" to "pendiente",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("solicitudesCambio").document(solicitudId).set(payload).await()
        return SolicitudCambioData(
            id = solicitudId,
            solicitanteUid = solicitanteUid,
            rol = rol,
            nombreActual = nombreActual.trim().take(100),
            resumenActual = resumenActual.trim().take(240),
            cambios = cambios,
            motivo = motivo.trim().take(300),
            estado = "pendiente"
        )
    }

    @Suppress("UNCHECKED_CAST")
    suspend fun obtenerMisSolicitudesCambio(uid: String, limite: Long = 10L): List<SolicitudCambioData> {
        val snap = db.collection("solicitudesCambio")
            .whereEqualTo("solicitanteUid", uid)
            .limit(limite)
            .get()
            .await()
        return snap.documents.map { doc ->
            SolicitudCambioData(
                id = doc.id,
                solicitanteUid = doc.getString("solicitanteUid") ?: uid,
                rol = doc.getString("rol") ?: "pasajero",
                nombreActual = doc.getString("nombreActual") ?: "",
                resumenActual = doc.getString("resumenActual") ?: "",
                cambios = (doc.get("cambios") as? Map<String, Any>).orEmpty(),
                motivo = doc.getString("motivo") ?: "",
                estado = doc.getString("estado") ?: "pendiente",
                respuestaAdmin = doc.getString("respuestaAdmin") ?: ""
            )
        }
    }

    @Suppress("UNCHECKED_CAST")
    suspend fun obtenerSolicitudesCambioAdmin(limite: Long = 20L): List<SolicitudCambioData> {
        val snap = db.collection("solicitudesCambio").limit(limite).get().await()
        return snap.documents.map { doc ->
            SolicitudCambioData(
                id = doc.id,
                solicitanteUid = doc.getString("solicitanteUid") ?: "",
                rol = doc.getString("rol") ?: "pasajero",
                nombreActual = doc.getString("nombreActual") ?: "",
                resumenActual = doc.getString("resumenActual") ?: "",
                cambios = (doc.get("cambios") as? Map<String, Any>).orEmpty(),
                motivo = doc.getString("motivo") ?: "",
                estado = doc.getString("estado") ?: "pendiente",
                respuestaAdmin = doc.getString("respuestaAdmin") ?: ""
            )
        }.sortedBy { if (it.estado == "pendiente") 0 else 1 }
    }

    suspend fun resolverSolicitudCambioAdmin(
        solicitud: SolicitudCambioData,
        aprobar: Boolean,
        respuestaAdmin: String = ""
    ) {
        val uid = solicitud.solicitanteUid
        val c = solicitud.cambios
        val batch = db.batch()

        if (aprobar) {
            val nombreNuevo = (c["nombre"] as? String)?.trim()?.take(100)
            if (!nombreNuevo.isNullOrBlank()) {
                batch.update(
                    db.collection("usuarios").document(uid),
                    mapOf("nombre" to nombreNuevo, "updatedAt" to FieldValue.serverTimestamp())
                )
            }

            val piiUpdates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
            (c["telefono"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { piiUpdates["telefono"] = it.take(30) }
            (c["email"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { piiUpdates["email"] = it.take(160) }
            (c["cedula"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { piiUpdates["cedula"] = it.take(40) }
            if (piiUpdates.size > 1) {
                batch.set(
                    db.collection("usuarios").document(uid).collection("private").document("pii"),
                    piiUpdates + ("uid" to uid),
                    SetOptions.merge()
                )
            }

            if (solicitud.rol == "pasajero" && !nombreNuevo.isNullOrBlank()) {
                batch.update(
                    db.collection("pasajeros").document(uid),
                    mapOf("nombre" to nombreNuevo, "updatedAt" to FieldValue.serverTimestamp())
                )
            }

            if (solicitud.rol == "conductor") {
                val condUpdates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
                if (!nombreNuevo.isNullOrBlank()) condUpdates["nombre"] = nombreNuevo
                (c["cedula"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { condUpdates["cedulaHash"] = it.take(40) }
                (c["vehiculoTipo"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { condUpdates["vehiculoTipo"] = it.take(40) }
                (c["vehiculoModelo"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { condUpdates["vehiculoModelo"] = it.take(80) }
                (c["vehiculoColor"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { condUpdates["vehiculoColor"] = it.take(40) }
                (c["vehiculoAnio"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { condUpdates["vehiculoAnio"] = it.take(10) }
                (c["placa"] as? String)?.trim()?.takeIf { it.isNotBlank() }?.let { condUpdates["placa"] = it.uppercase().take(20) }
                (c["capacidad"] as? Number)?.toInt()?.let { condUpdates["capacidad"] = it.coerceIn(1, 16) }
                if (condUpdates.size > 1) {
                    batch.update(db.collection("conductores").document(uid), condUpdates)
                }
            }
        }

        val solUpdates = mutableMapOf<String, Any>(
            "estado" to if (aprobar) "aprobada" else "rechazada",
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val respLimpia = respuestaAdmin.trim().take(240)
        if (respLimpia.isNotEmpty()) solUpdates["respuestaAdmin"] = respLimpia

        batch.update(db.collection("solicitudesCambio").document(solicitud.id), solUpdates)
        batch.commit().await()
    }

    // -------------------------------------------------------------------------
    // SOPORTE WHATSAPP (62546546), SINPE, TÉRMINOS Y TIPOS DE VEHÍCULO DINÁMICOS
    // -------------------------------------------------------------------------
    suspend fun obtenerConfiguracionGeneral(): Map<String, Any> {
        val snap = db.collection("configuracion").document("general").get().await()
        val defaults = mapOf(
            "whatsappSoporte" to "62546546",
            "sinpeNumero" to "62546546",
            "adminSinpeTitular" to "Administración Viaje Rural",
            "adminNombre" to "Administrador Viaje Rural",
            "adminTelefono" to "62546546",
            "adminEmail" to "sindicatosiserge@gmail.com",
            "linkDescarga" to DEFAULT_LINK_DESCARGA,
            "terminosCondiciones" to "Viaje Rural conecta pasajeros y conductores independientes. Pago directo en efectivo.",
            "tiposVehiculo" to listOf(
                mapOf("nombre" to "Moto", "maxPasajeros" to 1L, "descripcion" to "Mandados y 1 pasajero"),
                mapOf("nombre" to "Sedan", "maxPasajeros" to 4L, "descripcion" to "Camino lastreado o asfalto"),
                mapOf("nombre" to "Pickup 4x4", "maxPasajeros" to 5L, "descripcion" to "Barro, pendientes y fincas"),
                mapOf("nombre" to "SUV Rural", "maxPasajeros" to 5L, "descripcion" to "Trocha y grupos familiares"),
                mapOf("nombre" to "Microbus", "maxPasajeros" to 12L, "descripcion" to "Grupos grandes y carga")
            )
        )
        val data = snap.data ?: return defaults
        return defaults + data
    }

    suspend fun obtenerLinkDescargaApp(): String {
        return try {
            val snap = db.collection("configuracion").document("general").get().await()
            snap.getString("linkDescarga")?.trim()?.takeIf { it.isNotBlank() } ?: DEFAULT_LINK_DESCARGA
        } catch (_: Exception) {
            DEFAULT_LINK_DESCARGA
        }
    }

    suspend fun guardarConfiguracionGeneralAdmin(
        whatsappSoporte: String,
        sinpeNumero: String,
        sinpeTitular: String,
        adminNombre: String,
        adminTelefono: String,
        adminEmail: String,
        terminosCondiciones: String,
        tiposVehiculo: List<Map<String, Any>>,
        linkDescarga: String = DEFAULT_LINK_DESCARGA
    ) {
        val enlaceFinal = linkDescarga.trim().ifBlank { DEFAULT_LINK_DESCARGA }.take(500)
        db.collection("configuracion").document("general").set(
            mapOf(
                "whatsappSoporte" to whatsappSoporte.trim(),
                "sinpeNumero" to sinpeNumero.trim(),
                "adminSinpeTitular" to sinpeTitular.trim(),
                "adminNombre" to adminNombre.trim(),
                "adminTelefono" to adminTelefono.trim(),
                "adminEmail" to adminEmail.trim(),
                "linkDescarga" to enlaceFinal,
                "terminosCondiciones" to terminosCondiciones.trim(),
                "tiposVehiculo" to tiposVehiculo,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun obtenerDocumentosConductorAdmin(conductorId: String): Map<String, Any>? {
        val snap = db.collection("usuarios").document(conductorId)
            .collection("private").document("documentos").get().await()
        return snap.data
    }

    fun queryMensajesChat(viajeId: String): Query {
        return db.collection("chats")
            .document(viajeId)
            .collection("mensajes")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limit(30)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
