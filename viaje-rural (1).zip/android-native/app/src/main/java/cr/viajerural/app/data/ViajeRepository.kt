package cr.viajerural.app.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import cr.viajerural.app.util.ImageCompressionUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.Normalizer
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

data class AdminResumenLigero(
    val totalConductores: Long = 0L,
    val conductoresActivos: Long = 0L,
    val conductoresPendientes: Long = 0L,
    val totalPasajeros: Long = 0L,
    val solicitudesPendientes: Long = 0L
)

data class LicenciaRestanteInfo(
    val dias: Int,
    val fechaTexto: String,
    val estado: String, // "vencida" | "por_vencer" | "vigente"
    val etiqueta: String
)

data class CalculoMensualidadConductor(
    val montoBase: Int,
    val anioBase: Int,
    val anioActual: Int,
    val incrementosAplicados: Int,
    val porcentajeAcumulado: Double,
    val montoActual: Int,
    val montoProximoEnero: Int
)

fun formatearColonesEntero(monto: Int): String {
    val nf = NumberFormat.getIntegerInstance(Locale.US)
    return "₡${nf.format(monto)}"
}

fun calcularMensualidadConductorActual(
    montoBase: Int = ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
    anioBase: Int = ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD,
    ahoraMillis: Long = System.currentTimeMillis()
): CalculoMensualidadConductor {
    val baseNormalizada = montoBase.coerceIn(500, 1_000_000)
    val anioBaseNormalizado = anioBase.coerceIn(2020, 2100)
    val cal = Calendar.getInstance(TimeZone.getTimeZone("America/Costa_Rica")).apply {
        timeInMillis = ahoraMillis
    }
    val anioActual = cal.get(Calendar.YEAR)
    val incrementosAplicados = (anioActual - anioBaseNormalizado).coerceAtLeast(0)
    val montoActual = Math.round(baseNormalizada.toDouble() * 1.10.pow(incrementosAplicados)).toInt()
    val montoProximoEnero = Math.round(baseNormalizada.toDouble() * 1.10.pow(incrementosAplicados + 1)).toInt()
    val porcentajeAcumulado = ((1.10.pow(incrementosAplicados) - 1.0) * 1000.0).roundToInt() / 10.0
    return CalculoMensualidadConductor(
        montoBase = baseNormalizada,
        anioBase = anioBaseNormalizado,
        anioActual = anioActual,
        incrementosAplicados = incrementosAplicados,
        porcentajeAcumulado = porcentajeAcumulado,
        montoActual = montoActual,
        montoProximoEnero = montoProximoEnero
    )
}

fun resolverTerminosConductorDinamicos(
    textoBase: String?,
    montoBase: Int = ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
    anioBase: Int = ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD
): String {
    val fuente = textoBase?.trim()?.takeIf { it.length >= 20 }
        ?: ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
    val calc = calcularMensualidadConductorActual(montoBase, anioBase)
    val montoVigenteStr = formatearColonesEntero(calc.montoActual)
    val montoBaseStr = formatearColonesEntero(calc.montoBase)
    val montoProximoStr = formatearColonesEntero(calc.montoProximoEnero)

    val tieneToken = Regex("\\{\\{\\s*MONTO_CONDUCTOR(?:_VIGENTE)?\\s*\\}\\}", RegexOption.IGNORE_CASE)
        .containsMatchIn(fuente)

    var resuelto = fuente
        .replace(Regex("\\{\\{\\s*MONTO_CONDUCTOR_VIGENTE\\s*\\}\\}", RegexOption.IGNORE_CASE), montoVigenteStr)
        .replace(Regex("\\{\\{\\s*MONTO_CONDUCTOR\\s*\\}\\}", RegexOption.IGNORE_CASE), montoVigenteStr)
        .replace(Regex("\\{\\{\\s*MONTO_CONDUCTOR_BASE\\s*\\}\\}", RegexOption.IGNORE_CASE), montoBaseStr)
        .replace(Regex("\\{\\{\\s*MONTO_PROXIMO_ENERO\\s*\\}\\}", RegexOption.IGNORE_CASE), montoProximoStr)
        .replace(Regex("\\{\\{\\s*ANIO_BASE\\s*\\}\\}", RegexOption.IGNORE_CASE), calc.anioBase.toString())
        .replace(Regex("\\{\\{\\s*ANIO_VIGENTE\\s*\\}\\}", RegexOption.IGNORE_CASE), calc.anioActual.toString())

    if (!tieneToken) {
        val patronCuota = Regex("((?:cuota|mensualidad|licencia|tarifa)[^\\n₡]{0,60}?)₡\\s*[\\d.,]+", RegexOption.IGNORE_CASE)
        val patronColon = Regex("₡\\s*[\\d.,]+")
        resuelto = when {
            patronCuota.containsMatchIn(resuelto) ->
                resuelto.replace(patronCuota) { mr -> "${mr.groupValues[1]}$montoVigenteStr" }
            patronColon.containsMatchIn(resuelto) ->
                patronColon.replaceFirst(resuelto, montoVigenteStr)
            else ->
                "$resuelto\n\nCuota mensual vigente (${calc.anioActual}): $montoVigenteStr colones (+10% automático cada 1 de enero)."
        }
    }
    return resuelto
}

data class CambioItemData(
    val clave: String,
    val etiqueta: String,
    val tipo: String, // "texto" | "imagen"
    val valorAnterior: String,
    val valorNuevo: String,
    val estado: String = "pendiente", // "pendiente" | "aprobado" | "rechazado"
    val motivoRechazo: String = ""
) {
    fun toFirestoreMap(): Map<String, Any> = mapOf(
        "clave" to clave.trim().take(40),
        "etiqueta" to etiqueta.trim().take(80),
        "tipo" to if (tipo == "imagen") "imagen" else "texto",
        "valorAnterior" to valorAnterior.take(218_000),
        "valorNuevo" to valorNuevo.take(218_000),
        "estado" to when (estado) {
            "aprobado", "rechazado" -> estado
            else -> "pendiente"
        },
        "motivoRechazo" to motivoRechazo.trim().take(240)
    )
}

fun etiquetaCambioPorClave(clave: String): String = when (clave) {
    "nombre" -> "Nombre completo"
    "telefono" -> "Teléfono"
    "email" -> "Correo electrónico"
    "cedula" -> "Cédula"
    "vehiculoTipo" -> "Tipo de vehículo"
    "vehiculoMarca" -> "Marca del vehículo"
    "vehiculoModelo" -> "Modelo del vehículo"
    "color", "vehiculoColor" -> "Color del vehículo"
    "vehiculoAnio", "anio" -> "Año del vehículo"
    "placa" -> "Placa"
    "capacidad" -> "Capacidad (pasajeros)"
    "tarifaBase" -> "Tarifa base (₡)"
    "tarifaBaseCarga" -> "Tarifa base con carga / flete (₡)"
    "precioKm", "tarifaPorKm" -> "Precio por km (₡)"
    "tieneCascoExtra" -> "Casco extra para pasajero"
    "tieneCapaDisponible" -> "Capa impermeable disponible"
    "fotoVehiculo" -> "Foto del vehículo"
    "fotoCedula" -> "Foto de Cédula"
    "fotoLicencia" -> "Foto de Licencia"
    "fotoMarchamoRtv", "fotoCirculacion" -> "Foto Marchamo / RTV"
    else -> clave
}

data class SolicitudCambioData(
    val id: String,
    val solicitanteUid: String,
    val rol: String,
    val nombreActual: String,
    val resumenActual: String,
    val cambios: Map<String, Any> = emptyMap(),
    val items: List<CambioItemData> = emptyList(),
    val motivo: String = "",
    val estado: String = "pendiente",
    val estadoGeneral: String = "pendiente",
    val respuestaAdmin: String = "",
    val datosAnteriores: Map<String, Any> = emptyMap(),
    val createdAtMillis: Long = 0L
) {
    val esGranular: Boolean
        get() = items.isNotEmpty()

    val tienePendientes: Boolean
        get() = if (items.isNotEmpty()) {
            items.any { it.estado == "pendiente" }
        } else {
            estado == "pendiente" || estadoGeneral == "pendiente"
        }

    val cantidadPendientes: Int
        get() = if (items.isNotEmpty()) {
            items.count { it.estado == "pendiente" }
        } else if (estado == "pendiente") 1 else 0
}

fun parseLicenciaExpMillis(licenciaExp: Any?): Long? {
    return when (licenciaExp) {
        is Timestamp -> licenciaExp.toDate().time
        is Date -> licenciaExp.time
        is Number -> {
            val raw = licenciaExp.toLong()
            if (raw in 1L..99_999_999_999L) raw * 1000L else raw
        }
        is Map<*, *> -> {
            val sec = (licenciaExp["seconds"] as? Number)?.toLong()
                ?: (licenciaExp["_seconds"] as? Number)?.toLong()
            sec?.times(1000L)
        }
        is String -> {
            val limpio = licenciaExp.trim()
            if (limpio.isEmpty()) return null
            limpio.toLongOrNull()?.let { n ->
                return if (n in 1L..99_999_999_999L) n * 1000L else n
            }
            val patrones = listOf(
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd",
                "dd/MM/yyyy"
            )
            for (patron in patrones) {
                try {
                    val fmt = SimpleDateFormat(patron, Locale.US).apply { isLenient = false }
                    val parsed = fmt.parse(limpio)
                    if (parsed != null) return parsed.time
                } catch (_: Throwable) {
                }
            }
            null
        }
        else -> null
    }
}

fun calcularDiasLicenciaRestantes(licenciaExp: Any?): LicenciaRestanteInfo {
    val expMillis = parseLicenciaExpMillis(licenciaExp)
    if (expMillis == null) {
        return LicenciaRestanteInfo(
            dias = 0,
            fechaTexto = "--/--/----",
            estado = "vencida",
            etiqueta = "Licencia vencida"
        )
    }
    val diffMs = expMillis - System.currentTimeMillis()
    val dias = (diffMs / (1000L * 60L * 60L * 24L)).toInt()
    val formatter = SimpleDateFormat("dd/MM/yyyy", Locale("es", "CR"))
    val fechaTexto = formatter.format(Date(expMillis))
    val estado = when {
        dias <= 0 -> "vencida"
        dias <= 7 -> "por_vencer"
        else -> "vigente"
    }
    val etiqueta = if (dias > 0) {
        "Licencia vigente: $dias días"
    } else {
        "Licencia vencida"
    }
    return LicenciaRestanteInfo(dias = dias, fechaTexto = fechaTexto, estado = estado, etiqueta = etiqueta)
}

data class UbicacionSugerida(
    val nombre: String,
    val canton: String,
    val lat: Double,
    val lng: Double
)

data class RutaFavoritaData(
    val id: String,
    val alias: String,
    val origenNombre: String,
    val origenLat: Double,
    val origenLng: Double,
    val destinoNombre: String,
    val destinoLat: Double,
    val destinoLng: Double
)

data class ConductorDisponibleCercano(
    val uid: String,
    val nombre: String,
    val tipoVehiculo: String,
    val capacidad: Int,
    val lat: Double,
    val lng: Double,
    val distanciaKm: Double,
    val tarifaBase: Double,
    val tarifaPorKm: Double,
    val tarifaBaseCarga: Double? = null,
    val tieneCascoExtra: Boolean = false,
    val tieneCapaDisponible: Boolean = false
)

/**
 * Repositorio principal de Viaje Rural optimizado para ahorro de datos y costos de Firebase:
 * - Consultas ligeras bajo demanda con limit(20) solo al abrir cada pestaña.
 * - Conteos en servidor (AggregateSource.SERVER) para Resumen Admin sin descargar documentos.
 * - Transacción atómica para ofertas secuenciales (evita conflicto de listas).
 * - FieldValue.increment() en gananciasHoy y gananciasMes para evitar lecturas de historial.
 * - Rutas Favoritas y catálogo de ubicaciones (ej. Pozuelo, La Uruca, Pérez Zeledón) para autocompletado.
 */
class ViajeRepository {

    companion object {
        const val FIRESTORE_DATABASE_ID = "ai-studio-63fccfd3-d2c4-45bd-a1c6-d9b0d1e46b20"
        const val DEFAULT_LINK_DESCARGA = "https://viajerural.com/descargar"
        const val FCM_CHANNEL_OFERTAS = "viajes_ofertas"
        const val DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE = 7000
        const val DEFAULT_ANIO_BASE_MENSUALIDAD = 2026
        const val DEFAULT_TARIFA_BASE_NORMAL = 1500.0
        const val DEFAULT_TARIFA_KM = 650.0
        const val DEFAULT_TARIFA_BASE_CARGA = 3000.0
        const val DEFAULT_MULTIPLICADOR_TOPE_NORMAL = 1.6
        const val DEFAULT_MULTIPLICADOR_TOPE_CARGA = 2.2
        const val TOKEN_MONTO_CONDUCTOR_VIGENTE = "{{MONTO_CONDUCTOR_VIGENTE}}"

        fun esVehiculoCargo(tipo: String): Boolean {
            val decomposed = Normalizer.normalize(tipo.trim().lowercase(Locale.getDefault()), Normalizer.Form.NFD)
            val norm = decomposed.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            return norm.contains("pickup") ||
                norm.contains("pick up") ||
                norm.contains("4x4") ||
                norm.contains("carga") ||
                norm.contains("camion") ||
                norm.contains("flete") ||
                norm.contains("microbus") ||
                norm.contains("buseta")
        }

        fun esVehiculoMoto(tipo: String): Boolean {
            val decomposed = Normalizer.normalize(tipo.trim().lowercase(Locale.getDefault()), Normalizer.Form.NFD)
            val norm = decomposed.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            return norm.contains("moto")
        }

        fun calcularTarifaBaseEfectiva(
            tarifaBase: Double,
            tarifaBaseCarga: Double?,
            esCargaFlete: Boolean
        ): Double {
            if (!esCargaFlete) return tarifaBase
            return tarifaBaseCarga?.takeIf { it >= 500.0 }
                ?: maxOf(tarifaBase * 1.6, DEFAULT_TARIFA_BASE_CARGA)
        }

        fun calcularLimiteMaximoPermitido(
            montoReferenciaPromedio: Double,
            esCargaFlete: Boolean,
            multiplicadorTopeNormal: Double = DEFAULT_MULTIPLICADOR_TOPE_NORMAL,
            multiplicadorTopeCarga: Double = DEFAULT_MULTIPLICADOR_TOPE_CARGA
        ): Double {
            val mult = if (esCargaFlete) {
                multiplicadorTopeCarga.coerceIn(1.1, 5.0)
            } else {
                multiplicadorTopeNormal.coerceIn(1.1, 5.0)
            }
            return (montoReferenciaPromedio.coerceAtLeast(DEFAULT_TARIFA_BASE_NORMAL) * mult)
                .roundToInt()
                .toDouble()
        }
        const val DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR =
            "1. Naturaleza del servicio:\n" +
                "Plataforma tecnológica de intermediación que conecta conductores independientes con pasajeros; no presta servicio de transporte público ni existe relación laboral.\n\n" +
                "2. Tarifas y pagos:\n" +
                "Acuerdos de traslado y cobros directamente entre conductor y pasajero (solo conexión efectivo); sin comisiones por viaje.\n\n" +
                "3. Licencia de uso y cuota mensual:\n" +
                "Licencia mensual base de $TOKEN_MONTO_CONDUCTOR_VIGENTE colones mediante SINPE Móvil, con ajuste automático del 10% anual cada 1 de enero (hora Costa Rica).\n\n" +
                "4. Documentación y responsabilidad:\n" +
                "El conductor declara tener licencia vigente, derecho de circulación (marchamo) e inspección técnica vehicular (RTV/DEKRA) al día conforme a la normativa de Costa Rica.\n\n" +
                "5. Privacidad y GPS:\n" +
                "Recopilación y transmisión de ubicación GPS en tiempo real mientras el conductor esté activo o en viaje. Los números telefónicos permanecen protegidos y ocultos en el chat operativo."
        const val DEFAULT_TERMINOS_CONDICIONES_PASAJERO =
            "1. Uso Gratuito para el Pasajero (Sin Cobro de App ni Comisiones)\n" +
                "El uso de Viaje Rural es 100% gratuito para el pasajero. No se incluye ningún tipo de cobro por uso de la aplicación, suscripciones, comisiones ni cargos adicionales de plataforma sobre tus viajes.\n\n" +
                "2. Pago Directo en Efectivo al Conductor\n" +
                "El pasajero paga únicamente la tarifa del viaje mostrada antes de confirmar la solicitud, liquidándola directamente en efectivo al conductor al finalizar el traslado.\n\n" +
                "3. PIN de Seguridad y Uso Responsable\n" +
                "Cada viaje asignado genera un PIN de seguridad de 3 dígitos que debes entregar al conductor únicamente al momento de abordar el vehículo. En caso de cancelar, deberás indicar el motivo con transparencia.\n\n" +
                "4. Privacidad de Datos\n" +
                "Tu número telefónico y datos personales permanecen protegidos y no se muestran en el chat operativo ni a terceros; solo el Administrador autorizado puede revisarlos para soporte o verificación."

        /**
         * Geocodificación inversa para convertir coordenadas GPS en dirección legible
         * (ej: "Hospital México, La Uruca") usando Nominatim OpenStreetMap y fallback a Android Geocoder.
         */
        suspend fun reverseGeocodificarUbicacion(
            context: Context?,
            lat: Double,
            lng: Double
        ): String = withContext(Dispatchers.IO) {
            // 1) Intentar Nominatim Reverse API para formato de POI + distrito en Costa Rica
            var conn: HttpURLConnection? = null
            try {
                val urlStr = String.format(
                    Locale.US,
                    "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=%.6f&lon=%.6f&zoom=18&addressdetails=1",
                    lat,
                    lng
                )
                conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 4000
                    readTimeout = 4000
                    setRequestProperty("User-Agent", "ViajeRuralAndroid/1.0")
                    setRequestProperty("Accept-Language", "es")
                }
                if (conn.responseCode in 200..299) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    val addr = json.optJSONObject("address")
                    val punto = listOf(
                        json.optString("name"),
                        addr?.optString("amenity"),
                        addr?.optString("shop"),
                        addr?.optString("building"),
                        addr?.optString("road"),
                        json.optString("display_name").split(",").firstOrNull()
                    ).firstOrNull { !it.isNullOrBlank() }?.trim()

                    val localidad = listOf(
                        addr?.optString("suburb"),
                        addr?.optString("neighbourhood"),
                        addr?.optString("village"),
                        addr?.optString("city_district"),
                        addr?.optString("town"),
                        addr?.optString("city"),
                        addr?.optString("county")
                    ).firstOrNull {
                        !it.isNullOrBlank() && !it.equals(punto, ignoreCase = true)
                    }?.trim()

                    val combinada = listOfNotNull(punto, localidad)
                        .distinct()
                        .joinToString(", ")
                        .take(110)

                    if (combinada.isNotBlank()) {
                        return@withContext combinada
                    }
                }
            } catch (_: Throwable) {
            } finally {
                conn?.disconnect()
            }

            // 2) Fallback nativo con Android Geocoder si no hubo red o falló Nominatim
            if (context != null && Geocoder.isPresent()) {
                try {
                    val geocoder = Geocoder(context, Locale("es", "CR"))
                    @Suppress("DEPRECATION")
                    val direcciones = geocoder.getFromLocation(lat, lng, 1)
                    val dir = direcciones?.firstOrNull()
                    if (dir != null) {
                        val lineaPrincipal = dir.featureName?.takeIf {
                            it.isNotBlank() && !it.all { ch -> ch.isDigit() }
                        } ?: dir.thoroughfare
                        val zona = dir.subLocality ?: dir.locality ?: dir.subAdminArea
                        val texto = listOfNotNull(lineaPrincipal, zona)
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                            .distinct()
                            .joinToString(", ")
                            .take(110)
                        if (texto.isNotBlank()) {
                            return@withContext texto
                        }
                    }
                } catch (_: Throwable) {
                }
            }

            // 3) Fallback seguro de coordenadas legibles
            "Mi ubicación GPS (${String.format(Locale.US, "%.4f, %.4f", lat, lng)})"
        }

        /**
         * Construye el payload FCM de alta prioridad para enviar ofertas de viaje (15s) al Conductor
         * asegurando entrega inmediata en Doze/bloqueo (`priority = "high"`) y canal `viajes_ofertas`.
         */
        fun construirPayloadFcmOferta(
            tokenConductor: String,
            viajeId: String,
            origen: String,
            destino: String,
            pasajeros: Int,
            montoAproximado: Int,
            resenaUbicacion: String = ""
        ): Map<String, Any> {
            val titulo = "🚕 Nueva oferta de viaje ($pasajeros pas.)"
            val cuerpoBase = "$origen → $destino · ₡$montoAproximado"
            val cuerpo = if (resenaUbicacion.isNotBlank()) {
                "$cuerpoBase · Ref: $resenaUbicacion"
            } else {
                cuerpoBase
            }
            return mapOf(
                "to" to tokenConductor,
                "priority" to "high",
                "notification" to mapOf(
                    "title" to titulo,
                    "body" to cuerpo,
                    "channel_id" to FCM_CHANNEL_OFERTAS,
                    "sound" to "default"
                ),
                "android" to mapOf(
                    "priority" to "high",
                    "ttl" to "15s",
                    "notification" to mapOf(
                        "channel_id" to FCM_CHANNEL_OFERTAS,
                        "sound" to "default",
                        "notification_priority" to "PRIORITY_MAX",
                        "visibility" to "PUBLIC"
                    )
                ),
                "data" to mapOf(
                    "tipo" to "OFERTA_15S",
                    "viajeId" to viajeId,
                    "titulo" to titulo,
                    "resumen" to cuerpo,
                    "origen" to origen,
                    "destino" to destino,
                    "pasajeros" to pasajeros.toString(),
                    "montoAproximado" to montoAproximado.toString(),
                    "resenaUbicacion" to resenaUbicacion
                )
            )
        }
    }

    private val db: FirebaseFirestore by lazy {
        try {
            FirebaseFirestore.getInstance(FIRESTORE_DATABASE_ID)
        } catch (_: Throwable) {
            FirebaseFirestore.getInstance()
        }
    }

    private val auth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    // -------------------------------------------------------------------------
    // REQUISITO 5: AUTENTICACIÓN SEPARADA (PASAJERO, CONDUCTOR Y ADMIN SEGURO)
    // -------------------------------------------------------------------------
    suspend fun iniciarSesion(email: String, password: String): Result<String> {
        return try {
            val res = auth.signInWithEmailAndPassword(email.trim(), password).await()
            Result.success(res.user?.uid ?: throw IllegalStateException("UID nulo"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Login de Administrador Seguro:
     * 1. Autentica con FirebaseAuth.signInWithEmailAndPassword.
     * 2. Consulta usuarios/{uid} en Firestore y valida que rol == "admin".
     * 3. Si no es "admin", cierra sesión de inmediato y deniega el acceso.
     */
    suspend fun iniciarSesionAdmin(email: String, password: String): Result<String> {
        return try {
            val res = auth.signInWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: throw IllegalStateException("No se pudo obtener el UID del usuario.")
            val userSnap = db.collection("usuarios").document(uid).get().await()
            val rol = userSnap.getString("rol")?.trim()?.lowercase()
            if (rol != "admin") {
                auth.signOut()
                return Result.failure(SecurityException("Acceso denegado: tu cuenta no tiene rol de administrador."))
            }
            Result.success(uid)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun verificarRolAdminActual(uid: String): Boolean {
        return obtenerRolUsuarioActual(uid) == "admin"
    }

    private val SESSION_PREFS_NAME = "viaje_rural_session"
    private val KEY_LAST_UID = "last_uid"
    private val KEY_LAST_ROL = "last_rol"

    fun guardarRolLocal(context: Context, uid: String, rol: String) {
        try {
            context.applicationContext
                .getSharedPreferences(SESSION_PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LAST_UID, uid)
                .putString(KEY_LAST_ROL, rol.trim().lowercase())
                .apply()
        } catch (_: Throwable) {
        }
    }

    fun obtenerRolLocal(context: Context, uid: String): String? {
        return try {
            val prefs = context.applicationContext
                .getSharedPreferences(SESSION_PREFS_NAME, Context.MODE_PRIVATE)
            if (prefs.getString(KEY_LAST_UID, null) == uid) {
                prefs.getString(KEY_LAST_ROL, null)?.trim()?.lowercase()
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun limpiarRolLocal(context: Context) {
        try {
            context.applicationContext
                .getSharedPreferences(SESSION_PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .clear()
                .apply()
        } catch (_: Throwable) {
        }
    }

    /**
     * Lee el rol actual ("admin", "conductor" o "pasajero") desde Firestore (usuarios/{uid},
     * con fallback a conductores/{uid} y pasajeros/{uid}) y lo guarda localmente para autologin
     * confiable incluso tras cierre completo del sistema o reconexión offline.
     */
    suspend fun resolverRolUsuarioAutologin(context: Context, uid: String): String {
        val rolRemoto = obtenerRolUsuarioActual(uid)
        if (rolRemoto != null) {
            guardarRolLocal(context, uid, rolRemoto)
            return rolRemoto
        }
        return obtenerRolLocal(context, uid) ?: "pasajero"
    }

    /**
     * Asegura que usuarios/{uid} exista tras iniciar sesión y devuelve el rol definitivo.
     */
    suspend fun asegurarRolEnLogin(context: Context, uid: String, esConductorPreferido: Boolean): String {
        val rolExistente = obtenerRolUsuarioActual(uid)
        if (rolExistente != null) {
            guardarRolLocal(context, uid, rolExistente)
            return rolExistente
        }
        val rolInicial = if (esConductorPreferido) "conductor" else "pasajero"
        try {
            val user = auth.currentUser
            val nombre = user?.displayName?.trim()?.takeIf { it.length >= 2 }
                ?: if (esConductorPreferido) "Conductor Rural" else "Pasajero Rural"
            db.collection("usuarios").document(uid).set(
                mapOf(
                    "uid" to uid,
                    "nombre" to nombre,
                    "rol" to rolInicial,
                    "bloqueado" to false,
                    "terminosAceptados" to true,
                    "terminosAceptadosAt" to FieldValue.serverTimestamp(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
        } catch (_: Throwable) {
        }
        guardarRolLocal(context, uid, rolInicial)
        return rolInicial
    }

    /**
     * Lee únicamente el documento usuarios/{uid} (y conductores/{uid} / pasajeros/{uid} como respaldo)
     * para determinar el rol actual ("admin", "conductor" o "pasajero").
     * Retorna null si no se pudo determinar por error de red/ausencia de documento.
     */
    suspend fun obtenerRolUsuarioActual(uid: String): String? {
        try {
            val userDoc = try {
                db.collection("usuarios").document(uid).get(Source.DEFAULT).await()
            } catch (_: Throwable) {
                null
            }
            val userSnap = if (userDoc == null || !userDoc.exists()) {
                try {
                    db.collection("usuarios").document(uid).get(Source.SERVER).await()
                } catch (_: Throwable) {
                    userDoc
                }
            } else {
                userDoc
            }
            val rol = userSnap?.getString("rol")?.trim()?.lowercase()
            if (rol == "admin" || rol == "conductor" || rol == "pasajero") {
                return rol
            }
        } catch (_: Exception) {
        }

        // Respaldo: verificar si el usuario tiene ficha en conductores/{uid}
        try {
            val condSnap = db.collection("conductores").document(uid).get().await()
            if (condSnap.exists()) return "conductor"
        } catch (_: Exception) {
        }

        // Respaldo: verificar si el usuario tiene ficha en pasajeros/{uid}
        try {
            val pasSnap = db.collection("pasajeros").document(uid).get().await()
            if (pasSnap.exists()) return "pasajero"
        } catch (_: Exception) {
        }

        return null
    }

    fun cerrarSesion(context: Context? = null) {
        context?.let { limpiarRolLocal(it) }
        try {
            auth.signOut()
        } catch (_: Throwable) {
        }
    }

    suspend fun registrarPasajero(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        fotoUrl: String = ""
    ): Result<String> {
        return try {
            val res = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: throw IllegalStateException("No se pudo crear usuario")
            val fotoLimpia = fotoUrl.trim().take(148_000)
            val batch = db.batch()

            val usuarioMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "rol" to "pasajero",
                "bloqueado" to false,
                "terminosAceptados" to true,
                "terminosAceptadosAt" to FieldValue.serverTimestamp(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (fotoLimpia.isNotEmpty()) {
                usuarioMap["fotoUrl"] = fotoLimpia
            }
            batch.set(db.collection("usuarios").document(uid), usuarioMap)

            batch.set(
                db.collection("usuarios").document(uid).collection("private").document("pii"),
                mapOf(
                    "uid" to uid,
                    "telefono" to telefono.trim(),
                    "email" to email.trim(),
                    "cedula" to cedula.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            val pasajeroMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "promedioCalificacion" to 5.0,
                "totalCalificaciones" to 0,
                "favoritos" to emptyList<String>(),
                "rutasFavoritas" to emptyList<Map<String, Any>>(),
                "bloqueado" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (fotoLimpia.isNotEmpty()) {
                pasajeroMap["fotoUrl"] = fotoLimpia
            }
            batch.set(db.collection("pasajeros").document(uid), pasajeroMap)

            batch.commit().await()
            Result.success(uid)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registrarConductor(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        vehiculoTipo: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        fotoVehiculoDataUrl: String = "",
        fotoCedulaDataUrl: String = "",
        fotoLicenciaDataUrl: String = "",
        fotoCirculacionDataUrl: String = "",
        fotoPerfilDataUrl: String = "",
        tarifaBaseCarga: Double? = null,
        tieneCascoExtra: Boolean = false,
        tieneCapaDisponible: Boolean = false
    ): Result<String> {
        return try {
            val res = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: throw IllegalStateException("No se pudo crear conductor")
            val expDate = Timestamp(Date(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000))
            val fotoPerfilLimpia = fotoPerfilDataUrl.trim().take(148_000)
            val fotoVehiculoLimpia = fotoVehiculoDataUrl.trim().take(148_000)
            val batch = db.batch()

            val usuarioMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "rol" to "conductor",
                "bloqueado" to false,
                "terminosAceptados" to true,
                "terminosAceptadosAt" to FieldValue.serverTimestamp(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (fotoPerfilLimpia.isNotEmpty()) {
                usuarioMap["fotoUrl"] = fotoPerfilLimpia
            }
            batch.set(db.collection("usuarios").document(uid), usuarioMap)

            batch.set(
                db.collection("usuarios").document(uid).collection("private").document("pii"),
                mapOf(
                    "uid" to uid,
                    "telefono" to telefono.trim(),
                    "email" to email.trim(),
                    "cedula" to cedula.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                db.collection("usuarios").document(uid).collection("private").document("documentos"),
                mapOf(
                    "uid" to uid,
                    "fotoVehiculo" to fotoVehiculoDataUrl.trim().take(218_000),
                    "fotoCedula" to fotoCedulaDataUrl.trim().take(218_000),
                    "fotoLicencia" to fotoLicenciaDataUrl.trim().take(218_000),
                    "fotoCirculacion" to fotoCirculacionDataUrl.trim().take(218_000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            val conductorMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "nombre" to nombre.trim(),
                "vehiculoTipo" to vehiculoTipo,
                "tipoVehiculo" to normalizarTipoVehiculo(vehiculoTipo),
                "vehiculoModelo" to vehiculoModelo.trim(),
                "vehiculoColor" to vehiculoColor.trim(),
                "vehiculoAnio" to vehiculoAnio.trim(),
                "fotoVehiculoUrl" to fotoVehiculoLimpia,
                "placa" to placa.trim().uppercase(),
                "capacidad" to capacidad,
                "tarifaBase" to tarifaBase,
                "tarifaPorKm" to tarifaPorKm,
                "estadoCuenta" to "pendiente",
                "estadoOperativo" to "offline",
                "disponible" to false,
                "licenciaExp" to expDate,
                "mensualidadPendiente" to false,
                "promedioCalificacion" to 5.0,
                "totalCalificaciones" to 0,
                "totalViajes" to 0,
                "gananciasHoy" to 0.0,
                "gananciasMes" to 0.0,
                "cedulaHash" to cedula.trim(),
                "terminosAceptados" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (esVehiculoCargo(vehiculoTipo) && tarifaBaseCarga != null && tarifaBaseCarga >= 500.0) {
                conductorMap["tarifaBaseCarga"] = tarifaBaseCarga.coerceIn(500.0, 150000.0)
            }
            if (esVehiculoMoto(vehiculoTipo)) {
                conductorMap["tieneCascoExtra"] = tieneCascoExtra
                conductorMap["tieneCapaDisponible"] = tieneCapaDisponible
            }
            if (fotoPerfilLimpia.isNotEmpty()) {
                conductorMap["fotoUrl"] = fotoPerfilLimpia
            }
            batch.set(db.collection("conductores").document(uid), conductorMap)

            batch.commit().await()
            Result.success(uid)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun obtenerPerfilBasicoPasajero(pasajeroId: String): Pair<String, String> {
        return try {
            val snap = db.collection("pasajeros").document(pasajeroId).get().await()
            val nombre = snap.getString("nombre").orEmpty()
            val fotoUrl = snap.getString("fotoUrl").orEmpty()
            Pair(nombre, fotoUrl)
        } catch (_: Exception) {
            Pair("", "")
        }
    }

    suspend fun actualizarFotoPerfilPasajero(pasajeroId: String, fotoUrl: String) {
        val fotoLimpia = fotoUrl.trim().take(148_000)
        if (fotoLimpia.isEmpty()) return
        val batch = db.batch()
        batch.update(
            db.collection("usuarios").document(pasajeroId),
            mapOf(
                "fotoUrl" to fotoLimpia,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("pasajeros").document(pasajeroId),
            mapOf(
                "fotoUrl" to fotoLimpia,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
    }

    // -------------------------------------------------------------------------
    // RUTAS FAVORITAS Y AUTOCOMPLETADO DE UBICACIÓN ACTUAL / DESTINO
    // -------------------------------------------------------------------------
    private fun normalizarTexto(texto: String): String {
        val decomposed = Normalizer.normalize(texto.trim().lowercase(Locale.getDefault()), Normalizer.Form.NFD)
        return decomposed.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
    }

    fun buscarUbicacionesSugeridas(queryTexto: String): List<UbicacionSugerida> {
        val catalogo = listOf(
            UbicacionSugerida("Centro de Pérez Zeledón (Mercado)", "San Isidro, Pérez Zeledón", 9.3738, -83.7042),
            UbicacionSugerida("Santa Elena Centro", "General Viejo, Pérez Zeledón", 9.3895, -83.6490),
            UbicacionSugerida("San Gerardo de Rivas", "Rivas, Pérez Zeledón", 9.4545, -83.5752),
            UbicacionSugerida("EBAIS de Santa Elena", "General Viejo, Pérez Zeledón", 9.3912, -83.6358),
            UbicacionSugerida("Compañía de Galletas Pozuelo (La Uruca)", "La Uruca, San José", 9.9562, -84.1157),
            UbicacionSugerida("Cruce de Pozuelo (Radial Uruca - Heredia)", "La Uruca, San José", 9.9585, -84.1142),
            UbicacionSugerida("Pozuelo — Jardines del Recuerdo", "Valencia / Uruca, Heredia", 9.9614, -84.1135),
            UbicacionSugerida("Hospital México (La Uruca)", "La Uruca, San José", 9.9516, -84.1139),
            UbicacionSugerida("San José Centro (Parque Central)", "San José", 9.9327, -84.0796),
            UbicacionSugerida("Heredia Centro (Parque Nicolás Ulloa)", "Heredia", 9.9986, -84.1165),
            UbicacionSugerida("Alajuela Centro (Parque Juan Santamaría)", "Alajuela", 10.0162, -84.2116),
            UbicacionSugerida("Cartago Centro (Basílica de los Ángeles)", "Cartago", 9.8644, -83.9135),
            UbicacionSugerida("Terminal de Buses Quebradas", "San Isidro, Pérez Zeledón", 9.4234, -83.6941),
            UbicacionSugerida("Feria del Agricultor San Marcos", "Tarrazú, San José", 9.6594, -84.0205)
        )
        val q = normalizarTexto(queryTexto)
        if (q.isEmpty()) return catalogo.take(8)
        return catalogo.filter {
            normalizarTexto(it.nombre).contains(q) || normalizarTexto(it.canton).contains(q)
        }.take(8)
    }

    private fun expandirPalabrasClaveRurales(queryTexto: String): List<String> {
        val norm = normalizarTexto(queryTexto)
        val terminos = linkedSetOf(queryTexto.trim())
        when {
            norm.contains("pulperia") -> terminos.addAll(listOf("abastecedor", "minisuper"))
            norm.contains("licorera") || norm.contains("licores") -> terminos.addAll(listOf("licorera", "licores", "licoreria"))
            norm.contains("supermercado") || norm == "super" -> terminos.addAll(listOf("supermercado", "super", "supermarket", "pali"))
            norm.contains("farmacia") -> terminos.addAll(listOf("farmacia", "pharmacy"))
            norm.contains("restaurante") || norm.contains("soda") -> terminos.addAll(listOf("restaurante", "soda", "restaurant"))
            norm.contains("ebais") || norm.contains("clinica") -> terminos.addAll(listOf("ebais", "clinica", "clinic"))
            norm.contains("ferreteria") -> terminos.addAll(listOf("ferreteria", "hardware"))
            norm.contains("panaderia") -> terminos.addAll(listOf("panaderia", "bakery"))
        }
        return terminos.filter { it.length >= 2 }.take(3)
    }

    /**
     * Búsqueda cercana por palabras clave en Nominatim (OpenStreetMap) usando q + viewbox + bounded
     * centrados en el GPS actual, más enriquecimiento por geocodificación inversa.
     */
    suspend fun buscarUbicacionesNominatim(
        queryTexto: String,
        latCercana: Double = 9.3895,
        lngCercana: Double = -83.6490
    ): List<UbicacionSugerida> {
        val locales = buscarUbicacionesSugeridas(queryTexto)
        val q = queryTexto.trim()
        if (q.length < 2) return locales

        val terminos = expandirPalabrasClaveRurales(q)

        val remotos = withContext(Dispatchers.IO) {
            val acumulados = mutableListOf<UbicacionSugerida>()

            fun consultarNominatim(termino: String, delta: Double, boundedFlag: Int): List<UbicacionSugerida> {
                val lista = mutableListOf<UbicacionSugerida>()
                val left = String.format(Locale.US, "%.5f", lngCercana - delta)
                val top = String.format(Locale.US, "%.5f", latCercana + delta)
                val right = String.format(Locale.US, "%.5f", lngCercana + delta)
                val bottom = String.format(Locale.US, "%.5f", latCercana - delta)
                val viewbox = "$left,$top,$right,$bottom"
                val encodedQ = URLEncoder.encode(termino, "UTF-8")
                val urlStr =
                    "https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=cr" +
                        "&addressdetails=1&namedetails=1&limit=10&viewbox=$viewbox&bounded=$boundedFlag&q=$encodedQ"
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 4500
                        readTimeout = 4500
                        setRequestProperty("Accept-Language", "es")
                        setRequestProperty("User-Agent", "ViajeRuralAndroid/1.0 (contact@viajerural.app)")
                    }
                    if (conn.responseCode in 200..299) {
                        val body = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i) ?: continue
                            val lat = obj.optString("lat").toDoubleOrNull() ?: continue
                            val lon = obj.optString("lon").toDoubleOrNull() ?: continue
                            val displayName = obj.optString("display_name")
                            val partes = displayName.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val nameDetails = obj.optJSONObject("namedetails")
                            val address = obj.optJSONObject("address")

                            val nombrePoiAddress = listOfNotNull(
                                address?.optString("shop")?.takeIf { it.isNotBlank() && !it.equals("yes", true) },
                                address?.optString("amenity")?.takeIf { it.isNotBlank() && !it.equals("yes", true) },
                                address?.optString("supermarket")?.takeIf { it.isNotBlank() },
                                address?.optString("convenience")?.takeIf { it.isNotBlank() },
                                address?.optString("building")?.takeIf { it.isNotBlank() && !it.equals("yes", true) },
                                address?.optString("road")?.takeIf { it.isNotBlank() }
                            ).firstOrNull()

                            val nombrePrincipal = listOf(
                                obj.optString("name").trim(),
                                nameDetails?.optString("name:es")?.trim().orEmpty(),
                                nameDetails?.optString("name")?.trim().orEmpty(),
                                nombrePoiAddress.orEmpty(),
                                partes.take(2).joinToString(", ")
                            ).firstOrNull { it.isNotBlank() } ?: termino

                            val detalleZona = listOfNotNull(
                                address?.optString("road")?.takeIf { it.isNotBlank() },
                                address?.optString("neighbourhood")?.takeIf { it.isNotBlank() }
                                    ?: address?.optString("suburb")?.takeIf { it.isNotBlank() }
                                    ?: address?.optString("village")?.takeIf { it.isNotBlank() },
                                address?.optString("town")?.takeIf { it.isNotBlank() }
                                    ?: address?.optString("city")?.takeIf { it.isNotBlank() }
                                    ?: address?.optString("county")?.takeIf { it.isNotBlank() }
                            ).distinct().joinToString(", ")
                                .ifBlank { partes.drop(1).take(3).joinToString(", ") }
                                .ifBlank { "Costa Rica" }

                            lista.add(
                                UbicacionSugerida(
                                    nombre = nombrePrincipal.take(110),
                                    canton = detalleZona.take(90),
                                    lat = lat,
                                    lng = lon
                                )
                            )
                        }
                    }
                } catch (_: Throwable) {
                } finally {
                    conn?.disconnect()
                }
                return lista
            }

            // 1) Búsqueda estrictamente acotada alrededor del GPS actual (viewbox ~18 km, bounded=1)
            for (termino in terminos) {
                acumulados.addAll(consultarNominatim(termino, delta = 0.16, boundedFlag = 1))
                if (acumulados.size >= 6) break
            }

            // 2) Si hubo pocas coincidencias locales, ampliar radio a ~40 km manteniendo bounded=1
            if (acumulados.size < 3) {
                acumulados.addAll(consultarNominatim(q, delta = 0.35, boundedFlag = 1))
            }

            // 3) Si aún hay pocos resultados, buscar en todo CR priorizando el viewbox (bounded=0)
            if (acumulados.size < 3) {
                acumulados.addAll(consultarNominatim(q, delta = 0.18, boundedFlag = 0))
            }

            acumulados
        }

        // Enriquecer con distancia aproximada y búsqueda inversa cuando la zona venga genérica
        val ordenados = remotos
            .sortedBy { calcularDistanciaKm(latCercana, lngCercana, it.lat, it.lng) }
            .take(8)
            .mapIndexed { idx, item ->
                val distKm = calcularDistanciaKm(latCercana, lngCercana, item.lat, item.lng)
                val zonaEnriquecida = if (idx < 3 && (item.canton == "Costa Rica" || item.canton.isBlank())) {
                    reverseGeocodificarUbicacion(null, item.lat, item.lng)
                } else {
                    item.canton
                }
                item.copy(canton = "~$distKm km · $zonaEnriquecida".take(95))
            }

        val vistos = HashSet<String>()
        val combinados = mutableListOf<UbicacionSugerida>()
        for (item in ordenados + locales) {
            val key = "${normalizarTexto(item.nombre)}|${"%.3f".format(Locale.US, item.lat)}"
            if (vistos.add(key)) {
                combinados.add(item)
            }
        }
        return combinados.take(8)
    }

    fun normalizarTipoVehiculo(vehiculoTipo: String): String {
        val lower = normalizarTexto(vehiculoTipo)
        return when {
            lower.contains("moto") -> "moto"
            lower.contains("pickup") || lower.contains("pick up") || lower.contains("4x4") || lower.contains("camioneta") -> "pickup"
            lower.contains("buseta") || lower.contains("microbus") || lower.contains("bus") || lower.contains("van") -> "buseta"
            lower.contains("sedan") || lower.contains("carro") || lower.contains("auto") -> "auto"
            lower.isNotBlank() -> lower.take(40)
            else -> "auto"
        }
    }

    private fun conductorAceptaTipoVehiculo(
        tipoConductor: String,
        tiposPermitidosNormalizados: List<String>
    ): Boolean {
        if (tiposPermitidosNormalizados.isEmpty()) return true
        val normConductor = normalizarTipoVehiculo(tipoConductor)
        return normConductor in tiposPermitidosNormalizados
    }

    /**
     * Fórmula exacta de Haversine en kilómetros (sin redondeo ni piso mínimo)
     * para filtrar radio <= 10.0 km y ordenar conductores del más cercano al más lejano.
     */
    fun calcularDistanciaHaversineKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLng / 2) * sin(dLng / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    fun calcularDistanciaRutaKm(
        origenLat: Double,
        origenLng: Double,
        destinoLat: Double,
        destinoLng: Double
    ): Double {
        val km = (calcularDistanciaHaversineKm(origenLat, origenLng, destinoLat, destinoLng) * 10.0).roundToInt() / 10.0
        return km.coerceIn(0.5, 500.0)
    }

    private fun calcularDistanciaKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        return calcularDistanciaRutaKm(lat1, lng1, lat2, lng2)
    }

    @Suppress("UNCHECKED_CAST")
    suspend fun obtenerRutasFavoritasPasajero(pasajeroId: String): List<RutaFavoritaData> {
        val snap = db.collection("pasajeros").document(pasajeroId).get().await()
        if (!snap.exists()) return emptyList()
        val raw = snap.get("rutasFavoritas") as? List<Map<String, Any>> ?: return emptyList()
        return raw.map { m ->
            RutaFavoritaData(
                id = m["id"] as? String ?: "",
                alias = m["alias"] as? String ?: "",
                origenNombre = m["origenNombre"] as? String ?: "",
                origenLat = (m["origenLat"] as? Number)?.toDouble() ?: 0.0,
                origenLng = (m["origenLng"] as? Number)?.toDouble() ?: 0.0,
                destinoNombre = m["destinoNombre"] as? String ?: "",
                destinoLat = (m["destinoLat"] as? Number)?.toDouble() ?: 0.0,
                destinoLng = (m["destinoLng"] as? Number)?.toDouble() ?: 0.0
            )
        }
    }

    suspend fun guardarRutaFavoritaPasajero(
        pasajeroId: String,
        nuevaRuta: RutaFavoritaData
    ): List<RutaFavoritaData> {
        val actuales = obtenerRutasFavoritasPasajero(pasajeroId)
        val actualizadas = (listOf(nuevaRuta) + actuales).take(15)
        val payload = actualizadas.map {
            mapOf(
                "id" to it.id,
                "alias" to it.alias,
                "origenNombre" to it.origenNombre,
                "origenLat" to it.origenLat,
                "origenLng" to it.origenLng,
                "destinoNombre" to it.destinoNombre,
                "destinoLat" to it.destinoLat,
                "destinoLng" to it.destinoLng
            )
        }
        db.collection("pasajeros").document(pasajeroId).update(
            mapOf(
                "rutasFavoritas" to payload,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return actualizadas
    }

    suspend fun eliminarRutaFavoritaPasajero(
        pasajeroId: String,
        rutaId: String
    ): List<RutaFavoritaData> {
        val filtradas = obtenerRutasFavoritasPasajero(pasajeroId).filterNot { it.id == rutaId }
        val payload = filtradas.map {
            mapOf(
                "id" to it.id,
                "alias" to it.alias,
                "origenNombre" to it.origenNombre,
                "origenLat" to it.origenLat,
                "origenLng" to it.origenLng,
                "destinoNombre" to it.destinoNombre,
                "destinoLat" to it.destinoLat,
                "destinoLng" to it.destinoLng
            )
        }
        db.collection("pasajeros").document(pasajeroId).update(
            mapOf(
                "rutasFavoritas" to payload,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return filtradas
    }

    // -------------------------------------------------------------------------
    // RECUPERACIÓN DE ESTADO E HISTORIAL BAJO DEMANDA (limit(20))
    // -------------------------------------------------------------------------
    suspend fun recuperarViajeActivoConductor(conductorId: String): Map<String, Any>? {
        val snap = db.collection("viajes")
            .whereEqualTo("conductorId", conductorId)
            .limit(20)
            .get()
            .await()

        val activos = setOf("aceptado", "en_curso")
        val doc = snap.documents
            .filter { it.getString("estado") in activos }
            .maxByOrNull { it.getTimestamp("updatedAt")?.toDate()?.time ?: 0L }

        if (doc == null) {
            val condRef = db.collection("conductores").document(conductorId)
            val condSnap = condRef.get().await()
            val op = condSnap.getString("estadoOperativo")
            if (op == "en_camino" || op == "en_viaje") {
                condRef.set(
                    mapOf(
                        "disponible" to true,
                        "estadoOperativo" to "activo",
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                ).await()
            }
            return null
        }
        return doc.data?.plus("id" to doc.id)
    }

    suspend fun obtenerPinSecretoViaje(viajeId: String): String? {
        return try {
            db.collection("viajes")
                .document(viajeId)
                .collection("secreto")
                .document("codigo")
                .get()
                .await()
                .getString("pin")
        } catch (_: Throwable) {
            null
        }
    }

    suspend fun recuperarViajeActivoPasajero(pasajeroId: String): Pair<Map<String, Any>, String?>? {
        val q = db.collection("viajes")
            .whereEqualTo("pasajeroId", pasajeroId)
            .limit(30)
        val snap = try {
            q.get(Source.SERVER).await()
        } catch (_: Throwable) {
            q.get().await()
        }

        val activos = setOf("buscando", "aceptado", "en_curso")
        val doc = snap.documents
            .filter { it.getString("estado") in activos }
            .maxByOrNull { it.getTimestamp("updatedAt")?.toDate()?.time ?: 0L }
            ?: return null

        val pin = obtenerPinSecretoViaje(doc.id)
        return Pair(doc.data.orEmpty().plus("id" to doc.id), pin)
    }

    suspend fun obtenerHistorialPasajero(pasajeroId: String, limite: Long = 150L): List<Map<String, Any>> {
        val fetchLimit = limite.coerceAtLeast(200L)
        val q = db.collection("viajes")
            .whereEqualTo("pasajeroId", pasajeroId)
            .limit(fetchLimit)
        val snap = try {
            q.get(Source.SERVER).await()
        } catch (_: Throwable) {
            q.get().await()
        }
        return snap.documents
            .sortedByDescending {
                it.getTimestamp("updatedAt")?.toDate()?.time
                    ?: it.getTimestamp("createdAt")?.toDate()?.time
                    ?: 0L
            }
            .take(limite.toInt())
            .map { doc -> doc.data.orEmpty().plus("id" to doc.id) }
    }

    suspend fun obtenerHistorialConductor(conductorId: String, limite: Long = 150L): List<Map<String, Any>> {
        val fetchLimit = limite.coerceAtLeast(200L)
        val q = db.collection("viajes")
            .whereEqualTo("conductorId", conductorId)
            .limit(fetchLimit)
        val snap = try {
            q.get(Source.SERVER).await()
        } catch (_: Throwable) {
            q.get().await()
        }
        return snap.documents
            .sortedByDescending {
                it.getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time
                    ?: it.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time
                    ?: 0L
            }
            .take(limite.toInt())
            .map { doc -> doc.data.orEmpty().plus("id" to doc.id) }
    }

    // -------------------------------------------------------------------------
    // TRANSACCIÓN ATÓMICA, LISTENER DIRECTO SOBRE viajes/{viajeId} Y COLA 15s
    // -------------------------------------------------------------------------
    suspend fun obtenerViajePorId(viajeId: String): Map<String, Any>? {
        if (viajeId.isBlank()) return null
        val docRef = db.collection("viajes").document(viajeId)
        val snap = try {
            docRef.get(Source.SERVER).await()
        } catch (_: Throwable) {
            docRef.get().await()
        }
        return snap.data?.plus("id" to snap.id)
    }

    fun observarViajePorId(
        viajeId: String,
        onUpdate: (Map<String, Any>?) -> Unit
    ): ListenerRegistration {
        return db.collection("viajes")
            .document(viajeId)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                if (snap == null || !snap.exists()) {
                    onUpdate(null)
                    return@addSnapshotListener
                }
                onUpdate(snap.data.orEmpty().plus("id" to snap.id))
            }
    }

    fun observarViajeActivoConductor(
        conductorId: String,
        onUpdate: (Map<String, Any>?) -> Unit
    ): ListenerRegistration {
        val activos = setOf("aceptado", "en_curso")
        return db.collection("viajes")
            .whereEqualTo("conductorId", conductorId)
            .limit(20)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                val doc = snap?.documents
                    ?.filter { it.getString("estado") in activos }
                    ?.maxByOrNull { it.getTimestamp("updatedAt")?.toDate()?.time ?: 0L }
                onUpdate(doc?.data?.plus("id" to doc.id))
            }
    }

    fun observarOfertasConductor(
        conductorId: String,
        onUpdate: (List<Map<String, Any>>) -> Unit
    ): ListenerRegistration {
        return db.collection("viajes")
            .whereArrayContains("colaConductores", conductorId)
            .limit(10)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                val lista = snap?.documents
                    ?.filter { it.getString("estado") == "buscando" }
                    ?.map { d -> d.data.orEmpty().plus("id" to d.id) }
                    .orEmpty()
                onUpdate(lista)
            }
    }

    fun observarViajeActivoPasajero(
        pasajeroId: String,
        onUpdate: (Pair<Map<String, Any>, String?>?) -> Unit
    ): ListenerRegistration {
        val activos = setOf("buscando", "aceptado", "en_curso")
        return db.collection("viajes")
            .whereEqualTo("pasajeroId", pasajeroId)
            .limit(20)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                val doc = snap?.documents
                    ?.filter { it.getString("estado") in activos }
                    ?.maxByOrNull { it.getTimestamp("updatedAt")?.toDate()?.time ?: 0L }
                if (doc == null) {
                    onUpdate(null)
                    return@addSnapshotListener
                }
                val viajeMap = doc.data.orEmpty().plus("id" to doc.id)
                db.collection("viajes")
                    .document(doc.id)
                    .collection("secreto")
                    .document("codigo")
                    .get()
                    .addOnSuccessListener { secSnap ->
                        onUpdate(Pair(viajeMap, secSnap.getString("pin")))
                    }
                    .addOnFailureListener {
                        onUpdate(Pair(viajeMap, null))
                    }
            }
    }

    suspend fun aceptarOfertaAtomicamente(viajeId: String, conductorId: String): Result<Unit> {
        val viajeRef = db.collection("viajes").document(viajeId)
        val conductorRef = db.collection("conductores").document(conductorId)
        val configRef = db.collection("configuracion").document("general")

        return try {
            db.runTransaction { tx ->
                val viajeSnap = tx.get(viajeRef)
                val condSnap = tx.get(conductorRef)
                val configSnap = tx.get(configRef)

                require(viajeSnap.exists()) {
                    "La solicitud de viaje ya no está disponible."
                }
                require(viajeSnap.getString("estado") == "buscando") {
                    "Otro conductor aceptó este viaje primero."
                }
                require(condSnap.getString("estadoCuenta") == "activo") {
                    "Tu cuenta debe estar verificada por un administrador."
                }
                val estaDisponible = (condSnap.getBoolean("disponible") == true) ||
                    (condSnap.getString("estadoOperativo") == "activo") ||
                    (condSnap.getString("estadoOperativo") == "disponible")
                require(estaDisponible) {
                    "Conflicto de estado: debes estar disponible y sin otro viaje activo."
                }

                val cLat = condSnap.getDouble("lat") ?: 9.385
                val cLng = condSnap.getDouble("lng") ?: -83.682
                val oLat = viajeSnap.getDouble("origenLat") ?: cLat
                val oLng = viajeSnap.getDouble("origenLng") ?: cLng
                val distanciaViajeKm = viajeSnap.getDouble("distanciaKm") ?: 1.0
                val distRecogidaKm = calcularDistanciaHaversineKm(cLat, cLng, oLat, oLng)
                val distanciaInicialRedondeada = ((distRecogidaKm * 1000.0).roundToInt() / 1000.0).coerceAtLeast(0.0)
                val distanciaTextoInicial = if (distRecogidaKm < 1.0) {
                    "${(distRecogidaKm * 1000.0).roundToInt()} m"
                } else {
                    String.format(Locale.US, "%.1f km", distRecogidaKm)
                }
                val etaMinutos = ((distRecogidaKm / 30.0) * 60.0).roundToInt().coerceIn(1, 300)
                val tarifaBaseNormal = condSnap.getDouble("tarifaBase") ?: DEFAULT_TARIFA_BASE_NORMAL
                val tarifaBaseCarga = condSnap.getDouble("tarifaBaseCarga")
                val tarifaPorKm = condSnap.getDouble("tarifaPorKm") ?: DEFAULT_TARIFA_KM
                val esCargaFlete = viajeSnap.getBoolean("esCargaFlete") == true
                val tipoVehiculoCond = condSnap.getString("tipoVehiculo")
                    ?: condSnap.getString("vehiculoTipo")
                    ?: ""
                val aplicaCargoFlete = esCargaFlete && esVehiculoCargo(tipoVehiculoCond)
                val tarifaBaseAplicada = calcularTarifaBaseEfectiva(
                    tarifaBase = tarifaBaseNormal,
                    tarifaBaseCarga = tarifaBaseCarga,
                    esCargaFlete = aplicaCargoFlete
                )
                val montoAproximado = (tarifaBaseAplicada + (distanciaViajeKm * tarifaPorKm))
                    .coerceIn(DEFAULT_TARIFA_BASE_NORMAL, 500000.0)
                    .roundToInt()
                    .toDouble()

                val multNormal = (configSnap.getDouble("multiplicadorTopeNormal") ?: DEFAULT_MULTIPLICADOR_TOPE_NORMAL)
                    .coerceIn(1.1, 5.0)
                val multCarga = (configSnap.getDouble("multiplicadorTopeCarga") ?: DEFAULT_MULTIPLICADOR_TOPE_CARGA)
                    .coerceIn(1.1, 5.0)
                val baseRefFallback = if (esCargaFlete) DEFAULT_TARIFA_BASE_CARGA else DEFAULT_TARIFA_BASE_NORMAL
                val montoRef = (viajeSnap.getDouble("montoReferenciaPromedio")
                    ?: (baseRefFallback + distanciaViajeKm * DEFAULT_TARIFA_KM).coerceIn(1500.0, 500000.0).roundToInt().toDouble())
                val limiteMax = viajeSnap.getDouble("limiteMaximoPermitido")
                    ?: calcularLimiteMaximoPermitido(montoRef, esCargaFlete, multNormal, multCarga)

                val viajeUpdates = mutableMapOf<String, Any>(
                    "estado" to "aceptado",
                    "conductorId" to conductorId,
                    "conductorNombre" to (condSnap.getString("nombre") ?: "Conductor"),
                    "conductorPlaca" to (condSnap.getString("placa") ?: ""),
                    "vehiculoTipoSeleccionado" to (condSnap.getString("vehiculoTipo") ?: ""),
                    "tarifaBaseAplicada" to tarifaBaseAplicada,
                    "tarifaKmAplicada" to tarifaPorKm,
                    "montoAproximado" to montoAproximado,
                    "montoReferenciaPromedio" to montoRef,
                    "limiteMaximoPermitido" to limiteMax,
                    "conductorLat" to cLat,
                    "conductorLng" to cLng,
                    "etaMinutos" to etaMinutos,
                    "distanciaInicialRecogidaKm" to distanciaInicialRedondeada,
                    "distanciaTexto" to distanciaTextoInicial,
                    "conductorLlego" to false,
                    "gpsConductorActivo" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (aplicaCargoFlete) {
                    viajeUpdates["tarifaBaseCargaAplicada"] = tarifaBaseAplicada
                }

                tx.update(viajeRef, viajeUpdates)
                tx.update(
                    conductorRef,
                    mapOf(
                        "estadoOperativo" to "en_camino",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun avanzarColaPorTimeoutSecuencial(viajeId: String, conductorId: String) {
        val viajeRef = db.collection("viajes").document(viajeId)
        db.runTransaction { tx ->
            val snap = tx.get(viajeRef)
            if (snap.getString("estado") != "buscando") return@runTransaction

            @Suppress("UNCHECKED_CAST")
            val cola = (snap.get("colaConductores") as? List<String>).orEmpty()
            if (cola.isEmpty()) return@runTransaction

            val idxActual = ((snap.getLong("ofertaActualIndex") ?: 0L).toInt()) % cola.size
            if (cola[idxActual] != conductorId) return@runTransaction

            val nuevoIdx = (idxActual + 1) % cola.size
            tx.update(
                viajeRef,
                mapOf(
                    "ofertaActualIndex" to nuevoIdx,
                    "ofertaExpiraAt" to (System.currentTimeMillis() + 15_000L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    suspend fun rechazarOfertaSecuencial(viajeId: String, conductorId: String) {
        val viajeRef = db.collection("viajes").document(viajeId)
        db.runTransaction { tx ->
            val snap = tx.get(viajeRef)
            if (snap.getString("estado") != "buscando") return@runTransaction

            @Suppress("UNCHECKED_CAST")
            val cola = (snap.get("colaConductores") as? List<String>).orEmpty().toMutableList()
            cola.remove(conductorId)
            cola.add(conductorId)

            val idxActual = (snap.getLong("ofertaActualIndex") ?: 0L).toInt()
            val nuevoIdx = if (cola.isEmpty() || idxActual >= cola.size) 0 else idxActual

            tx.update(
                viajeRef,
                mapOf(
                    "colaConductores" to cola,
                    "ofertaActualIndex" to nuevoIdx,
                    "ofertaExpiraAt" to (System.currentTimeMillis() + 15_000L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    suspend fun verificarPinViaje(
        viajeId: String,
        conductorId: String,
        pinIngresado: String
    ): Boolean {
        val snap = db.collection("viajes").document(viajeId).get().await()
        val pinHash = snap.getString("pinHash") ?: return false
        return confirmarPinYDetenerGps(viajeId, conductorId, pinIngresado, pinHash)
    }

    suspend fun confirmarPinYDetenerGps(
        viajeId: String,
        conductorId: String,
        pinIngresado: String,
        pinHashEsperado: String
    ): Boolean {
        val hash = sha256("$viajeId:${pinIngresado.trim()}")
        if (hash != pinHashEsperado) return false

        val batch = db.batch()
        batch.update(
            db.collection("viajes").document(viajeId),
            mapOf(
                "estado" to "en_curso",
                "pinVerificado" to true,
                "gpsConductorActivo" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("conductores").document(conductorId),
            mapOf(
                "estadoOperativo" to "en_viaje",
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
        return true
    }

    // -------------------------------------------------------------------------
    // REQUISITO 8 Y 9 + FINANZAS LOCALES ESTRICTAS (HORA LOCAL / COSTA RICA)
    // -------------------------------------------------------------------------
    private fun obtenerRangosCalendarioLocal(): Pair<LongRange, LongRange> {
        val tz = TimeZone.getDefault()
        val calInicioHoy = Calendar.getInstance(tz).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val calFinHoy = Calendar.getInstance(tz).apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        val calInicioMes = Calendar.getInstance(tz).apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val calFinMes = Calendar.getInstance(tz).apply {
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        val rangoHoy = calInicioHoy.timeInMillis..calFinHoy.timeInMillis
        val rangoMes = calInicioMes.timeInMillis..calFinMes.timeInMillis
        return Pair(rangoHoy, rangoMes)
    }

    private fun calcularFinanzasDesdeDocumentos(
        docs: List<DocumentSnapshot>,
        excluirViajeId: String? = null
    ): Pair<Double, Double> {
        val (rangoHoy, rangoMes) = obtenerRangosCalendarioLocal()
        var totalHoy = 0.0
        var totalMes = 0.0
        for (doc in docs) {
            if (excluirViajeId != null && doc.id == excluirViajeId) continue
            if (doc.getString("estado") != "finalizado") continue
            val ts = doc.getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: continue
            val fechaMs = ts.toDate().time
            val monto = (doc.get("montoCobrado") as? Number)?.toDouble()?.takeIf { it > 0.0 }
                ?: (doc.get("montoAproximado") as? Number)?.toDouble()?.coerceAtLeast(0.0)
                ?: 0.0
            if (fechaMs in rangoHoy) {
                totalHoy += monto
            }
            if (fechaMs in rangoMes) {
                totalMes += monto
            }
        }
        return Pair(totalHoy, totalMes)
    }

    suspend fun finalizarViajeConFinanzas(
        viajeId: String,
        conductorId: String,
        montoCobrado: Double,
        lat: Double? = null,
        lng: Double? = null
    ) {
        val montoValido = montoCobrado.coerceIn(0.0, 2_000_000.0)
        val viajeRef = db.collection("viajes").document(viajeId)
        val viajeSnap = try {
            viajeRef.get().await()
        } catch (_: Throwable) {
            null
        }
        val cfg = try {
            obtenerConfiguracionGeneral()
        } catch (_: Throwable) {
            configuracionDefaults()
        }
        val esCargaFlete = viajeSnap?.getBoolean("esCargaFlete") == true
        val distanciaViajeKm = (viajeSnap?.get("distanciaKm") as? Number)?.toDouble() ?: 1.0
        val multNormal = ((cfg["multiplicadorTopeNormal"] as? Number)?.toDouble() ?: DEFAULT_MULTIPLICADOR_TOPE_NORMAL)
            .coerceIn(1.1, 5.0)
        val multCarga = ((cfg["multiplicadorTopeCarga"] as? Number)?.toDouble() ?: DEFAULT_MULTIPLICADOR_TOPE_CARGA)
            .coerceIn(1.1, 5.0)
        val baseRef = if (esCargaFlete) DEFAULT_TARIFA_BASE_CARGA else DEFAULT_TARIFA_BASE_NORMAL
        val montoRef = (viajeSnap?.get("montoReferenciaPromedio") as? Number)?.toDouble()
            ?: (baseRef + distanciaViajeKm * DEFAULT_TARIFA_KM).coerceIn(1500.0, 500000.0).roundToInt().toDouble()
        val limiteMax = (viajeSnap?.get("limiteMaximoPermitido") as? Number)?.toDouble()
            ?: calcularLimiteMaximoPermitido(montoRef, esCargaFlete, multNormal, multCarga)
        val alertaCobroExcesivo = montoValido > limiteMax

        val finanzasRecalculadas: Pair<Double, Double>? = try {
            val q = db.collection("viajes")
                .whereEqualTo("conductorId", conductorId)
                .limit(250L)
            val snap = try {
                q.get(Source.SERVER).await()
            } catch (_: Throwable) {
                q.get().await()
            }
            val (prevHoy, prevMes) = calcularFinanzasDesdeDocumentos(
                docs = snap.documents,
                excluirViajeId = viajeId
            )
            Pair(prevHoy + montoValido, prevMes + montoValido)
        } catch (_: Throwable) {
            null
        }

        val batch = db.batch()
        batch.update(
            viajeRef,
            mapOf(
                "estado" to "finalizado",
                "gpsConductorActivo" to false,
                "montoCobrado" to montoValido,
                "montoReferenciaPromedio" to montoRef,
                "limiteMaximoPermitido" to limiteMax,
                "alertaCobroExcesivo" to alertaCobroExcesivo,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        val conductorUpdates = mutableMapOf<String, Any>(
            "estadoOperativo" to "activo",
            "disponible" to true,
            "totalViajes" to FieldValue.increment(1L),
            "gananciasHoy" to (finanzasRecalculadas?.first ?: FieldValue.increment(montoValido)),
            "gananciasMes" to (finanzasRecalculadas?.second ?: FieldValue.increment(montoValido)),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (lat != null && lng != null) {
            conductorUpdates["lat"] = lat
            conductorUpdates["lng"] = lng
            conductorUpdates["ultimaActualizacion"] = FieldValue.serverTimestamp()
            conductorUpdates["ultimoPingAt"] = FieldValue.serverTimestamp()
        }
        batch.update(
            db.collection("conductores").document(conductorId),
            conductorUpdates
        )
        batch.commit().await()
    }

    suspend fun actualizarUbicacionPostViajeConductor(
        conductorId: String,
        lat: Double,
        lng: Double
    ) {
        if (conductorId.isBlank() || auth.currentUser == null) return
        db.collection("conductores").document(conductorId)
            .set(
                mapOf(
                    "disponible" to true,
                    "estadoOperativo" to "activo",
                    "lat" to lat,
                    "lng" to lng,
                    "ultimaActualizacion" to FieldValue.serverTimestamp(),
                    "ultimoPingAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            .await()
    }

    suspend fun cancelarViajeConMotivo(
        viajeId: String,
        canceladoPor: String,
        motivo: String,
        conductorId: String? = null
    ) {
        val nota = motivo.trim().take(280)
        require(nota.length >= 3) {
            "Debes ingresar una nota explicando el motivo de la cancelación (mínimo 3 caracteres)."
        }

        val batch = db.batch()
        batch.update(
            db.collection("viajes").document(viajeId),
            mapOf(
                "estado" to "cancelado",
                "gpsConductorActivo" to false,
                "canceladoPor" to canceladoPor,
                "motivoCancelacion" to nota,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        if (canceladoPor == "conductor" && !conductorId.isNullOrBlank()) {
            batch.update(
                db.collection("conductores").document(conductorId),
                mapOf(
                    "disponible" to true,
                    "estadoOperativo" to "activo",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.commit().await()
    }

    suspend fun restaurarConductorDisponibleTrasCancelacion(conductorId: String) {
        if (conductorId.isBlank()) return
        db.collection("conductores").document(conductorId)
            .set(
                mapOf(
                    "disponible" to true,
                    "estadoOperativo" to "activo",
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            .await()
    }

    /**
     * Calcula gananciasHoy y gananciasMes estrictamente desde los viajes finalizados
     * del conductor usando inicio/fin del día y mes en zona horaria local del dispositivo.
     */
    suspend fun obtenerFinanzasConductor(conductorId: String): Pair<Double, Double> {
        val q = db.collection("viajes")
            .whereEqualTo("conductorId", conductorId)
            .limit(250L)
        val snap = try {
            q.get(Source.SERVER).await()
        } catch (_: Throwable) {
            q.get().await()
        }
        val (hoy, mes) = calcularFinanzasDesdeDocumentos(snap.documents)
        try {
            val condSnap = db.collection("conductores").document(conductorId).get().await()
            val hoyDoc = condSnap.getDouble("gananciasHoy") ?: 0.0
            val mesDoc = condSnap.getDouble("gananciasMes") ?: 0.0
            val estadoCuenta = condSnap.getString("estadoCuenta")
            if (estadoCuenta != "bloqueado" &&
                (kotlin.math.abs(hoyDoc - hoy) >= 0.01 || kotlin.math.abs(mesDoc - mes) >= 0.01)
            ) {
                db.collection("conductores").document(conductorId)
                    .update(
                        mapOf(
                            "gananciasHoy" to hoy,
                            "gananciasMes" to mes,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    .await()
            }
        } catch (_: Throwable) {
        }
        return Pair(hoy, mes)
    }

    fun observarFinanzasConductor(
        conductorId: String,
        onUpdate: (Double, Double) -> Unit
    ): ListenerRegistration {
        return db.collection("viajes")
            .whereEqualTo("conductorId", conductorId)
            .limit(250L)
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                val (hoy, mes) = calcularFinanzasDesdeDocumentos(snap.documents)
                onUpdate(hoy, mes)
            }
    }

    suspend fun obtenerPerfilYLicenciaConductor(conductorId: String): Map<String, Any>? {
        val docRef = db.collection("conductores").document(conductorId)
        val snap = try {
            docRef.get(Source.SERVER).await()
        } catch (_: Throwable) {
            docRef.get().await()
        }
        return snap.data?.plus("uid" to snap.id)
    }

    fun observarPerfilConductor(
        conductorId: String,
        onUpdate: (Map<String, Any>) -> Unit
    ): ListenerRegistration {
        return db.collection("conductores").document(conductorId)
            .addSnapshotListener { snap, _ ->
                val data = snap?.data ?: return@addSnapshotListener
                onUpdate(data + ("uid" to snap.id))
            }
    }

    /**
     * Obtiene la ubicación GPS actual del conductor UNA SOLA VEZ y apaga el receptor de inmediato
     * cancelando el CancellationTokenSource para ahorrar batería y datos móviles.
     */
    @SuppressLint("MissingPermission")
    suspend fun obtenerUbicacionUnicaGps(context: Context): Pair<Double, Double> {
        val tieneFina = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val tieneAprox = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!tieneFina && !tieneAprox) {
            throw SecurityException("Activa el permiso de ubicación para quedar disponible.")
        }

        val fused = LocationServices.getFusedLocationProviderClient(context)
        val cts = CancellationTokenSource()
        return try {
            val location = try {
                fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token).await()
            } catch (_: Throwable) {
                null
            } ?: try {
                fused.lastLocation.await()
            } catch (_: Throwable) {
                null
            }
            requireNotNull(location) {
                "No se pudo obtener tu ubicación GPS actual. Enciende la ubicación del teléfono e intenta de nuevo."
            }
            Pair(location.latitude, location.longitude)
        } finally {
            // Apagar inmediatamente el flujo/solicitud GPS tras capturar el pulso único
            cts.cancel()
        }
    }

    suspend fun actualizarDisponibilidadConductor(
        conductorId: String,
        disponible: Boolean,
        lat: Double? = null,
        lng: Double? = null,
        tipoVehiculo: String? = null,
        capacidad: Int? = null
    ) {
        val user = auth.currentUser
            ?: throw SecurityException("Tu sesión expiró. Inicia sesión nuevamente.")
        user.getIdToken(false).await()

        if (disponible) {
            require(lat != null && lng != null) {
                "Se requieren las coordenadas GPS actuales para quedar disponible."
            }
        }

        val conductorRef = db.collection("conductores").document(conductorId)
        val docSnap = try {
            conductorRef.get().await()
        } catch (_: Throwable) {
            null
        }
        val existente = docSnap?.exists() == true

        val tipoVehiculoDoc = docSnap?.getString("tipoVehiculo")?.takeIf { it.isNotBlank() }
            ?: docSnap?.getString("vehiculoTipo")?.takeIf { it.isNotBlank() }
        val tipoFinal = normalizarTipoVehiculo(
            tipoVehiculo?.takeIf { it.isNotBlank() } ?: tipoVehiculoDoc ?: "auto"
        )
        val capacidadDoc = docSnap?.getLong("capacidad")?.toInt()
        val capacidadFinal = (capacidad?.takeIf { it in 1..16 }
            ?: capacidadDoc?.takeIf { it in 1..16 }
            ?: 4)

        if (existente) {
            val data = if (disponible) {
                mapOf(
                    "disponible" to true,
                    "estadoOperativo" to "activo",
                    "lat" to lat!!,
                    "lng" to lng!!,
                    "tipoVehiculo" to tipoFinal,
                    "capacidad" to capacidadFinal,
                    "ultimaActualizacion" to FieldValue.serverTimestamp(),
                    "ultimoPingAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            } else {
                mapOf(
                    "disponible" to false,
                    "estadoOperativo" to "inactivo",
                    "lat" to FieldValue.delete(),
                    "lng" to FieldValue.delete(),
                    "ultimaActualizacion" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            }
            conductorRef.set(data, SetOptions.merge()).await()
        } else {
            // Si el documento conductores/{uid} no existe aún en Firestore, se crea automáticamente
            // con set(..., SetOptions.merge()) y todos los campos requeridos.
            val nombreUsuario = try {
                db.collection("usuarios").document(conductorId).get().await()
                    .getString("nombre")?.trim()?.takeIf { it.length >= 2 }
            } catch (_: Throwable) {
                null
            } ?: user.displayName?.trim()?.takeIf { it.length >= 2 }
                ?: "Conductor Rural"

            val vehiculoTipoDisplay = tipoVehiculo?.trim()?.takeIf { it.length >= 2 } ?: "Pickup 4x4"
            val expDate = Timestamp(Date(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000))
            val dataNuevo = mutableMapOf<String, Any>(
                "uid" to conductorId,
                "nombre" to nombreUsuario,
                "vehiculoTipo" to vehiculoTipoDisplay,
                "tipoVehiculo" to tipoFinal,
                "placa" to "PENDIENTE",
                "capacidad" to capacidadFinal,
                "tarifaBase" to 1500.0,
                "tarifaPorKm" to 650.0,
                "estadoCuenta" to "pendiente",
                "estadoOperativo" to if (disponible) "activo" else "inactivo",
                "disponible" to disponible,
                "licenciaExp" to expDate,
                "mensualidadPendiente" to false,
                "promedioCalificacion" to 5.0,
                "totalCalificaciones" to 0,
                "totalViajes" to 0,
                "gananciasHoy" to 0.0,
                "gananciasMes" to 0.0,
                "terminosAceptados" to true,
                "ultimaActualizacion" to FieldValue.serverTimestamp(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (disponible && lat != null && lng != null) {
                dataNuevo["lat"] = lat
                dataNuevo["lng"] = lng
                dataNuevo["ultimoPingAt"] = FieldValue.serverTimestamp()
            }
            conductorRef.set(dataNuevo, SetOptions.merge()).await()
        }
    }

    suspend fun actualizarUbicacionPeriodicaConductor(
        conductorId: String,
        lat: Double,
        lng: Double
    ) {
        if (conductorId.isBlank() || auth.currentUser == null) return
        db.collection("conductores").document(conductorId)
            .set(
                mapOf(
                    "lat" to lat,
                    "lng" to lng,
                    "ultimaActualizacion" to FieldValue.serverTimestamp(),
                    "ultimoPingAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            .await()
    }

    suspend fun actualizarUbicacionRecogidaConDistancia(
        viajeId: String,
        conductorId: String,
        lat: Double,
        lng: Double,
        etaMinutos: Int,
        distanciaTexto: String
    ) {
        if (viajeId.isBlank() || conductorId.isBlank() || auth.currentUser == null) return
        val batch = db.batch()
        batch.update(
            db.collection("viajes").document(viajeId),
            mapOf(
                "conductorLat" to lat,
                "conductorLng" to lng,
                "etaMinutos" to etaMinutos.coerceIn(1, 300),
                "distanciaTexto" to distanciaTexto.take(40),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("conductores").document(conductorId),
            mapOf(
                "lat" to lat,
                "lng" to lng,
                "ultimaActualizacion" to FieldValue.serverTimestamp(),
                "ultimoPingAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
        batch.commit().await()
    }

    suspend fun marcarConductorLlegoRecogida(viajeId: String) {
        if (viajeId.isBlank() || auth.currentUser == null) return
        db.collection("viajes").document(viajeId)
            .update(
                mapOf(
                    "conductorLlego" to true,
                    "conductorLlegoAt" to FieldValue.serverTimestamp(),
                    "distanciaTexto" to "El conductor ha llegado",
                    "etaMinutos" to 0,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            .await()
    }

    fun desactivarConductorPorCierreSinBloquear(
        conductorId: String,
        onComplete: (() -> Unit)? = null
    ) {
        if (conductorId.isBlank() || auth.currentUser == null) {
            onComplete?.invoke()
            return
        }
        try {
            db.collection("conductores").document(conductorId)
                .set(
                    mapOf(
                        "disponible" to false,
                        "estadoOperativo" to "inactivo",
                        "lat" to FieldValue.delete(),
                        "lng" to FieldValue.delete(),
                        "ultimaActualizacion" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
                .addOnCompleteListener { onComplete?.invoke() }
        } catch (_: Throwable) {
            onComplete?.invoke()
        }
    }

    /**
     * Consulta en Firestore conductores con whereEqualTo("disponible", true),
     * calcula la distancia con Haversine en Kotlin, descarta > 10.0 km y ordena
     * del conductor más cercano al más lejano.
     */
    suspend fun buscarConductoresDisponiblesCercanos(
        origenLat: Double,
        origenLng: Double,
        radioMaxKm: Double = 10.0,
        cantidadPasajerosMin: Int = 1,
        tiposVehiculoPermitidos: List<String> = emptyList()
    ): List<ConductorDisponibleCercano> {
        val tiposNorm = tiposVehiculoPermitidos.map { normalizarTipoVehiculo(it) }.distinct()
        val snap = try {
            db.collection("conductores")
                .whereEqualTo("disponible", true)
                .limit(30)
                .get(Source.SERVER)
                .await()
        } catch (_: Throwable) {
            db.collection("conductores")
                .whereEqualTo("disponible", true)
                .limit(30)
                .get()
                .await()
        }

        return snap.documents.mapNotNull { doc ->
            if (doc.getString("estadoCuenta") == "bloqueado") return@mapNotNull null
            val latCond = doc.getDouble("lat") ?: return@mapNotNull null
            val lngCond = doc.getDouble("lng") ?: return@mapNotNull null
            val dist = calcularDistanciaHaversineKm(origenLat, origenLng, latCond, lngCond)
            // Descartar cualquier conductor a más de 10.0 km
            if (dist > radioMaxKm) return@mapNotNull null

            val cap = (doc.getLong("capacidad") ?: 4L).toInt()
            if (cap < cantidadPasajerosMin) return@mapNotNull null

            val tipo = doc.getString("tipoVehiculo")?.takeIf { it.isNotBlank() }
                ?: doc.getString("vehiculoTipo")?.takeIf { it.isNotBlank() }
                ?: "auto"
            if (!conductorAceptaTipoVehiculo(tipo, tiposNorm)) return@mapNotNull null

            ConductorDisponibleCercano(
                uid = doc.id,
                nombre = doc.getString("nombre") ?: "Conductor Rural",
                tipoVehiculo = tipo,
                capacidad = cap,
                lat = latCond,
                lng = lngCond,
                distanciaKm = dist,
                tarifaBase = doc.getDouble("tarifaBase") ?: DEFAULT_TARIFA_BASE_NORMAL,
                tarifaPorKm = doc.getDouble("tarifaPorKm") ?: DEFAULT_TARIFA_KM,
                tarifaBaseCarga = doc.getDouble("tarifaBaseCarga"),
                tieneCascoExtra = doc.getBoolean("tieneCascoExtra") == true,
                tieneCapaDisponible = doc.getBoolean("tieneCapaDisponible") == true
            )
        }.sortedBy { it.distanciaKm }
    }

    suspend fun solicitarViajeConResena(
        pasajeroId: String,
        pasajeroNombre: String,
        cantidadPasajeros: Int,
        origenNombre: String,
        origenLat: Double,
        origenLng: Double,
        destinoNombre: String,
        destinoLat: Double,
        destinoLng: Double,
        resenaUbicacion: String,
        tiposVehiculoPermitidos: List<String> = emptyList(),
        esCargaFlete: Boolean = false
    ): Pair<Map<String, Any>, String> {
        // Garantizar que FirebaseAuth tenga sesión activa y token válido antes de escribir en Firestore
        val currentUser = auth.currentUser
            ?: throw SecurityException("Tu sesión expiró. Inicia sesión nuevamente para solicitar un viaje.")
        currentUser.getIdToken(false).await()
        val uidAutenticado = currentUser.uid
        val tiposNorm = tiposVehiculoPermitidos
            .map { normalizarTipoVehiculo(it) }
            .distinct()
            .take(6)

        val esCargaAplicable = esCargaFlete && tiposNorm.any { esVehiculoCargo(it) }

        val cfg = try {
            obtenerConfiguracionGeneral()
        } catch (_: Throwable) {
            configuracionDefaults()
        }
        val multNormal = ((cfg["multiplicadorTopeNormal"] as? Number)?.toDouble() ?: DEFAULT_MULTIPLICADOR_TOPE_NORMAL)
            .coerceIn(1.1, 5.0)
        val multCarga = ((cfg["multiplicadorTopeCarga"] as? Number)?.toDouble() ?: DEFAULT_MULTIPLICADOR_TOPE_CARGA)
            .coerceIn(1.1, 5.0)

        // 1) Leer lista de conductores disponibles usando exclusivamente sus últimas coordenadas guardadas en Firestore
        val conductoresSnap = try {
            db.collection("conductores")
                .whereEqualTo("disponible", true)
                .limit(30)
                .get(Source.SERVER)
                .await()
        } catch (_: Throwable) {
            db.collection("conductores")
                .whereEqualTo("disponible", true)
                .limit(30)
                .get()
                .await()
        }

        // 2) Calcular distancia con Haversine en Kotlin, descartar > 10.0 km, filtrar capacidad + vehículo y ordenar
        val candidatos = conductoresSnap.documents.mapNotNull { doc ->
            if (doc.getString("estadoCuenta") == "bloqueado") return@mapNotNull null
            val latCond = doc.getDouble("lat") ?: return@mapNotNull null
            val lngCond = doc.getDouble("lng") ?: return@mapNotNull null
            val dist = calcularDistanciaHaversineKm(origenLat, origenLng, latCond, lngCond)
            // Descartar a cualquier conductor cuya distancia sea mayor a 10.0 km
            if (dist > 10.0) return@mapNotNull null

            val cap = (doc.getLong("capacidad") ?: 4L).toInt()
            val tipo = doc.getString("tipoVehiculo")?.takeIf { it.isNotBlank() }
                ?: doc.getString("vehiculoTipo")?.takeIf { it.isNotBlank() }
                ?: "auto"

            ConductorDisponibleCercano(
                uid = doc.id,
                nombre = doc.getString("nombre") ?: "Conductor Rural",
                tipoVehiculo = tipo,
                capacidad = cap,
                lat = latCond,
                lng = lngCond,
                distanciaKm = dist,
                tarifaBase = doc.getDouble("tarifaBase") ?: DEFAULT_TARIFA_BASE_NORMAL,
                tarifaPorKm = doc.getDouble("tarifaPorKm") ?: DEFAULT_TARIFA_KM,
                tarifaBaseCarga = doc.getDouble("tarifaBaseCarga"),
                tieneCascoExtra = doc.getBoolean("tieneCascoExtra") == true,
                tieneCapaDisponible = doc.getBoolean("tieneCapaDisponible") == true
            )
        }

        val compatibles = candidatos.filter {
            it.capacidad >= cantidadPasajeros && conductorAceptaTipoVehiculo(it.tipoVehiculo, tiposNorm)
        }
        val listaOrdenada = compatibles.sortedBy { it.distanciaKm }
        val colaConductores = listaOrdenada.map { it.uid }.take(20)

        val viajeRef = db.collection("viajes").document()
        val viajeId = viajeRef.id
        val pin = (100..999).random().toString()
        val pinHash = sha256("$viajeId:$pin")

        val origenLimpio = origenNombre.trim().let { if (it.length < 2) "Ubicación actual" else it }.take(160)
        val destinoLimpio = destinoNombre.trim().let { if (it.length < 2) "Destino rural" else it }.take(160)
        val resenaLimpia = resenaUbicacion.trim().let { if (it.length < 3) "Punto de encuentro" else it }.take(280)
        val nombreLimpio = pasajeroNombre.trim().let { if (it.length < 2) "Pasajero Rural" else it }.take(100)
        val distanciaKm = calcularDistanciaKm(origenLat, origenLng, destinoLat, destinoLng)

        val baseDefecto = if (esCargaAplicable) DEFAULT_TARIFA_BASE_CARGA else DEFAULT_TARIFA_BASE_NORMAL
        val tBaseAplicada = if (compatibles.isNotEmpty()) {
            compatibles.map {
                calcularTarifaBaseEfectiva(
                    tarifaBase = it.tarifaBase,
                    tarifaBaseCarga = it.tarifaBaseCarga,
                    esCargaFlete = esCargaAplicable && esVehiculoCargo(it.tipoVehiculo)
                )
            }.average()
        } else {
            baseDefecto
        }
        val tKmAplicada = if (compatibles.isNotEmpty()) {
            compatibles.map { it.tarifaPorKm }.average()
        } else {
            DEFAULT_TARIFA_KM
        }
        val montoAproximado = if (compatibles.isNotEmpty()) {
            compatibles.map {
                val baseEf = calcularTarifaBaseEfectiva(
                    tarifaBase = it.tarifaBase,
                    tarifaBaseCarga = it.tarifaBaseCarga,
                    esCargaFlete = esCargaAplicable && esVehiculoCargo(it.tipoVehiculo)
                )
                (baseEf + distanciaKm * it.tarifaPorKm).coerceIn(DEFAULT_TARIFA_BASE_NORMAL, 500000.0)
            }.average().roundToInt().toDouble()
        } else {
            (tBaseAplicada + distanciaKm * tKmAplicada)
                .coerceIn(DEFAULT_TARIFA_BASE_NORMAL, 500000.0)
                .roundToInt()
                .toDouble()
        }

        val montoRefSistema = (baseDefecto + distanciaKm * DEFAULT_TARIFA_KM)
            .coerceIn(DEFAULT_TARIFA_BASE_NORMAL, 500000.0)
            .roundToInt()
            .toDouble()
        val montoReferenciaPromedio = if (compatibles.size >= 2) {
            minOf(montoAproximado, montoRefSistema * 1.25).roundToInt().toDouble()
        } else {
            montoRefSistema
        }
        val limiteMaximoPermitido = calcularLimiteMaximoPermitido(
            montoReferenciaPromedio = montoReferenciaPromedio,
            esCargaFlete = esCargaAplicable,
            multiplicadorTopeNormal = multNormal,
            multiplicadorTopeCarga = multCarga
        )

        val payload = mutableMapOf<String, Any>(
            "pasajeroId" to uidAutenticado,
            "pasajeroNombre" to nombreLimpio,
            "cantidadPasajeros" to cantidadPasajeros.coerceIn(1, 16),
            "tiposVehiculoPermitidos" to tiposNorm,
            "esCargaFlete" to esCargaAplicable,
            "origenNombre" to origenLimpio,
            "origenLat" to origenLat,
            "origenLng" to origenLng,
            "destinoNombre" to destinoLimpio,
            "destinoLat" to destinoLat,
            "destinoLng" to destinoLng,
            "distanciaKm" to distanciaKm,
            "resenaUbicacion" to resenaLimpia,
            "montoAproximado" to montoAproximado,
            "tarifaBaseAplicada" to tBaseAplicada,
            "tarifaKmAplicada" to tKmAplicada,
            "montoReferenciaPromedio" to montoReferenciaPromedio,
            "limiteMaximoPermitido" to limiteMaximoPermitido,
            "pinHash" to pinHash,
            "pinVerificado" to false,
            "gpsConductorActivo" to false,
            "colaConductores" to colaConductores,
            "ofertaActualIndex" to 0,
            "ofertaExpiraAt" to (System.currentTimeMillis() + 15_000L),
            "estado" to "buscando",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (esCargaAplicable) {
            payload["tarifaBaseCargaAplicada"] = tBaseAplicada
        }

        // ESCRITURA SECUENCIAL OBLIGATORIA:
        // Las reglas de /viajes/{viajeId}/secreto/{docId} verifican exists(.../viajes/{viajeId}).
        viajeRef.set(payload).await()
        viajeRef.collection("secreto").document("codigo").set(
            mapOf(
                "pasajeroId" to uidAutenticado,
                "pin" to pin,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()

        return Pair(payload + ("id" to viajeId), pin)
    }

    // -------------------------------------------------------------------------
    // REQUISITO 6: CALIFICACIÓN MUTUA Y PROMEDIO GUARDADO EN FIRESTORE
    // -------------------------------------------------------------------------
    suspend fun enviarCalificacionYActualizarPromedio(
        viajeId: String,
        autorUid: String,
        destinatarioUid: String,
        destinatarioRol: String,
        estrellas: Int,
        comentario: String = ""
    ) {
        val calId = "cal_${viajeId}_$destinatarioRol"
        val calRef = db.collection("calificaciones").document(calId)
        val targetCollection = if (destinatarioRol == "conductor") "conductores" else "pasajeros"
        val targetRef = db.collection(targetCollection).document(destinatarioUid)

        db.runTransaction { tx ->
            val targetSnap = tx.get(targetRef)
            val promedioPrevio = targetSnap.getDouble("promedioCalificacion") ?: 5.0
            val totalPrevio = (targetSnap.getLong("totalCalificaciones") ?: 0L).toInt()
            val nuevoTotal = totalPrevio + 1
            val nuevoPromedio = ((promedioPrevio * totalPrevio) + estrellas) / nuevoTotal

            tx.set(
                calRef,
                mapOf(
                    "viajeId" to viajeId,
                    "autorUid" to autorUid,
                    "destinatarioUid" to destinatarioUid,
                    "destinatarioRol" to destinatarioRol,
                    "estrellas" to estrellas,
                    "comentario" to comentario.take(240),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            tx.update(
                targetRef,
                mapOf(
                    "promedioCalificacion" to Math.round(nuevoPromedio * 100.0) / 100.0,
                    "totalCalificaciones" to nuevoTotal,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    // -------------------------------------------------------------------------
    // PANEL ADMIN MODULAR: RESUMEN (COUNT) + CONSULTAS LAZY CON limit(20)
    // -------------------------------------------------------------------------
    suspend fun obtenerResumenAdminLigero(): AdminResumenLigero {
        val condTotal = db.collection("conductores").count().get(AggregateSource.SERVER).await().count
        val condActivos = db.collection("conductores")
            .whereEqualTo("estadoCuenta", "activo")
            .count().get(AggregateSource.SERVER).await().count
        val condPendientes = db.collection("conductores")
            .whereEqualTo("estadoCuenta", "pendiente")
            .count().get(AggregateSource.SERVER).await().count
        val pasTotal = db.collection("pasajeros").count().get(AggregateSource.SERVER).await().count
        val solPendientes = db.collection("solicitudesCambio")
            .whereEqualTo("estado", "pendiente")
            .count().get(AggregateSource.SERVER).await().count

        return AdminResumenLigero(
            totalConductores = condTotal,
            conductoresActivos = condActivos,
            conductoresPendientes = condPendientes,
            totalPasajeros = pasTotal,
            solicitudesPendientes = solPendientes
        )
    }

    suspend fun obtenerPasajerosAdmin(limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("pasajeros").limit(limite).get().await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("uid" to doc.id) }
    }

    suspend fun obtenerConductoresAdmin(limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("conductores").limit(limite).get().await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("uid" to doc.id) }
    }

    suspend fun obtenerConductoresPendientesAdmin(limite: Long = 20L): List<Map<String, Any>> {
        val snap = db.collection("conductores")
            .whereEqualTo("estadoCuenta", "pendiente")
            .limit(limite)
            .get()
            .await()
        return snap.documents.map { doc -> doc.data.orEmpty().plus("uid" to doc.id) }
    }

    /**
     * Aprueba y activa un conductor pendiente y establece su fecha de licencia
     * exactamente a 1 mes a partir de la fecha de hoy.
     */
    suspend fun aprobarYActivarConductorAdmin(conductorId: String): Timestamp {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        val nuevaLicenciaExp = Timestamp(cal.time)
        db.collection("conductores").document(conductorId).update(
            mapOf(
                "estadoCuenta" to "activo",
                "estadoOperativo" to "disponible",
                "disponible" to true,
                "mensualidadPendiente" to false,
                "licenciaExp" to nuevaLicenciaExp,
                "docVehiculoAprobado" to true,
                "docCedulaAprobado" to true,
                "docLicenciaAprobado" to true,
                "docCirculacionAprobado" to true,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return nuevaLicenciaExp
    }

    /**
     * Renueva la licencia del conductor en Firestore sumando exactamente 1 mes
     * a la fecha actual en el campo licenciaExp.
     */
    suspend fun renovarLicenciaConductorAdmin(conductorId: String): Timestamp {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        val nuevaLicenciaExp = Timestamp(cal.time)
        db.collection("conductores").document(conductorId).update(
            mapOf(
                "licenciaExp" to nuevaLicenciaExp,
                "mensualidadPendiente" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return nuevaLicenciaExp
    }

    /**
     * Actualiza la ficha completa del conductor desde el panel de Administrador,
     * manteniendo intacto su UID, fecha de registro, total de viajes y finanzas históricas.
     */
    suspend fun actualizarTarifasYEquipamientoConductor(
        conductorId: String,
        vehiculoTipo: String,
        tarifaBase: Double,
        tarifaPorKm: Double,
        tarifaBaseCarga: Double?,
        tieneCascoExtra: Boolean,
        tieneCapaDisponible: Boolean
    ) {
        val updates = mutableMapOf<String, Any>(
            "tarifaBase" to tarifaBase.coerceIn(500.0, 50000.0),
            "tarifaPorKm" to tarifaPorKm.coerceIn(100.0, 10000.0),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (esVehiculoCargo(vehiculoTipo) && tarifaBaseCarga != null && tarifaBaseCarga >= 500.0) {
            updates["tarifaBaseCarga"] = tarifaBaseCarga.coerceIn(500.0, 150000.0)
        } else {
            updates["tarifaBaseCarga"] = FieldValue.delete()
        }
        if (esVehiculoMoto(vehiculoTipo)) {
            updates["tieneCascoExtra"] = tieneCascoExtra
            updates["tieneCapaDisponible"] = tieneCapaDisponible
        }
        db.collection("conductores").document(conductorId).update(updates).await()
    }

    suspend fun actualizarFichaConductorAdmin(
        conductorId: String,
        nombre: String,
        telefono: String,
        cedula: String,
        vehiculoTipo: String,
        vehiculoMarca: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        estadoCuenta: String,
        mensualidadPendiente: Boolean,
        licenciaExpMillis: Long,
        docVehiculoAprobado: Boolean,
        docCedulaAprobado: Boolean,
        docLicenciaAprobado: Boolean,
        docCirculacionAprobado: Boolean,
        tarifaBaseCarga: Double? = null,
        tieneCascoExtra: Boolean = false,
        tieneCapaDisponible: Boolean = false
    ): Timestamp {
        val nombreLimpio = nombre.trim().take(100)
        require(nombreLimpio.length >= 2) { "El nombre debe tener al menos 2 caracteres." }
        val placaLimpia = placa.trim().uppercase().take(20)
        require(placaLimpia.length >= 3) { "La placa debe tener al menos 3 caracteres." }
        val vehiculoTipoLimpio = vehiculoTipo.trim().ifBlank { "Pickup 4x4" }.take(40)
        require(vehiculoTipoLimpio.length >= 2) { "Indica un tipo de vehículo válido." }

        val telLimpio = telefono.trim().take(30)
        if (telLimpio.isNotEmpty() && telLimpio.length < 6) {
            throw IllegalArgumentException("El teléfono debe tener al menos 6 dígitos.")
        }

        val estadoLimpio = when (estadoCuenta.trim().lowercase()) {
            "activo", "inactivo", "pendiente", "bloqueado" -> estadoCuenta.trim().lowercase()
            else -> "inactivo"
        }
        val expTimestamp = Timestamp(Date(licenciaExpMillis))

        val userRef = db.collection("usuarios").document(conductorId)
        val piiRef = userRef.collection("private").document("pii")
        val userSnap = try { userRef.get().await() } catch (_: Throwable) { null }
        val piiSnap = try { piiRef.get().await() } catch (_: Throwable) { null }

        val batch = db.batch()
        val condUpdates = mutableMapOf<String, Any>(
            "nombre" to nombreLimpio,
            "vehiculoTipo" to vehiculoTipoLimpio,
            "tipoVehiculo" to normalizarTipoVehiculo(vehiculoTipoLimpio),
            "vehiculoMarca" to vehiculoMarca.trim().take(60),
            "vehiculoModelo" to vehiculoModelo.trim().take(80),
            "vehiculoColor" to vehiculoColor.trim().take(40),
            "vehiculoAnio" to vehiculoAnio.trim().take(10),
            "placa" to placaLimpia,
            "capacidad" to capacidad.coerceIn(1, 24),
            "tarifaBase" to tarifaBase.coerceIn(500.0, 50000.0),
            "tarifaPorKm" to tarifaPorKm.coerceIn(100.0, 10000.0),
            "estadoCuenta" to estadoLimpio,
            "mensualidadPendiente" to mensualidadPendiente,
            "licenciaExp" to expTimestamp,
            "docVehiculoAprobado" to docVehiculoAprobado,
            "docCedulaAprobado" to docCedulaAprobado,
            "docLicenciaAprobado" to docLicenciaAprobado,
            "docCirculacionAprobado" to docCirculacionAprobado,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (esVehiculoCargo(vehiculoTipoLimpio) && tarifaBaseCarga != null && tarifaBaseCarga >= 500.0) {
            condUpdates["tarifaBaseCarga"] = tarifaBaseCarga.coerceIn(500.0, 150000.0)
        } else {
            condUpdates["tarifaBaseCarga"] = FieldValue.delete()
        }
        if (esVehiculoMoto(vehiculoTipoLimpio)) {
            condUpdates["tieneCascoExtra"] = tieneCascoExtra
            condUpdates["tieneCapaDisponible"] = tieneCapaDisponible
        } else {
            condUpdates["tieneCascoExtra"] = false
            condUpdates["tieneCapaDisponible"] = false
        }
        if (estadoLimpio != "activo") {
            condUpdates["disponible"] = false
            condUpdates["estadoOperativo"] = "offline"
        }
        batch.update(db.collection("conductores").document(conductorId), condUpdates)

        if (userSnap != null && userSnap.exists()) {
            batch.update(
                userRef,
                mapOf(
                    "nombre" to nombreLimpio,
                    "bloqueado" to (estadoLimpio == "bloqueado"),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }

        if (telLimpio.length >= 6) {
            if (piiSnap != null && piiSnap.exists()) {
                batch.update(
                    piiRef,
                    mapOf(
                        "telefono" to telLimpio,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                val cedulaFinal = cedula.trim().take(40).let { if (it.length >= 4) it else "PENDIENTE" }
                batch.set(
                    piiRef,
                    mapOf(
                        "uid" to conductorId,
                        "telefono" to telLimpio,
                        "cedula" to cedulaFinal,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }

        batch.commit().await()
        return expTimestamp
    }

    suspend fun obtenerMiPii(uid: String): Map<String, Any>? {
        val snap = db.collection("usuarios").document(uid)
            .collection("private").document("pii").get().await()
        return snap.data
    }

    suspend fun obtenerMisDocumentosConductor(uid: String): Map<String, Any>? {
        val snap = db.collection("usuarios").document(uid)
            .collection("private").document("documentos").get().await()
        return snap.data
    }

    suspend fun obtenerPiiUsuarioAdmin(uid: String): Map<String, Any>? {
        val snap = db.collection("usuarios").document(uid)
            .collection("private").document("pii").get().await()
        return snap.data
    }

    suspend fun actualizarFichaPasajeroAdmin(
        pasajeroId: String,
        nombre: String,
        telefono: String,
        email: String,
        cedula: String
    ) {
        val batch = db.batch()
        batch.update(
            db.collection("pasajeros").document(pasajeroId),
            mapOf(
                "nombre" to nombre.trim().take(100),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("usuarios").document(pasajeroId),
            mapOf(
                "nombre" to nombre.trim().take(100),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("usuarios").document(pasajeroId)
                .collection("private").document("pii"),
            mapOf(
                "uid" to pasajeroId,
                "telefono" to telefono.trim().take(30),
                "email" to email.trim().take(160),
                "cedula" to cedula.trim().take(40),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
        batch.commit().await()
    }

    suspend fun toggleBloqueoPasajeroAdmin(pasajeroId: String, bloquear: Boolean) {
        val batch = db.batch()
        batch.update(
            db.collection("pasajeros").document(pasajeroId),
            mapOf(
                "bloqueado" to bloquear,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("usuarios").document(pasajeroId),
            mapOf(
                "bloqueado" to bloquear,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
    }

    suspend fun eliminarCuentaPasajeroAdmin(pasajeroId: String) {
        val batch = db.batch()
        batch.delete(
            db.collection("usuarios").document(pasajeroId)
                .collection("private").document("pii")
        )
        batch.delete(db.collection("pasajeros").document(pasajeroId))
        batch.delete(db.collection("usuarios").document(pasajeroId))
        batch.commit().await()
    }

    // -------------------------------------------------------------------------
    // PETICIONES DE CAMBIO DE DATOS (PASAJERO / CONDUCTOR -> ADMIN)
    // -------------------------------------------------------------------------
    suspend fun crearSolicitudCambioLineas(
        solicitanteUid: String,
        rol: String,
        nombreActual: String,
        resumenActual: String,
        items: List<CambioItemData>,
        motivo: String
    ): SolicitudCambioData {
        val itemsLimpios = items.mapNotNull { item ->
            val clave = item.clave.trim().take(40)
            if (clave.isEmpty()) return@mapNotNull null
            val esImg = item.tipo == "imagen"
            val valAnt = if (esImg) {
                item.valorAnterior.trim().take(218_000)
            } else {
                item.valorAnterior.trim().take(300)
            }
            val valNew = if (esImg) {
                item.valorNuevo.trim().take(218_000)
            } else {
                val rawNew = item.valorNuevo.trim()
                if (clave == "placa") rawNew.uppercase().take(20) else rawNew.take(300)
            }
            if (valNew.isBlank() || valNew == valAnt) return@mapNotNull null
            CambioItemData(
                clave = clave,
                etiqueta = item.etiqueta.trim().ifBlank { etiquetaCambioPorClave(clave) }.take(80),
                tipo = if (esImg) "imagen" else "texto",
                valorAnterior = valAnt,
                valorNuevo = valNew,
                estado = "pendiente",
                motivoRechazo = ""
            )
        }.take(16)

        require(itemsLimpios.isNotEmpty()) {
            "Modifica al menos un campo o selecciona una foto nueva antes de enviar."
        }

        val motivoLimpio = motivo.trim().take(300)
        require(motivoLimpio.length >= 3) {
            "El motivo del cambio debe tener al menos 3 caracteres."
        }

        // Protección contra límite de 1 MiB en documentos de Firestore si se reemplazan varias fotos a la vez
        var itemsFinales = itemsLimpios
        val totalChars = itemsFinales.sumOf { it.valorAnterior.length + it.valorNuevo.length }
        if (totalChars > 760_000) {
            val imgCount = itemsFinales.count { it.tipo == "imagen" }.coerceAtLeast(1)
            val presupuestoPorLado = (680_000 / (imgCount * 2)).coerceIn(45_000, 110_000)
            itemsFinales = itemsFinales.map { it ->
                if (it.tipo == "imagen") {
                    it.copy(
                        valorAnterior = ImageCompressionUtils.recomprimirDataUrlParaLimite(
                            it.valorAnterior,
                            maxAnchoPx = 560,
                            calidadJpeg = 58,
                            maxBase64Chars = presupuestoPorLado
                        ),
                        valorNuevo = ImageCompressionUtils.recomprimirDataUrlParaLimite(
                            it.valorNuevo,
                            maxAnchoPx = 800,
                            calidadJpeg = 65,
                            maxBase64Chars = presupuestoPorLado
                        )
                    )
                } else it
            }
        }

        val nombreSeguro = nombreActual.trim().ifBlank { "Usuario Rural" }.let {
            if (it.length >= 2) it.take(100) else "Usuario Rural"
        }
        val resumenSeguro = resumenActual.trim().ifBlank { "Perfil registrado" }.let {
            if (it.length >= 2) it.take(240) else "Perfil registrado"
        }

        val solicitudId = "sol_${solicitanteUid.take(12)}_${System.currentTimeMillis()}"
        val payload = mapOf<String, Any>(
            "id" to solicitudId,
            "solicitanteUid" to solicitanteUid,
            "rol" to rol,
            "nombreActual" to nombreSeguro,
            "resumenActual" to resumenSeguro,
            "cambios" to itemsFinales.map { it.toFirestoreMap() },
            "motivo" to motivoLimpio,
            "estado" to "pendiente",
            "estadoGeneral" to "pendiente",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("solicitudesCambio").document(solicitudId).set(payload).await()
        return SolicitudCambioData(
            id = solicitudId,
            solicitanteUid = solicitanteUid,
            rol = rol,
            nombreActual = nombreSeguro,
            resumenActual = resumenSeguro,
            cambios = emptyMap(),
            items = itemsFinales,
            motivo = motivoLimpio,
            estado = "pendiente",
            estadoGeneral = "pendiente",
            createdAtMillis = System.currentTimeMillis()
        )
    }

    suspend fun crearSolicitudCambioDatos(
        solicitanteUid: String,
        rol: String,
        nombreActual: String,
        resumenActual: String,
        cambios: Map<String, Any>,
        motivo: String,
        datosAnteriores: Map<String, Any> = emptyMap()
    ): SolicitudCambioData {
        val cambiosLimpios = mutableMapOf<String, Any>()
        (cambios["nombre"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { cambiosLimpios["nombre"] = it.take(100) }
        (cambios["telefono"] as? String)?.trim()?.takeIf { it.length >= 6 }?.let { cambiosLimpios["telefono"] = it.take(30) }
        (cambios["email"] as? String)?.trim()?.takeIf { it.length >= 5 }?.let { cambiosLimpios["email"] = it.take(160) }
        (cambios["cedula"] as? String)?.trim()?.takeIf { it.length >= 4 }?.let { cambiosLimpios["cedula"] = it.take(40) }
        (cambios["vehiculoTipo"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { cambiosLimpios["vehiculoTipo"] = it.take(40) }
        (cambios["vehiculoMarca"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { cambiosLimpios["vehiculoMarca"] = it.take(60) }
        (cambios["vehiculoModelo"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { cambiosLimpios["vehiculoModelo"] = it.take(80) }
        (cambios["vehiculoColor"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { cambiosLimpios["vehiculoColor"] = it.take(40) }
        (cambios["vehiculoAnio"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { cambiosLimpios["vehiculoAnio"] = it.take(10) }
        (cambios["placa"] as? String)?.trim()?.takeIf { it.length >= 3 }?.let { cambiosLimpios["placa"] = it.uppercase().take(20) }
        (cambios["capacidad"] as? Number)?.toInt()?.let { cambiosLimpios["capacidad"] = it.coerceIn(1, 24) }

        require(cambiosLimpios.isNotEmpty()) {
            "Verifica la longitud mínima de los campos que deseas cambiar (ej. nombre ≥ 2, teléfono ≥ 6, placa ≥ 3)."
        }

        val motivoLimpio = motivo.trim().take(300)
        require(motivoLimpio.length >= 3) {
            "El motivo del cambio debe tener al menos 3 caracteres."
        }

        val nombreSeguro = nombreActual.trim().ifBlank { "Usuario Rural" }.let {
            if (it.length >= 2) it.take(100) else "Usuario Rural"
        }
        val resumenSeguro = resumenActual.trim().ifBlank { "Perfil registrado" }.let {
            if (it.length >= 2) it.take(240) else "Perfil registrado"
        }

        val datosAnterioresLimpios = mutableMapOf<String, Any>()
        cambiosLimpios.keys.forEach { clave ->
            val prev = datosAnteriores[clave]
            when (prev) {
                is Number -> datosAnterioresLimpios[clave] = prev.toInt()
                is String -> datosAnterioresLimpios[clave] = prev.trim().take(160)
            }
        }

        val itemsGranulares = cambiosLimpios.entries.map { (clave, valorNuevo) ->
            CambioItemData(
                clave = clave,
                etiqueta = etiquetaCambioPorClave(clave),
                tipo = "texto",
                valorAnterior = datosAnterioresLimpios[clave]?.toString().orEmpty(),
                valorNuevo = valorNuevo.toString(),
                estado = "pendiente",
                motivoRechazo = ""
            )
        }

        val solicitudId = "sol_${solicitanteUid.take(12)}_${System.currentTimeMillis()}"
        val payload = mutableMapOf<String, Any>(
            "id" to solicitudId,
            "solicitanteUid" to solicitanteUid,
            "rol" to rol,
            "nombreActual" to nombreSeguro,
            "resumenActual" to resumenSeguro,
            "cambios" to cambiosLimpios,
            "motivo" to motivoLimpio,
            "estado" to "pendiente",
            "estadoGeneral" to "pendiente",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (datosAnterioresLimpios.isNotEmpty()) {
            payload["datosAnteriores"] = datosAnterioresLimpios
        }

        db.collection("solicitudesCambio").document(solicitudId).set(payload).await()
        return SolicitudCambioData(
            id = solicitudId,
            solicitanteUid = solicitanteUid,
            rol = rol,
            nombreActual = nombreSeguro,
            resumenActual = resumenSeguro,
            cambios = cambiosLimpios,
            items = itemsGranulares,
            motivo = motivoLimpio,
            estado = "pendiente",
            estadoGeneral = "pendiente",
            datosAnteriores = datosAnterioresLimpios,
            createdAtMillis = System.currentTimeMillis()
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseItemsDesdeRaw(
        rawCambios: Any?,
        datosAnteriores: Map<String, Any>,
        estadoDoc: String
    ): Pair<List<CambioItemData>, Map<String, Any>> {
        val estadoItemFallback = when (estadoDoc) {
            "aprobada", "aprobado" -> "aprobado"
            "rechazada", "rechazado" -> "rechazado"
            else -> "pendiente"
        }
        return when (rawCambios) {
            is List<*> -> {
                val items = rawCambios.mapNotNull { entry ->
                    val m = entry as? Map<*, *> ?: return@mapNotNull null
                    val clave = (m["clave"] as? String)?.trim().orEmpty()
                    if (clave.isEmpty()) return@mapNotNull null
                    CambioItemData(
                        clave = clave,
                        etiqueta = (m["etiqueta"] as? String)?.takeIf { it.isNotBlank() }
                            ?: etiquetaCambioPorClave(clave),
                        tipo = if ((m["tipo"] as? String) == "imagen") "imagen" else "texto",
                        valorAnterior = (m["valorAnterior"] as? String) ?: "",
                        valorNuevo = (m["valorNuevo"] as? String) ?: "",
                        estado = when (val st = m["estado"] as? String) {
                            "aprobado", "rechazado", "pendiente" -> st
                            else -> "pendiente"
                        },
                        motivoRechazo = (m["motivoRechazo"] as? String) ?: ""
                    )
                }
                items to emptyMap()
            }
            is Map<*, *> -> {
                val typedMap = rawCambios.entries.mapNotNull { (k, v) ->
                    val key = k as? String ?: return@mapNotNull null
                    val value = v ?: return@mapNotNull null
                    key to value
                }.toMap()
                val primerValorEsItem = typedMap.values.firstOrNull() is Map<*, *>
                if (primerValorEsItem) {
                    val items = typedMap.entries.mapNotNull { (clave, v) ->
                        val m = v as? Map<*, *> ?: return@mapNotNull null
                        CambioItemData(
                            clave = (m["clave"] as? String)?.takeIf { it.isNotBlank() } ?: clave,
                            etiqueta = (m["etiqueta"] as? String)?.takeIf { it.isNotBlank() }
                                ?: etiquetaCambioPorClave(clave),
                            tipo = if ((m["tipo"] as? String) == "imagen") "imagen" else "texto",
                            valorAnterior = (m["valorAnterior"] as? String) ?: "",
                            valorNuevo = (m["valorNuevo"] as? String) ?: "",
                            estado = when (val st = m["estado"] as? String) {
                                "aprobado", "rechazado", "pendiente" -> st
                                else -> "pendiente"
                            },
                            motivoRechazo = (m["motivoRechazo"] as? String) ?: ""
                        )
                    }
                    items to emptyMap()
                } else {
                    val items = typedMap.entries.map { (clave, valor) ->
                        CambioItemData(
                            clave = clave,
                            etiqueta = etiquetaCambioPorClave(clave),
                            tipo = "texto",
                            valorAnterior = datosAnteriores[clave]?.toString().orEmpty(),
                            valorNuevo = valor.toString(),
                            estado = estadoItemFallback,
                            motivoRechazo = ""
                        )
                    }
                    items to typedMap
                }
            }
            else -> emptyList<CambioItemData>() to emptyMap()
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapSolicitudCambioDoc(doc: DocumentSnapshot, fallbackUid: String = ""): SolicitudCambioData {
        val createdAtMs = parseLicenciaExpMillis(doc.get("createdAt"))
            ?: parseLicenciaExpMillis(doc.get("updatedAt"))
            ?: 0L
        val estadoDoc = doc.getString("estado") ?: "pendiente"
        val datosAnteriores = (doc.get("datosAnteriores") as? Map<String, Any>).orEmpty()
        val (items, cambiosFlat) = parseItemsDesdeRaw(doc.get("cambios"), datosAnteriores, estadoDoc)
        val estadoGeneralDoc = doc.getString("estadoGeneral")
            ?: if (items.any { it.estado == "pendiente" } || estadoDoc == "pendiente") "pendiente" else "completada"
        return SolicitudCambioData(
            id = doc.id,
            solicitanteUid = doc.getString("solicitanteUid") ?: fallbackUid,
            rol = doc.getString("rol") ?: "pasajero",
            nombreActual = doc.getString("nombreActual") ?: "",
            resumenActual = doc.getString("resumenActual") ?: "",
            cambios = cambiosFlat,
            items = items,
            motivo = doc.getString("motivo") ?: "",
            estado = estadoDoc,
            estadoGeneral = estadoGeneralDoc,
            respuestaAdmin = doc.getString("respuestaAdmin") ?: "",
            datosAnteriores = datosAnteriores,
            createdAtMillis = createdAtMs
        )
    }

    suspend fun obtenerMisSolicitudesCambio(uid: String, limite: Long = 10L): List<SolicitudCambioData> {
        val snap = db.collection("solicitudesCambio")
            .whereEqualTo("solicitanteUid", uid)
            .limit(limite)
            .get()
            .await()
        return snap.documents
            .map { mapSolicitudCambioDoc(it, uid) }
            .sortedByDescending { it.createdAtMillis }
    }

    fun observarMisSolicitudesCambio(
        uid: String,
        limite: Long = 10L,
        onUpdate: (List<SolicitudCambioData>) -> Unit
    ): ListenerRegistration {
        return db.collection("solicitudesCambio")
            .whereEqualTo("solicitanteUid", uid)
            .limit(limite)
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                val lista = snap.documents
                    .map { mapSolicitudCambioDoc(it, uid) }
                    .sortedByDescending { it.createdAtMillis }
                onUpdate(lista)
            }
    }

    suspend fun obtenerSolicitudesCambioAdmin(limite: Long = 30L): List<SolicitudCambioData> {
        val snap = db.collection("solicitudesCambio").limit(limite).get().await()
        return snap.documents
            .map { mapSolicitudCambioDoc(it) }
            .sortedWith(
                compareBy<SolicitudCambioData> { if (it.tienePendientes) 0 else 1 }
                    .thenByDescending { it.createdAtMillis }
            )
    }

    fun observarSolicitudesCambioPendientesAdmin(
        onUpdate: (List<SolicitudCambioData>) -> Unit,
        onError: (Throwable) -> Unit = {}
    ): ListenerRegistration {
        return db.collection("solicitudesCambio")
            .whereEqualTo("estado", "pendiente")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    onError(err)
                    return@addSnapshotListener
                }
                val lista = snap?.documents
                    ?.map { mapSolicitudCambioDoc(it) }
                    ?.filter { it.tienePendientes }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
                onUpdate(lista)
            }
    }

    suspend fun resolverLineaSolicitudCambioAdmin(
        solicitudId: String,
        claveItem: String,
        aprobar: Boolean,
        motivoRechazo: String = ""
    ): SolicitudCambioData {
        val solRef = db.collection("solicitudesCambio").document(solicitudId)
        val motivoLimpio = if (aprobar) "" else motivoRechazo.trim().take(240)

        return db.runTransaction { tx ->
            val solSnap = tx.get(solRef)
            require(solSnap.exists()) { "La solicitud ya no existe." }
            val actual = mapSolicitudCambioDoc(solSnap)
            val uid = actual.solicitanteUid
            val targetIdx = actual.items.indexOfFirst { it.clave == claveItem }
            require(targetIdx >= 0) { "El campo '$claveItem' no se encontró en la solicitud." }

            val itemObjetivo = actual.items[targetIdx]
            if (itemObjetivo.estado != "pendiente") {
                return@runTransaction actual
            }

            // TODAS LAS LECTURAS ANTES DE CUALQUIER ESCRITURA EN FIRESTORE TRANSACTION
            val userRef = db.collection("usuarios").document(uid)
            val piiRef = userRef.collection("private").document("pii")
            val docsRef = userRef.collection("private").document("documentos")
            val condRef = db.collection("conductores").document(uid)
            val pasRef = db.collection("pasajeros").document(uid)

            val necesitaUser = aprobar && claveItem == "nombre"
            val necesitaPii = aprobar && claveItem in listOf("telefono", "email", "cedula")
            val necesitaDocs = aprobar && claveItem in listOf(
                "fotoVehiculo", "fotoCedula", "fotoLicencia", "fotoMarchamoRtv", "fotoCirculacion"
            )
            val necesitaCond = aprobar && actual.rol == "conductor" && claveItem in listOf(
                "nombre", "cedula", "vehiculoTipo", "vehiculoMarca", "vehiculoModelo",
                "color", "vehiculoColor", "vehiculoAnio", "anio", "placa", "capacidad",
                "tarifaBase", "tarifaBaseCarga", "precioKm", "tarifaPorKm",
                "tieneCascoExtra", "tieneCapaDisponible",
                "fotoVehiculo", "fotoCedula", "fotoLicencia", "fotoMarchamoRtv", "fotoCirculacion"
            )
            val necesitaPas = aprobar && actual.rol == "pasajero" && claveItem == "nombre"

            val userSnap = if (necesitaUser) tx.get(userRef) else null
            val piiSnap = if (necesitaPii) tx.get(piiRef) else null
            val docsSnap = if (necesitaDocs) tx.get(docsRef) else null
            val condSnap = if (necesitaCond) tx.get(condRef) else null
            val pasSnap = if (necesitaPas) tx.get(pasRef) else null

            // ESCRITURAS DESPUÉS DE TODAS LAS LECTURAS
            if (aprobar) {
                val nuevoVal = itemObjetivo.valorNuevo.trim()
                when (claveItem) {
                    "nombre" -> {
                        val nombreSeguro = nuevoVal.take(100)
                        require(nombreSeguro.length >= 2) { "El nombre debe tener al menos 2 caracteres." }
                        if (userSnap != null && userSnap.exists()) {
                            tx.update(userRef, mapOf("nombre" to nombreSeguro, "updatedAt" to FieldValue.serverTimestamp()))
                        }
                        if (condSnap != null && condSnap.exists()) {
                            tx.update(condRef, mapOf("nombre" to nombreSeguro, "updatedAt" to FieldValue.serverTimestamp()))
                        }
                        if (pasSnap != null && pasSnap.exists()) {
                            tx.update(pasRef, mapOf("nombre" to nombreSeguro, "updatedAt" to FieldValue.serverTimestamp()))
                        }
                    }
                    "telefono", "email", "cedula" -> {
                        val existingPii = piiSnap?.exists() == true
                        if (existingPii) {
                            val piiUpdates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
                            when (claveItem) {
                                "telefono" -> {
                                    require(nuevoVal.length >= 6) { "Teléfono inválido." }
                                    piiUpdates["telefono"] = nuevoVal.take(30)
                                }
                                "email" -> piiUpdates["email"] = nuevoVal.take(160)
                                "cedula" -> {
                                    require(nuevoVal.length >= 4) { "Cédula inválida." }
                                    piiUpdates["cedula"] = nuevoVal.take(40)
                                }
                            }
                            tx.update(piiRef, piiUpdates)
                        } else {
                            val piiNew = mutableMapOf<String, Any>(
                                "uid" to uid,
                                "telefono" to if (claveItem == "telefono") nuevoVal.take(30) else "00000000",
                                "cedula" to if (claveItem == "cedula") nuevoVal.take(40) else "PENDIENTE",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                            if (claveItem == "email") piiNew["email"] = nuevoVal.take(160)
                            tx.set(piiRef, piiNew)
                        }
                        if (claveItem == "cedula" && condSnap != null && condSnap.exists()) {
                            tx.update(condRef, mapOf("cedulaHash" to nuevoVal.take(40), "updatedAt" to FieldValue.serverTimestamp()))
                        }
                    }
                    "vehiculoTipo" -> if (condSnap != null && condSnap.exists()) {
                        val tipoLimpio = nuevoVal.take(40)
                        require(tipoLimpio.length >= 2) { "Tipo de vehículo inválido." }
                        tx.update(
                            condRef,
                            mapOf(
                                "vehiculoTipo" to tipoLimpio,
                                "tipoVehiculo" to normalizarTipoVehiculo(tipoLimpio),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    "vehiculoMarca" -> if (condSnap != null && condSnap.exists()) {
                        tx.update(condRef, mapOf("vehiculoMarca" to nuevoVal.take(60), "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "vehiculoModelo" -> if (condSnap != null && condSnap.exists()) {
                        val mod = nuevoVal.take(80)
                        require(mod.length >= 2) { "Modelo inválido." }
                        tx.update(condRef, mapOf("vehiculoModelo" to mod, "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "color", "vehiculoColor" -> if (condSnap != null && condSnap.exists()) {
                        tx.update(condRef, mapOf("vehiculoColor" to nuevoVal.take(40), "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "vehiculoAnio", "anio" -> if (condSnap != null && condSnap.exists()) {
                        tx.update(condRef, mapOf("vehiculoAnio" to nuevoVal.take(10), "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "placa" -> if (condSnap != null && condSnap.exists()) {
                        val pl = nuevoVal.uppercase().take(20)
                        require(pl.length >= 3) { "Placa inválida." }
                        tx.update(condRef, mapOf("placa" to pl, "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "capacidad" -> if (condSnap != null && condSnap.exists()) {
                        val cap = (nuevoVal.toIntOrNull() ?: 4).coerceIn(1, 24)
                        tx.update(condRef, mapOf("capacidad" to cap, "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "tarifaBase" -> if (condSnap != null && condSnap.exists()) {
                        val base = (nuevoVal.replace(",", "").toDoubleOrNull() ?: 1500.0).coerceIn(500.0, 50_000.0)
                        tx.update(condRef, mapOf("tarifaBase" to base, "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "tarifaBaseCarga" -> if (condSnap != null && condSnap.exists()) {
                        val baseCarga = nuevoVal.replace(",", "").toDoubleOrNull()
                        if (baseCarga != null && baseCarga >= 500.0) {
                            tx.update(condRef, mapOf("tarifaBaseCarga" to baseCarga.coerceIn(500.0, 150_000.0), "updatedAt" to FieldValue.serverTimestamp()))
                        } else {
                            tx.update(condRef, mapOf("tarifaBaseCarga" to FieldValue.delete(), "updatedAt" to FieldValue.serverTimestamp()))
                        }
                    }
                    "precioKm", "tarifaPorKm" -> if (condSnap != null && condSnap.exists()) {
                        val km = (nuevoVal.replace(",", "").toDoubleOrNull() ?: 650.0).coerceIn(100.0, 10_000.0)
                        tx.update(condRef, mapOf("tarifaPorKm" to km, "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "tieneCascoExtra" -> if (condSnap != null && condSnap.exists()) {
                        val flag = nuevoVal.equals("true", ignoreCase = true) || nuevoVal.equals("sí", ignoreCase = true) || nuevoVal.equals("si", ignoreCase = true)
                        tx.update(condRef, mapOf("tieneCascoExtra" to flag, "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "tieneCapaDisponible" -> if (condSnap != null && condSnap.exists()) {
                        val flag = nuevoVal.equals("true", ignoreCase = true) || nuevoVal.equals("sí", ignoreCase = true) || nuevoVal.equals("si", ignoreCase = true)
                        tx.update(condRef, mapOf("tieneCapaDisponible" to flag, "updatedAt" to FieldValue.serverTimestamp()))
                    }
                    "fotoVehiculo", "fotoCedula", "fotoLicencia", "fotoMarchamoRtv", "fotoCirculacion" -> {
                        val campoDoc = when (claveItem) {
                            "fotoVehiculo" -> "fotoVehiculo"
                            "fotoCedula" -> "fotoCedula"
                            "fotoLicencia" -> "fotoLicencia"
                            else -> "fotoCirculacion"
                        }
                        val imgSegura = nuevoVal.take(218_000)
                        if (docsSnap != null && docsSnap.exists()) {
                            tx.update(
                                docsRef,
                                mapOf(
                                    campoDoc to imgSegura,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            )
                        } else {
                            val nuevoDocs = mutableMapOf<String, Any>(
                                "uid" to uid,
                                "fotoVehiculo" to "",
                                "fotoCedula" to "",
                                "fotoLicencia" to "",
                                "fotoCirculacion" to "",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                            nuevoDocs[campoDoc] = imgSegura
                            tx.set(docsRef, nuevoDocs)
                        }
                        if (condSnap != null && condSnap.exists()) {
                            val condImgUpdates = mutableMapOf<String, Any>(
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                            when (campoDoc) {
                                "fotoVehiculo" -> {
                                    condImgUpdates["fotoVehiculoUrl"] = imgSegura.take(148_000)
                                    condImgUpdates["docVehiculoAprobado"] = true
                                }
                                "fotoCedula" -> condImgUpdates["docCedulaAprobado"] = true
                                "fotoLicencia" -> condImgUpdates["docLicenciaAprobado"] = true
                                "fotoCirculacion" -> condImgUpdates["docCirculacionAprobado"] = true
                            }
                            tx.update(condRef, condImgUpdates)
                        }
                    }
                }
            }

            val itemActualizado = itemObjetivo.copy(
                estado = if (aprobar) "aprobado" else "rechazado",
                motivoRechazo = motivoLimpio
            )
            val nuevosItems = actual.items.toMutableList().apply {
                set(targetIdx, itemActualizado)
            }
            val quedanPendientes = nuevosItems.any { it.estado == "pendiente" }
            val nuevoEstadoGeneral = if (quedanPendientes) "pendiente" else "completada"

            val solUpdates = mutableMapOf<String, Any>(
                "estadoGeneral" to nuevoEstadoGeneral,
                "estado" to nuevoEstadoGeneral,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            // Si la solicitud original venía en formato lista granular, actualizamos la lista;
            // si venía en formato mapa legado, la migramos o resolvemos acorde.
            val rawCambios = solSnap.get("cambios")
            if (rawCambios is List<*>) {
                solUpdates["cambios"] = nuevosItems.map { it.toFirestoreMap() }
            } else {
                // Legado mapa plano: respetar immutabilidad de cambios si tiene 1 o marcar estado final
                solUpdates["estado"] = if (aprobar) "aprobada" else "rechazada"
                solUpdates["estadoGeneral"] = "completada"
                if (motivoLimpio.isNotBlank()) solUpdates["respuestaAdmin"] = motivoLimpio
            }

            tx.update(solRef, solUpdates)

            actual.copy(
                items = nuevosItems,
                estado = solUpdates["estado"] as String,
                estadoGeneral = nuevoEstadoGeneral
            )
        }.await()
    }

    suspend fun resolverSolicitudCambioAdmin(
        solicitud: SolicitudCambioData,
        aprobar: Boolean,
        respuestaAdmin: String = ""
    ) {
        val uid = solicitud.solicitanteUid
        val c = solicitud.cambios
        val userRef = db.collection("usuarios").document(uid)
        val piiRef = userRef.collection("private").document("pii")
        val condRef = db.collection("conductores").document(uid)
        val pasRef = db.collection("pasajeros").document(uid)

        val userExists = if (aprobar) (try { userRef.get().await().exists() } catch (_: Throwable) { false }) else false
        val piiSnap = if (aprobar) (try { piiRef.get().await() } catch (_: Throwable) { null }) else null
        val condExists = if (aprobar && solicitud.rol == "conductor") (try { condRef.get().await().exists() } catch (_: Throwable) { false }) else false
        val pasExists = if (aprobar && solicitud.rol == "pasajero") (try { pasRef.get().await().exists() } catch (_: Throwable) { false }) else false

        val batch = db.batch()

        if (aprobar) {
            val nombreNuevo = (c["nombre"] as? String)?.trim()?.take(100)
            if (!nombreNuevo.isNullOrBlank() && userExists) {
                batch.update(
                    userRef,
                    mapOf("nombre" to nombreNuevo, "updatedAt" to FieldValue.serverTimestamp())
                )
            }

            val telNuevo = (c["telefono"] as? String)?.trim()?.takeIf { it.length >= 6 }?.take(30)
            val emailNuevo = (c["email"] as? String)?.trim()?.takeIf { it.length >= 5 }?.take(160)
            val cedulaNueva = (c["cedula"] as? String)?.trim()?.takeIf { it.length >= 4 }?.take(40)
            if (telNuevo != null || emailNuevo != null || cedulaNueva != null) {
                if (piiSnap != null && piiSnap.exists()) {
                    val piiUpdates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
                    telNuevo?.let { piiUpdates["telefono"] = it }
                    emailNuevo?.let { piiUpdates["email"] = it }
                    cedulaNueva?.let { piiUpdates["cedula"] = it }
                    batch.update(piiRef, piiUpdates)
                } else {
                    val piiNew = mutableMapOf<String, Any>(
                        "uid" to uid,
                        "telefono" to (telNuevo ?: "00000000"),
                        "cedula" to (cedulaNueva ?: "PENDIENTE"),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    emailNuevo?.let { piiNew["email"] = it }
                    batch.set(piiRef, piiNew)
                }
            }

            if (solicitud.rol == "pasajero" && pasExists && !nombreNuevo.isNullOrBlank()) {
                batch.update(
                    pasRef,
                    mapOf("nombre" to nombreNuevo, "updatedAt" to FieldValue.serverTimestamp())
                )
            }

            if (solicitud.rol == "conductor" && condExists) {
                val condUpdates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
                if (!nombreNuevo.isNullOrBlank()) condUpdates["nombre"] = nombreNuevo
                cedulaNueva?.let { condUpdates["cedulaHash"] = it }
                (c["vehiculoTipo"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let {
                    val tipoLimpio = it.take(40)
                    condUpdates["vehiculoTipo"] = tipoLimpio
                    condUpdates["tipoVehiculo"] = normalizarTipoVehiculo(tipoLimpio)
                }
                (c["vehiculoMarca"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { condUpdates["vehiculoMarca"] = it.take(60) }
                (c["vehiculoModelo"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { condUpdates["vehiculoModelo"] = it.take(80) }
                (c["vehiculoColor"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { condUpdates["vehiculoColor"] = it.take(40) }
                (c["vehiculoAnio"] as? String)?.trim()?.takeIf { it.length >= 2 }?.let { condUpdates["vehiculoAnio"] = it.take(10) }
                (c["placa"] as? String)?.trim()?.takeIf { it.length >= 3 }?.let { condUpdates["placa"] = it.uppercase().take(20) }
                (c["capacidad"] as? Number)?.toInt()?.let { condUpdates["capacidad"] = it.coerceIn(1, 24) }
                if (condUpdates.size > 1) {
                    batch.update(condRef, condUpdates)
                }
            }
        }

        val solUpdates = mutableMapOf<String, Any>(
            "estado" to if (aprobar) "aprobada" else "rechazada",
            "estadoGeneral" to "completada",
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val respLimpia = respuestaAdmin.trim().take(240)
        if (respLimpia.isNotEmpty()) solUpdates["respuestaAdmin"] = respLimpia

        batch.update(db.collection("solicitudesCambio").document(solicitud.id), solUpdates)
        batch.commit().await()
    }

    // -------------------------------------------------------------------------
    // SOPORTE WHATSAPP (62546546), SINPE, TÉRMINOS Y TIPOS DE VEHÍCULO DINÁMICOS
    // -------------------------------------------------------------------------
    private fun configuracionDefaults(): Map<String, Any> = mapOf(
        "whatsappSoporte" to "62546546",
        "sinpeNumero" to "62546546",
        "adminSinpeTitular" to "Administración Viaje Rural",
        "adminNombre" to "Administrador Viaje Rural",
        "adminTelefono" to "62546546",
        "adminEmail" to "sindicatosiserge@gmail.com",
        "linkDescarga" to DEFAULT_LINK_DESCARGA,
        "terminosCondiciones" to DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR,
        "terminosCondicionesPasajero" to DEFAULT_TERMINOS_CONDICIONES_PASAJERO,
        "montoMensualConductorBase" to DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE.toLong(),
        "anioBaseMensualidad" to DEFAULT_ANIO_BASE_MENSUALIDAD.toLong(),
        "multiplicadorTopeNormal" to DEFAULT_MULTIPLICADOR_TOPE_NORMAL,
        "multiplicadorTopeCarga" to DEFAULT_MULTIPLICADOR_TOPE_CARGA,
        "tiposVehiculo" to listOf(
            mapOf("nombre" to "Moto", "maxPasajeros" to 1L, "descripcion" to "Mandados y 1 pasajero"),
            mapOf("nombre" to "Sedan", "maxPasajeros" to 4L, "descripcion" to "Camino lastreado o asfalto"),
            mapOf("nombre" to "Pickup 4x4", "maxPasajeros" to 5L, "descripcion" to "Barro, pendientes y fincas"),
            mapOf("nombre" to "SUV Rural", "maxPasajeros" to 5L, "descripcion" to "Trocha y grupos familiares"),
            mapOf("nombre" to "Microbus", "maxPasajeros" to 12L, "descripcion" to "Grupos grandes y carga")
        )
    )

    private fun normalizarConfiguracion(defaults: Map<String, Any>, data: Map<String, Any>): Map<String, Any> {
        val merged = (defaults + data).toMutableMap()
        val termPas = (merged["terminosCondicionesPasajero"] as? String)?.trim()
        if (termPas.isNullOrBlank() || termPas.length < 20) {
            merged["terminosCondicionesPasajero"] = DEFAULT_TERMINOS_CONDICIONES_PASAJERO
        }
        val termCond = (merged["terminosCondiciones"] as? String)?.trim()
        if (termCond.isNullOrBlank() || termCond.length < 20) {
            merged["terminosCondiciones"] = DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
        }
        val montoBase = ((merged["montoMensualConductorBase"] as? Number)?.toInt()
            ?: DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE).coerceIn(500, 1_000_000)
        val anioBase = ((merged["anioBaseMensualidad"] as? Number)?.toInt()
            ?: DEFAULT_ANIO_BASE_MENSUALIDAD).coerceIn(2020, 2100)
        val multNormal = ((merged["multiplicadorTopeNormal"] as? Number)?.toDouble()
            ?: DEFAULT_MULTIPLICADOR_TOPE_NORMAL).coerceIn(1.1, 5.0)
        val multCarga = ((merged["multiplicadorTopeCarga"] as? Number)?.toDouble()
            ?: DEFAULT_MULTIPLICADOR_TOPE_CARGA).coerceIn(1.1, 5.0)
        merged["montoMensualConductorBase"] = montoBase.toLong()
        merged["anioBaseMensualidad"] = anioBase.toLong()
        merged["multiplicadorTopeNormal"] = multNormal
        merged["multiplicadorTopeCarga"] = multCarga
        return merged
    }

    suspend fun obtenerViajesCobroExcesivoAdmin(limite: Long = 30L): List<Map<String, Any>> {
        val snap = db.collection("viajes")
            .whereEqualTo("alertaCobroExcesivo", true)
            .limit(limite)
            .get()
            .await()
        return snap.documents
            .sortedByDescending {
                it.getTimestamp("updatedAt")?.toDate()?.time
                    ?: it.getTimestamp("createdAt")?.toDate()?.time
                    ?: 0L
            }
            .map { doc -> doc.data.orEmpty().plus("id" to doc.id) }
    }

    suspend fun obtenerConfiguracionGeneral(): Map<String, Any> {
        val snap = db.collection("configuracion").document("general").get().await()
        val defaults = configuracionDefaults()
        val data = snap.data ?: return defaults
        return normalizarConfiguracion(defaults, data)
    }

    fun observarConfiguracionGeneral(onUpdate: (Map<String, Any>) -> Unit): ListenerRegistration {
        val defaults = configuracionDefaults()
        return db.collection("configuracion").document("general")
            .addSnapshotListener { snap, _ ->
                val data = snap?.data
                if (data == null) {
                    onUpdate(defaults)
                    return@addSnapshotListener
                }
                onUpdate(normalizarConfiguracion(defaults, data))
            }
    }

    suspend fun obtenerLinkDescargaApp(): String {
        return try {
            val snap = db.collection("configuracion").document("general").get().await()
            snap.getString("linkDescarga")?.trim()?.takeIf { it.isNotBlank() } ?: DEFAULT_LINK_DESCARGA
        } catch (_: Exception) {
            DEFAULT_LINK_DESCARGA
        }
    }

    suspend fun guardarConfiguracionGeneralAdmin(
        whatsappSoporte: String,
        sinpeNumero: String,
        sinpeTitular: String,
        adminNombre: String,
        adminTelefono: String,
        adminEmail: String,
        terminosCondiciones: String,
        tiposVehiculo: List<Map<String, Any>>,
        linkDescarga: String = DEFAULT_LINK_DESCARGA,
        terminosCondicionesPasajero: String = DEFAULT_TERMINOS_CONDICIONES_PASAJERO,
        montoMensualConductorBase: Int = DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
        anioBaseMensualidad: Int = DEFAULT_ANIO_BASE_MENSUALIDAD,
        multiplicadorTopeNormal: Double = DEFAULT_MULTIPLICADOR_TOPE_NORMAL,
        multiplicadorTopeCarga: Double = DEFAULT_MULTIPLICADOR_TOPE_CARGA
    ) {
        val enlaceFinal = linkDescarga.trim().ifBlank { DEFAULT_LINK_DESCARGA }.take(500)
        val terminosPasajeroFinal = terminosCondicionesPasajero
            .trim()
            .ifBlank { DEFAULT_TERMINOS_CONDICIONES_PASAJERO }
            .take(8000)
        val terminosCondFinal = terminosCondiciones
            .trim()
            .ifBlank { DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR }
            .take(8000)
        val montoBaseFinal = montoMensualConductorBase.coerceIn(500, 1_000_000).toLong()
        val anioBaseFinal = anioBaseMensualidad.coerceIn(2020, 2100).toLong()
        val multNormalFinal = ((multiplicadorTopeNormal.coerceIn(1.1, 5.0)) * 100.0).roundToInt() / 100.0
        val multCargaFinal = ((multiplicadorTopeCarga.coerceIn(1.1, 5.0)) * 100.0).roundToInt() / 100.0
        db.collection("configuracion").document("general").set(
            mapOf(
                "whatsappSoporte" to whatsappSoporte.trim(),
                "sinpeNumero" to sinpeNumero.trim(),
                "adminSinpeTitular" to sinpeTitular.trim(),
                "adminNombre" to adminNombre.trim(),
                "adminTelefono" to adminTelefono.trim(),
                "adminEmail" to adminEmail.trim(),
                "linkDescarga" to enlaceFinal,
                "terminosCondiciones" to terminosCondFinal,
                "terminosCondicionesPasajero" to terminosPasajeroFinal,
                "montoMensualConductorBase" to montoBaseFinal,
                "anioBaseMensualidad" to anioBaseFinal,
                "multiplicadorTopeNormal" to multNormalFinal,
                "multiplicadorTopeCarga" to multCargaFinal,
                "tiposVehiculo" to tiposVehiculo,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun obtenerDocumentosConductorAdmin(conductorId: String): Map<String, Any>? {
        val snap = db.collection("usuarios").document(conductorId)
            .collection("private").document("documentos").get().await()
        return snap.data
    }

    fun queryMensajesChat(viajeId: String): Query {
        return db.collection("chats")
            .document(viajeId)
            .collection("mensajes")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limit(30)
    }

    fun observarMensajesChat(
        viajeId: String,
        onUpdate: (List<Map<String, Any>>) -> Unit
    ): ListenerRegistration {
        return queryMensajesChat(viajeId).addSnapshotListener { snap, _ ->
            val lista = snap?.documents?.map { doc ->
                doc.data.orEmpty().plus("id" to doc.id)
            }.orEmpty()
            onUpdate(lista)
        }
    }

    suspend fun enviarMensajeChat(
        viajeId: String,
        autorUid: String,
        autorRol: String,
        autorNombre: String,
        texto: String
    ) {
        val limpio = texto.trim().take(400)
        if (limpio.isEmpty()) return
        val mensajeId = "msg_${autorUid.take(10)}_${System.currentTimeMillis()}"
        db.collection("chats")
            .document(viajeId)
            .collection("mensajes")
            .document(mensajeId)
            .set(
                mapOf(
                    "viajeId" to viajeId,
                    "autorUid" to autorUid,
                    "autorRol" to autorRol,
                    "autorNombre" to autorNombre.trim().ifBlank { "Usuario" }.take(80),
                    "texto" to limpio,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            .await()
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
