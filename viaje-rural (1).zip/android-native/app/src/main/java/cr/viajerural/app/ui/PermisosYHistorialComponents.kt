package cr.viajerural.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val TIMEZONE_COSTA_RICA: TimeZone = TimeZone.getTimeZone("America/Costa_Rica")
private val LOCALE_CR: Locale = Locale("es", "CR")
private val NOMBRES_MESES_ES = listOf(
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

fun obtenerMesActualCostaRicaKey(): String {
    val cal = Calendar.getInstance(TIMEZONE_COSTA_RICA)
    val year = cal.get(Calendar.YEAR)
    val month = cal.get(Calendar.MONTH) + 1
    return String.format(Locale.US, "%04d-%02d", year, month)
}

fun extraerTimestampViajeMs(viaje: Map<String, Any>): Long? {
    val raw = viaje["updatedAt"] ?: viaje["createdAt"] ?: return null
    return when (raw) {
        is Timestamp -> raw.toDate().time
        is Date -> raw.time
        is Number -> {
            val v = raw.toLong()
            if (v < 100_000_000_000L) v * 1000L else v
        }
        is String -> try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }.parse(raw)?.time
        } catch (_: Throwable) {
            null
        }
        else -> null
    }
}

fun extraerMesKeyCostaRica(viaje: Map<String, Any>): String? {
    val ms = extraerTimestampViajeMs(viaje) ?: return null
    val cal = Calendar.getInstance(TIMEZONE_COSTA_RICA).apply { timeInMillis = ms }
    val year = cal.get(Calendar.YEAR)
    val month = cal.get(Calendar.MONTH) + 1
    return String.format(Locale.US, "%04d-%02d", year, month)
}

fun parsearMesKey(mesKey: String): Pair<Int, Int> {
    val partes = mesKey.split("-")
    val year = partes.getOrNull(0)?.toIntOrNull()
    val month = partes.getOrNull(1)?.toIntOrNull()
    if (year != null && month != null && month in 1..12) {
        return Pair(year, month)
    }
    val cal = Calendar.getInstance(TIMEZONE_COSTA_RICA)
    return Pair(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1)
}

fun formatearMesKeyLabel(mesKey: String): String {
    val (year, month) = parsearMesKey(mesKey)
    val nombre = NOMBRES_MESES_ES.getOrElse(month - 1) { "Mes" }
    return "$nombre $year"
}

fun desplazarMesKey(mesKey: String, deltaMeses: Int): String {
    val (year, month) = parsearMesKey(mesKey)
    val cal = Calendar.getInstance(TIMEZONE_COSTA_RICA).apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month - 1)
        set(Calendar.DAY_OF_MONTH, 15)
        add(Calendar.MONTH, deltaMeses)
    }
    return String.format(Locale.US, "%04d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1)
}

fun filtrarViajesPorMesCostaRica(
    viajes: List<Map<String, Any>>,
    mesKey: String
): List<Map<String, Any>> {
    return viajes.filter { extraerMesKeyCostaRica(it) == mesKey }
}

fun formatearFechaHoraCostaRica(viaje: Map<String, Any>): String {
    val ms = extraerTimestampViajeMs(viaje) ?: return "Reciente"
    val fmt = SimpleDateFormat("dd/MM/yyyy hh:mm a", LOCALE_CR).apply {
        timeZone = TIMEZONE_COSTA_RICA
    }
    return fmt.format(Date(ms))
}

@Composable
fun SelectorMesHistorialCard(
    viajes: List<Map<String, Any>>,
    viajesFiltrados: List<Map<String, Any>>,
    mesSeleccionado: String,
    onSelectMes: (String) -> Unit,
    etiquetaTotal: String = "Total del mes"
) {
    val mesActualKey = remember { obtenerMesActualCostaRicaKey() }
    var menuAbierto by remember { mutableStateOf(false) }

    val opcionesMeses = remember(viajes, mesSeleccionado, mesActualKey) {
        val set = linkedSetOf<String>()
        set.add(mesActualKey)
        set.add(mesSeleccionado)
        viajes.forEach { v ->
            extraerMesKeyCostaRica(v)?.let { set.add(it) }
        }
        set.sortedDescending()
    }

    val resumen = remember(viajesFiltrados) {
        var completados = 0
        var totalColones = 0
        viajesFiltrados.forEach { v ->
            if ((v["estado"] as? String) == "finalizado") {
                completados += 1
                totalColones += (v["montoAproximado"] as? Number)?.toInt() ?: 0
            }
        }
        Triple(viajesFiltrados.size, completados, totalColones)
    }

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Mes (Hora Costa Rica)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF14231A)
                )
                if (mesSeleccionado != mesActualKey) {
                    TextButton(
                        onClick = { onSelectMes(mesActualKey) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ir a mes actual",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedIconButton(
                    onClick = { onSelectMes(desplazarMesKey(mesSeleccionado, -1)) },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = "Mes anterior"
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { menuAbierto = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                    ) {
                        Text(
                            text = formatearMesKeyLabel(mesSeleccionado),
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF14231A),
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Seleccionar mes"
                        )
                    }
                    DropdownMenu(
                        expanded = menuAbierto,
                        onDismissRequest = { menuAbierto = false }
                    ) {
                        opcionesMeses.forEach { key ->
                            val sufijo = if (key == mesActualKey) " (Actual)" else ""
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${formatearMesKeyLabel(key)}$sufijo",
                                        fontWeight = if (key == mesSeleccionado) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSelectMes(key)
                                    menuAbierto = false
                                }
                            )
                        }
                    }
                }

                OutlinedIconButton(
                    onClick = { onSelectMes(desplazarMesKey(mesSeleccionado, 1)) },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Mes siguiente"
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFFF7F8F6), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Column {
                        Text(
                            text = "Viajes",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF525B50)
                        )
                        Text(
                            text = "${resumen.first}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14231A)
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFFF7F8F6), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Column {
                        Text(
                            text = "Completados",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF525B50)
                        )
                        Text(
                            text = "${resumen.second}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14231A)
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .background(Color(0xFFF0FDF4), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Column {
                        Text(
                            text = etiquetaTotal,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF166534)
                        )
                        Text(
                            text = "₡${resumen.third}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }
        }
    }
}

private data class EstadoPermisosSistema(
    val permisoUbicacionFina: Boolean,
    val gpsAltaPrecisionActivo: Boolean,
    val permisoUbicacionSegundoPlano: Boolean,
    val notificacionesActivas: Boolean,
    val optimizacionBateriaDesactivada: Boolean,
    val redDisponible: Boolean,
    val sesionFirebaseActiva: Boolean
)

private fun consultarEstadoPermisosSistema(context: Context): EstadoPermisosSistema {
    val fina = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    val gpsOn = try {
        lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true
    } catch (_: Throwable) {
        false
    }

    val segundoPlano = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }

    val notifPermOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
    val notifHabilitadas = notifPermOk && NotificationManagerCompat.from(context).areNotificationsEnabled()

    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val ignoraBateria = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        pm?.isIgnoringBatteryOptimizations(context.packageName) == true
    } else {
        true
    }

    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val redOk = try {
        val net = cm?.activeNetwork
        val caps = if (net != null) cm.getNetworkCapabilities(net) else null
        caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Throwable) {
        false
    }

    val authOk = try {
        FirebaseAuth.getInstance().currentUser != null
    } catch (_: Throwable) {
        false
    }

    return EstadoPermisosSistema(
        permisoUbicacionFina = fina,
        gpsAltaPrecisionActivo = gpsOn,
        permisoUbicacionSegundoPlano = segundoPlano,
        notificacionesActivas = notifHabilitadas,
        optimizacionBateriaDesactivada = ignoraBateria,
        redDisponible = redOk,
        sesionFirebaseActiva = authOk
    )
}

@Composable
fun PanelPermisosConfiguracionCard(
    rol: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    @Suppress("DEPRECATION")
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current

    var estado by remember { mutableStateOf(consultarEstadoPermisosSistema(context)) }
    var syncEstadoTexto by remember {
        mutableStateOf(
            if (estado.redDisponible) "Conectado a red · Toca Verificar para probar servidor"
            else "Sin conexión a internet detectada"
        )
    }
    var syncOk by remember { mutableStateOf(estado.redDisponible && estado.sesionFirebaseActiva) }
    var verificandoSync by remember { mutableStateOf(false) }

    fun refrescar() {
        estado = consultarEstadoPermisosSistema(context)
        if (!estado.redDisponible) {
            syncOk = false
            syncEstadoTexto = "Sin conexión a internet en este dispositivo."
        }
    }

    fun comprobarSincronizacionServidor() {
        scope.launch {
            verificandoSync = true
            refrescar()
            if (!estado.redDisponible) {
                syncOk = false
                syncEstadoTexto = "Sin conexión a internet en este dispositivo."
                verificandoSync = false
                return@launch
            }
            val inicio = System.currentTimeMillis()
            try {
                FirebaseFirestore.getInstance()
                    .collection("configuracion")
                    .document("general")
                    .get(Source.SERVER)
                    .await()
                val ms = (System.currentTimeMillis() - inicio).coerceAtLeast(1L)
                syncOk = true
                syncEstadoTexto = if (estado.sesionFirebaseActiva) {
                    "Sincronizado con el servidor ($ms ms)"
                } else {
                    "Servidor accesible ($ms ms) · Sesión pendiente"
                }
            } catch (_: Throwable) {
                syncOk = false
                syncEstadoTexto = "No se pudo confirmar respuesta del servidor Firebase."
            } finally {
                verificandoSync = false
            }
        }
    }

    val launcherUbicacion = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refrescar()
    }

    val launcherNotificaciones = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        refrescar()
        if (!granted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            abrirAjustesNotificacionesApp(context)
        }
    }

    val launcherBackgroundUbicacion = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        refrescar()
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refrescar()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        comprobarSincronizacionServidor()
    }

    val versionApp = remember {
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            info.versionName ?: "1.0"
        } catch (_: Throwable) {
            "1.0"
        }
    }

    OutlinedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E6DF)),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = Color(0xFF15803D)
                    )
                    Column {
                        Text(
                            text = "Permisos y Configuración",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14231A)
                        )
                        Text(
                            text = "Estado en tiempo real (${if (rol == "conductor") "Conductor" else "Pasajero"})",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF525B50)
                        )
                    }
                }
                IconButton(onClick = {
                    refrescar()
                    comprobarSincronizacionServidor()
                }) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Actualizar permisos",
                        tint = Color(0xFF15803D)
                    )
                }
            }

            // 1. Ubicación GPS
            val ubicacionCompletaOk = estado.permisoUbicacionFina && estado.gpsAltaPrecisionActivo
            FilaPermisoSistema(
                icono = Icons.Default.LocationOn,
                titulo = "Ubicación GPS",
                activo = ubicacionCompletaOk,
                estadoEtiqueta = when {
                    ubicacionCompletaOk -> "Concedido · Alta precisión activa"
                    estado.permisoUbicacionFina && !estado.gpsAltaPrecisionActivo -> "GPS del teléfono apagado"
                    else -> "Pendiente / Denegado"
                },
                descripcion = if (rol == "conductor" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    if (estado.permisoUbicacionSegundoPlano) {
                        "Ubicación en segundo plano ('Todo el tiempo') concedida."
                    } else {
                        "Recomendado activar 'Permitir todo el tiempo' para usar Waze sin cortes."
                    }
                } else {
                    "Necesaria para ubicarte con precisión y calcular rutas."
                },
                textoBoton = when {
                    !estado.permisoUbicacionFina -> "Conceder"
                    !estado.gpsAltaPrecisionActivo -> "Activar GPS"
                    rol == "conductor" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !estado.permisoUbicacionSegundoPlano -> "Todo el tiempo"
                    else -> "Ajustes GPS"
                },
                onAccion = {
                    when {
                        !estado.permisoUbicacionFina -> {
                            launcherUbicacion.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                        !estado.gpsAltaPrecisionActivo -> abrirAjustesUbicacionSistema(context)
                        rol == "conductor" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !estado.permisoUbicacionSegundoPlano -> {
                            try {
                                launcherBackgroundUbicacion.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                            } catch (_: Throwable) {
                                abrirAjustesDetalleApp(context)
                            }
                        }
                        else -> abrirAjustesUbicacionSistema(context)
                    }
                }
            )

            // 2. Notificaciones Push
            FilaPermisoSistema(
                icono = Icons.Default.Notifications,
                titulo = "Notificaciones Push",
                activo = estado.notificacionesActivas,
                estadoEtiqueta = if (estado.notificacionesActivas) "Activo / Concedido" else "Pendiente / Desactivado",
                descripcion = if (rol == "conductor") {
                    "Alertas prioritarias de ofertas 15s, chats y avisos incluso con pantalla apagada."
                } else {
                    "Avisos cuando tu conductor acepte, llegue al punto o envíe mensajes."
                },
                textoBoton = if (estado.notificacionesActivas) "Ajustes" else "Activar",
                onAccion = {
                    if (!estado.notificacionesActivas && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        abrirAjustesNotificacionesApp(context)
                    }
                }
            )

            // 3. Ejecución en segundo plano / Optimización de batería
            FilaPermisoSistema(
                icono = Icons.Default.BatteryChargingFull,
                titulo = "Segundo plano y batería",
                activo = estado.optimizacionBateriaDesactivada,
                estadoEtiqueta = if (estado.optimizacionBateriaDesactivada) "Sin restricciones" else "Ahorro de batería activo",
                descripcion = if (rol == "conductor") {
                    "Evita que Android cierre tu estado Activo o el GPS al usar Waze o minimizar."
                } else {
                    "Mantiene la espera del viaje activa sin interrupciones por ahorro energético."
                },
                textoBoton = if (estado.optimizacionBateriaDesactivada) "Configurado" else "Permitir",
                onAccion = { abrirAjustesSinRestriccionBateria(context) }
            )

            // 4. Estado de conexión y sincronización
            FilaPermisoSistema(
                icono = Icons.Default.Wifi,
                titulo = "Conexión y sincronización",
                activo = estado.redDisponible && syncOk,
                estadoEtiqueta = if (estado.redDisponible && syncOk) "En línea y sincronizado" else "Pendiente / Sin conexión",
                descripcion = syncEstadoTexto,
                textoBoton = if (verificandoSync) "Probando..." else "Verificar",
                botonHabilitado = !verificandoSync,
                onAccion = { comprobarSincronizacionServidor() }
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF7F8F6), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Zona: America/Costa_Rica · v$versionApp",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF525B50)
                )
                TextButton(
                    onClick = { abrirAjustesDetalleApp(context) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Ajustes de la App",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                }
            }
        }
    }
}

@Composable
private fun FilaPermisoSistema(
    icono: ImageVector,
    titulo: String,
    activo: Boolean,
    estadoEtiqueta: String,
    descripcion: String,
    textoBoton: String,
    botonHabilitado: Boolean = true,
    onAccion: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF7F8F6), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icono,
                    contentDescription = null,
                    tint = if (activo) Color(0xFF15803D) else Color(0xFFB45309),
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(
                        text = titulo,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14231A)
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (activo) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (activo) Color(0xFF15803D) else Color(0xFFB45309),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = estadoEtiqueta,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (activo) Color(0xFF15803D) else Color(0xFFB45309)
                        )
                    }
                }
            }

            if (activo) {
                OutlinedButton(
                    onClick = onAccion,
                    enabled = botonHabilitado,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = textoBoton,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                Button(
                    onClick = onAccion,
                    enabled = botonHabilitado,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = textoBoton,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Text(
            text = descripcion,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF525B50)
        )
    }
}

@Composable
fun ModalPermisosConfiguracion(
    rol: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFFF7F8F6)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PanelPermisosConfiguracionCard(rol = rol)
                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cerrar", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

fun abrirAjustesUbicacionSistema(context: Context) {
    try {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Throwable) {
        abrirAjustesDetalleApp(context)
    }
}

fun abrirAjustesNotificacionesApp(context: Context) {
    try {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null)
            ).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }
        context.startActivity(intent)
    } catch (_: Throwable) {
        abrirAjustesDetalleApp(context)
    }
}

fun abrirAjustesSinRestriccionBateria(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        try {
            val intent = Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${context.packageName}")
            ).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            return
        } catch (_: Throwable) {
        }
        try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            return
        } catch (_: Throwable) {
        }
    }
    abrirAjustesDetalleApp(context)
}

fun abrirAjustesDetalleApp(context: Context) {
    try {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Throwable) {
    }
}

@Composable
fun ModalTerminosPasajeroDialog(
    terminosPasajero: String,
    onDismiss: () -> Unit
) {
    val textoMostrar = terminosPasajero
        .trim()
        .ifBlank { cr.viajerural.app.data.ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Términos y Condiciones del Pasajero",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF0FDF4),
                    border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "0% cobro de app o servicio adicional",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14532D)
                        )
                        Text(
                            text = "Para el pasajero no se incluye ningún tipo de cobro por uso de la aplicación, comisiones ni cargos extra. Pagas únicamente la tarifa directa en efectivo al conductor.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF166534)
                        )
                    }
                }
                Text(
                    text = textoMostrar,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF333D32)
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Entendido")
            }
        }
    )
}

