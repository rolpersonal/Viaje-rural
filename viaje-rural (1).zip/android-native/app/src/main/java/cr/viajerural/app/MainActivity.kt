package cr.viajerural.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import cr.viajerural.app.ui.AdminScreen
import cr.viajerural.app.ui.AuthScreen
import cr.viajerural.app.ui.ConductorScreen
import cr.viajerural.app.ui.PasajeroScreen
import cr.viajerural.app.viewmodel.AdminViewModel
import cr.viajerural.app.viewmodel.AuthViewModel
import cr.viajerural.app.viewmodel.ConductorViewModel
import cr.viajerural.app.viewmodel.PasajeroViewModel

/**
 * MainActivity de Viaje Rural (Android 13/14+ compatible):
 * 1. Inicialización segura de Firebase con try-catch y pantalla de error legible si falla.
 * 2. Solicitud "suave" de permisos en Compose con ActivityResultLauncher:
 *    - ACCESS_FINE_LOCATION + ACCESS_COARSE_LOCATION (sin pedir ACCESS_BACKGROUND_LOCATION de golpe)
 *    - POST_NOTIFICATIONS solo en Android 13+ (API 33+)
 * 3. Navegación segura hacia Auth, Pasajero, Conductor o Administrador.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ViajeRuralEntryScreen()
                }
            }
        }
    }
}

@Composable
private fun ViajeRuralEntryScreen() {
    val context = LocalContext.current

    // 1. Inicialización segura de Firebase con try-catch
    var firebaseError by remember { mutableStateOf(ViajeRuralApp.firebaseInitError) }
    var firebaseListo by remember { mutableStateOf(false) }

    fun verificarFirebase() {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val app = FirebaseApp.initializeApp(context)
                if (app == null) {
                    firebaseError = "FirebaseApp devolvió null. Revisa que google-services.json corresponda al paquete cr.viajerural.app."
                    firebaseListo = false
                    return
                }
            }
            // Prueba rápida de acceso a FirebaseAuth dentro del try-catch
            FirebaseAuth.getInstance()
            firebaseError = null
            firebaseListo = true
        } catch (t: Throwable) {
            firebaseError = t.localizedMessage ?: "Error al iniciar los servicios de Firebase."
            firebaseListo = false
        }
    }

    LaunchedEffect(Unit) {
        verificarFirebase()
    }

    // 2. Solicitud "suave" de permisos usando ActivityResultLauncher en Compose
    val permisosRequeridos = remember {
        buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
    }

    var permisosConcedidos by remember {
        mutableStateOf(
            permisosRequeridos.all { perm ->
                ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var solicitudInicialRealizada by remember { mutableStateOf(false) }
    var mostrarAvisoPermisos by remember { mutableStateOf(false) }

    val launcherPermisos = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { resultados ->
        val ubicacionOk =
            resultados[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                resultados[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
        permisosConcedidos = resultados.values.all { it }
        mostrarAvisoPermisos = !ubicacionOk
    }

    // Lanzar solicitud suave una sola vez tras pintar la primera pantalla (no bloquea el arranque)
    LaunchedEffect(firebaseListo) {
        if (firebaseListo && !solicitudInicialRealizada && !permisosConcedidos) {
            solicitudInicialRealizada = true
            launcherPermisos.launch(permisosRequeridos)
        }
    }

    if (firebaseError != null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "No se pudo conectar con Firebase",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = firebaseError.orEmpty(),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = { verificarFirebase() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reintentar conexión")
                    }
                }
            }
        }
        return
    }

    if (!firebaseListo) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (mostrarAvisoPermisos) {
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Activa Ubicación y Notificaciones para recibir ofertas y calcular tu ruta.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { launcherPermisos.launch(permisosRequeridos) }) {
                        Text("Activar")
                    }
                }
            }
        }

        ViajeRuralAppContent(
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ViajeRuralAppContent(modifier: Modifier = Modifier) {
    val authViewModel: AuthViewModel = viewModel()
    val pasajeroViewModel: PasajeroViewModel = viewModel()
    val conductorViewModel: ConductorViewModel = viewModel()
    val adminViewModel: AdminViewModel = viewModel()

    var uidActual by remember {
        mutableStateOf(
            try {
                FirebaseAuth.getInstance().currentUser?.uid
            } catch (_: Throwable) {
                null
            }
        )
    }
    var emailActual by remember {
        mutableStateOf(
            try {
                FirebaseAuth.getInstance().currentUser?.email.orEmpty()
            } catch (_: Throwable) {
                ""
            }
        )
    }
    var esConductor by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        if (uidActual == null) {
            AuthScreen(
                viewModel = authViewModel,
                onAuthenticated = { uid, conductorRole ->
                    uidActual = uid
                    emailActual = try {
                        FirebaseAuth.getInstance().currentUser?.email.orEmpty()
                    } catch (_: Throwable) {
                        ""
                    }
                    esConductor = conductorRole
                }
            )
        } else if (emailActual.equals("sindicatosiserge@gmail.com", ignoreCase = true)) {
            AdminScreen(viewModel = adminViewModel)
        } else if (esConductor) {
            val condState by conductorViewModel.uiState.collectAsState()
            val uid = uidActual!!
            LaunchedEffect(uid) {
                conductorViewModel.restaurarEstadoYFinanzas(uid)
            }
            val viaje = condState.viajeActivo
            ConductorScreen(
                tabActual = condState.tabActual,
                onSelectTab = { conductorViewModel.seleccionarTab(it, uid) },
                conductorId = uid,
                viajeActivoId = viaje?.get("id") as? String,
                estadoViaje = viaje?.get("estado") as? String,
                pasajeroNombre = viaje?.get("pasajeroNombre") as? String,
                cantidadPasajeros = (viaje?.get("cantidadPasajeros") as? Number)?.toInt() ?: 1,
                resenaUbicacion = viaje?.get("resenaUbicacion") as? String,
                origenLat = (viaje?.get("origenLat") as? Number)?.toDouble(),
                origenLng = (viaje?.get("origenLng") as? Number)?.toDouble(),
                destinoLat = (viaje?.get("destinoLat") as? Number)?.toDouble(),
                destinoLng = (viaje?.get("destinoLng") as? Number)?.toDouble(),
                segundosOfertaRestantes = null,
                gananciasHoy = condState.finanzas.gananciasHoy,
                gananciasMes = condState.finanzas.gananciasMes,
                historial = condState.historial,
                cargandoHistorial = condState.cargandoHistorial,
                mostrarModalCobro = condState.mostrarModalCobro,
                montoACobrar = condState.montoACobrar,
                onAceptarOferta = {},
                onRechazarOferta = {},
                onVerificarPin = {},
                onFinalizarViaje = {
                    val vId = viaje?.get("id") as? String ?: return@ConductorScreen
                    val pId = viaje["pasajeroId"] as? String ?: return@ConductorScreen
                    val monto = (viaje["montoAproximado"] as? Number)?.toDouble() ?: 0.0
                    conductorViewModel.finalizarViaje(vId, uid, pId, monto)
                },
                onCalificarPasajero = { estrellas, comentario ->
                    conductorViewModel.calificarPasajero(uid, estrellas, comentario)
                },
                onDismissModalCobro = { conductorViewModel.cerrarModalCobro() },
                licenciaRestante = condState.licenciaRestante,
                nombreConductor = condState.nombreConductor,
                placa = condState.placa,
                vehiculoTipo = condState.vehiculoTipo,
                tarifaBase = condState.tarifaBase,
                tarifaPorKm = condState.tarifaPorKm,
                misSolicitudes = condState.misSolicitudes,
                onEnviarSolicitudCambio = { cambios, motivo ->
                    conductorViewModel.enviarSolicitudCambioConductor(uid, cambios, motivo)
                },
                onCancelarViaje = { motivo ->
                    val vId = viaje?.get("id") as? String ?: return@ConductorScreen
                    conductorViewModel.cancelarViajeActivo(vId, uid, motivo)
                },
                avisoCancelacionFlotante = condState.avisoCancelacionFlotante,
                onDismissAvisoCancelacion = { conductorViewModel.limpiarAvisoCancelacionFlotante() }
            )
        } else {
            val pasState by pasajeroViewModel.uiState.collectAsState()
            val uid = uidActual!!
            LaunchedEffect(uid) {
                pasajeroViewModel.restaurarViajeActivo(uid)
            }
            val viaje = pasState.viajeActivo
            PasajeroScreen(
                tabActual = pasState.tabActual,
                onSelectTab = { pasajeroViewModel.seleccionarTab(it, uid) },
                estadoViaje = viaje?.get("estado") as? String ?: "idle",
                pinPersistente = pasState.pinPersistente,
                conductorNombre = viaje?.get("conductorNombre") as? String,
                conductorPlaca = viaje?.get("conductorPlaca") as? String,
                etaMinutos = (viaje?.get("etaMinutos") as? Number)?.toInt(),
                montoAproximado = (viaje?.get("montoAproximado") as? Number)?.toInt() ?: 0,
                rutasFavoritas = pasState.rutasFavoritas,
                sugerenciasOrigen = pasState.sugerenciasOrigen,
                sugerenciasDestino = pasState.sugerenciasDestino,
                historial = pasState.historial,
                cargandoHistorial = pasState.cargandoHistorial,
                mostrarModalPago = pasState.mostrarModalPago,
                onBuscarOrigen = { pasajeroViewModel.buscarSugerenciasOrigen(it) },
                onBuscarDestino = { pasajeroViewModel.buscarSugerenciasDestino(it) },
                onGuardarFavorita = { pasajeroViewModel.guardarRutaFavorita(uid, it) },
                onEliminarFavorita = { pasajeroViewModel.eliminarRutaFavorita(uid, it) },
                onSolicitarViaje = { _, _, _, _ -> },
                onCalificarConductor = { estrellas, comentario ->
                    pasajeroViewModel.calificarConductor(uid, estrellas, comentario)
                },
                onDismissModalPago = { pasajeroViewModel.cerrarModalPago() },
                nombrePasajero = pasState.nombrePasajero,
                misSolicitudes = pasState.misSolicitudes,
                onEnviarSolicitudCambio = { cambios, motivo ->
                    pasajeroViewModel.enviarSolicitudCambioPasajero(
                        uid,
                        pasState.nombrePasajero,
                        cambios,
                        motivo
                    )
                },
                avisoCancelacion = pasState.avisoCancelacion,
                onDismissAvisoCancelacion = { pasajeroViewModel.limpiarAvisoCancelacion() },
                onCancelarViaje = { motivo ->
                    val vId = viaje?.get("id") as? String ?: return@PasajeroScreen
                    pasajeroViewModel.cancelarViajeActivo(vId, motivo)
                },
                precisionUbicacionMetros = pasState.precisionUbicacionMetros
            )
        }
    }
}
