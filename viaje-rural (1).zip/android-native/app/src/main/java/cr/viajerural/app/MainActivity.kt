package cr.viajerural.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import cr.viajerural.app.ui.AdminScreen
import cr.viajerural.app.ui.AuthScreen
import cr.viajerural.app.ui.ConductorScreen
import cr.viajerural.app.ui.PasajeroScreen
import cr.viajerural.app.viewmodel.AdminViewModel
import cr.viajerural.app.viewmodel.AuthViewModel
import cr.viajerural.app.viewmodel.ChatViewModel
import cr.viajerural.app.viewmodel.ConductorTab
import cr.viajerural.app.viewmodel.ConductorViewModel
import cr.viajerural.app.viewmodel.PasajeroViewModel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * MainActivity de Viaje Rural (Android 11-14+ compatible):
 * 1. Inicialización segura de Firebase con try-catch y pantalla de error legible si falla.
 * 2. Solicitud secuencial y segura de permisos en Compose con rememberLauncherForActivityResult:
 *    - Primero ubicación en primer plano (ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION).
 *    - En Android 13+, POST_NOTIFICATIONS después (nunca mezclar ACCESS_BACKGROUND_LOCATION aquí).
 *    - El flujo completo de Conductor (Notificaciones + Segundo Plano "Permitir todo el tiempo" + ForegroundService location)
 *      se gestiona al abrir ConductorScreen y al activar el interruptor "Activo".
 * 3. Navegación segura hacia Auth, Pasajero, Conductor o Administrador.
 */
private val ViajeRuralColorScheme = lightColorScheme(
    primary = Color(0xFF15803D),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCFCE7),
    onPrimaryContainer = Color(0xFF14532D),
    secondary = Color(0xFF1E3A2F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8ECE5),
    onSecondaryContainer = Color(0xFF14231A),
    tertiary = Color(0xFFB45309),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFEF3C7),
    onTertiaryContainer = Color(0xFF78350F),
    background = Color(0xFFF7F8F6),
    onBackground = Color(0xFF14231A),
    surface = Color.White,
    onSurface = Color(0xFF14231A),
    surfaceVariant = Color(0xFFF1F4EE),
    onSurfaceVariant = Color(0xFF525B50),
    outline = Color(0xFFE2E6DF),
    error = Color(0xFFDC2626),
    onError = Color.White,
    errorContainer = Color(0xFFFEF2F2),
    onErrorContainer = Color(0xFF991B1B)
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        setContent {
            MaterialTheme(colorScheme = ViajeRuralColorScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ViajeRuralEntryScreen()
                }
            }
        }
    }

    override fun onDestroy() {
        val uidCerrar = conductorActivoUidParaCierre ?: ViajeRuralApp.conductorActivoEnProcesoUid
        if (isFinishing && !isChangingConfigurations && !uidCerrar.isNullOrBlank()) {
            ViajeRuralApp.conductorActivoEnProcesoUid = null
            onLimpiarCicloGpsConductor?.invoke()
            cr.viajerural.app.service.ConductorOnlineService.stop(this)
            cr.viajerural.app.data.ViajeRepository().desactivarConductorPorCierreSinBloquear(uidCerrar)
        }
        super.onDestroy()
    }

    companion object {
        @Volatile
        var conductorActivoUidParaCierre: String? = null

        @Volatile
        var onLimpiarCicloGpsConductor: (() -> Unit)? = null
    }
}

@Composable
private fun ViajeRuralEntryScreen() {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current

    // 1. Inicialización segura de Firebase con try-catch
    var firebaseError by remember { mutableStateOf(ViajeRuralApp.firebaseInitError) }
    var firebaseListo by remember { mutableStateOf(false) }

    fun verificarFirebase() {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val app = FirebaseApp.initializeApp(context)
                if (app == null) {
                    firebaseError = "FirebaseApp devolvió null. Revisa que google-services.json corresponda al paquete cr.viajerural.app."
                    firebaseListo = false
                    return
                }
            }
            // Prueba rápida de acceso a FirebaseAuth dentro del try-catch
            FirebaseAuth.getInstance()
            firebaseError = null
            firebaseListo = true
        } catch (t: Throwable) {
            firebaseError = t.localizedMessage ?: "Error al iniciar los servicios de Firebase."
            firebaseListo = false
        }
    }

    LaunchedEffect(Unit) {
        verificarFirebase()
    }

    // 2. Solicitud "suave" y secuencial de permisos iniciales (NUNCA incluir ACCESS_BACKGROUND_LOCATION aquí)
    fun tieneUbicacionPrimerPlano(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
    }

    fun tieneNotificaciones(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    var solicitudInicialRealizada by remember { mutableStateOf(false) }
    var pendienteUbicacionInicial by remember { mutableStateOf(false) }
    var mostrarAvisoPermisos by remember { mutableStateOf(!tieneUbicacionPrimerPlano()) }

    val launcherNotificaciones = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        mostrarAvisoPermisos = !tieneUbicacionPrimerPlano()
        if (!tieneUbicacionPrimerPlano()) {
            pendienteUbicacionInicial = true
        }
    }

    val launcherUbicacionPrimerPlano = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val ubicacionOk = tieneUbicacionPrimerPlano()
        mostrarAvisoPermisos = !ubicacionOk
        if (ubicacionOk && !tieneNotificaciones() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
            } catch (_: Throwable) {
            }
        }
    }

    LaunchedEffect(pendienteUbicacionInicial) {
        if (pendienteUbicacionInicial && !tieneUbicacionPrimerPlano()) {
            pendienteUbicacionInicial = false
            kotlinx.coroutines.delay(150)
            try {
                launcherUbicacionPrimerPlano.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            } catch (_: Throwable) {
                mostrarAvisoPermisos = !tieneUbicacionPrimerPlano()
            }
        }
    }

    // Actualizar banner automáticamente al regresar de Ajustes
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                mostrarAvisoPermisos = !tieneUbicacionPrimerPlano()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Lanzar solicitud al iniciar: POST_NOTIFICATIONS primero (Android 13+) y luego ubicación en primer plano
    LaunchedEffect(firebaseListo) {
        if (firebaseListo && !solicitudInicialRealizada) {
            solicitudInicialRealizada = true
            kotlinx.coroutines.delay(250)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !tieneNotificaciones()) {
                    launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else if (!tieneUbicacionPrimerPlano()) {
                    launcherUbicacionPrimerPlano.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            } catch (_: Throwable) {
                mostrarAvisoPermisos = !tieneUbicacionPrimerPlano()
            }
        }
    }

    if (firebaseError != null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "No se pudo conectar con Firebase",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = firebaseError.orEmpty(),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = { verificarFirebase() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reintentar conexión")
                    }
                }
            }
        }
        return
    }

    if (!firebaseListo) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .consumeWindowInsets(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .consumeWindowInsets(WindowInsets.navigationBars)
    ) {
        if (mostrarAvisoPermisos) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Activa Ubicación y Notificaciones para recibir ofertas y calcular tu ruta.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        try {
                            launcherUbicacionPrimerPlano.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        } catch (_: Throwable) {
                        }
                    }) {
                        Text("Activar", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        ViajeRuralAppContent(
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ViajeRuralAppContent(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    val auth = remember { FirebaseAuth.getInstance() }
    val repo = remember { cr.viajerural.app.data.ViajeRepository() }
    val authViewModel: AuthViewModel = viewModel()
    val chatViewModel: ChatViewModel = viewModel()
    val coroutineScope = rememberCoroutineScope()
    var conductorViewModelRef by remember { mutableStateOf<ConductorViewModel?>(null) }
    var appEnPrimerPlano by remember { mutableStateOf(true) }

    val usuarioInicial = remember {
        try {
            auth.currentUser
        } catch (_: Throwable) {
            null
        }
    }

    var uidActual by remember { mutableStateOf(usuarioInicial?.uid) }
    var esConductor by remember { mutableStateOf(false) }
    var esAdminVerificado by remember { mutableStateOf(false) }
    var rolResuelto by remember { mutableStateOf(usuarioInicial == null) }
    var linkDescarga by remember { mutableStateOf(cr.viajerural.app.data.ViajeRepository.DEFAULT_LINK_DESCARGA) }

    // Sincronizar sesión persistida con FirebaseAuth.AuthStateListener y estado primer/segundo plano
    DisposableEffect(auth, lifecycleOwner) {
        val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = try {
                firebaseAuth.currentUser
            } catch (_: Throwable) {
                null
            }
            val nuevoUid = user?.uid
            if (nuevoUid == null) {
                uidActual = null
                esConductor = false
                esAdminVerificado = false
                rolResuelto = true
            } else if (nuevoUid != uidActual) {
                rolResuelto = false
                uidActual = nuevoUid
            }
        }
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    appEnPrimerPlano = true
                    chatViewModel.setAppEnPrimerPlano(true)
                }
                Lifecycle.Event.ON_STOP -> {
                    appEnPrimerPlano = false
                    chatViewModel.setAppEnPrimerPlano(false)
                }
                Lifecycle.Event.ON_RESUME -> {
                    appEnPrimerPlano = true
                    chatViewModel.setAppEnPrimerPlano(true)
                    val user = try {
                        auth.currentUser
                    } catch (_: Throwable) {
                        null
                    }
                    val nuevoUid = user?.uid
                    if (nuevoUid != null && nuevoUid != uidActual) {
                        rolResuelto = false
                        uidActual = nuevoUid
                    }
                }
                else -> {}
            }
        }
        auth.addAuthStateListener(authListener)
        lifecycleOwner.lifecycle.addObserver(lifecycleObserver)
        onDispose {
            auth.removeAuthStateListener(authListener)
            lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
        }
    }

    // Autologin para los 3 roles (Admin, Conductor o Pasajero) al iniciar o al recrear la app por el sistema
    LaunchedEffect(uidActual, rolResuelto) {
        val uid = uidActual
        if (uid == null) {
            rolResuelto = true
            return@LaunchedEffect
        }
        if (!rolResuelto) {
            try {
                // Validar que la cuenta siga habilitada sin cerrar sesión si el teléfono está temporalmente offline
                auth.currentUser?.getIdToken(false)
            } catch (invalid: com.google.firebase.auth.FirebaseAuthInvalidUserException) {
                repo.cerrarSesion(context)
                authViewModel.limpiarEstadoAuth(context)
                uidActual = null
                esConductor = false
                esAdminVerificado = false
                rolResuelto = true
                return@LaunchedEffect
            } catch (_: Throwable) {
            }

            val rol = try {
                repo.resolverRolUsuarioAutologin(context, uid)
            } catch (_: Throwable) {
                repo.obtenerRolLocal(context, uid) ?: "pasajero"
            }
            esAdminVerificado = rol == "admin"
            esConductor = rol == "conductor"
            if (esConductor) {
                cr.viajerural.app.worker.MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
            }
            rolResuelto = true
        }
        linkDescarga = try {
            repo.obtenerLinkDescargaApp()
        } catch (_: Throwable) {
            cr.viajerural.app.data.ViajeRepository.DEFAULT_LINK_DESCARGA
        }
    }

    val cerrarSesion: () -> Unit = {
        cr.viajerural.app.service.PickupLocationService.stop(context)
        cr.viajerural.app.service.ConductorOnlineService.stop(context)
        ViajeRuralApp.conductorActivoEnProcesoUid = null
        val uidCerrar = if (esConductor) uidActual else null
        MainActivity.conductorActivoUidParaCierre = null
        MainActivity.onLimpiarCicloGpsConductor = null
        chatViewModel.sincronizarViajeChat(context, null, null)
        coroutineScope.launch {
            if (!uidCerrar.isNullOrBlank()) {
                val vm = conductorViewModelRef
                if (vm != null) {
                    vm.desactivarConductorAlCerrarSesion(uidCerrar)
                } else {
                    try {
                        repo.actualizarDisponibilidadConductor(
                            conductorId = uidCerrar,
                            disponible = false
                        )
                    } catch (_: Throwable) {
                    }
                }
            }
            repo.cerrarSesion(context)
            authViewModel.limpiarEstadoAuth(context)
            uidActual = null
            esConductor = false
            esAdminVerificado = false
            rolResuelto = true
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (uidActual != null && !rolResuelto) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator()
                    Text(
                        text = "Restaurando tu sesión...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else if (uidActual != null && esAdminVerificado) {
            val adminViewModel: AdminViewModel = viewModel()
            AdminScreen(
                viewModel = adminViewModel,
                onSalirAdmin = cerrarSesion
            )
        } else if (uidActual == null) {
            AuthScreen(
                viewModel = authViewModel,
                onAuthenticated = { uid, conductorRole ->
                    uidActual = uid
                    esConductor = conductorRole
                    esAdminVerificado = false
                    rolResuelto = true
                },
                onAdminAuthenticated = { uid ->
                    uidActual = uid
                    esConductor = false
                    esAdminVerificado = true
                    rolResuelto = true
                }
            )
        } else if (esConductor) {
            val conductorViewModel: ConductorViewModel = viewModel()
            val condState by conductorViewModel.uiState.collectAsState()
            val chatState by chatViewModel.uiState.collectAsState()
            val uid = uidActual!!
            BackHandler(enabled = condState.disponible && condState.tabActual == ConductorTab.INICIO) {
                (context as? Activity)?.moveTaskToBack(true)
            }
            DisposableEffect(uid, condState.disponible) {
                conductorViewModelRef = conductorViewModel
                MainActivity.conductorActivoUidParaCierre = if (condState.disponible) uid else null
                MainActivity.onLimpiarCicloGpsConductor = {
                    conductorViewModel.detenerCicloGps(limpiarNotificacion = true)
                }
                onDispose {
                    MainActivity.onLimpiarCicloGpsConductor = null
                }
            }
            LaunchedEffect(uid) {
                conductorViewModel.restaurarEstadoYFinanzas(uid, context)
            }
            LaunchedEffect(appEnPrimerPlano) {
                conductorViewModel.setAppEnPrimerPlano(appEnPrimerPlano)
            }
            val viaje = condState.viajeActivo
            val oferta = condState.ofertaPendiente
            val estadoViajeActivo = viaje?.get("estado") as? String
            val viajeChatId = if (estadoViajeActivo == "aceptado" || estadoViajeActivo == "en_curso") {
                viaje?.get("id") as? String
            } else {
                null
            }
            LaunchedEffect(viajeChatId, uid) {
                chatViewModel.sincronizarViajeChat(context, viajeChatId, uid)
            }
            ConductorScreen(
                tabActual = condState.tabActual,
                onSelectTab = { conductorViewModel.seleccionarTab(it, uid) },
                conductorId = uid,
                viajeActivoId = viaje?.get("id") as? String,
                estadoViaje = estadoViajeActivo,
                pasajeroNombre = (viaje?.get("pasajeroNombre") ?: oferta?.get("pasajeroNombre")) as? String,
                cantidadPasajeros = ((viaje?.get("cantidadPasajeros") ?: oferta?.get("cantidadPasajeros")) as? Number)?.toInt() ?: 1,
                resenaUbicacion = (viaje?.get("resenaUbicacion") ?: oferta?.get("resenaUbicacion")) as? String,
                origenLat = ((viaje?.get("origenLat") ?: oferta?.get("origenLat")) as? Number)?.toDouble(),
                origenLng = ((viaje?.get("origenLng") ?: oferta?.get("origenLng")) as? Number)?.toDouble(),
                destinoLat = ((viaje?.get("destinoLat") ?: oferta?.get("destinoLat")) as? Number)?.toDouble(),
                destinoLng = ((viaje?.get("destinoLng") ?: oferta?.get("destinoLng")) as? Number)?.toDouble(),
                segundosOfertaRestantes = condState.segundosOfertaRestantes,
                gananciasHoy = condState.finanzas.gananciasHoy,
                gananciasMes = condState.finanzas.gananciasMes,
                historial = condState.historial,
                cargandoHistorial = condState.cargandoHistorial,
                mostrarModalCobro = condState.mostrarModalCobro,
                montoACobrar = condState.montoACobrar,
                onAceptarOferta = {
                    conductorViewModel.aceptarOfertaActual(uid)
                },
                onRechazarOferta = { conductorViewModel.rechazarOfertaActual(uid) },
                onVerificarPin = { pin ->
                    val vId = viaje?.get("id") as? String ?: return@ConductorScreen
                    conductorViewModel.verificarPin(vId, uid, pin)
                },
                onFinalizarViaje = {
                    val vId = viaje?.get("id") as? String ?: return@ConductorScreen
                    val pId = viaje["pasajeroId"] as? String ?: return@ConductorScreen
                    val monto = (viaje["montoAproximado"] as? Number)?.toDouble() ?: 0.0
                    conductorViewModel.finalizarViaje(vId, uid, pId, monto)
                },
                onCalificarPasajero = { estrellas, comentario ->
                    conductorViewModel.calificarPasajero(uid, estrellas, comentario)
                },
                onDismissModalCobro = { conductorViewModel.cerrarModalCobro() },
                licenciaRestante = condState.licenciaRestante,
                nombreConductor = condState.nombreConductor,
                placa = condState.placa,
                vehiculoTipo = condState.vehiculoTipo,
                tarifaBase = condState.tarifaBase,
                tarifaPorKm = condState.tarifaPorKm,
                misSolicitudes = condState.misSolicitudes,
                onEnviarSolicitudCambio = { cambios, motivo ->
                    conductorViewModel.enviarSolicitudCambioConductor(uid, cambios, motivo)
                },
                onCancelarViaje = { motivo ->
                    val vId = viaje?.get("id") as? String ?: return@ConductorScreen
                    conductorViewModel.cancelarViajeActivo(vId, uid, motivo)
                },
                avisoCancelacionFlotante = condState.avisoCancelacionFlotante,
                onDismissAvisoCancelacion = { conductorViewModel.limpiarAvisoCancelacionFlotante() },
                disponible = condState.disponible,
                actualizandoDisponibilidad = condState.actualizandoDisponibilidad,
                mensajeEstado = condState.mensajeEstado,
                onDismissMensajeEstado = { conductorViewModel.limpiarMensajeEstado() },
                onToggleDisponible = { activo ->
                    conductorViewModel.cambiarDisponibilidad(context, uid, activo)
                },
                procesandoOferta = condState.procesandoOferta,
                errorPin = condState.errorPin,
                mensajesChat = chatState.mensajes,
                onAbrirChat = { vId ->
                    chatViewModel.sincronizarViajeChat(context, vId, uid)
                    chatViewModel.setChatAbierto(true)
                },
                onCerrarChat = { chatViewModel.setChatAbierto(false) },
                onEnviarMensajeChat = { vId, texto ->
                    chatViewModel.enviarMensaje(
                        viajeId = vId,
                        autorUid = uid,
                        autorRol = "conductor",
                        autorNombre = condState.nombreConductor.ifBlank { "Conductor" },
                        texto = texto
                    )
                },
                linkDescarga = linkDescarga,
                onCerrarSesion = cerrarSesion,
                chatNoLeidos = chatState.mensajesNoLeidos,
                alertaChatFlotante = chatState.alertaMensajeEnApp,
                onDismissAlertaChat = { chatViewModel.limpiarAlertaMensajeEnApp() },
                conductorLlego = (viaje?.get("conductorLlego") as? Boolean) == true,
                onNotificarLlegada = {
                    val vId = viaje?.get("id") as? String
                    if (!vId.isNullOrBlank()) {
                        conductorViewModel.marcarConductorLlego(vId)
                    }
                }
            )
        } else {
            val pasajeroViewModel: PasajeroViewModel = viewModel()
            val pasState by pasajeroViewModel.uiState.collectAsState()
            val chatState by chatViewModel.uiState.collectAsState()
            val uid = uidActual!!
            LaunchedEffect(uid) {
                pasajeroViewModel.restaurarViajeActivo(uid, context)
            }
            DisposableEffect(lifecycleOwner, uid) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        pasajeroViewModel.restaurarViajeActivo(uid, context)
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }
            val viaje = pasState.viajeActivo
            val estadoViajeActivo = viaje?.get("estado") as? String
            val viajeChatId = if (estadoViajeActivo == "aceptado" || estadoViajeActivo == "en_curso") {
                viaje?.get("id") as? String
            } else {
                null
            }
            LaunchedEffect(viajeChatId, uid) {
                chatViewModel.sincronizarViajeChat(context, viajeChatId, uid)
            }
            PasajeroScreen(
                tabActual = pasState.tabActual,
                onSelectTab = { pasajeroViewModel.seleccionarTab(it, uid) },
                estadoViaje = estadoViajeActivo ?: "idle",
                pinPersistente = pasState.pinPersistente,
                conductorNombre = (viaje?.get("conductorNombre") as? String) ?: pasState.ultimoConductorNombre,
                conductorPlaca = viaje?.get("conductorPlaca") as? String,
                etaMinutos = (viaje?.get("etaMinutos") as? Number)?.toInt(),
                montoAproximado = (viaje?.get("montoAproximado") as? Number)?.toInt() ?: 0,
                rutasFavoritas = pasState.rutasFavoritas,
                sugerenciasOrigen = pasState.sugerenciasOrigen,
                sugerenciasDestino = pasState.sugerenciasDestino,
                buscandoDestino = pasState.buscandoDestino,
                historial = pasState.historial,
                cargandoHistorial = pasState.cargandoHistorial,
                mostrarModalPago = pasState.mostrarModalPago,
                onBuscarOrigen = { q, lat, lng -> pasajeroViewModel.buscarSugerenciasOrigen(q, lat, lng) },
                onBuscarDestino = { q, lat, lng -> pasajeroViewModel.buscarSugerenciasDestino(q, lat, lng) },
                onGuardarFavorita = { pasajeroViewModel.guardarRutaFavorita(uid, it) },
                onEliminarFavorita = { pasajeroViewModel.eliminarRutaFavorita(uid, it) },
                onSolicitarViaje = { pasajeros, origen, origenLat, origenLng, destino, destinoLat, destinoLng, resena, tiposVehiculoPermitidos ->
                    pasajeroViewModel.solicitarViaje(
                        pasajeroId = uid,
                        cantidadPasajeros = pasajeros,
                        origenNombre = origen,
                        origenLat = origenLat,
                        origenLng = origenLng,
                        destinoNombre = destino,
                        destinoLat = destinoLat,
                        destinoLng = destinoLng,
                        resenaUbicacion = resena,
                        tiposVehiculoPermitidos = tiposVehiculoPermitidos
                    )
                },
                onCalificarConductor = { estrellas, comentario ->
                    pasajeroViewModel.calificarConductor(uid, estrellas, comentario)
                },
                onDismissModalPago = { pasajeroViewModel.cerrarModalPago(uid) },
                nombrePasajero = pasState.nombrePasajero,
                fotoUrl = pasState.fotoUrl,
                actualizandoFoto = pasState.actualizandoFoto,
                onActualizarFotoPerfil = { nuevaFoto ->
                    pasajeroViewModel.actualizarFotoPerfil(uid, nuevaFoto)
                },
                misSolicitudes = pasState.misSolicitudes,
                onEnviarSolicitudCambio = { cambios, motivo ->
                    pasajeroViewModel.enviarSolicitudCambioPasajero(
                        uid,
                        pasState.nombrePasajero,
                        cambios,
                        motivo
                    )
                },
                avisoCancelacion = pasState.avisoCancelacion,
                onDismissAvisoCancelacion = { pasajeroViewModel.limpiarAvisoCancelacion() },
                onCancelarViaje = { motivo ->
                    val vId = viaje?.get("id") as? String ?: return@PasajeroScreen
                    pasajeroViewModel.cancelarViajeActivo(vId, motivo)
                },
                precisionUbicacionMetros = pasState.precisionUbicacionMetros,
                onPrecisionActualizada = { prec -> pasajeroViewModel.actualizarUbicacionGps(prec) },
                linkDescarga = linkDescarga,
                onCerrarSesion = cerrarSesion,
                solicitandoViaje = pasState.solicitandoViaje,
                errorSolicitud = pasState.errorSolicitud,
                origenViajeActivo = viaje?.get("origenNombre") as? String,
                destinoViajeActivo = viaje?.get("destinoNombre") as? String,
                pasajerosViajeActivo = (viaje?.get("cantidadPasajeros") as? Number)?.toInt(),
                resenaViajeActivo = viaje?.get("resenaUbicacion") as? String,
                mensajesChat = chatState.mensajes,
                onAbrirChat = {
                    viajeChatId?.let { chatViewModel.sincronizarViajeChat(context, it, uid) }
                    chatViewModel.setChatAbierto(true)
                },
                onCerrarChat = { chatViewModel.setChatAbierto(false) },
                onEnviarMensajeChat = { texto ->
                    val vId = viaje?.get("id") as? String ?: return@PasajeroScreen
                    chatViewModel.enviarMensaje(
                        viajeId = vId,
                        autorUid = uid,
                        autorRol = "pasajero",
                        autorNombre = pasState.nombrePasajero.ifBlank { "Pasajero" },
                        texto = texto
                    )
                },
                opcionesVehiculosDisponibles = pasState.opcionesVehiculosDisponibles,
                buscandoConductores = pasState.buscandoConductores,
                busquedaVehiculosRealizada = pasState.busquedaVehiculosRealizada,
                distanciaViajeKm = pasState.distanciaViajeKm,
                mensajeDisponibilidad = pasState.mensajeDisponibilidad,
                onBuscarVehiculosDisponibles = { oLat, oLng, dLat, dLng, pax ->
                    pasajeroViewModel.buscarVehiculosDisponibles(oLat, oLng, dLat, dLng, pax)
                },
                onLimpiarBusquedaVehiculos = { pasajeroViewModel.limpiarBusquedaVehiculos() },
                chatNoLeidos = chatState.mensajesNoLeidos,
                alertaChatFlotante = chatState.alertaMensajeEnApp,
                onDismissAlertaChat = { chatViewModel.limpiarAlertaMensajeEnApp() },
                montoAPagar = pasState.montoAPagar.roundToInt(),
                conductorLat = (viaje?.get("conductorLat") as? Number)?.toDouble(),
                conductorLng = (viaje?.get("conductorLng") as? Number)?.toDouble(),
                viajeActivoId = viaje?.get("id") as? String,
                conductorLlego = (viaje?.get("conductorLlego") as? Boolean) == true,
                distanciaTexto = viaje?.get("distanciaTexto") as? String,
                distanciaInicialRecogidaKm = (viaje?.get("distanciaInicialRecogidaKm") as? Number)?.toDouble(),
                origenViajeLat = (viaje?.get("origenLat") as? Number)?.toDouble(),
                origenViajeLng = (viaje?.get("origenLng") as? Number)?.toDouble()
            )
        }
    }
}
