package cr.viajerural.app.viewmodel

import android.content.Context
import android.location.Location
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ListenerRegistration
import cr.viajerural.app.ViajeRuralApp
import cr.viajerural.app.data.AdminResumenLigero
import cr.viajerural.app.data.CambioItemData
import cr.viajerural.app.data.LicenciaRestanteInfo
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularDiasLicenciaRestantes
import cr.viajerural.app.data.etiquetaCambioPorClave
import cr.viajerural.app.data.formatearColones
import cr.viajerural.app.data.parseLicenciaExpMillis
import cr.viajerural.app.messaging.NotificationHelper
import cr.viajerural.app.service.ConductorOnlineService
import cr.viajerural.app.worker.MonthlyPaymentReminderWorker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

// =============================================================================
// 1. AUTH VIEWMODEL (Login y Registro separados para Pasajero y Conductor)
// =============================================================================
data class AuthUiState(
    val cargando: Boolean = false,
    val error: String? = null,
    val uidAutenticado: String? = null,
    val rolAutenticado: String? = null,
    val adminCargando: Boolean = false,
    val adminError: String? = null,
    val uidAdminAutenticado: String? = null,
    val terminosCondicionesPasajero: String = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO,
    val terminosCondicionesConductor: String = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR,
    val montoMensualConductorBase: Int = ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
    val anioBaseMensualidad: Int = ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD
)

class AuthViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private var configListener: com.google.firebase.firestore.ListenerRegistration? = null

    init {
        configListener = repository.observarConfiguracionGeneral { cfg ->
            val terminos = (cfg["terminosCondicionesPasajero"] as? String)
                ?.trim()
                ?.takeIf { it.length >= 20 }
                ?: ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO
            val terminosConductor = (cfg["terminosCondiciones"] as? String)
                ?.trim()
                ?.takeIf { it.length >= 20 }
                ?: ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
            val montoBase = (cfg["montoMensualConductorBase"] as? Number)
                ?.toInt()
                ?.coerceIn(500, 1_000_000)
                ?: ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE
            val anioBase = (cfg["anioBaseMensualidad"] as? Number)
                ?.toInt()
                ?.coerceIn(2020, 2100)
                ?: ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD
            _uiState.value = _uiState.value.copy(
                terminosCondicionesPasajero = terminos,
                terminosCondicionesConductor = terminosConductor,
                montoMensualConductorBase = montoBase,
                anioBaseMensualidad = anioBase
            )
        }
    }

    override fun onCleared() {
        configListener?.remove()
        configListener = null
        super.onCleared()
    }

    fun limpiarEstadoAuth(context: Context? = null) {
        context?.let { repository.limpiarRolLocal(it) }
        _uiState.value = AuthUiState(
            terminosCondicionesPasajero = _uiState.value.terminosCondicionesPasajero,
            terminosCondicionesConductor = _uiState.value.terminosCondicionesConductor,
            montoMensualConductorBase = _uiState.value.montoMensualConductorBase,
            anioBaseMensualidad = _uiState.value.anioBaseMensualidad
        )
    }

    fun login(email: String, password: String, esConductor: Boolean, context: Context) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.iniciarSesion(email, password)
            result.fold(
                onSuccess = { uid ->
                    val rolFinal = repository.asegurarRolEnLogin(context, uid, esConductor)
                    if (rolFinal == "conductor") {
                        MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    }
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        uidAutenticado = uid,
                        rolAutenticado = rolFinal
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        error = err.message ?: "Error al iniciar sesión"
                    )
                }
            )
        }
    }

    /**
     * Login de Administrador Seguro:
     * Autentica con FirebaseAuth.signInWithEmailAndPassword y verifica usuarios/{uid}.rol == "admin".
     */
    fun loginAdminSeguro(email: String, password: String, context: Context? = null) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = _uiState.value.copy(adminError = "Ingresa correo y contraseña.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(adminCargando = true, adminError = null)
            val result = repository.iniciarSesionAdmin(email, password)
            result.fold(
                onSuccess = { uid ->
                    context?.let { repository.guardarRolLocal(it, uid, "admin") }
                    _uiState.value = _uiState.value.copy(
                        adminCargando = false,
                        uidAdminAutenticado = uid,
                        rolAutenticado = "admin",
                        adminError = null
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        adminCargando = false,
                        uidAdminAutenticado = null,
                        adminError = err.message ?: "Acceso denegado."
                    )
                }
            )
        }
    }

    fun limpiarErrorAdmin() {
        _uiState.value = _uiState.value.copy(adminError = null)
    }

    fun registrarPasajero(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        fotoUrl: String = "",
        context: Context? = null
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.registrarPasajero(nombre, email, telefono, cedula, password, fotoUrl)
            result.fold(
                onSuccess = { uid ->
                    context?.let { repository.guardarRolLocal(it, uid, "pasajero") }
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        uidAutenticado = uid,
                        rolAutenticado = "pasajero"
                    )
                },
                onFailure = { err -> _uiState.value = _uiState.value.copy(cargando = false, error = err.message) }
            )
        }
    }

    fun registrarConductor(
        context: Context,
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        vehiculoTipo: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        fotoVehiculoDataUrl: String = "",
        fotoCedulaDataUrl: String = "",
        fotoLicenciaDataUrl: String = "",
        fotoCirculacionDataUrl: String = "",
        fotoPerfilDataUrl: String = "",
        tarifaBaseCarga: Double? = null,
        tieneCascoExtra: Boolean = false,
        tieneCapaDisponible: Boolean = false
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.registrarConductor(
                nombre, email, telefono, cedula, password,
                vehiculoTipo, vehiculoModelo, vehiculoColor, vehiculoAnio,
                placa, capacidad, tarifaBase, tarifaPorKm,
                fotoVehiculoDataUrl, fotoCedulaDataUrl, fotoLicenciaDataUrl, fotoCirculacionDataUrl,
                fotoPerfilDataUrl,
                tarifaBaseCarga,
                tieneCascoExtra,
                tieneCapaDisponible
            )
            result.fold(
                onSuccess = { uid ->
                    repository.guardarRolLocal(context, uid, "conductor")
                    MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        uidAutenticado = uid,
                        rolAutenticado = "conductor"
                    )
                },
                onFailure = { err -> _uiState.value = _uiState.value.copy(cargando = false, error = err.message) }
            )
        }
    }
}

// =============================================================================
// 2. CONDUCTOR VIEWMODEL (4 pestañas BottomNavigation, Finanzas 2-datos, Historial lazy)
// =============================================================================
enum class ConductorTab { INICIO, FINANZAS, HISTORIAL, PERFIL }

data class ConductorFinanzasSimple(
    val gananciasHoy: Double = 0.0,
    val gananciasMes: Double = 0.0
)

data class ConductorUiState(
    val tabActual: ConductorTab = ConductorTab.INICIO,
    val disponible: Boolean = false,
    val viajeActivo: Map<String, Any>? = null,
    val ofertaPendiente: Map<String, Any>? = null,
    val segundosOfertaRestantes: Int? = null,
    val procesandoOferta: Boolean = false,
    val errorPin: String? = null,
    val mensajesChat: List<Map<String, Any>> = emptyList(),
    val finanzas: ConductorFinanzasSimple = ConductorFinanzasSimple(),
    val nombreConductor: String = "",
    val telefonoConductor: String = "",
    val placa: String = "",
    val vehiculoTipo: String = "",
    val vehiculoMarca: String = "",
    val vehiculoModelo: String = "",
    val vehiculoColor: String = "",
    val vehiculoAnio: String = "",
    val capacidad: Int = 4,
    val tarifaBase: Double = 1500.0,
    val tarifaBaseCarga: Double? = null,
    val tarifaPorKm: Double = 650.0,
    val tieneCascoExtra: Boolean = false,
    val tieneCapaDisponible: Boolean = false,
    val fotoVehiculo: String = "",
    val fotoCedula: String = "",
    val fotoLicencia: String = "",
    val fotoCirculacion: String = "",
    val licenciaRestante: LicenciaRestanteInfo? = null,
    val misSolicitudes: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val historial: List<Map<String, Any>> = emptyList(),
    val historialCargado: Boolean = false,
    val cargandoHistorial: Boolean = false,
    val mostrarModalCobro: Boolean = false,
    val montoACobrar: Double = 0.0,
    val ultimoViajeId: String? = null,
    val ultimoPasajeroId: String? = null,
    val mensajeEstado: String? = null,
    val actualizandoDisponibilidad: Boolean = false,
    val avisoCancelacionFlotante: String? = null,
    val montoMensualConductorBase: Int = ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
    val anioBaseMensualidad: Int = ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD,
    val multiplicadorTopeNormal: Double = ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_NORMAL,
    val multiplicadorTopeCarga: Double = ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_CARGA,
    val terminosCondicionesConductor: String = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR,
    val sinpeNumero: String = "62546546",
    val sinpeTitular: String = "Administración Viaje Rural",
    val estadoCuenta: String = "pendiente"
)

class ConductorViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConductorUiState())
    val uiState: StateFlow<ConductorUiState> = _uiState.asStateFlow()

    private var perfilListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var viajeActivoListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var viajeDocListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var ofertasListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var chatListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var finanzasListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var configListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var misSolicitudesListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var ofertaTimerJob: Job? = null
    private var ofertaDiferidaJob: Job? = null
    private var ultimasOfertasBuscando: List<Map<String, Any>> = emptyList()
    private val ofertasRechazadasLocalmente = LinkedHashSet<String>()
    private var latConductorActual: Double? = null
    private var lngConductorActual: Double? = null
    private var ofertaLocalKey: String? = null
    private var ofertaLocalExpiraAt: Long = 0L
    private var perfilObservadoUid: String? = null
    private var viajeDocObservadoId: String? = null
    private var cancelacionPropiaViajeId: String? = null
    private var actualizandoDisponibilidadLock = false
    private var estadoInicialReseteadoUid: String? = null
    private var finanzasCalculadasDesdeViajes = false
    private var appContext: Context? = null
    private var appEnPrimerPlano: Boolean = true

    private val gpsHandler = Handler(Looper.getMainLooper())
    private var gpsRunnable: Runnable? = null
    private var conductorGpsActivoId: String? = null
    private var modoGpsActual: String? = null
    private var viajeRecogidaActivoId: String? = null
    private val intervaloGps15MinMs = 15L * 60L * 1000L
    private val intervaloGps90SegMs = 90L * 1000L

    private fun aplicarPerfilConductor(perfil: Map<String, Any>) {
        val hoy = if (finanzasCalculadasDesdeViajes) {
            _uiState.value.finanzas.gananciasHoy
        } else {
            (perfil["gananciasHoy"] as? Number)?.toDouble() ?: _uiState.value.finanzas.gananciasHoy
        }
        val mes = if (finanzasCalculadasDesdeViajes) {
            _uiState.value.finanzas.gananciasMes
        } else {
            (perfil["gananciasMes"] as? Number)?.toDouble() ?: _uiState.value.finanzas.gananciasMes
        }
        val licInfo = if (perfil.containsKey("licenciaExp")) {
            calcularDiasLicenciaRestantes(perfil["licenciaExp"])
        } else {
            _uiState.value.licenciaRestante
        }
        (perfil["lat"] as? Number)?.toDouble()?.let { latConductorActual = it }
        (perfil["lng"] as? Number)?.toDouble()?.let { lngConductorActual = it }

        val perfilUid = perfil["uid"] as? String
        val yaActivoEnProceso = !perfilUid.isNullOrBlank() &&
            ViajeRuralApp.conductorActivoEnProcesoUid == perfilUid
        val esperandoResetInicial = !perfilUid.isNullOrBlank() &&
            estadoInicialReseteadoUid != perfilUid &&
            !yaActivoEnProceso &&
            _uiState.value.viajeActivo == null
        val dispRemoto = (perfil["disponible"] as? Boolean)
            ?: (perfil["estadoOperativo"] == "activo" || perfil["estadoOperativo"] == "disponible")
        val dispFinal = when {
            actualizandoDisponibilidadLock -> _uiState.value.disponible
            esperandoResetInicial -> false
            yaActivoEnProceso -> true
            else -> dispRemoto
        }
        val estadoCuentaRemoto = (perfil["estadoCuenta"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: _uiState.value.estadoCuenta
        _uiState.value = _uiState.value.copy(
            disponible = dispFinal,
            estadoCuenta = estadoCuentaRemoto,
            finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
            nombreConductor = perfil["nombre"] as? String ?: _uiState.value.nombreConductor,
            placa = perfil["placa"] as? String ?: _uiState.value.placa,
            vehiculoTipo = (perfil["tipoVehiculo"] as? String)?.takeIf { it.isNotBlank() }
                ?: (perfil["vehiculoTipo"] as? String)
                ?: _uiState.value.vehiculoTipo,
            vehiculoMarca = perfil["vehiculoMarca"] as? String ?: _uiState.value.vehiculoMarca,
            vehiculoModelo = perfil["vehiculoModelo"] as? String ?: _uiState.value.vehiculoModelo,
            vehiculoColor = perfil["vehiculoColor"] as? String ?: _uiState.value.vehiculoColor,
            vehiculoAnio = perfil["vehiculoAnio"] as? String ?: _uiState.value.vehiculoAnio,
            capacidad = (perfil["capacidad"] as? Number)?.toInt() ?: _uiState.value.capacidad,
            tarifaBase = (perfil["tarifaBase"] as? Number)?.toDouble() ?: _uiState.value.tarifaBase,
            tarifaBaseCarga = if (perfil.containsKey("tarifaBaseCarga")) {
                (perfil["tarifaBaseCarga"] as? Number)?.toDouble()
            } else {
                null
            },
            tarifaPorKm = (perfil["tarifaPorKm"] as? Number)?.toDouble() ?: _uiState.value.tarifaPorKm,
            tieneCascoExtra = (perfil["tieneCascoExtra"] as? Boolean) ?: false,
            tieneCapaDisponible = (perfil["tieneCapaDisponible"] as? Boolean) ?: false,
            licenciaRestante = licInfo
        )
        if (!perfilUid.isNullOrBlank()) {
            procesarOfertasEntrantes(perfilUid)
        }
    }

    override fun onCleared() {
        detenerCicloGps15Min()
        perfilListener?.remove()
        perfilListener = null
        viajeActivoListener?.remove()
        viajeActivoListener = null
        viajeDocListener?.remove()
        viajeDocListener = null
        viajeDocObservadoId = null
        ofertasListener?.remove()
        ofertasListener = null
        chatListener?.remove()
        chatListener = null
        finanzasListener?.remove()
        finanzasListener = null
        configListener?.remove()
        configListener = null
        misSolicitudesListener?.remove()
        misSolicitudesListener = null
        ofertaTimerJob?.cancel()
        ofertaDiferidaJob?.cancel()
        super.onCleared()
    }

    fun seleccionarTab(tab: ConductorTab, conductorId: String, context: Context? = null) {
        if (context != null) {
            appContext = context.applicationContext
        }
        _uiState.value = _uiState.value.copy(tabActual = tab)
        if (tab == ConductorTab.HISTORIAL && !_uiState.value.historialCargado) {
            cargarHistorial(conductorId)
        }
        if (tab == ConductorTab.INICIO || tab == ConductorTab.FINANZAS) {
            restaurarEstadoYFinanzas(conductorId, context)
            if (tab == ConductorTab.FINANZAS) {
                viewModelScope.launch {
                    try {
                        val (hoy, mes) = repository.obtenerFinanzasConductor(conductorId)
                        finanzasCalculadasDesdeViajes = true
                        _uiState.value = _uiState.value.copy(
                            finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes)
                        )
                    } catch (_: Throwable) {
                    }
                }
            }
        }
        if (tab == ConductorTab.PERFIL && !_uiState.value.solicitudesCargadas) {
            cargarMisSolicitudes(conductorId)
        }
    }

    fun iniciarModoEspera15Min(context: Context, conductorId: String) {
        if (conductorId.isBlank()) return
        val appCtx = context.applicationContext
        appContext = appCtx
        if (modoGpsActual == "espera" && conductorGpsActivoId == conductorId && gpsRunnable != null) return
        detenerCicloGps(limpiarNotificacion = true)
        conductorGpsActivoId = conductorId
        modoGpsActual = "espera"

        val tarea = object : Runnable {
            override fun run() {
                val viaje = _uiState.value.viajeActivo
                val estadoViaje = viaje?.get("estado") as? String
                if (!_uiState.value.disponible || estadoViaje == "en_curso") {
                    detenerCicloGps(limpiarNotificacion = true)
                    return
                }
                if (estadoViaje == "aceptado") {
                    val vId = viaje["id"] as? String
                    val oLat = (viaje["origenLat"] as? Number)?.toDouble()
                    val oLng = (viaje["origenLng"] as? Number)?.toDouble()
                    if (!vId.isNullOrBlank() && oLat != null && oLng != null) {
                        iniciarModoRecogida90Seg(appCtx, conductorId, vId, oLat, oLng)
                        return
                    }
                }
                viewModelScope.launch {
                    try {
                        repository.asegurarSesionConductorValida(conductorId)
                        val (lat, lng) = repository.obtenerUbicacionUnicaGps(appCtx)
                        repository.actualizarUbicacionPeriodicaConductor(conductorId, lat, lng)
                    } catch (_: Throwable) {
                    }
                }
                gpsHandler.postDelayed(this, intervaloGps15MinMs)
            }
        }
        gpsRunnable = tarea
        gpsHandler.postDelayed(tarea, intervaloGps15MinMs)
    }

    fun iniciarModoRecogida90Seg(
        context: Context,
        conductorId: String,
        viajeId: String,
        origenLat: Double,
        origenLng: Double
    ) {
        if (conductorId.isBlank() || viajeId.isBlank()) return
        val appCtx = context.applicationContext
        appContext = appCtx
        if (modoGpsActual == "recogida" && viajeRecogidaActivoId == viajeId && gpsRunnable != null) return
        detenerCicloGps(limpiarNotificacion = false)
        conductorGpsActivoId = conductorId
        modoGpsActual = "recogida"
        viajeRecogidaActivoId = viajeId

        val tarea = object : Runnable {
            override fun run() {
                val viajeActual = _uiState.value.viajeActivo
                val estadoViaje = viajeActual?.get("estado") as? String
                val conductorLlego = (viajeActual?.get("conductorLlego") as? Boolean) == true
                if (estadoViaje == "en_curso") {
                    detenerCicloGps(limpiarNotificacion = true)
                    return
                }
                if (conductorLlego) {
                    return
                }
                viewModelScope.launch {
                    try {
                        repository.asegurarSesionConductorValida(conductorId)
                        val (lat, lng) = repository.obtenerUbicacionUnicaGps(appCtx)
                        val resultados = FloatArray(1)
                        Location.distanceBetween(lat, lng, origenLat, origenLng, resultados)
                        val distanciaMetros = resultados[0].coerceAtLeast(0f)
                        val distanciaTexto = if (distanciaMetros < 1000f) {
                            "${distanciaMetros.roundToInt()} m"
                        } else {
                            String.format(Locale.US, "%.1f km", distanciaMetros / 1000f)
                        }
                        val etaMinutos = ((distanciaMetros / 1000.0) / 30.0 * 60.0)
                            .roundToInt()
                            .coerceIn(1, 300)

                        repository.actualizarUbicacionRecogidaConDistancia(
                            viajeId = viajeId,
                            conductorId = conductorId,
                            lat = lat,
                            lng = lng,
                            etaMinutos = etaMinutos,
                            distanciaTexto = distanciaTexto
                        )
                        NotificationHelper.mostrarNotificacionSeguimientoRecogida(
                            context = appCtx,
                            distanciaTexto = distanciaTexto,
                            etaMinutos = etaMinutos
                        )
                    } catch (_: Throwable) {
                    }
                }
                gpsHandler.postDelayed(this, intervaloGps90SegMs)
            }
        }
        gpsRunnable = tarea
        gpsHandler.post(tarea)
    }

    fun iniciarCicloGps15Min(context: Context, conductorId: String) {
        iniciarModoEspera15Min(context, conductorId)
    }

    fun detenerCicloGps(limpiarNotificacion: Boolean = true) {
        gpsRunnable?.let { gpsHandler.removeCallbacks(it) }
        gpsRunnable = null
        modoGpsActual = null
        viajeRecogidaActivoId = null
        conductorGpsActivoId = null
        if (limpiarNotificacion) {
            appContext?.let { NotificationHelper.cancelarNotificacionSeguimientoRecogida(it) }
        }
    }

    fun detenerCicloGps15Min() {
        detenerCicloGps(limpiarNotificacion = true)
    }

    suspend fun desactivarConductorAlCerrarSesion(conductorId: String) {
        detenerCicloGps(limpiarNotificacion = true)
        ViajeRuralApp.conductorActivoEnProcesoUid = null
        appContext?.let { ConductorOnlineService.stop(it) }
        ofertaTimerJob?.cancel()
        ofertaDiferidaJob?.cancel()
        try {
            repository.actualizarDisponibilidadConductor(
                conductorId = conductorId,
                disponible = false
            )
        } catch (_: Throwable) {
        }
        _uiState.value = _uiState.value.copy(
            disponible = false,
            ofertaPendiente = null,
            segundosOfertaRestantes = null
        )
    }

    fun cambiarDisponibilidad(
        context: Context,
        conductorId: String,
        activo: Boolean,
        onExito: () -> Unit = {},
        onFallo: (String) -> Unit = {}
    ) {
        appContext = context.applicationContext
        estadoInicialReseteadoUid = conductorId
        val previo = _uiState.value.disponible
        actualizandoDisponibilidadLock = true
        _uiState.value = _uiState.value.copy(
            disponible = activo,
            actualizandoDisponibilidad = true,
            mensajeEstado = null
        )
        viewModelScope.launch {
            try {
                if (activo) {
                    // Capturar ubicación GPS UNA SOLA VEZ y programar ciclo de 15 min con Handler
                    val (lat, lng) = repository.obtenerUbicacionUnicaGps(context)
                    latConductorActual = lat
                    lngConductorActual = lng
                    repository.actualizarDisponibilidadConductor(
                        conductorId = conductorId,
                        disponible = true,
                        lat = lat,
                        lng = lng,
                        tipoVehiculo = _uiState.value.vehiculoTipo,
                        capacidad = _uiState.value.capacidad
                    )
                    ConductorOnlineService.start(context, conductorId)
                    iniciarCicloGps15Min(context, conductorId)
                } else {
                    // Al pasar a Inactivo, detener Handler, detener servicio de presencia y marcar inactivo
                    detenerCicloGps15Min()
                    ConductorOnlineService.stop(context)
                    repository.actualizarDisponibilidadConductor(
                        conductorId = conductorId,
                        disponible = false
                    )
                    ofertaTimerJob?.cancel()
                    ofertaDiferidaJob?.cancel()
                    _uiState.value = _uiState.value.copy(
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null
                    )
                }
                actualizandoDisponibilidadLock = false
                _uiState.value = _uiState.value.copy(
                    disponible = activo,
                    actualizandoDisponibilidad = false
                )
                if (activo) {
                    procesarOfertasEntrantes(conductorId)
                }
                onExito()
            } catch (e: Exception) {
                actualizandoDisponibilidadLock = false
                if (!activo) {
                    detenerCicloGps15Min()
                    ConductorOnlineService.stop(context)
                }
                val msg = e.localizedMessage ?: "No se pudo actualizar tu estado en Firestore."
                _uiState.value = _uiState.value.copy(
                    disponible = previo,
                    actualizandoDisponibilidad = false,
                    mensajeEstado = msg
                )
                onFallo(msg)
            }
        }
    }

    fun limpiarMensajeEstado() {
        _uiState.value = _uiState.value.copy(mensajeEstado = null)
    }

    fun setAppEnPrimerPlano(enPrimerPlano: Boolean) {
        appEnPrimerPlano = enPrimerPlano
    }

    @Suppress("UNCHECKED_CAST")
    private fun procesarOfertasEntrantes(
        conductorId: String,
        ofertasOverride: List<Map<String, Any>>? = null
    ) {
        if (ofertasOverride != null) {
            ultimasOfertasBuscando = ofertasOverride
        }
        val ofertas = ofertasOverride ?: ultimasOfertasBuscando
        ofertaDiferidaJob?.cancel()

        val st = _uiState.value
        val licenciaVigente = (st.licenciaRestante?.dias ?: 1) > 0
        if (st.viajeActivo != null || !st.disponible || st.estadoCuenta == "bloqueado" || !licenciaVigente) {
            ofertaTimerJob?.cancel()
            _uiState.value = st.copy(
                ofertaPendiente = null,
                segundosOfertaRestantes = null
            )
            return
        }

        val tipoCond = st.vehiculoTipo
        val capCond = st.capacidad.coerceAtLeast(1)
        val ahora = System.currentTimeMillis()
        val compat = ofertas.filter { viaje ->
            val vId = viaje["id"] as? String ?: return@filter false
            if (viaje["estado"] != "buscando") return@filter false
            if (vId in ofertasRechazadasLocalmente) return@filter false
            val paxViaje = (viaje["cantidadPasajeros"] as? Number)?.toInt()?.coerceAtLeast(1) ?: 1
            val tiposPermitidos = (viaje["tiposVehiculoPermitidos"] as? List<*>)
                ?.mapNotNull { it as? String }
                .orEmpty()
            if (!repository.conductorAceptaViaje(tipoCond, capCond, tiposPermitidos, paxViaje)) {
                return@filter false
            }
            val cola = (viaje["colaConductores"] as? List<String>).orEmpty()
            if (conductorId in cola) return@filter true
            val latCond = latConductorActual
            val lngCond = lngConductorActual
            val oLat = (viaje["origenLat"] as? Number)?.toDouble()
            val oLng = (viaje["origenLng"] as? Number)?.toDouble()
            if (latCond != null && lngCond != null && oLat != null && oLng != null) {
                repository.calcularDistanciaHaversineKm(latCond, lngCond, oLat, oLng) <= 15.0
            } else {
                true
            }
        }

        var indiceTurno = 0
        var esTurnoDirectoEnCola = false
        var ofertaSeleccionada = compat.firstOrNull { viaje ->
            val cola = (viaje["colaConductores"] as? List<String>).orEmpty()
            if (cola.isEmpty()) return@firstOrNull false
            val idx = ((viaje["ofertaActualIndex"] as? Number)?.toInt() ?: 0) % cola.size
            if (cola[idx] == conductorId) {
                indiceTurno = idx
                esTurnoDirectoEnCola = true
                true
            } else {
                false
            }
        }

        if (ofertaSeleccionada == null) {
            var menorEsperaMs: Long? = null
            ofertaSeleccionada = compat.firstOrNull { viaje ->
                val cola = (viaje["colaConductores"] as? List<String>).orEmpty()
                if (cola.isEmpty()) {
                    true
                } else {
                    val expiraCola = (viaje["ofertaExpiraAt"] as? Number)?.toLong() ?: 0L
                    if (expiraCola <= 0L || ahora > expiraCola + 2_000L) {
                        true
                    } else {
                        val espera = (expiraCola + 2_200L) - ahora
                        if (menorEsperaMs == null || espera < menorEsperaMs!!) {
                            menorEsperaMs = espera
                        }
                        false
                    }
                }
            }
            if (ofertaSeleccionada == null && menorEsperaMs != null) {
                val esperaMs = menorEsperaMs!!.coerceIn(1_000L, 16_000L)
                ofertaDiferidaJob = viewModelScope.launch {
                    delay(esperaMs)
                    procesarOfertasEntrantes(conductorId)
                }
            }
        }

        if (ofertaSeleccionada == null) {
            ofertaTimerJob?.cancel()
            _uiState.value = _uiState.value.copy(
                ofertaPendiente = null,
                segundosOfertaRestantes = null
            )
            return
        }

        val viajeId = ofertaSeleccionada["id"] as? String ?: return
        val colaSel = (ofertaSeleccionada["colaConductores"] as? List<String>).orEmpty()
        val turnKey = "${viajeId}_${if (esTurnoDirectoEnCola) indiceTurno else "abierta"}"
        val rawExpiraAt = (ofertaSeleccionada["ofertaExpiraAt"] as? Number)?.toLong()
        val expiraAt = if (esTurnoDirectoEnCola && rawExpiraAt != null && (rawExpiraAt - ahora) in 3_000L..25_000L) {
            rawExpiraAt
        } else {
            if (ofertaLocalKey != turnKey || ofertaLocalExpiraAt <= ahora) {
                ofertaLocalKey = turnKey
                ofertaLocalExpiraAt = ahora + 15_000L
            }
            ofertaLocalExpiraAt
        }

        // Disparar alerta con sonido tanto en primer plano como en segundo plano.
        val ctx = appContext
        if (ctx != null) {
            val pasajero = (ofertaSeleccionada["pasajeroNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "Pasajero"
            val origen = (ofertaSeleccionada["origenNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "Punto de recogida"
            val destino = (ofertaSeleccionada["destinoNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "Destino"
            val monto = (ofertaSeleccionada["montoAproximado"] as? Number)?.toInt() ?: 0
            NotificationHelper.mostrarOfertaViajeHeadsUp(
                context = ctx,
                titulo = "Nueva solicitud de viaje · $pasajero",
                cuerpo = "$origen → $destino · Tarifa aprox: ${formatearColones(monto)}",
                viajeId = viajeId,
                claveDeduplicacion = "oferta_$turnKey",
                enPrimerPlano = appEnPrimerPlano
            )
        }

        val yaMostrandoMismoTurno = _uiState.value.ofertaPendiente?.get("id") == viajeId &&
            ofertaTimerJob?.isActive == true
        _uiState.value = _uiState.value.copy(ofertaPendiente = ofertaSeleccionada)
        if (yaMostrandoMismoTurno) return

        ofertaTimerJob?.cancel()
        ofertaTimerJob = viewModelScope.launch {
            while (true) {
                val restantes = ((expiraAt - System.currentTimeMillis()) / 1000L).toInt().coerceAtLeast(0)
                _uiState.value = _uiState.value.copy(segundosOfertaRestantes = restantes)
                if (restantes <= 0) {
                    if (conductorId in colaSel && esTurnoDirectoEnCola) {
                        try {
                            repository.avanzarColaPorTimeoutSecuencial(viajeId, conductorId)
                        } catch (_: Exception) {
                        }
                        if (colaSel.size <= 1) {
                            ofertasRechazadasLocalmente.add(viajeId)
                        }
                    } else {
                        ofertasRechazadasLocalmente.add(viajeId)
                    }
                    procesarOfertasEntrantes(conductorId)
                    break
                }
                delay(1_000L)
            }
        }
    }

    fun aceptarOfertaActual(conductorId: String, onAceptado: (String) -> Unit = {}) {
        val oferta = _uiState.value.ofertaPendiente ?: return
        val viajeId = oferta["id"] as? String ?: return
        if (_uiState.value.procesandoOferta) return
        val origenLat = (oferta["origenLat"] as? Number)?.toDouble()
        val origenLng = (oferta["origenLng"] as? Number)?.toDouble()

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(procesandoOferta = true, mensajeEstado = null)
            val result = repository.aceptarOfertaAtomicamente(viajeId, conductorId)
            result.fold(
                onSuccess = {
                    ofertaTimerJob?.cancel()
                    ofertaDiferidaJob?.cancel()
                    iniciarEscuchaViajeDocumento(viajeId, conductorId)
                    val ctx = appContext
                    if (ctx != null && origenLat != null && origenLng != null) {
                        iniciarModoRecogida90Seg(ctx, conductorId, viajeId, origenLat, origenLng)
                    }
                    _uiState.value = _uiState.value.copy(
                        procesandoOferta = false,
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null,
                        errorPin = null
                    )
                    onAceptado(viajeId)
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        procesandoOferta = false,
                        mensajeEstado = err.localizedMessage ?: "No se pudo aceptar la oferta."
                    )
                }
            )
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun rechazarOfertaActual(conductorId: String) {
        val oferta = _uiState.value.ofertaPendiente ?: return
        val viajeId = oferta["id"] as? String ?: return
        if (_uiState.value.procesandoOferta) return

        val cola = (oferta["colaConductores"] as? List<String>).orEmpty()
        ofertasRechazadasLocalmente.add(viajeId)
        ofertaTimerJob?.cancel()
        _uiState.value = _uiState.value.copy(
            procesandoOferta = false,
            ofertaPendiente = null,
            segundosOfertaRestantes = null
        )

        if (conductorId in cola) {
            viewModelScope.launch {
                try {
                    repository.rechazarOfertaSecuencial(viajeId, conductorId)
                } catch (_: Exception) {
                }
                procesarOfertasEntrantes(conductorId)
            }
        } else {
            procesarOfertasEntrantes(conductorId)
        }
    }

    fun verificarPin(
        viajeId: String,
        conductorId: String,
        pinIngresado: String,
        onPinCorrecto: () -> Unit = {}
    ) {
        if (pinIngresado.trim().length != 3) {
            _uiState.value = _uiState.value.copy(errorPin = "Ingresa el PIN de 3 dígitos.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(errorPin = null)
            try {
                val valido = repository.verificarPinViaje(viajeId, conductorId, pinIngresado)
                if (valido) {
                    // Detener por completo el Handler GPS al recoger al pasajero (PIN confirmado)
                    detenerCicloGps(limpiarNotificacion = true)
                    _uiState.value = _uiState.value.copy(errorPin = null)
                    onPinCorrecto()
                } else {
                    _uiState.value = _uiState.value.copy(
                        errorPin = "PIN incorrecto. Pídele al pasajero el código de 3 dígitos."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorPin = e.localizedMessage ?: "No se pudo verificar el PIN."
                )
            }
        }
    }

    fun marcarConductorLlego(viajeId: String) {
        if (viajeId.isBlank()) return
        viewModelScope.launch {
            try {
                repository.marcarConductorLlegoRecogida(viajeId)
                detenerCicloGps(limpiarNotificacion = true)
                val viajeActualizado = _uiState.value.viajeActivo?.toMutableMap()?.apply {
                    put("conductorLlego", true)
                    put("distanciaTexto", "El conductor ha llegado")
                    put("etaMinutos", 0)
                }
                _uiState.value = _uiState.value.copy(
                    viajeActivo = viajeActualizado ?: _uiState.value.viajeActivo,
                    mensajeEstado = "¡Aviso enviado! El pasajero recibió la notificación de que ya llegaste."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo enviar el aviso de llegada."
                )
            }
        }
    }

    fun observarChat(viajeId: String) {
        chatListener?.remove()
        chatListener = repository.observarMensajesChat(viajeId) { msgs ->
            _uiState.value = _uiState.value.copy(mensajesChat = msgs)
        }
    }

    fun detenerChat() {
        chatListener?.remove()
        chatListener = null
    }

    fun enviarMensajeChat(viajeId: String, conductorId: String, texto: String) {
        viewModelScope.launch {
            try {
                repository.enviarMensajeChat(
                    viajeId = viajeId,
                    autorUid = conductorId,
                    autorRol = "conductor",
                    autorNombre = _uiState.value.nombreConductor.ifBlank { "Conductor" },
                    texto = texto
                )
            } catch (_: Exception) {
            }
        }
    }

    private fun iniciarEscuchaViajeDocumento(viajeId: String, conductorId: String) {
        if (viajeId.isBlank()) return
        if (viajeDocObservadoId == viajeId && viajeDocListener != null) return
        viajeDocListener?.remove()
        viajeDocObservadoId = viajeId
        viajeDocListener = repository.observarViajePorId(viajeId) { viaje ->
            if (viaje == null) {
                viajeDocListener?.remove()
                viajeDocListener = null
                viajeDocObservadoId = null
                _uiState.value = _uiState.value.copy(viajeActivo = null)
                return@observarViajePorId
            }

            val estado = viaje["estado"] as? String
            when (estado) {
                "aceptado" -> {
                    ofertaTimerJob?.cancel()
                    val ctx = appContext
                    val oLat = (viaje["origenLat"] as? Number)?.toDouble()
                    val oLng = (viaje["origenLng"] as? Number)?.toDouble()
                    val conductorLlego = (viaje["conductorLlego"] as? Boolean) == true
                    if (conductorLlego) {
                        detenerCicloGps(limpiarNotificacion = true)
                    } else if (ctx != null && oLat != null && oLng != null) {
                        iniciarModoRecogida90Seg(ctx, conductorId, viajeId, oLat, oLng)
                    }
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = viaje,
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null
                    )
                }
                "en_curso" -> {
                    ofertaTimerJob?.cancel()
                    detenerCicloGps(limpiarNotificacion = true)
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = viaje,
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null
                    )
                }
                "cancelado" -> {
                    viajeDocListener?.remove()
                    viajeDocListener = null
                    viajeDocObservadoId = null
                    detenerCicloGps(limpiarNotificacion = true)
                    val ctx = appContext
                    if (ctx != null) {
                        iniciarModoEspera15Min(ctx, conductorId)
                    }
                    val canceladoPor = viaje["canceladoPor"] as? String
                    if (canceladoPor == "pasajero" || (viajeId != cancelacionPropiaViajeId && canceladoPor != "conductor")) {
                        val pasajeroNombre = (viaje["pasajeroNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "El pasajero"
                        val motivo = (viaje["motivoCancelacion"] as? String)?.takeIf { it.isNotBlank() }
                            ?: "El pasajero canceló el viaje."
                        viewModelScope.launch {
                            try {
                                repository.restaurarConductorDisponibleTrasCancelacion(conductorId)
                            } catch (_: Exception) {
                            }
                        }
                        onViajeCanceladoPorPasajero(pasajeroNombre, motivo)
                    } else {
                        _uiState.value = _uiState.value.copy(viajeActivo = null, disponible = true)
                    }
                }
                "finalizado" -> {
                    viajeDocListener?.remove()
                    viajeDocListener = null
                    viajeDocObservadoId = null
                    detenerCicloGps(limpiarNotificacion = true)
                    val ctx = appContext
                    if (ctx != null && _uiState.value.disponible) {
                        iniciarModoEspera15Min(ctx, conductorId)
                    }
                }
            }
        }
    }

    fun restaurarEstadoYFinanzas(conductorId: String, context: Context? = null) {
        if (conductorId.isBlank()) return
        if (context != null) {
            appContext = context.applicationContext
        }
        if (configListener == null) {
            configListener = repository.observarConfiguracionGeneral { cfg ->
                val montoBase = (cfg["montoMensualConductorBase"] as? Number)
                    ?.toInt()
                    ?.coerceIn(500, 1_000_000)
                    ?: ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE
                val anioBase = (cfg["anioBaseMensualidad"] as? Number)
                    ?.toInt()
                    ?.coerceIn(2020, 2100)
                    ?: ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD
                val terminosConductor = (cfg["terminosCondiciones"] as? String)
                    ?.trim()
                    ?.takeIf { it.length >= 20 }
                    ?: ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR
                val multNormal = ((cfg["multiplicadorTopeNormal"] as? Number)?.toDouble()
                    ?: ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_NORMAL).coerceIn(1.1, 5.0)
                val multCarga = ((cfg["multiplicadorTopeCarga"] as? Number)?.toDouble()
                    ?: ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_CARGA).coerceIn(1.1, 5.0)
                val sinpe = (cfg["sinpeNumero"] as? String)?.takeIf { it.isNotBlank() } ?: "62546546"
                val titular = (cfg["adminSinpeTitular"] as? String)?.takeIf { it.isNotBlank() }
                    ?: "Administración Viaje Rural"
                _uiState.value = _uiState.value.copy(
                    montoMensualConductorBase = montoBase,
                    anioBaseMensualidad = anioBase,
                    multiplicadorTopeNormal = multNormal,
                    multiplicadorTopeCarga = multCarga,
                    terminosCondicionesConductor = terminosConductor,
                    sinpeNumero = sinpe,
                    sinpeTitular = titular
                )
            }
        }
        viewModelScope.launch {
            try {
                // Garantizar sesión FirebaseAuth + ID token vigentes antes de abrir listeners/consultas
                repository.asegurarSesionConductorValida(conductorId)

                if (perfilObservadoUid != conductorId) {
                    perfilListener?.remove()
                    viajeActivoListener?.remove()
                    ofertasListener?.remove()
                    finanzasListener?.remove()
                    misSolicitudesListener?.remove()
                    finanzasCalculadasDesdeViajes = false
                    perfilObservadoUid = conductorId

                    perfilListener = repository.observarPerfilConductor(
                        conductorId = conductorId,
                        onError = { err ->
                            _uiState.value = _uiState.value.copy(
                                mensajeEstado = "Error al leer perfil del conductor: ${err.localizedMessage ?: err.javaClass.simpleName}"
                            )
                        }
                    ) { perfil ->
                        if (_uiState.value.mensajeEstado?.contains("perfil del conductor", ignoreCase = true) == true) {
                            _uiState.value = _uiState.value.copy(mensajeEstado = null)
                        }
                        aplicarPerfilConductor(perfil)
                    }
                    finanzasListener = repository.observarFinanzasConductor(
                        conductorId = conductorId,
                        onError = { err ->
                            _uiState.value = _uiState.value.copy(
                                mensajeEstado = "Error al leer finanzas del conductor: ${err.localizedMessage ?: err.javaClass.simpleName}"
                            )
                        }
                    ) { hoy, mes ->
                        finanzasCalculadasDesdeViajes = true
                        _uiState.value = _uiState.value.copy(
                            finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes)
                        )
                    }
                    viajeActivoListener = repository.observarViajeActivoConductor(
                        conductorId = conductorId,
                        onError = { err ->
                            _uiState.value = _uiState.value.copy(
                                mensajeEstado = "Error al escuchar viaje activo: ${err.localizedMessage ?: err.javaClass.simpleName}"
                            )
                        }
                    ) { viaje ->
                        if (viaje != null) {
                            val vId = viaje["id"] as? String
                            if (!vId.isNullOrBlank()) {
                                iniciarEscuchaViajeDocumento(vId, conductorId)
                            }
                            ofertaTimerJob?.cancel()
                            _uiState.value = _uiState.value.copy(
                                viajeActivo = viaje,
                                ofertaPendiente = null,
                                segundosOfertaRestantes = null
                            )
                        } else if (viajeDocListener == null) {
                            _uiState.value = _uiState.value.copy(viajeActivo = null)
                            procesarOfertasEntrantes(conductorId)
                        }
                    }
                    ofertasListener = repository.observarOfertasConductor(
                        conductorId = conductorId,
                        onUpdate = { ofertas ->
                            if (_uiState.value.mensajeEstado?.contains("escuchar solicitudes", ignoreCase = true) == true) {
                                _uiState.value = _uiState.value.copy(mensajeEstado = null)
                            }
                            procesarOfertasEntrantes(conductorId, ofertas)
                        },
                        onError = { err ->
                            _uiState.value = _uiState.value.copy(
                                mensajeEstado = "Error al escuchar solicitudes en tiempo real: ${err.localizedMessage ?: err.javaClass.simpleName}"
                            )
                        }
                    )
                    misSolicitudesListener = repository.observarMisSolicitudesCambio(
                        uid = conductorId,
                        onError = { err ->
                            _uiState.value = _uiState.value.copy(
                                mensajeEstado = "Error al consultar solicitudes de cambio: ${err.localizedMessage ?: err.javaClass.simpleName}"
                            )
                        }
                    ) { lista ->
                        _uiState.value = _uiState.value.copy(
                            misSolicitudes = lista,
                            solicitudesCargadas = true
                        )
                    }
                }

                val (hoyCalc, mesCalc) = try {
                    repository.obtenerFinanzasConductor(conductorId)
                } catch (_: Throwable) {
                    Pair(_uiState.value.finanzas.gananciasHoy, _uiState.value.finanzas.gananciasMes)
                }
                finanzasCalculadasDesdeViajes = true
                _uiState.value = _uiState.value.copy(
                    finanzas = ConductorFinanzasSimple(gananciasHoy = hoyCalc, gananciasMes = mesCalc)
                )
                val viaje = repository.recuperarViajeActivoConductor(conductorId)
                val perfil = repository.obtenerPerfilYLicenciaConductor(conductorId)
                val pii = try {
                    repository.obtenerMiPii(conductorId)
                } catch (_: Throwable) {
                    null
                }
                val docs = try {
                    repository.obtenerMisDocumentosConductor(conductorId)
                } catch (_: Throwable) {
                    null
                }
                val telPii = (pii?.get("telefono") as? String)?.trim().orEmpty()
                _uiState.value = _uiState.value.copy(
                    telefonoConductor = telPii.ifBlank { _uiState.value.telefonoConductor },
                    fotoVehiculo = (docs?.get("fotoVehiculo") as? String) ?: _uiState.value.fotoVehiculo,
                    fotoCedula = (docs?.get("fotoCedula") as? String) ?: _uiState.value.fotoCedula,
                    fotoLicencia = (docs?.get("fotoLicencia") as? String) ?: _uiState.value.fotoLicencia,
                    fotoCirculacion = (docs?.get("fotoCirculacion") as? String) ?: _uiState.value.fotoCirculacion
                )
                val yaActivoEnProceso = ViajeRuralApp.conductorActivoEnProcesoUid == conductorId
                val esInicioSesion = estadoInicialReseteadoUid != conductorId && !yaActivoEnProceso
                estadoInicialReseteadoUid = conductorId

                if (viaje != null) {
                    val vId = viaje["id"] as? String
                    if (!vId.isNullOrBlank()) {
                        iniciarEscuchaViajeDocumento(vId, conductorId)
                    }
                    _uiState.value = _uiState.value.copy(viajeActivo = viaje)
                } else {
                    if (viajeDocListener == null) {
                        _uiState.value = _uiState.value.copy(viajeActivo = null)
                    }
                    if (esInicioSesion && !actualizandoDisponibilidadLock) {
                        // Solo al abrir la app por primera vez (arranque en frío tras cierre completo)
                        // sin viaje activo ni sesión activa en el proceso, inicia inactivo/desconectado.
                        detenerCicloGps(limpiarNotificacion = true)
                        appContext?.let { ConductorOnlineService.stop(it) }
                        _uiState.value = _uiState.value.copy(
                            disponible = false,
                            ofertaPendiente = null,
                            segundosOfertaRestantes = null
                        )
                        val estabaEnLineaEnNube = (perfil?.get("disponible") as? Boolean) == true ||
                            perfil?.get("estadoOperativo") == "activo" ||
                            perfil?.get("estadoOperativo") == "disponible"
                        if (estabaEnLineaEnNube) {
                            try {
                                repository.actualizarDisponibilidadConductor(
                                    conductorId = conductorId,
                                    disponible = false
                                )
                            } catch (_: Throwable) {
                            }
                        }
                    } else if (yaActivoEnProceso) {
                        _uiState.value = _uiState.value.copy(disponible = true)
                    }
                }
                if (perfil != null) {
                    val perfilAplicable = if (esInicioSesion && viaje == null) {
                        perfil + mapOf("disponible" to false, "estadoOperativo" to "inactivo")
                    } else if (yaActivoEnProceso && viaje == null) {
                        perfil + mapOf("disponible" to true, "estadoOperativo" to "activo")
                    } else {
                        perfil
                    }
                    aplicarPerfilConductor(perfilAplicable)
                }
                val ctx = context?.applicationContext ?: appContext
                val estadoViajeActual = viaje?.get("estado") as? String
                val vIdActual = viaje?.get("id") as? String
                val oLatActual = (viaje?.get("origenLat") as? Number)?.toDouble()
                val oLngActual = (viaje?.get("origenLng") as? Number)?.toDouble()
                if (ctx != null) {
                    when {
                        estadoViajeActual == "aceptado" && !vIdActual.isNullOrBlank() && oLatActual != null && oLngActual != null -> {
                            ConductorOnlineService.start(ctx, conductorId)
                            iniciarModoRecogida90Seg(ctx, conductorId, vIdActual, oLatActual, oLngActual)
                        }
                        estadoViajeActual == "en_curso" -> {
                            ConductorOnlineService.start(ctx, conductorId)
                            detenerCicloGps(limpiarNotificacion = true)
                        }
                        (_uiState.value.disponible || yaActivoEnProceso) && gpsRunnable == null -> {
                            ConductorOnlineService.start(ctx, conductorId)
                            iniciarModoEspera15Min(ctx, conductorId)
                        }
                    }
                }
            } catch (e: Exception) {
                perfilObservadoUid = null
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo sincronizar datos del conductor."
                )
            }
        }
    }

    fun cargarMisSolicitudes(conductorId: String) {
        viewModelScope.launch {
            try {
                val lista = repository.obtenerMisSolicitudesCambio(conductorId)
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = lista,
                    solicitudesCargadas = true
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(solicitudesCargadas = true)
            }
        }
    }

    fun enviarSolicitudCambioGranularConductor(
        conductorId: String,
        items: List<CambioItemData>,
        motivo: String
    ) {
        if (items.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                val st = _uiState.value
                val creada = repository.crearSolicitudCambioLineas(
                    solicitanteUid = conductorId,
                    rol = "conductor",
                    nombreActual = st.nombreConductor.ifBlank { "Conductor Rural" },
                    resumenActual = "${st.vehiculoTipo.ifBlank { "Vehículo" }} · Placa ${st.placa.ifBlank { "-" }}",
                    items = items,
                    motivo = motivo
                )
                val sinDuplicado = _uiState.value.misSolicitudes.filterNot { it.id == creada.id }
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = listOf(creada) + sinDuplicado,
                    solicitudesCargadas = true,
                    mensajeEstado = "Petición con ${creada.items.size} cambio(s) enviada al Administrador."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo enviar la petición."
                )
            }
        }
    }

    fun enviarSolicitudCambioConductor(
        conductorId: String,
        cambios: Map<String, Any>,
        motivo: String
    ) {
        if (cambios.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                val st = _uiState.value
                val mapaActual = mapOf<String, Any>(
                    "nombre" to st.nombreConductor,
                    "telefono" to st.telefonoConductor,
                    "vehiculoTipo" to st.vehiculoTipo,
                    "vehiculoMarca" to st.vehiculoMarca,
                    "vehiculoModelo" to st.vehiculoModelo,
                    "vehiculoColor" to st.vehiculoColor,
                    "vehiculoAnio" to st.vehiculoAnio,
                    "placa" to st.placa,
                    "capacidad" to st.capacidad
                )
                val datosAnteriores = mutableMapOf<String, Any>()
                cambios.keys.forEach { clave ->
                    val prev = mapaActual[clave]
                    when (prev) {
                        is Number -> datosAnteriores[clave] = prev.toInt()
                        is String -> if (prev.isNotBlank()) datosAnteriores[clave] = prev.trim()
                    }
                }
                val creada = repository.crearSolicitudCambioDatos(
                    solicitanteUid = conductorId,
                    rol = "conductor",
                    nombreActual = st.nombreConductor.ifBlank { "Conductor Rural" },
                    resumenActual = "${st.vehiculoTipo.ifBlank { "Vehículo" }} · Placa ${st.placa.ifBlank { "-" }}",
                    cambios = cambios,
                    motivo = motivo,
                    datosAnteriores = datosAnteriores
                )
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = listOf(creada) + _uiState.value.misSolicitudes,
                    solicitudesCargadas = true,
                    mensajeEstado = "Petición enviada al Administrador para su aprobación."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo enviar la petición."
                )
            }
        }
    }

    fun actualizarTarifasYEquipamiento(
        conductorId: String,
        tarifaBase: Double,
        tarifaPorKm: Double,
        tarifaBaseCarga: Double?,
        tieneCascoExtra: Boolean,
        tieneCapaDisponible: Boolean
    ) {
        viewModelScope.launch {
            try {
                val tipo = _uiState.value.vehiculoTipo
                repository.actualizarTarifasYEquipamientoConductor(
                    conductorId = conductorId,
                    vehiculoTipo = tipo,
                    tarifaBase = tarifaBase,
                    tarifaPorKm = tarifaPorKm,
                    tarifaBaseCarga = tarifaBaseCarga,
                    tieneCascoExtra = tieneCascoExtra,
                    tieneCapaDisponible = tieneCapaDisponible
                )
                _uiState.value = _uiState.value.copy(
                    tarifaBase = tarifaBase.coerceIn(500.0, 50000.0),
                    tarifaPorKm = tarifaPorKm.coerceIn(100.0, 10000.0),
                    tarifaBaseCarga = if (ViajeRepository.esVehiculoCargo(tipo)) {
                        tarifaBaseCarga?.takeIf { it >= 500.0 }?.coerceIn(500.0, 150000.0)
                    } else null,
                    tieneCascoExtra = if (ViajeRepository.esVehiculoMoto(tipo)) tieneCascoExtra else false,
                    tieneCapaDisponible = if (ViajeRepository.esVehiculoMoto(tipo)) tieneCapaDisponible else false,
                    mensajeEstado = "Tarifas y equipamiento actualizados correctamente."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudieron guardar tus tarifas."
                )
            }
        }
    }

    fun cargarHistorial(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargandoHistorial = true)
            try {
                val lista = repository.obtenerHistorialConductor(conductorId, 150L)
                _uiState.value = _uiState.value.copy(
                    historial = lista,
                    historialCargado = true,
                    cargandoHistorial = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(cargandoHistorial = false)
            }
        }
    }

    fun finalizarViaje(viajeId: String, conductorId: String, pasajeroId: String, montoCobrado: Double) {
        viewModelScope.launch {
            try {
                val gps = appContext?.let {
                    try {
                        repository.obtenerUbicacionUnicaGps(it)
                    } catch (_: Throwable) {
                        null
                    }
                }
                repository.finalizarViajeConFinanzas(
                    viajeId = viajeId,
                    conductorId = conductorId,
                    montoCobrado = montoCobrado,
                    lat = gps?.first,
                    lng = gps?.second
                )
                detenerCicloGps(limpiarNotificacion = true)
                val (hoy, mes) = repository.obtenerFinanzasConductor(conductorId)
                finanzasCalculadasDesdeViajes = true
                val historialActualizado = if (_uiState.value.historialCargado) {
                    try {
                        repository.obtenerHistorialConductor(conductorId, 20L)
                    } catch (_: Exception) {
                        _uiState.value.historial
                    }
                } else {
                    _uiState.value.historial
                }
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    disponible = true,
                    errorPin = null,
                    historial = historialActualizado,
                    historialCargado = _uiState.value.historialCargado,
                    finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
                    mostrarModalCobro = true,
                    montoACobrar = montoCobrado,
                    ultimoViajeId = viajeId,
                    ultimoPasajeroId = pasajeroId
                )
                val ctx = appContext
                if (ctx != null) {
                    ConductorOnlineService.start(ctx, conductorId)
                    iniciarModoEspera15Min(ctx, conductorId)
                } else {
                    ViajeRuralApp.conductorActivoEnProcesoUid = conductorId
                }
                procesarOfertasEntrantes(conductorId)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "Error al finalizar el viaje."
                )
            }
        }
    }

    fun calificarPasajero(conductorId: String, estrellas: Int, comentario: String) {
        val viajeId = _uiState.value.ultimoViajeId ?: return
        val pasajeroId = _uiState.value.ultimoPasajeroId ?: return
        viewModelScope.launch {
            try {
                repository.enviarCalificacionYActualizarPromedio(
                    viajeId = viajeId,
                    autorUid = conductorId,
                    destinatarioUid = pasajeroId,
                    destinatarioRol = "pasajero",
                    estrellas = estrellas,
                    comentario = comentario
                )
                val gps = appContext?.let {
                    try {
                        repository.obtenerUbicacionUnicaGps(it)
                    } catch (_: Throwable) {
                        null
                    }
                }
                if (gps != null) {
                    repository.actualizarUbicacionPostViajeConductor(
                        conductorId = conductorId,
                        lat = gps.first,
                        lng = gps.second
                    )
                }
            } catch (_: Exception) {
            } finally {
                _uiState.value = _uiState.value.copy(
                    mostrarModalCobro = false,
                    errorPin = null,
                    historialCargado = false
                )
            }
        }
    }

    fun cancelarViajeActivo(viajeId: String, conductorId: String, motivo: String) {
        if (motivo.trim().length < 3) return
        cancelacionPropiaViajeId = viajeId
        viajeDocListener?.remove()
        viajeDocListener = null
        viajeDocObservadoId = null
        viewModelScope.launch {
            try {
                repository.cancelarViajeConMotivo(
                    viajeId = viajeId,
                    canceladoPor = "conductor",
                    motivo = motivo,
                    conductorId = conductorId
                )
                detenerCicloGps(limpiarNotificacion = true)
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    disponible = true,
                    mensajeEstado = "Viaje cancelado. Motivo registrado: ${motivo.trim()}"
                )
                val ctx = appContext
                if (ctx != null) {
                    ConductorOnlineService.start(ctx, conductorId)
                    iniciarModoEspera15Min(ctx, conductorId)
                } else {
                    ViajeRuralApp.conductorActivoEnProcesoUid = conductorId
                }
                procesarOfertasEntrantes(conductorId)
            } catch (e: Exception) {
                cancelacionPropiaViajeId = null
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo cancelar el viaje."
                )
            }
        }
    }

    fun onViajeCanceladoPorPasajero(pasajeroNombre: String, motivo: String) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            disponible = true,
            avisoCancelacionFlotante = "$pasajeroNombre canceló el viaje: \"$motivo\""
        )
    }

    fun limpiarAvisoCancelacionFlotante() {
        _uiState.value = _uiState.value.copy(avisoCancelacionFlotante = null)
    }

    fun cerrarModalCobro() {
        _uiState.value = _uiState.value.copy(mostrarModalCobro = false)
    }
}

// =============================================================================
// 3. ADMIN VIEWMODEL (Pestañas Modulares, Lazy limit(20), Fichas en Modal)
// =============================================================================
enum class AdminSeccion { RESUMEN, PENDIENTES, CONDUCTORES, PASAJEROS, SOLICITUDES, ALERTAS, DUPLICADOS, CONFIGURACION }

data class ConductorAdminItem(
    val uid: String,
    val nombre: String,
    val placa: String,
    val vehiculoTipo: String,
    val tarifaBase: Double,
    val tarifaPorKm: Double,
    val tarifaBaseCarga: Double? = null,
    val gananciasMes: Double,
    val esTarifaAbusiva: Boolean,
    val esTarifaCargaAbusiva: Boolean = false,
    val tieneCascoExtra: Boolean = false,
    val tieneCapaDisponible: Boolean = false,
    val estadoCuenta: String,
    val cedulaHash: String = "",
    val diasLicenciaRestantes: Int = 30,
    val etiquetaLicencia: String = "Quedan 30 días",
    val estadoLicencia: String = "vigente",
    val fechaLicenciaTexto: String = "",
    val telefono: String = "",
    val email: String = "",
    val vehiculoMarca: String = "",
    val vehiculoModelo: String = "",
    val vehiculoColor: String = "",
    val vehiculoAnio: String = "",
    val capacidad: Int = 4,
    val mensualidadPendiente: Boolean = false,
    val licenciaExpMillis: Long? = null,
    val docVehiculoAprobado: Boolean = false,
    val docCedulaAprobado: Boolean = false,
    val docLicenciaAprobado: Boolean = false,
    val docCirculacionAprobado: Boolean = false
)

data class ViajeAlertaCobroUi(
    val id: String,
    val pasajeroNombre: String,
    val conductorNombre: String,
    val vehiculoTipo: String,
    val origenNombre: String,
    val destinoNombre: String,
    val esCargaFlete: Boolean,
    val montoAproximado: Double,
    val montoCobrado: Double,
    val montoReferenciaPromedio: Double,
    val limiteMaximoPermitido: Double,
    val updatedAtMillis: Long = 0L
)

data class ConductorDocumentosUi(
    val fotoVehiculo: String = "",
    val fotoCedula: String = "",
    val fotoLicencia: String = "",
    val fotoCirculacion: String = ""
)

data class PasajeroAdminItem(
    val uid: String,
    val nombre: String,
    val promedioCalificacion: Double,
    val bloqueado: Boolean,
    val telefono: String = "",
    val email: String = "",
    val cedula: String = ""
)

data class VehiculoTipoUi(
    val nombre: String,
    val maxPasajeros: Int,
    val descripcion: String = ""
)

data class ConfiguracionGeneralUi(
    val whatsappSoporte: String = "62546546",
    val sinpeNumero: String = "62546546",
    val sinpeTitular: String = "Administración Viaje Rural",
    val adminNombre: String = "Administrador Viaje Rural",
    val adminTelefono: String = "62546546",
    val adminEmail: String = "sindicatosiserge@gmail.com",
    val linkDescarga: String = ViajeRepository.DEFAULT_LINK_DESCARGA,
    val terminosCondiciones: String = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR,
    val terminosCondicionesPasajero: String = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO,
    val montoMensualConductorBase: Int = ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
    val anioBaseMensualidad: Int = ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD,
    val multiplicadorTopeNormal: Double = ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_NORMAL,
    val multiplicadorTopeCarga: Double = ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_CARGA,
    val tiposVehiculo: List<VehiculoTipoUi> = emptyList()
)

data class AdminUiState(
    val seccionActual: AdminSeccion = AdminSeccion.RESUMEN,
    val resumen: AdminResumenLigero = AdminResumenLigero(),
    val pendientes: List<ConductorAdminItem> = emptyList(),
    val pendientesCargados: Boolean = false,
    val conductores: List<ConductorAdminItem> = emptyList(),
    val conductoresCargados: Boolean = false,
    val viajesCobroExcesivo: List<ViajeAlertaCobroUi> = emptyList(),
    val pasajeros: List<PasajeroAdminItem> = emptyList(),
    val pasajerosCargados: Boolean = false,
    val solicitudesCambio: List<SolicitudCambioData> = emptyList(),
    val solicitudesPendientesCount: Int = 0,
    val solicitudesCargadas: Boolean = false,
    val conductorSeleccionado: ConductorAdminItem? = null,
    val documentosConductorSeleccionado: ConductorDocumentosUi? = null,
    val cargandoDocumentos: Boolean = false,
    val aprobandoConductor: Boolean = false,
    val renovandoLicencia: Boolean = false,
    val guardandoFichaConductor: Boolean = false,
    val pasajeroSeleccionado: PasajeroAdminItem? = null,
    val gestionandoPasajero: Boolean = false,
    val configuracion: ConfiguracionGeneralUi = ConfiguracionGeneralUi(),
    val promedioBaseFlota: Double = ViajeRepository.DEFAULT_TARIFA_BASE_NORMAL,
    val promedioBaseCargaFlota: Double = ViajeRepository.DEFAULT_TARIFA_BASE_CARGA,
    val promedioKmFlota: Double = ViajeRepository.DEFAULT_TARIFA_KM,
    val cargando: Boolean = false,
    val errorMensaje: String? = null,
    val accionMensaje: String? = null
)

class AdminViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    private var solicitudesPendientesListener: ListenerRegistration? = null
    private var appContext: Context? = null
    private var escuchaSolicitudesInicializada = false
    private val solicitudesPendientesNotificadas = LinkedHashSet<String>()
    private var solicitudesResueltasCache: List<SolicitudCambioData> = emptyList()

    override fun onCleared() {
        solicitudesPendientesListener?.remove()
        solicitudesPendientesListener = null
        super.onCleared()
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseConfiguracionUi(rawConfig: Map<String, Any>): ConfiguracionGeneralUi {
        val tiposRaw = (rawConfig["tiposVehiculo"] as? List<Map<String, Any>>).orEmpty()
        val tiposUi = tiposRaw.map { t ->
            VehiculoTipoUi(
                nombre = t["nombre"] as? String ?: "",
                maxPasajeros = (t["maxPasajeros"] as? Number)?.toInt() ?: 4,
                descripcion = t["descripcion"] as? String ?: ""
            )
        }
        return ConfiguracionGeneralUi(
            whatsappSoporte = rawConfig["whatsappSoporte"] as? String ?: "62546546",
            sinpeNumero = rawConfig["sinpeNumero"] as? String ?: "62546546",
            sinpeTitular = rawConfig["adminSinpeTitular"] as? String ?: "Administración Viaje Rural",
            adminNombre = rawConfig["adminNombre"] as? String ?: "Administrador Viaje Rural",
            adminTelefono = rawConfig["adminTelefono"] as? String ?: "62546546",
            adminEmail = rawConfig["adminEmail"] as? String ?: "sindicatosiserge@gmail.com",
            linkDescarga = (rawConfig["linkDescarga"] as? String)?.trim()?.takeIf { it.isNotBlank() }
                ?: ViajeRepository.DEFAULT_LINK_DESCARGA,
            terminosCondiciones = (rawConfig["terminosCondiciones"] as? String)
                ?.trim()
                ?.takeIf { it.length >= 20 }
                ?: ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR,
            terminosCondicionesPasajero = (rawConfig["terminosCondicionesPasajero"] as? String)
                ?.trim()
                ?.takeIf { it.length >= 20 }
                ?: ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_PASAJERO,
            montoMensualConductorBase = (rawConfig["montoMensualConductorBase"] as? Number)
                ?.toInt()
                ?.coerceIn(500, 1_000_000)
                ?: ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
            anioBaseMensualidad = (rawConfig["anioBaseMensualidad"] as? Number)
                ?.toInt()
                ?.coerceIn(2020, 2100)
                ?: ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD,
            multiplicadorTopeNormal = ((rawConfig["multiplicadorTopeNormal"] as? Number)?.toDouble()
                ?: ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_NORMAL).coerceIn(1.1, 5.0),
            multiplicadorTopeCarga = ((rawConfig["multiplicadorTopeCarga"] as? Number)?.toDouble()
                ?: ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_CARGA).coerceIn(1.1, 5.0),
            tiposVehiculo = tiposUi
        )
    }

    private fun mapConductoresUi(
        rawConductores: List<Map<String, Any>>,
        promedioBase: Double = ViajeRepository.DEFAULT_TARIFA_BASE_NORMAL,
        promedioKm: Double = ViajeRepository.DEFAULT_TARIFA_KM,
        promedioBaseCarga: Double = ViajeRepository.DEFAULT_TARIFA_BASE_CARGA
    ): List<ConductorAdminItem> {
        return rawConductores.map { c ->
            val tBase = (c["tarifaBase"] as? Number)?.toDouble() ?: 0.0
            val tKm = (c["tarifaPorKm"] as? Number)?.toDouble() ?: 0.0
            val tCarga = (c["tarifaBaseCarga"] as? Number)?.toDouble()
            val vehiculoTipo = c["vehiculoTipo"] as? String ?: ""
            val esCargaAbusiva = ViajeRepository.esVehiculoCargo(vehiculoTipo) &&
                tCarga != null && tCarga > promedioBaseCarga * 1.30
            val abusiva = tBase > promedioBase * 1.30 || tKm > promedioKm * 1.30 || esCargaAbusiva
            val licInfo = calcularDiasLicenciaRestantes(c["licenciaExp"])
            val estadoCuenta = c["estadoCuenta"] as? String ?: "pendiente"
            val docFallback = estadoCuenta == "activo"
            ConductorAdminItem(
                uid = c["uid"] as? String ?: "",
                nombre = c["nombre"] as? String ?: "",
                placa = c["placa"] as? String ?: "",
                vehiculoTipo = vehiculoTipo,
                tarifaBase = tBase,
                tarifaPorKm = tKm,
                tarifaBaseCarga = tCarga,
                gananciasMes = (c["gananciasMes"] as? Number)?.toDouble() ?: 0.0,
                esTarifaAbusiva = abusiva,
                esTarifaCargaAbusiva = esCargaAbusiva,
                tieneCascoExtra = (c["tieneCascoExtra"] as? Boolean) == true,
                tieneCapaDisponible = (c["tieneCapaDisponible"] as? Boolean) == true,
                estadoCuenta = estadoCuenta,
                cedulaHash = c["cedulaHash"] as? String ?: "",
                diasLicenciaRestantes = licInfo.dias,
                etiquetaLicencia = licInfo.etiqueta,
                estadoLicencia = licInfo.estado,
                fechaLicenciaTexto = licInfo.fechaTexto,
                vehiculoMarca = c["vehiculoMarca"] as? String ?: "",
                vehiculoModelo = c["vehiculoModelo"] as? String ?: "",
                vehiculoColor = c["vehiculoColor"] as? String ?: "",
                vehiculoAnio = c["vehiculoAnio"] as? String ?: "",
                capacidad = (c["capacidad"] as? Number)?.toInt() ?: 4,
                mensualidadPendiente = c["mensualidadPendiente"] as? Boolean ?: false,
                licenciaExpMillis = parseLicenciaExpMillis(c["licenciaExp"]),
                docVehiculoAprobado = c["docVehiculoAprobado"] as? Boolean ?: docFallback,
                docCedulaAprobado = c["docCedulaAprobado"] as? Boolean ?: docFallback,
                docLicenciaAprobado = c["docLicenciaAprobado"] as? Boolean ?: docFallback,
                docCirculacionAprobado = c["docCirculacionAprobado"] as? Boolean ?: docFallback
            )
        }
    }

    private fun etiquetarCampoCambio(clave: String): String = when (clave) {
        "nombre" -> "Nombre"
        "telefono" -> "Teléfono"
        "email" -> "Correo"
        "cedula" -> "Cédula"
        "vehiculoTipo" -> "Tipo vehículo"
        "vehiculoMarca" -> "Marca"
        "vehiculoModelo" -> "Modelo"
        "vehiculoColor" -> "Color"
        "vehiculoAnio" -> "Año"
        "placa" -> "Placa"
        "capacidad" -> "Capacidad"
        "tarifaBase" -> "Tarifa base (₡)"
        "tarifaBaseCarga" -> "Tarifa base carga / flete (₡)"
        "precioKm", "tarifaPorKm" -> "Precio por km (₡)"
        "tieneCascoExtra" -> "Casco extra (Moto)"
        "tieneCapaDisponible" -> "Capa impermeable (Moto)"
        else -> clave
    }

    private fun combinarSolicitudesConCache(pendientes: List<SolicitudCambioData>): List<SolicitudCambioData> {
        val idsPendientes = pendientes.map { it.id }.toSet()
        val resueltas = solicitudesResueltasCache.filter { it.id !in idsPendientes && !it.tienePendientes }
        return (pendientes + resueltas).sortedWith(
            compareBy<SolicitudCambioData> { if (it.tienePendientes) 0 else 1 }
                .thenByDescending { it.createdAtMillis }
        )
    }

    fun iniciarEscuchaSolicitudesTiempoReal(context: Context) {
        val appCtx = context.applicationContext
        appContext = appCtx
        NotificationHelper.crearTodosLosCanales(appCtx)
        if (solicitudesPendientesListener != null) return

        solicitudesPendientesListener = repository.observarSolicitudesCambioPendientesAdmin(
            onUpdate = { pendientes ->
                val conPendientes = pendientes.filter { it.tienePendientes }
                if (!escuchaSolicitudesInicializada) {
                    escuchaSolicitudesInicializada = true
                    conPendientes.forEach { solicitudesPendientesNotificadas.add(it.id) }
                } else {
                    conPendientes.forEach { sol ->
                        if (solicitudesPendientesNotificadas.add(sol.id)) {
                            val resumen = if (sol.items.isNotEmpty()) {
                                sol.items.joinToString(", ") { it.etiqueta }
                            } else {
                                sol.cambios.keys.joinToString(", ") { etiquetarCampoCambio(it) }
                            }
                            NotificationHelper.mostrarNotificacionAdminSolicitudCambio(
                                context = appCtx,
                                solicitudId = sol.id,
                                nombreConductor = sol.nombreActual,
                                resumenCambios = resumen
                            )
                        }
                    }
                }
                val combinadas = combinarSolicitudesConCache(conPendientes)
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = combinadas,
                    solicitudesPendientesCount = conPendientes.size,
                    solicitudesCargadas = true,
                    resumen = _uiState.value.resumen.copy(solicitudesPendientes = conPendientes.size.toLong())
                )
            }
        )
    }

    fun cargarResumenInicial() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val resumen = repository.obtenerResumenAdminLigero()
                val rawConfig = try {
                    repository.obtenerConfiguracionGeneral()
                } catch (_: Exception) {
                    null
                }
                val configUi = rawConfig?.let { parseConfiguracionUi(it) } ?: _uiState.value.configuracion
                _uiState.value = _uiState.value.copy(
                    resumen = resumen,
                    configuracion = configUi,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = "Panel Administrador activo. Inicia sesión con cuenta admin para sincronizar datos en la nube (${e.localizedMessage ?: "sin conexión"})."
                )
            }
        }
    }

    /**
     * Carga cada pestaña bajo demanda con limit(20) ÚNICAMENTE cuando el Admin la toca.
     */
    fun seleccionarSeccion(seccion: AdminSeccion) {
        _uiState.value = _uiState.value.copy(seccionActual = seccion, accionMensaje = null)
        when (seccion) {
            AdminSeccion.RESUMEN -> cargarResumenInicial()
            AdminSeccion.PENDIENTES -> cargarPendientesLazy()
            AdminSeccion.CONDUCTORES, AdminSeccion.DUPLICADOS -> {
                if (!_uiState.value.conductoresCargados) cargarConductoresLazy()
            }
            AdminSeccion.ALERTAS -> {
                if (!_uiState.value.conductoresCargados) cargarConductoresLazy()
                cargarViajesCobroExcesivo()
            }
            AdminSeccion.PASAJEROS -> {
                if (!_uiState.value.pasajerosCargados) cargarPasajerosLazy()
            }
            AdminSeccion.SOLICITUDES -> {
                cargarSolicitudesCambioLazy()
            }
            AdminSeccion.CONFIGURACION -> cargarConfiguracion()
        }
    }

    fun cargarPendientesLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawPendientes = repository.obtenerConductoresPendientesAdmin(20L)
                val lista = mapConductoresUi(rawPendientes)
                _uiState.value = _uiState.value.copy(
                    pendientes = lista,
                    pendientesCargados = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los conductores pendientes."
                )
            }
        }
    }

    fun cargarSolicitudesCambioLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val lista = repository.obtenerSolicitudesCambioAdmin(30L)
                solicitudesResueltasCache = lista.filter { !it.tienePendientes }
                val pendientesActuales = if (solicitudesPendientesListener != null) {
                    _uiState.value.solicitudesCambio.filter { it.tienePendientes }
                        .ifEmpty { lista.filter { it.tienePendientes } }
                } else {
                    lista.filter { it.tienePendientes }
                }
                val combinadas = combinarSolicitudesConCache(pendientesActuales)
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = combinadas,
                    solicitudesPendientesCount = pendientesActuales.size,
                    solicitudesCargadas = true,
                    resumen = _uiState.value.resumen.copy(solicitudesPendientes = pendientesActuales.size.toLong()),
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar las peticiones."
                )
            }
        }
    }

    fun resolverLineaSolicitudCambio(
        solicitud: SolicitudCambioData,
        claveItem: String,
        aprobar: Boolean,
        motivoRechazo: String = ""
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(errorMensaje = null)
            try {
                val actualizada = repository.resolverLineaSolicitudCambioAdmin(
                    solicitudId = solicitud.id,
                    claveItem = claveItem,
                    aprobar = aprobar,
                    motivoRechazo = motivoRechazo
                )
                if (!actualizada.tienePendientes) {
                    solicitudesResueltasCache = listOf(actualizada) + solicitudesResueltasCache.filterNot { it.id == solicitud.id }
                }
                val actualizadas = _uiState.value.solicitudesCambio
                    .map { if (it.id == solicitud.id) actualizada else it }
                    .sortedWith(
                        compareBy<SolicitudCambioData> { if (it.tienePendientes) 0 else 1 }
                            .thenByDescending { it.createdAtMillis }
                    )
                val pendCount = actualizadas.count { it.tienePendientes }
                val etiqueta = actualizada.items.firstOrNull { it.clave == claveItem }?.etiqueta
                    ?: etiquetaCambioPorClave(claveItem)
                val msg = if (aprobar) {
                    "'$etiqueta' aprobado y aplicado en la ficha oficial."
                } else {
                    "'$etiqueta' rechazado."
                }
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = actualizadas,
                    solicitudesPendientesCount = pendCount,
                    resumen = _uiState.value.resumen.copy(solicitudesPendientes = pendCount.toLong()),
                    conductoresCargados = if (aprobar && solicitud.rol == "conductor") false else _uiState.value.conductoresCargados,
                    pasajerosCargados = if (aprobar && solicitud.rol == "pasajero") false else _uiState.value.pasajerosCargados,
                    accionMensaje = msg
                )
                if (!actualizada.tienePendientes) {
                    cargarResumenInicial()
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo procesar el cambio solicitado."
                )
            }
        }
    }

    fun resolverSolicitudCambio(
        solicitud: SolicitudCambioData,
        aprobar: Boolean,
        respuestaAdmin: String = ""
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(errorMensaje = null)
            try {
                repository.resolverSolicitudCambioAdmin(solicitud, aprobar, respuestaAdmin)
                val itemsResueltos = solicitud.items.map {
                    it.copy(
                        estado = if (aprobar) "aprobado" else "rechazado",
                        motivoRechazo = if (aprobar) "" else respuestaAdmin.trim().take(240)
                    )
                }
                val resuelta = solicitud.copy(
                    items = itemsResueltos,
                    estado = if (aprobar) "aprobada" else "rechazada",
                    estadoGeneral = "completada",
                    respuestaAdmin = respuestaAdmin
                )
                solicitudesResueltasCache = listOf(resuelta) + solicitudesResueltasCache.filterNot { it.id == solicitud.id }
                val actualizadas = _uiState.value.solicitudesCambio
                    .map { if (it.id == solicitud.id) resuelta else it }
                    .sortedWith(
                        compareBy<SolicitudCambioData> { if (it.tienePendientes) 0 else 1 }
                            .thenByDescending { it.createdAtMillis }
                    )
                val pendCount = actualizadas.count { it.tienePendientes }
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = actualizadas,
                    solicitudesPendientesCount = pendCount,
                    resumen = _uiState.value.resumen.copy(solicitudesPendientes = pendCount.toLong()),
                    conductoresCargados = if (aprobar && solicitud.rol == "conductor") false else _uiState.value.conductoresCargados,
                    pasajerosCargados = if (aprobar && solicitud.rol == "pasajero") false else _uiState.value.pasajerosCargados,
                    accionMensaje = if (aprobar) "Solicitud aprobada y cambios aplicados." else "Solicitud rechazada."
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo procesar la petición."
                )
            }
        }
    }

    fun cargarViajesCobroExcesivo() {
        viewModelScope.launch {
            try {
                val rawViajes = repository.obtenerViajesCobroExcesivoAdmin(30L)
                val alertas = rawViajes.map { v ->
                    ViajeAlertaCobroUi(
                        id = v["id"] as? String ?: "",
                        pasajeroNombre = v["pasajeroNombre"] as? String ?: "Pasajero",
                        conductorNombre = v["conductorNombre"] as? String ?: "Conductor",
                        vehiculoTipo = v["vehiculoTipoSeleccionado"] as? String ?: "",
                        origenNombre = v["origenNombre"] as? String ?: "",
                        destinoNombre = v["destinoNombre"] as? String ?: "",
                        esCargaFlete = (v["esCargaFlete"] as? Boolean) == true,
                        montoAproximado = (v["montoAproximado"] as? Number)?.toDouble() ?: 0.0,
                        montoCobrado = (v["montoCobrado"] as? Number)?.toDouble() ?: 0.0,
                        montoReferenciaPromedio = (v["montoReferenciaPromedio"] as? Number)?.toDouble() ?: 0.0,
                        limiteMaximoPermitido = (v["limiteMaximoPermitido"] as? Number)?.toDouble() ?: 0.0,
                        updatedAtMillis = parseLicenciaExpMillis(v["updatedAt"]) ?: 0L
                    )
                }
                _uiState.value = _uiState.value.copy(viajesCobroExcesivo = alertas)
            } catch (_: Exception) {
            }
        }
    }

    fun cargarConductoresLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawConductores = repository.obtenerConductoresAdmin(20L)
                val bases = rawConductores.mapNotNull { (it["tarifaBase"] as? Number)?.toDouble() }
                val kms = rawConductores.mapNotNull { (it["tarifaPorKm"] as? Number)?.toDouble() }
                val cargas = rawConductores.filter {
                    ViajeRepository.esVehiculoCargo(it["vehiculoTipo"] as? String ?: "")
                }.mapNotNull { (it["tarifaBaseCarga"] as? Number)?.toDouble()?.takeIf { c -> c >= 500.0 } }

                val promedioBase = if (bases.isNotEmpty()) bases.average() else ViajeRepository.DEFAULT_TARIFA_BASE_NORMAL
                val promedioKm = if (kms.isNotEmpty()) kms.average() else ViajeRepository.DEFAULT_TARIFA_KM
                val promedioBaseCarga = if (cargas.isNotEmpty()) cargas.average() else ViajeRepository.DEFAULT_TARIFA_BASE_CARGA

                val conductoresUi = mapConductoresUi(rawConductores, promedioBase, promedioKm, promedioBaseCarga)
                _uiState.value = _uiState.value.copy(
                    conductores = conductoresUi,
                    conductoresCargados = true,
                    promedioBaseFlota = promedioBase,
                    promedioBaseCargaFlota = promedioBaseCarga,
                    promedioKmFlota = promedioKm,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los conductores."
                )
            }
        }
    }

    fun cargarPasajerosLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawPasajeros = repository.obtenerPasajerosAdmin(20L)
                val pasajerosUi = rawPasajeros.map { p ->
                    PasajeroAdminItem(
                        uid = p["uid"] as? String ?: "",
                        nombre = p["nombre"] as? String ?: "",
                        promedioCalificacion = (p["promedioCalificacion"] as? Number)?.toDouble() ?: 5.0,
                        bloqueado = p["bloqueado"] as? Boolean ?: false
                    )
                }
                _uiState.value = _uiState.value.copy(
                    pasajeros = pasajerosUi,
                    pasajerosCargados = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los pasajeros."
                )
            }
        }
    }

    fun cargarConfiguracion() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawConfig = repository.obtenerConfiguracionGeneral()
                val configUi = parseConfiguracionUi(rawConfig)
                _uiState.value = _uiState.value.copy(configuracion = configUi, cargando = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo cargar la configuración."
                )
            }
        }
    }

    fun seleccionarConductor(conductor: ConductorAdminItem) {
        _uiState.value = _uiState.value.copy(
            conductorSeleccionado = conductor,
            documentosConductorSeleccionado = null,
            cargandoDocumentos = true
        )
        viewModelScope.launch {
            val rawDocs = try {
                repository.obtenerDocumentosConductorAdmin(conductor.uid)
            } catch (_: Exception) {
                null
            }
            val pii = try {
                repository.obtenerPiiUsuarioAdmin(conductor.uid)
            } catch (_: Exception) {
                null
            }
            val docsUi = ConductorDocumentosUi(
                fotoVehiculo = rawDocs?.get("fotoVehiculo") as? String ?: "",
                fotoCedula = rawDocs?.get("fotoCedula") as? String ?: "",
                fotoLicencia = rawDocs?.get("fotoLicencia") as? String ?: "",
                fotoCirculacion = rawDocs?.get("fotoCirculacion") as? String ?: ""
            )
            val telefonoPii = (pii?.get("telefono") as? String)?.trim().orEmpty()
            val emailPii = (pii?.get("email") as? String)?.trim().orEmpty()
            val cedulaPii = (pii?.get("cedula") as? String)?.trim().orEmpty()
            val actualizado = _uiState.value.conductorSeleccionado?.let { actual ->
                if (actual.uid == conductor.uid) {
                    actual.copy(
                        telefono = telefonoPii.ifBlank { actual.telefono },
                        email = emailPii.ifBlank { actual.email },
                        cedulaHash = actual.cedulaHash.ifBlank { cedulaPii }
                    )
                } else {
                    actual
                }
            }
            _uiState.value = _uiState.value.copy(
                conductorSeleccionado = actualizado,
                documentosConductorSeleccionado = docsUi,
                cargandoDocumentos = false
            )
        }
    }

    fun cerrarFichaConductor() {
        _uiState.value = _uiState.value.copy(
            conductorSeleccionado = null,
            documentosConductorSeleccionado = null,
            cargandoDocumentos = false,
            renovandoLicencia = false,
            guardandoFichaConductor = false
        )
    }

    fun guardarFichaConductor(
        conductorId: String,
        nombre: String,
        telefono: String,
        cedula: String,
        vehiculoTipo: String,
        vehiculoMarca: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        estadoCuenta: String,
        mensualidadPendiente: Boolean,
        licenciaExpMillis: Long,
        docVehiculoAprobado: Boolean,
        docCedulaAprobado: Boolean,
        docLicenciaAprobado: Boolean,
        docCirculacionAprobado: Boolean,
        tarifaBaseCarga: Double? = null,
        tieneCascoExtra: Boolean = false,
        tieneCapaDisponible: Boolean = false,
        onExito: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(guardandoFichaConductor = true, errorMensaje = null)
            try {
                val expTs = repository.actualizarFichaConductorAdmin(
                    conductorId = conductorId,
                    nombre = nombre,
                    telefono = telefono,
                    cedula = cedula,
                    vehiculoTipo = vehiculoTipo,
                    vehiculoMarca = vehiculoMarca,
                    vehiculoModelo = vehiculoModelo,
                    vehiculoColor = vehiculoColor,
                    vehiculoAnio = vehiculoAnio,
                    placa = placa,
                    capacidad = capacidad,
                    tarifaBase = tarifaBase,
                    tarifaPorKm = tarifaPorKm,
                    estadoCuenta = estadoCuenta,
                    mensualidadPendiente = mensualidadPendiente,
                    licenciaExpMillis = licenciaExpMillis,
                    docVehiculoAprobado = docVehiculoAprobado,
                    docCedulaAprobado = docCedulaAprobado,
                    docLicenciaAprobado = docLicenciaAprobado,
                    docCirculacionAprobado = docCirculacionAprobado,
                    tarifaBaseCarga = tarifaBaseCarga,
                    tieneCascoExtra = tieneCascoExtra,
                    tieneCapaDisponible = tieneCapaDisponible
                )
                val licInfo = calcularDiasLicenciaRestantes(expTs)
                val promBase = _uiState.value.promedioBaseFlota
                val promBaseCarga = _uiState.value.promedioBaseCargaFlota
                val promKm = _uiState.value.promedioKmFlota
                val cargaLim = if (ViajeRepository.esVehiculoCargo(vehiculoTipo)) {
                    tarifaBaseCarga?.takeIf { it >= 500.0 }?.coerceIn(500.0, 150000.0)
                } else null
                val esCargaAbusiva = cargaLim != null && cargaLim > promBaseCarga * 1.30
                val esAbusiva = tarifaBase > promBase * 1.30 || tarifaPorKm > promKm * 1.30 || esCargaAbusiva
                val cascoFinal = ViajeRepository.esVehiculoMoto(vehiculoTipo) && tieneCascoExtra
                val capaFinal = ViajeRepository.esVehiculoMoto(vehiculoTipo) && tieneCapaDisponible
                val actualizarItem: (ConductorAdminItem) -> ConductorAdminItem = { item ->
                    if (item.uid == conductorId) {
                        item.copy(
                            nombre = nombre.trim(),
                            telefono = telefono.trim(),
                            vehiculoTipo = vehiculoTipo.trim(),
                            vehiculoMarca = vehiculoMarca.trim(),
                            vehiculoModelo = vehiculoModelo.trim(),
                            vehiculoColor = vehiculoColor.trim(),
                            vehiculoAnio = vehiculoAnio.trim(),
                            placa = placa.trim().uppercase(),
                            capacidad = capacidad.coerceIn(1, 24),
                            tarifaBase = tarifaBase.coerceIn(500.0, 50000.0),
                            tarifaPorKm = tarifaPorKm.coerceIn(100.0, 10000.0),
                            tarifaBaseCarga = cargaLim,
                            esTarifaAbusiva = esAbusiva,
                            esTarifaCargaAbusiva = esCargaAbusiva,
                            tieneCascoExtra = cascoFinal,
                            tieneCapaDisponible = capaFinal,
                            estadoCuenta = estadoCuenta,
                            mensualidadPendiente = mensualidadPendiente,
                            licenciaExpMillis = expTs.toDate().time,
                            diasLicenciaRestantes = licInfo.dias,
                            etiquetaLicencia = licInfo.etiqueta,
                            estadoLicencia = licInfo.estado,
                            fechaLicenciaTexto = licInfo.fechaTexto,
                            docVehiculoAprobado = docVehiculoAprobado,
                            docCedulaAprobado = docCedulaAprobado,
                            docLicenciaAprobado = docLicenciaAprobado,
                            docCirculacionAprobado = docCirculacionAprobado
                        )
                    } else item
                }
                val nuevasPendientes = if (estadoCuenta == "pendiente") {
                    _uiState.value.pendientes.map(actualizarItem)
                } else {
                    _uiState.value.pendientes.filterNot { it.uid == conductorId }
                }
                val msg = "Cambios guardados en la ficha de ${nombre.trim()}."
                _uiState.value = _uiState.value.copy(
                    guardandoFichaConductor = false,
                    conductorSeleccionado = _uiState.value.conductorSeleccionado?.let(actualizarItem),
                    conductores = _uiState.value.conductores.map(actualizarItem),
                    pendientes = nuevasPendientes,
                    accionMensaje = msg
                )
                cargarResumenInicial()
                onExito(msg)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    guardandoFichaConductor = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron guardar los cambios de la ficha."
                )
            }
        }
    }

    fun renovarLicenciaUnMes(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(renovandoLicencia = true, errorMensaje = null)
            try {
                val nuevaExp = repository.renovarLicenciaConductorAdmin(conductorId)
                val licInfo = calcularDiasLicenciaRestantes(nuevaExp)
                val actualizarItem: (ConductorAdminItem) -> ConductorAdminItem = { item ->
                    if (item.uid == conductorId) {
                        item.copy(
                            mensualidadPendiente = false,
                            licenciaExpMillis = nuevaExp.toDate().time,
                            diasLicenciaRestantes = licInfo.dias,
                            etiquetaLicencia = licInfo.etiqueta,
                            estadoLicencia = licInfo.estado,
                            fechaLicenciaTexto = licInfo.fechaTexto
                        )
                    } else item
                }
                _uiState.value = _uiState.value.copy(
                    renovandoLicencia = false,
                    conductorSeleccionado = _uiState.value.conductorSeleccionado?.let(actualizarItem),
                    conductores = _uiState.value.conductores.map(actualizarItem),
                    pendientes = _uiState.value.pendientes.map(actualizarItem),
                    accionMensaje = "Licencia renovada (+1 mes) hasta ${licInfo.fechaTexto}."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    renovandoLicencia = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo renovar la licencia."
                )
            }
        }
    }

    fun aprobarYActivarConductor(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(aprobandoConductor = true, errorMensaje = null)
            try {
                val nuevaExp = repository.aprobarYActivarConductorAdmin(conductorId)
                val licInfo = calcularDiasLicenciaRestantes(nuevaExp)
                _uiState.value = _uiState.value.copy(
                    aprobandoConductor = false,
                    conductorSeleccionado = null,
                    documentosConductorSeleccionado = null,
                    pendientes = _uiState.value.pendientes.filterNot { it.uid == conductorId },
                    conductores = _uiState.value.conductores.map {
                        if (it.uid == conductorId) {
                            it.copy(
                                estadoCuenta = "activo",
                                mensualidadPendiente = false,
                                licenciaExpMillis = nuevaExp.toDate().time,
                                diasLicenciaRestantes = licInfo.dias,
                                etiquetaLicencia = licInfo.etiqueta,
                                estadoLicencia = licInfo.estado,
                                fechaLicenciaTexto = licInfo.fechaTexto,
                                docVehiculoAprobado = true,
                                docCedulaAprobado = true,
                                docLicenciaAprobado = true,
                                docCirculacionAprobado = true
                            )
                        } else it
                    },
                    conductoresCargados = false,
                    accionMensaje = "Conductor aprobado y activado. Licencia vigente hasta ${licInfo.fechaTexto}."
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    aprobandoConductor = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo aprobar y activar el conductor."
                )
            }
        }
    }

    fun seleccionarPasajero(pasajero: PasajeroAdminItem) {
        viewModelScope.launch {
            try {
                val pii = repository.obtenerPiiUsuarioAdmin(pasajero.uid)
                _uiState.value = _uiState.value.copy(
                    pasajeroSeleccionado = pasajero.copy(
                        telefono = pii?.get("telefono") as? String ?: "",
                        email = pii?.get("email") as? String ?: "",
                        cedula = pii?.get("cedula") as? String ?: ""
                    )
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(pasajeroSeleccionado = pasajero)
            }
        }
    }

    fun guardarFichaPasajero(
        uid: String,
        nombre: String,
        telefono: String,
        email: String,
        cedula: String
    ) {
        viewModelScope.launch {
            try {
                repository.actualizarFichaPasajeroAdmin(uid, nombre, telefono, email, cedula)
                _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null)
                cargarPasajerosLazy()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo guardar el pasajero."
                )
            }
        }
    }

    fun toggleBloqueoPasajero(pasajero: PasajeroAdminItem) {
        val nuevoEstado = !pasajero.bloqueado
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(gestionandoPasajero = true, errorMensaje = null)
            try {
                repository.toggleBloqueoPasajeroAdmin(pasajero.uid, nuevoEstado)
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    pasajeroSeleccionado = _uiState.value.pasajeroSeleccionado?.copy(bloqueado = nuevoEstado),
                    pasajeros = _uiState.value.pasajeros.map {
                        if (it.uid == pasajero.uid) it.copy(bloqueado = nuevoEstado) else it
                    },
                    accionMensaje = if (nuevoEstado) "Pasajero bloqueado en Firestore." else "Pasajero desbloqueado en Firestore."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo actualizar el bloqueo del pasajero."
                )
            }
        }
    }

    fun eliminarCuentaPasajero(pasajeroId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(gestionandoPasajero = true, errorMensaje = null)
            try {
                repository.eliminarCuentaPasajeroAdmin(pasajeroId)
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    pasajeroSeleccionado = null,
                    pasajeros = _uiState.value.pasajeros.filterNot { it.uid == pasajeroId },
                    accionMensaje = "Cuenta del pasajero eliminada de Firestore."
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo eliminar la cuenta del pasajero."
                )
            }
        }
    }

    fun cerrarFichaPasajero() {
        _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null, gestionandoPasajero = false)
    }

    fun limpiarAccionMensaje() {
        _uiState.value = _uiState.value.copy(accionMensaje = null)
    }

    fun guardarConfiguracion(config: ConfiguracionGeneralUi) {
        viewModelScope.launch {
            try {
                val tiposMap = config.tiposVehiculo.map {
                    mapOf(
                        "nombre" to it.nombre,
                        "maxPasajeros" to it.maxPasajeros,
                        "descripcion" to it.descripcion
                    )
                }
                repository.guardarConfiguracionGeneralAdmin(
                    whatsappSoporte = config.whatsappSoporte,
                    sinpeNumero = config.sinpeNumero,
                    sinpeTitular = config.sinpeTitular,
                    adminNombre = config.adminNombre,
                    adminTelefono = config.adminTelefono,
                    adminEmail = config.adminEmail,
                    terminosCondiciones = config.terminosCondiciones,
                    tiposVehiculo = tiposMap,
                    linkDescarga = config.linkDescarga,
                    terminosCondicionesPasajero = config.terminosCondicionesPasajero,
                    montoMensualConductorBase = config.montoMensualConductorBase.coerceIn(500, 1_000_000),
                    anioBaseMensualidad = config.anioBaseMensualidad.coerceIn(2020, 2100),
                    multiplicadorTopeNormal = config.multiplicadorTopeNormal.coerceIn(1.1, 5.0),
                    multiplicadorTopeCarga = config.multiplicadorTopeCarga.coerceIn(1.1, 5.0)
                )
                _uiState.value = _uiState.value.copy(
                    configuracion = config,
                    accionMensaje = "Configuración, mensualidad, topes y Términos guardados."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo guardar la configuración."
                )
            }
        }
    }
}
