package cr.viajerural.app.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Timestamp
import cr.viajerural.app.data.AdminResumenLigero
import cr.viajerural.app.data.LicenciaRestanteInfo
import cr.viajerural.app.data.RutaFavoritaData
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.UbicacionSugerida
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularDiasLicenciaRestantes
import cr.viajerural.app.worker.MonthlyPaymentReminderWorker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// =============================================================================
// 1. AUTH VIEWMODEL (Login y Registro separados para Pasajero y Conductor)
// =============================================================================
data class AuthUiState(
    val cargando: Boolean = false,
    val error: String? = null,
    val uidAutenticado: String? = null,
    val adminCargando: Boolean = false,
    val adminError: String? = null,
    val uidAdminAutenticado: String? = null
)

class AuthViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun login(email: String, password: String, esConductor: Boolean, context: Context) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.iniciarSesion(email, password)
            result.fold(
                onSuccess = { uid ->
                    if (esConductor) {
                        MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    }
                    _uiState.value = _uiState.value.copy(cargando = false, uidAutenticado = uid)
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        error = err.message ?: "Error al iniciar sesión"
                    )
                }
            )
        }
    }

    /**
     * Login de Administrador Seguro:
     * Autentica con FirebaseAuth.signInWithEmailAndPassword y verifica usuarios/{uid}.rol == "admin".
     */
    fun loginAdminSeguro(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = _uiState.value.copy(adminError = "Ingresa correo y contraseña.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(adminCargando = true, adminError = null)
            val result = repository.iniciarSesionAdmin(email, password)
            result.fold(
                onSuccess = { uid ->
                    _uiState.value = _uiState.value.copy(
                        adminCargando = false,
                        uidAdminAutenticado = uid,
                        adminError = null
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        adminCargando = false,
                        uidAdminAutenticado = null,
                        adminError = err.message ?: "Acceso denegado."
                    )
                }
            )
        }
    }

    fun limpiarErrorAdmin() {
        _uiState.value = _uiState.value.copy(adminError = null)
    }

    fun registrarPasajero(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        fotoUrl: String = ""
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.registrarPasajero(nombre, email, telefono, cedula, password, fotoUrl)
            result.fold(
                onSuccess = { uid -> _uiState.value = _uiState.value.copy(cargando = false, uidAutenticado = uid) },
                onFailure = { err -> _uiState.value = _uiState.value.copy(cargando = false, error = err.message) }
            )
        }
    }

    fun registrarConductor(
        context: Context,
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        vehiculoTipo: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        fotoVehiculoDataUrl: String = "",
        fotoCedulaDataUrl: String = "",
        fotoLicenciaDataUrl: String = "",
        fotoCirculacionDataUrl: String = "",
        fotoPerfilDataUrl: String = ""
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.registrarConductor(
                nombre, email, telefono, cedula, password,
                vehiculoTipo, vehiculoModelo, vehiculoColor, vehiculoAnio,
                placa, capacidad, tarifaBase, tarifaPorKm,
                fotoVehiculoDataUrl, fotoCedulaDataUrl, fotoLicenciaDataUrl, fotoCirculacionDataUrl,
                fotoPerfilDataUrl
            )
            result.fold(
                onSuccess = { uid ->
                    MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    _uiState.value = _uiState.value.copy(cargando = false, uidAutenticado = uid)
                },
                onFailure = { err -> _uiState.value = _uiState.value.copy(cargando = false, error = err.message) }
            )
        }
    }
}

// =============================================================================
// 2. CONDUCTOR VIEWMODEL (4 pestañas BottomNavigation, Finanzas 2-datos, Historial lazy)
// =============================================================================
enum class ConductorTab { INICIO, FINANZAS, HISTORIAL, PERFIL }

data class ConductorFinanzasSimple(
    val gananciasHoy: Double = 0.0,
    val gananciasMes: Double = 0.0
)

data class ConductorUiState(
    val tabActual: ConductorTab = ConductorTab.INICIO,
    val disponible: Boolean = false,
    val viajeActivo: Map<String, Any>? = null,
    val finanzas: ConductorFinanzasSimple = ConductorFinanzasSimple(),
    val nombreConductor: String = "",
    val placa: String = "",
    val vehiculoTipo: String = "",
    val vehiculoModelo: String = "",
    val vehiculoColor: String = "",
    val vehiculoAnio: String = "",
    val capacidad: Int = 4,
    val tarifaBase: Double = 1500.0,
    val tarifaPorKm: Double = 650.0,
    val licenciaRestante: LicenciaRestanteInfo? = null,
    val misSolicitudes: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val historial: List<Map<String, Any>> = emptyList(),
    val historialCargado: Boolean = false,
    val cargandoHistorial: Boolean = false,
    val mostrarModalCobro: Boolean = false,
    val montoACobrar: Double = 0.0,
    val ultimoViajeId: String? = null,
    val ultimoPasajeroId: String? = null,
    val mensajeEstado: String? = null,
    val avisoCancelacionFlotante: String? = null
)

class ConductorViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConductorUiState())
    val uiState: StateFlow<ConductorUiState> = _uiState.asStateFlow()

    fun seleccionarTab(tab: ConductorTab, conductorId: String) {
        _uiState.value = _uiState.value.copy(tabActual = tab)
        if (tab == ConductorTab.HISTORIAL && !_uiState.value.historialCargado) {
            cargarHistorial(conductorId)
        }
        if (tab == ConductorTab.FINANZAS) {
            restaurarEstadoYFinanzas(conductorId)
        }
        if (tab == ConductorTab.PERFIL && !_uiState.value.solicitudesCargadas) {
            cargarMisSolicitudes(conductorId)
        }
    }

    fun cambiarDisponibilidad(conductorId: String, activo: Boolean) {
        val previo = _uiState.value.disponible
        _uiState.value = _uiState.value.copy(disponible = activo)
        viewModelScope.launch {
            try {
                repository.actualizarDisponibilidadConductor(conductorId, activo)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    disponible = previo,
                    mensajeEstado = e.localizedMessage ?: "No se pudo actualizar disponibilidad."
                )
            }
        }
    }

    fun restaurarEstadoYFinanzas(conductorId: String) {
        viewModelScope.launch {
            try {
                val viaje = repository.recuperarViajeActivoConductor(conductorId)
                val perfil = repository.obtenerPerfilYLicenciaConductor(conductorId)
                val hoy = (perfil?.get("gananciasHoy") as? Number)?.toDouble() ?: 0.0
                val mes = (perfil?.get("gananciasMes") as? Number)?.toDouble() ?: 0.0
                val licInfo = calcularDiasLicenciaRestantes(perfil?.get("licenciaExp") as? Timestamp)
                val disp = (perfil?.get("disponible") as? Boolean)
                    ?: (perfil?.get("estadoOperativo") == "disponible")
                _uiState.value = _uiState.value.copy(
                    disponible = disp,
                    viajeActivo = viaje,
                    finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
                    nombreConductor = perfil?.get("nombre") as? String ?: "",
                    placa = perfil?.get("placa") as? String ?: "",
                    vehiculoTipo = perfil?.get("vehiculoTipo") as? String ?: "",
                    vehiculoModelo = perfil?.get("vehiculoModelo") as? String ?: "",
                    vehiculoColor = perfil?.get("vehiculoColor") as? String ?: "",
                    vehiculoAnio = perfil?.get("vehiculoAnio") as? String ?: "",
                    capacidad = (perfil?.get("capacidad") as? Number)?.toInt() ?: 4,
                    tarifaBase = (perfil?.get("tarifaBase") as? Number)?.toDouble() ?: 1500.0,
                    tarifaPorKm = (perfil?.get("tarifaPorKm") as? Number)?.toDouble() ?: 650.0,
                    licenciaRestante = licInfo
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo sincronizar datos del conductor."
                )
            }
        }
    }

    fun cargarMisSolicitudes(conductorId: String) {
        viewModelScope.launch {
            try {
                val lista = repository.obtenerMisSolicitudesCambio(conductorId)
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = lista,
                    solicitudesCargadas = true
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(solicitudesCargadas = true)
            }
        }
    }

    fun enviarSolicitudCambioConductor(
        conductorId: String,
        cambios: Map<String, Any>,
        motivo: String
    ) {
        if (cambios.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                val creada = repository.crearSolicitudCambioDatos(
                    solicitanteUid = conductorId,
                    rol = "conductor",
                    nombreActual = _uiState.value.nombreConductor.ifBlank { "Conductor Rural" },
                    resumenActual = "${_uiState.value.vehiculoTipo} · Placa ${_uiState.value.placa}",
                    cambios = cambios,
                    motivo = motivo
                )
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = listOf(creada) + _uiState.value.misSolicitudes,
                    mensajeEstado = "Petición enviada al Administrador para su aprobación."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo enviar la petición."
                )
            }
        }
    }

    fun cargarHistorial(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargandoHistorial = true)
            try {
                val lista = repository.obtenerHistorialConductor(conductorId, 20L)
                _uiState.value = _uiState.value.copy(
                    historial = lista,
                    historialCargado = true,
                    cargandoHistorial = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(cargandoHistorial = false)
            }
        }
    }

    fun finalizarViaje(viajeId: String, conductorId: String, pasajeroId: String, montoCobrado: Double) {
        viewModelScope.launch {
            try {
                repository.finalizarViajeConFinanzas(viajeId, conductorId, montoCobrado)
                val (hoy, mes) = repository.obtenerFinanzasConductor(conductorId)
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
                    mostrarModalCobro = true,
                    montoACobrar = montoCobrado,
                    ultimoViajeId = viajeId,
                    ultimoPasajeroId = pasajeroId
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "Error al finalizar el viaje."
                )
            }
        }
    }

    fun calificarPasajero(conductorId: String, estrellas: Int, comentario: String) {
        val viajeId = _uiState.value.ultimoViajeId ?: return
        val pasajeroId = _uiState.value.ultimoPasajeroId ?: return
        viewModelScope.launch {
            try {
                repository.enviarCalificacionYActualizarPromedio(
                    viajeId = viajeId,
                    autorUid = conductorId,
                    destinatarioUid = pasajeroId,
                    destinatarioRol = "pasajero",
                    estrellas = estrellas,
                    comentario = comentario
                )
            } catch (_: Exception) {
            } finally {
                _uiState.value = _uiState.value.copy(mostrarModalCobro = false)
            }
        }
    }

    fun cancelarViajeActivo(viajeId: String, conductorId: String, motivo: String) {
        if (motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                repository.cancelarViajeConMotivo(
                    viajeId = viajeId,
                    canceladoPor = "conductor",
                    motivo = motivo,
                    conductorId = conductorId
                )
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    mensajeEstado = "Viaje cancelado. Motivo registrado: ${motivo.trim()}"
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo cancelar el viaje."
                )
            }
        }
    }

    fun onViajeCanceladoPorPasajero(pasajeroNombre: String, motivo: String) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            avisoCancelacionFlotante = "$pasajeroNombre canceló el viaje: \"$motivo\""
        )
    }

    fun limpiarAvisoCancelacionFlotante() {
        _uiState.value = _uiState.value.copy(avisoCancelacionFlotante = null)
    }

    fun cerrarModalCobro() {
        _uiState.value = _uiState.value.copy(mostrarModalCobro = false)
    }
}

// =============================================================================
// 3. PASAJERO VIEWMODEL (3 pestañas BottomNavigation, Rutas Favoritas, Autocompletado)
// =============================================================================
enum class PasajeroTab { VIAJE, HISTORIAL, PERFIL }

data class PasajeroUiState(
    val tabActual: PasajeroTab = PasajeroTab.VIAJE,
    val viajeActivo: Map<String, Any>? = null,
    val pinPersistente: String? = null,
    val nombrePasajero: String = "",
    val fotoUrl: String = "",
    val actualizandoFoto: Boolean = false,
    val misSolicitudes: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val historial: List<Map<String, Any>> = emptyList(),
    val historialCargado: Boolean = false,
    val cargandoHistorial: Boolean = false,
    val rutasFavoritas: List<RutaFavoritaData> = emptyList(),
    val sugerenciasOrigen: List<UbicacionSugerida> = emptyList(),
    val sugerenciasDestino: List<UbicacionSugerida> = emptyList(),
    val mostrarModalPago: Boolean = false,
    val montoAPagar: Double = 0.0,
    val ultimoViajeId: String? = null,
    val ultimoConductorId: String? = null,
    val avisoCancelacion: String? = null,
    val precisionUbicacionMetros: Int? = null,
    val solicitandoViaje: Boolean = false,
    val errorSolicitud: String? = null
)

class PasajeroViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(PasajeroUiState())
    val uiState: StateFlow<PasajeroUiState> = _uiState.asStateFlow()

    private var busquedaOrigenJob: Job? = null
    private var busquedaDestinoJob: Job? = null

    fun seleccionarTab(tab: PasajeroTab, pasajeroId: String) {
        _uiState.value = _uiState.value.copy(tabActual = tab)
        if (tab == PasajeroTab.HISTORIAL && !_uiState.value.historialCargado) {
            cargarHistorial(pasajeroId)
        }
        if (tab == PasajeroTab.PERFIL && !_uiState.value.solicitudesCargadas) {
            cargarMisSolicitudes(pasajeroId)
        }
    }

    fun cargarMisSolicitudes(pasajeroId: String) {
        viewModelScope.launch {
            try {
                val lista = repository.obtenerMisSolicitudesCambio(pasajeroId)
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = lista,
                    solicitudesCargadas = true
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(solicitudesCargadas = true)
            }
        }
    }

    fun enviarSolicitudCambioPasajero(
        pasajeroId: String,
        nombreActual: String,
        cambios: Map<String, Any>,
        motivo: String
    ) {
        if (cambios.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                val creada = repository.crearSolicitudCambioDatos(
                    solicitanteUid = pasajeroId,
                    rol = "pasajero",
                    nombreActual = nombreActual.ifBlank { "Pasajero Rural" },
                    resumenActual = "Pasajero registrado",
                    cambios = cambios,
                    motivo = motivo
                )
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = listOf(creada) + _uiState.value.misSolicitudes
                )
            } catch (_: Exception) {
            }
        }
    }

    fun restaurarViajeActivo(pasajeroId: String) {
        viewModelScope.launch {
            try {
                val resultado = repository.recuperarViajeActivoPasajero(pasajeroId)
                val favoritas = repository.obtenerRutasFavoritasPasajero(pasajeroId)
                val (nombre, foto) = repository.obtenerPerfilBasicoPasajero(pasajeroId)
                _uiState.value = _uiState.value.copy(
                    viajeActivo = resultado?.first,
                    pinPersistente = resultado?.second,
                    rutasFavoritas = favoritas,
                    nombrePasajero = if (nombre.isNotBlank()) nombre else _uiState.value.nombrePasajero,
                    fotoUrl = if (foto.isNotBlank()) foto else _uiState.value.fotoUrl
                )
            } catch (_: Exception) {
            }
        }
    }

    fun actualizarFotoPerfil(pasajeroId: String, fotoUrl: String) {
        if (fotoUrl.isBlank()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(actualizandoFoto = true)
            try {
                repository.actualizarFotoPerfilPasajero(pasajeroId, fotoUrl)
                _uiState.value = _uiState.value.copy(
                    fotoUrl = fotoUrl,
                    actualizandoFoto = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(actualizandoFoto = false)
            }
        }
    }

    fun solicitarViaje(
        pasajeroId: String,
        cantidadPasajeros: Int,
        origenNombre: String,
        origenLat: Double,
        origenLng: Double,
        destinoNombre: String,
        destinoLat: Double,
        destinoLng: Double,
        resenaUbicacion: String
    ) {
        if (cantidadPasajeros < 1 || resenaUbicacion.trim().length < 3) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(solicitandoViaje = true, errorSolicitud = null)
            try {
                val (viaje, pin) = repository.solicitarViajeConResena(
                    pasajeroId = pasajeroId,
                    pasajeroNombre = _uiState.value.nombrePasajero.ifBlank { "Pasajero Rural" },
                    cantidadPasajeros = cantidadPasajeros,
                    origenNombre = origenNombre,
                    origenLat = origenLat,
                    origenLng = origenLng,
                    destinoNombre = destinoNombre,
                    destinoLat = destinoLat,
                    destinoLng = destinoLng,
                    resenaUbicacion = resenaUbicacion
                )
                _uiState.value = _uiState.value.copy(
                    viajeActivo = viaje,
                    pinPersistente = pin,
                    solicitandoViaje = false,
                    errorSolicitud = null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    solicitandoViaje = false,
                    errorSolicitud = e.localizedMessage ?: "No se pudo solicitar el viaje. Intenta de nuevo."
                )
            }
        }
    }

    fun limpiarErrorSolicitud() {
        _uiState.value = _uiState.value.copy(errorSolicitud = null)
    }

    fun actualizarUbicacionGps(precisionMetros: Int?) {
        _uiState.value = _uiState.value.copy(precisionUbicacionMetros = precisionMetros)
    }

    fun buscarSugerenciasOrigen(
        query: String,
        latCercana: Double = 9.3895,
        lngCercana: Double = -83.6490
    ) {
        _uiState.value = _uiState.value.copy(
            sugerenciasOrigen = repository.buscarUbicacionesSugeridas(query)
        )
        busquedaOrigenJob?.cancel()
        if (query.trim().length < 2) return
        busquedaOrigenJob = viewModelScope.launch {
            delay(300)
            val resultados = repository.buscarUbicacionesNominatim(query, latCercana, lngCercana)
            _uiState.value = _uiState.value.copy(sugerenciasOrigen = resultados)
        }
    }

    fun buscarSugerenciasDestino(
        query: String,
        latCercana: Double = 9.3895,
        lngCercana: Double = -83.6490
    ) {
        _uiState.value = _uiState.value.copy(
            sugerenciasDestino = repository.buscarUbicacionesSugeridas(query)
        )
        busquedaDestinoJob?.cancel()
        if (query.trim().length < 2) return
        busquedaDestinoJob = viewModelScope.launch {
            delay(300)
            val resultados = repository.buscarUbicacionesNominatim(query, latCercana, lngCercana)
            _uiState.value = _uiState.value.copy(sugerenciasDestino = resultados)
        }
    }

    fun guardarRutaFavorita(pasajeroId: String, ruta: RutaFavoritaData) {
        viewModelScope.launch {
            try {
                val actualizadas = repository.guardarRutaFavoritaPasajero(pasajeroId, ruta)
                _uiState.value = _uiState.value.copy(rutasFavoritas = actualizadas)
            } catch (_: Exception) {
            }
        }
    }

    fun eliminarRutaFavorita(pasajeroId: String, rutaId: String) {
        viewModelScope.launch {
            try {
                val actualizadas = repository.eliminarRutaFavoritaPasajero(pasajeroId, rutaId)
                _uiState.value = _uiState.value.copy(rutasFavoritas = actualizadas)
            } catch (_: Exception) {
            }
        }
    }

    fun cargarHistorial(pasajeroId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargandoHistorial = true)
            try {
                val lista = repository.obtenerHistorialPasajero(pasajeroId, 20L)
                _uiState.value = _uiState.value.copy(
                    historial = lista,
                    historialCargado = true,
                    cargandoHistorial = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(cargandoHistorial = false)
            }
        }
    }

    fun onViajeFinalizado(viajeId: String, conductorId: String, montoAPagar: Double) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            pinPersistente = null,
            mostrarModalPago = true,
            montoAPagar = montoAPagar,
            ultimoViajeId = viajeId,
            ultimoConductorId = conductorId
        )
    }

    fun calificarConductor(pasajeroId: String, estrellas: Int, comentario: String) {
        val viajeId = _uiState.value.ultimoViajeId ?: return
        val conductorId = _uiState.value.ultimoConductorId ?: return
        viewModelScope.launch {
            try {
                repository.enviarCalificacionYActualizarPromedio(
                    viajeId = viajeId,
                    autorUid = pasajeroId,
                    destinatarioUid = conductorId,
                    destinatarioRol = "conductor",
                    estrellas = estrellas,
                    comentario = comentario
                )
            } catch (_: Exception) {
            } finally {
                _uiState.value = _uiState.value.copy(mostrarModalPago = false)
            }
        }
    }

    fun cancelarViajeActivo(viajeId: String, motivo: String) {
        if (motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                repository.cancelarViajeConMotivo(
                    viajeId = viajeId,
                    canceladoPor = "pasajero",
                    motivo = motivo
                )
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    pinPersistente = null
                )
            } catch (_: Exception) {
            }
        }
    }

    fun onViajeCanceladoPorConductor(motivo: String) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            pinPersistente = null,
            avisoCancelacion = motivo
        )
    }

    fun limpiarAvisoCancelacion() {
        _uiState.value = _uiState.value.copy(avisoCancelacion = null)
    }

    fun cerrarModalPago() {
        _uiState.value = _uiState.value.copy(mostrarModalPago = false)
    }
}

// =============================================================================
// 4. ADMIN VIEWMODEL (Pestañas Modulares, Lazy limit(20), Fichas en Modal)
// =============================================================================
enum class AdminSeccion { RESUMEN, PENDIENTES, CONDUCTORES, PASAJEROS, SOLICITUDES, ALERTAS, DUPLICADOS, CONFIGURACION }

data class ConductorAdminItem(
    val uid: String,
    val nombre: String,
    val placa: String,
    val vehiculoTipo: String,
    val tarifaBase: Double,
    val tarifaPorKm: Double,
    val gananciasMes: Double,
    val esTarifaAbusiva: Boolean,
    val estadoCuenta: String,
    val cedulaHash: String = "",
    val diasLicenciaRestantes: Int = 30,
    val etiquetaLicencia: String = "Quedan 30 días",
    val estadoLicencia: String = "vigente",
    val fechaLicenciaTexto: String = ""
)

data class ConductorDocumentosUi(
    val fotoVehiculo: String = "",
    val fotoCedula: String = "",
    val fotoLicencia: String = "",
    val fotoCirculacion: String = ""
)

data class PasajeroAdminItem(
    val uid: String,
    val nombre: String,
    val promedioCalificacion: Double,
    val bloqueado: Boolean,
    val telefono: String = "",
    val email: String = "",
    val cedula: String = ""
)

data class VehiculoTipoUi(
    val nombre: String,
    val maxPasajeros: Int,
    val descripcion: String = ""
)

data class ConfiguracionGeneralUi(
    val whatsappSoporte: String = "62546546",
    val sinpeNumero: String = "62546546",
    val sinpeTitular: String = "Administración Viaje Rural",
    val adminNombre: String = "Administrador Viaje Rural",
    val adminTelefono: String = "62546546",
    val adminEmail: String = "sindicatosiserge@gmail.com",
    val linkDescarga: String = ViajeRepository.DEFAULT_LINK_DESCARGA,
    val terminosCondiciones: String = "",
    val tiposVehiculo: List<VehiculoTipoUi> = emptyList()
)

data class AdminUiState(
    val seccionActual: AdminSeccion = AdminSeccion.RESUMEN,
    val resumen: AdminResumenLigero = AdminResumenLigero(),
    val pendientes: List<ConductorAdminItem> = emptyList(),
    val pendientesCargados: Boolean = false,
    val conductores: List<ConductorAdminItem> = emptyList(),
    val conductoresCargados: Boolean = false,
    val pasajeros: List<PasajeroAdminItem> = emptyList(),
    val pasajerosCargados: Boolean = false,
    val solicitudesCambio: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val conductorSeleccionado: ConductorAdminItem? = null,
    val documentosConductorSeleccionado: ConductorDocumentosUi? = null,
    val cargandoDocumentos: Boolean = false,
    val aprobandoConductor: Boolean = false,
    val renovandoLicencia: Boolean = false,
    val pasajeroSeleccionado: PasajeroAdminItem? = null,
    val gestionandoPasajero: Boolean = false,
    val configuracion: ConfiguracionGeneralUi = ConfiguracionGeneralUi(),
    val promedioBaseFlota: Double = 1500.0,
    val promedioKmFlota: Double = 650.0,
    val cargando: Boolean = false,
    val errorMensaje: String? = null,
    val accionMensaje: String? = null
)

class AdminViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    @Suppress("UNCHECKED_CAST")
    private fun parseConfiguracionUi(rawConfig: Map<String, Any>): ConfiguracionGeneralUi {
        val tiposRaw = (rawConfig["tiposVehiculo"] as? List<Map<String, Any>>).orEmpty()
        val tiposUi = tiposRaw.map { t ->
            VehiculoTipoUi(
                nombre = t["nombre"] as? String ?: "",
                maxPasajeros = (t["maxPasajeros"] as? Number)?.toInt() ?: 4,
                descripcion = t["descripcion"] as? String ?: ""
            )
        }
        return ConfiguracionGeneralUi(
            whatsappSoporte = rawConfig["whatsappSoporte"] as? String ?: "62546546",
            sinpeNumero = rawConfig["sinpeNumero"] as? String ?: "62546546",
            sinpeTitular = rawConfig["adminSinpeTitular"] as? String ?: "Administración Viaje Rural",
            adminNombre = rawConfig["adminNombre"] as? String ?: "Administrador Viaje Rural",
            adminTelefono = rawConfig["adminTelefono"] as? String ?: "62546546",
            adminEmail = rawConfig["adminEmail"] as? String ?: "sindicatosiserge@gmail.com",
            linkDescarga = (rawConfig["linkDescarga"] as? String)?.trim()?.takeIf { it.isNotBlank() }
                ?: ViajeRepository.DEFAULT_LINK_DESCARGA,
            terminosCondiciones = rawConfig["terminosCondiciones"] as? String ?: "",
            tiposVehiculo = tiposUi
        )
    }

    private fun mapConductoresUi(
        rawConductores: List<Map<String, Any>>,
        promedioBase: Double = 1500.0,
        promedioKm: Double = 650.0
    ): List<ConductorAdminItem> {
        return rawConductores.map { c ->
            val tBase = (c["tarifaBase"] as? Number)?.toDouble() ?: 0.0
            val tKm = (c["tarifaPorKm"] as? Number)?.toDouble() ?: 0.0
            val abusiva = tBase > promedioBase * 1.30 || tKm > promedioKm * 1.30
            val licInfo = calcularDiasLicenciaRestantes(c["licenciaExp"] as? Timestamp)
            ConductorAdminItem(
                uid = c["uid"] as? String ?: "",
                nombre = c["nombre"] as? String ?: "",
                placa = c["placa"] as? String ?: "",
                vehiculoTipo = c["vehiculoTipo"] as? String ?: "",
                tarifaBase = tBase,
                tarifaPorKm = tKm,
                gananciasMes = (c["gananciasMes"] as? Number)?.toDouble() ?: 0.0,
                esTarifaAbusiva = abusiva,
                estadoCuenta = c["estadoCuenta"] as? String ?: "pendiente",
                cedulaHash = c["cedulaHash"] as? String ?: "",
                diasLicenciaRestantes = licInfo.dias,
                etiquetaLicencia = licInfo.etiqueta,
                estadoLicencia = licInfo.estado,
                fechaLicenciaTexto = licInfo.fechaTexto
            )
        }
    }

    fun cargarResumenInicial() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val resumen = repository.obtenerResumenAdminLigero()
                val rawConfig = try {
                    repository.obtenerConfiguracionGeneral()
                } catch (_: Exception) {
                    null
                }
                val configUi = rawConfig?.let { parseConfiguracionUi(it) } ?: _uiState.value.configuracion
                _uiState.value = _uiState.value.copy(
                    resumen = resumen,
                    configuracion = configUi,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = "Panel Administrador activo. Inicia sesión con cuenta admin para sincronizar datos en la nube (${e.localizedMessage ?: "sin conexión"})."
                )
            }
        }
    }

    /**
     * Carga cada pestaña bajo demanda con limit(20) ÚNICAMENTE cuando el Admin la toca.
     */
    fun seleccionarSeccion(seccion: AdminSeccion) {
        _uiState.value = _uiState.value.copy(seccionActual = seccion, accionMensaje = null)
        when (seccion) {
            AdminSeccion.RESUMEN -> cargarResumenInicial()
            AdminSeccion.PENDIENTES -> cargarPendientesLazy()
            AdminSeccion.CONDUCTORES, AdminSeccion.ALERTAS, AdminSeccion.DUPLICADOS -> {
                if (!_uiState.value.conductoresCargados) cargarConductoresLazy()
            }
            AdminSeccion.PASAJEROS -> {
                if (!_uiState.value.pasajerosCargados) cargarPasajerosLazy()
            }
            AdminSeccion.SOLICITUDES -> {
                if (!_uiState.value.solicitudesCargadas) cargarSolicitudesCambioLazy()
            }
            AdminSeccion.CONFIGURACION -> cargarConfiguracion()
        }
    }

    fun cargarPendientesLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawPendientes = repository.obtenerConductoresPendientesAdmin(20L)
                val lista = mapConductoresUi(rawPendientes)
                _uiState.value = _uiState.value.copy(
                    pendientes = lista,
                    pendientesCargados = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los conductores pendientes."
                )
            }
        }
    }

    fun cargarSolicitudesCambioLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val lista = repository.obtenerSolicitudesCambioAdmin(20L)
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = lista,
                    solicitudesCargadas = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar las peticiones."
                )
            }
        }
    }

    fun resolverSolicitudCambio(
        solicitud: SolicitudCambioData,
        aprobar: Boolean,
        respuestaAdmin: String = ""
    ) {
        viewModelScope.launch {
            try {
                repository.resolverSolicitudCambioAdmin(solicitud, aprobar, respuestaAdmin)
                val actualizadas = _uiState.value.solicitudesCambio.map {
                    if (it.id == solicitud.id) {
                        it.copy(
                            estado = if (aprobar) "aprobada" else "rechazada",
                            respuestaAdmin = respuestaAdmin
                        )
                    } else it
                }
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = actualizadas,
                    conductoresCargados = if (aprobar && solicitud.rol == "conductor") false else _uiState.value.conductoresCargados,
                    pasajerosCargados = if (aprobar && solicitud.rol == "pasajero") false else _uiState.value.pasajerosCargados
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo procesar la petición."
                )
            }
        }
    }

    fun cargarConductoresLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawConductores = repository.obtenerConductoresAdmin(20L)
                val promedioBase = if (rawConductores.isNotEmpty()) {
                    rawConductores.mapNotNull { (it["tarifaBase"] as? Number)?.toDouble() }.average()
                } else 1500.0
                val promedioKm = if (rawConductores.isNotEmpty()) {
                    rawConductores.mapNotNull { (it["tarifaPorKm"] as? Number)?.toDouble() }.average()
                } else 650.0

                val conductoresUi = mapConductoresUi(rawConductores, promedioBase, promedioKm)
                _uiState.value = _uiState.value.copy(
                    conductores = conductoresUi,
                    conductoresCargados = true,
                    promedioBaseFlota = promedioBase,
                    promedioKmFlota = promedioKm,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los conductores."
                )
            }
        }
    }

    fun cargarPasajerosLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawPasajeros = repository.obtenerPasajerosAdmin(20L)
                val pasajerosUi = rawPasajeros.map { p ->
                    PasajeroAdminItem(
                        uid = p["uid"] as? String ?: "",
                        nombre = p["nombre"] as? String ?: "",
                        promedioCalificacion = (p["promedioCalificacion"] as? Number)?.toDouble() ?: 5.0,
                        bloqueado = p["bloqueado"] as? Boolean ?: false
                    )
                }
                _uiState.value = _uiState.value.copy(
                    pasajeros = pasajerosUi,
                    pasajerosCargados = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los pasajeros."
                )
            }
        }
    }

    fun cargarConfiguracion() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawConfig = repository.obtenerConfiguracionGeneral()
                val configUi = parseConfiguracionUi(rawConfig)
                _uiState.value = _uiState.value.copy(configuracion = configUi, cargando = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo cargar la configuración."
                )
            }
        }
    }

    fun seleccionarConductor(conductor: ConductorAdminItem) {
        _uiState.value = _uiState.value.copy(
            conductorSeleccionado = conductor,
            documentosConductorSeleccionado = null,
            cargandoDocumentos = true
        )
        viewModelScope.launch {
            try {
                val rawDocs = repository.obtenerDocumentosConductorAdmin(conductor.uid)
                val docsUi = ConductorDocumentosUi(
                    fotoVehiculo = rawDocs?.get("fotoVehiculo") as? String ?: "",
                    fotoCedula = rawDocs?.get("fotoCedula") as? String ?: "",
                    fotoLicencia = rawDocs?.get("fotoLicencia") as? String ?: "",
                    fotoCirculacion = rawDocs?.get("fotoCirculacion") as? String ?: ""
                )
                _uiState.value = _uiState.value.copy(
                    documentosConductorSeleccionado = docsUi,
                    cargandoDocumentos = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(
                    documentosConductorSeleccionado = ConductorDocumentosUi(),
                    cargandoDocumentos = false
                )
            }
        }
    }

    fun cerrarFichaConductor() {
        _uiState.value = _uiState.value.copy(
            conductorSeleccionado = null,
            documentosConductorSeleccionado = null,
            cargandoDocumentos = false,
            renovandoLicencia = false
        )
    }

    fun renovarLicenciaUnMes(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(renovandoLicencia = true, errorMensaje = null)
            try {
                val nuevaExp = repository.renovarLicenciaConductorAdmin(conductorId)
                val licInfo = calcularDiasLicenciaRestantes(nuevaExp)
                val actualizarItem: (ConductorAdminItem) -> ConductorAdminItem = { item ->
                    if (item.uid == conductorId) {
                        item.copy(
                            diasLicenciaRestantes = licInfo.dias,
                            etiquetaLicencia = licInfo.etiqueta,
                            estadoLicencia = licInfo.estado,
                            fechaLicenciaTexto = licInfo.fechaTexto
                        )
                    } else item
                }
                _uiState.value = _uiState.value.copy(
                    renovandoLicencia = false,
                    conductorSeleccionado = _uiState.value.conductorSeleccionado?.let(actualizarItem),
                    conductores = _uiState.value.conductores.map(actualizarItem),
                    pendientes = _uiState.value.pendientes.map(actualizarItem),
                    accionMensaje = "Licencia renovada (+1 mes) hasta ${licInfo.fechaTexto}."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    renovandoLicencia = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo renovar la licencia."
                )
            }
        }
    }

    fun aprobarYActivarConductor(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(aprobandoConductor = true, errorMensaje = null)
            try {
                val nuevaExp = repository.aprobarYActivarConductorAdmin(conductorId)
                val licInfo = calcularDiasLicenciaRestantes(nuevaExp)
                _uiState.value = _uiState.value.copy(
                    aprobandoConductor = false,
                    conductorSeleccionado = null,
                    documentosConductorSeleccionado = null,
                    pendientes = _uiState.value.pendientes.filterNot { it.uid == conductorId },
                    conductores = _uiState.value.conductores.map {
                        if (it.uid == conductorId) {
                            it.copy(
                                estadoCuenta = "activo",
                                diasLicenciaRestantes = licInfo.dias,
                                etiquetaLicencia = licInfo.etiqueta,
                                estadoLicencia = licInfo.estado,
                                fechaLicenciaTexto = licInfo.fechaTexto
                            )
                        } else it
                    },
                    conductoresCargados = false,
                    accionMensaje = "Conductor aprobado y activado. Licencia vigente hasta ${licInfo.fechaTexto}."
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    aprobandoConductor = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo aprobar y activar el conductor."
                )
            }
        }
    }

    fun seleccionarPasajero(pasajero: PasajeroAdminItem) {
        viewModelScope.launch {
            try {
                val pii = repository.obtenerPiiUsuarioAdmin(pasajero.uid)
                _uiState.value = _uiState.value.copy(
                    pasajeroSeleccionado = pasajero.copy(
                        telefono = pii?.get("telefono") as? String ?: "",
                        email = pii?.get("email") as? String ?: "",
                        cedula = pii?.get("cedula") as? String ?: ""
                    )
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(pasajeroSeleccionado = pasajero)
            }
        }
    }

    fun guardarFichaPasajero(
        uid: String,
        nombre: String,
        telefono: String,
        email: String,
        cedula: String
    ) {
        viewModelScope.launch {
            try {
                repository.actualizarFichaPasajeroAdmin(uid, nombre, telefono, email, cedula)
                _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null)
                cargarPasajerosLazy()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo guardar el pasajero."
                )
            }
        }
    }

    fun toggleBloqueoPasajero(pasajero: PasajeroAdminItem) {
        val nuevoEstado = !pasajero.bloqueado
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(gestionandoPasajero = true, errorMensaje = null)
            try {
                repository.toggleBloqueoPasajeroAdmin(pasajero.uid, nuevoEstado)
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    pasajeroSeleccionado = _uiState.value.pasajeroSeleccionado?.copy(bloqueado = nuevoEstado),
                    pasajeros = _uiState.value.pasajeros.map {
                        if (it.uid == pasajero.uid) it.copy(bloqueado = nuevoEstado) else it
                    },
                    accionMensaje = if (nuevoEstado) "Pasajero bloqueado en Firestore." else "Pasajero desbloqueado en Firestore."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo actualizar el bloqueo del pasajero."
                )
            }
        }
    }

    fun eliminarCuentaPasajero(pasajeroId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(gestionandoPasajero = true, errorMensaje = null)
            try {
                repository.eliminarCuentaPasajeroAdmin(pasajeroId)
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    pasajeroSeleccionado = null,
                    pasajeros = _uiState.value.pasajeros.filterNot { it.uid == pasajeroId },
                    accionMensaje = "Cuenta del pasajero eliminada de Firestore."
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo eliminar la cuenta del pasajero."
                )
            }
        }
    }

    fun cerrarFichaPasajero() {
        _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null, gestionandoPasajero = false)
    }

    fun limpiarAccionMensaje() {
        _uiState.value = _uiState.value.copy(accionMensaje = null)
    }

    fun guardarConfiguracion(config: ConfiguracionGeneralUi) {
        viewModelScope.launch {
            try {
                val tiposMap = config.tiposVehiculo.map {
                    mapOf(
                        "nombre" to it.nombre,
                        "maxPasajeros" to it.maxPasajeros,
                        "descripcion" to it.descripcion
                    )
                }
                repository.guardarConfiguracionGeneralAdmin(
                    whatsappSoporte = config.whatsappSoporte,
                    sinpeNumero = config.sinpeNumero,
                    sinpeTitular = config.sinpeTitular,
                    adminNombre = config.adminNombre,
                    adminTelefono = config.adminTelefono,
                    adminEmail = config.adminEmail,
                    terminosCondiciones = config.terminosCondiciones,
                    tiposVehiculo = tiposMap,
                    linkDescarga = config.linkDescarga
                )
                _uiState.value = _uiState.value.copy(
                    configuracion = config,
                    accionMensaje = "Configuración y enlace de descarga guardados."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo guardar la configuración."
                )
            }
        }
    }
}
