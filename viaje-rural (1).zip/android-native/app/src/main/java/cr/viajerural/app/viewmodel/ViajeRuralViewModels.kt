package cr.viajerural.app.viewmodel

import android.content.Context
import android.location.Location
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Timestamp
import cr.viajerural.app.data.AdminResumenLigero
import cr.viajerural.app.data.LicenciaRestanteInfo
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularDiasLicenciaRestantes
import cr.viajerural.app.messaging.NotificationHelper
import cr.viajerural.app.worker.MonthlyPaymentReminderWorker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

// =============================================================================
// 1. AUTH VIEWMODEL (Login y Registro separados para Pasajero y Conductor)
// =============================================================================
data class AuthUiState(
    val cargando: Boolean = false,
    val error: String? = null,
    val uidAutenticado: String? = null,
    val rolAutenticado: String? = null,
    val adminCargando: Boolean = false,
    val adminError: String? = null,
    val uidAdminAutenticado: String? = null
)

class AuthViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun limpiarEstadoAuth(context: Context? = null) {
        context?.let { repository.limpiarRolLocal(it) }
        _uiState.value = AuthUiState()
    }

    fun login(email: String, password: String, esConductor: Boolean, context: Context) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.iniciarSesion(email, password)
            result.fold(
                onSuccess = { uid ->
                    val rolFinal = repository.asegurarRolEnLogin(context, uid, esConductor)
                    if (rolFinal == "conductor") {
                        MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    }
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        uidAutenticado = uid,
                        rolAutenticado = rolFinal
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        error = err.message ?: "Error al iniciar sesión"
                    )
                }
            )
        }
    }

    /**
     * Login de Administrador Seguro:
     * Autentica con FirebaseAuth.signInWithEmailAndPassword y verifica usuarios/{uid}.rol == "admin".
     */
    fun loginAdminSeguro(email: String, password: String, context: Context? = null) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = _uiState.value.copy(adminError = "Ingresa correo y contraseña.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(adminCargando = true, adminError = null)
            val result = repository.iniciarSesionAdmin(email, password)
            result.fold(
                onSuccess = { uid ->
                    context?.let { repository.guardarRolLocal(it, uid, "admin") }
                    _uiState.value = _uiState.value.copy(
                        adminCargando = false,
                        uidAdminAutenticado = uid,
                        rolAutenticado = "admin",
                        adminError = null
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        adminCargando = false,
                        uidAdminAutenticado = null,
                        adminError = err.message ?: "Acceso denegado."
                    )
                }
            )
        }
    }

    fun limpiarErrorAdmin() {
        _uiState.value = _uiState.value.copy(adminError = null)
    }

    fun registrarPasajero(
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        fotoUrl: String = "",
        context: Context? = null
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.registrarPasajero(nombre, email, telefono, cedula, password, fotoUrl)
            result.fold(
                onSuccess = { uid ->
                    context?.let { repository.guardarRolLocal(it, uid, "pasajero") }
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        uidAutenticado = uid,
                        rolAutenticado = "pasajero"
                    )
                },
                onFailure = { err -> _uiState.value = _uiState.value.copy(cargando = false, error = err.message) }
            )
        }
    }

    fun registrarConductor(
        context: Context,
        nombre: String,
        email: String,
        telefono: String,
        cedula: String,
        password: String,
        vehiculoTipo: String,
        vehiculoModelo: String,
        vehiculoColor: String,
        vehiculoAnio: String,
        placa: String,
        capacidad: Int,
        tarifaBase: Double,
        tarifaPorKm: Double,
        fotoVehiculoDataUrl: String = "",
        fotoCedulaDataUrl: String = "",
        fotoLicenciaDataUrl: String = "",
        fotoCirculacionDataUrl: String = "",
        fotoPerfilDataUrl: String = ""
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, error = null)
            val result = repository.registrarConductor(
                nombre, email, telefono, cedula, password,
                vehiculoTipo, vehiculoModelo, vehiculoColor, vehiculoAnio,
                placa, capacidad, tarifaBase, tarifaPorKm,
                fotoVehiculoDataUrl, fotoCedulaDataUrl, fotoLicenciaDataUrl, fotoCirculacionDataUrl,
                fotoPerfilDataUrl
            )
            result.fold(
                onSuccess = { uid ->
                    repository.guardarRolLocal(context, uid, "conductor")
                    MonthlyPaymentReminderWorker.scheduleMonthlyReminder(context)
                    _uiState.value = _uiState.value.copy(
                        cargando = false,
                        uidAutenticado = uid,
                        rolAutenticado = "conductor"
                    )
                },
                onFailure = { err -> _uiState.value = _uiState.value.copy(cargando = false, error = err.message) }
            )
        }
    }
}

// =============================================================================
// 2. CONDUCTOR VIEWMODEL (4 pestañas BottomNavigation, Finanzas 2-datos, Historial lazy)
// =============================================================================
enum class ConductorTab { INICIO, FINANZAS, HISTORIAL, PERFIL }

data class ConductorFinanzasSimple(
    val gananciasHoy: Double = 0.0,
    val gananciasMes: Double = 0.0
)

data class ConductorUiState(
    val tabActual: ConductorTab = ConductorTab.INICIO,
    val disponible: Boolean = false,
    val viajeActivo: Map<String, Any>? = null,
    val ofertaPendiente: Map<String, Any>? = null,
    val segundosOfertaRestantes: Int? = null,
    val procesandoOferta: Boolean = false,
    val errorPin: String? = null,
    val mensajesChat: List<Map<String, Any>> = emptyList(),
    val finanzas: ConductorFinanzasSimple = ConductorFinanzasSimple(),
    val nombreConductor: String = "",
    val placa: String = "",
    val vehiculoTipo: String = "",
    val vehiculoModelo: String = "",
    val vehiculoColor: String = "",
    val vehiculoAnio: String = "",
    val capacidad: Int = 4,
    val tarifaBase: Double = 1500.0,
    val tarifaPorKm: Double = 650.0,
    val licenciaRestante: LicenciaRestanteInfo? = null,
    val misSolicitudes: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val historial: List<Map<String, Any>> = emptyList(),
    val historialCargado: Boolean = false,
    val cargandoHistorial: Boolean = false,
    val mostrarModalCobro: Boolean = false,
    val montoACobrar: Double = 0.0,
    val ultimoViajeId: String? = null,
    val ultimoPasajeroId: String? = null,
    val mensajeEstado: String? = null,
    val actualizandoDisponibilidad: Boolean = false,
    val avisoCancelacionFlotante: String? = null
)

class ConductorViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConductorUiState())
    val uiState: StateFlow<ConductorUiState> = _uiState.asStateFlow()

    private var perfilListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var viajeActivoListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var viajeDocListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var ofertasListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var chatListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var ofertaTimerJob: Job? = null
    private var perfilObservadoUid: String? = null
    private var viajeDocObservadoId: String? = null
    private var cancelacionPropiaViajeId: String? = null
    private var actualizandoDisponibilidadLock = false
    private var appContext: Context? = null
    private var appEnPrimerPlano: Boolean = true

    private val gpsHandler = Handler(Looper.getMainLooper())
    private var gpsRunnable: Runnable? = null
    private var conductorGpsActivoId: String? = null
    private var modoGpsActual: String? = null
    private var viajeRecogidaActivoId: String? = null
    private val intervaloGps15MinMs = 15L * 60L * 1000L
    private val intervaloGps90SegMs = 90L * 1000L

    private fun aplicarPerfilConductor(perfil: Map<String, Any>) {
        val hoy = (perfil["gananciasHoy"] as? Number)?.toDouble() ?: _uiState.value.finanzas.gananciasHoy
        val mes = (perfil["gananciasMes"] as? Number)?.toDouble() ?: _uiState.value.finanzas.gananciasMes
        val licInfo = if (perfil.containsKey("licenciaExp")) {
            calcularDiasLicenciaRestantes(perfil["licenciaExp"])
        } else {
            _uiState.value.licenciaRestante
        }
        val dispRemoto = (perfil["disponible"] as? Boolean)
            ?: (perfil["estadoOperativo"] == "activo" || perfil["estadoOperativo"] == "disponible")
        val dispFinal = if (actualizandoDisponibilidadLock) _uiState.value.disponible else dispRemoto
        _uiState.value = _uiState.value.copy(
            disponible = dispFinal,
            finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
            nombreConductor = perfil["nombre"] as? String ?: _uiState.value.nombreConductor,
            placa = perfil["placa"] as? String ?: _uiState.value.placa,
            vehiculoTipo = (perfil["tipoVehiculo"] as? String)?.takeIf { it.isNotBlank() }
                ?: (perfil["vehiculoTipo"] as? String)
                ?: _uiState.value.vehiculoTipo,
            vehiculoModelo = perfil["vehiculoModelo"] as? String ?: _uiState.value.vehiculoModelo,
            vehiculoColor = perfil["vehiculoColor"] as? String ?: _uiState.value.vehiculoColor,
            vehiculoAnio = perfil["vehiculoAnio"] as? String ?: _uiState.value.vehiculoAnio,
            capacidad = (perfil["capacidad"] as? Number)?.toInt() ?: _uiState.value.capacidad,
            tarifaBase = (perfil["tarifaBase"] as? Number)?.toDouble() ?: _uiState.value.tarifaBase,
            tarifaPorKm = (perfil["tarifaPorKm"] as? Number)?.toDouble() ?: _uiState.value.tarifaPorKm,
            licenciaRestante = licInfo
        )
    }

    override fun onCleared() {
        detenerCicloGps15Min()
        perfilListener?.remove()
        perfilListener = null
        viajeActivoListener?.remove()
        viajeActivoListener = null
        viajeDocListener?.remove()
        viajeDocListener = null
        viajeDocObservadoId = null
        ofertasListener?.remove()
        ofertasListener = null
        chatListener?.remove()
        chatListener = null
        ofertaTimerJob?.cancel()
        super.onCleared()
    }

    fun seleccionarTab(tab: ConductorTab, conductorId: String) {
        _uiState.value = _uiState.value.copy(tabActual = tab)
        if (tab == ConductorTab.HISTORIAL && !_uiState.value.historialCargado) {
            cargarHistorial(conductorId)
        }
        if (tab == ConductorTab.INICIO || tab == ConductorTab.FINANZAS) {
            restaurarEstadoYFinanzas(conductorId)
        }
        if (tab == ConductorTab.PERFIL && !_uiState.value.solicitudesCargadas) {
            cargarMisSolicitudes(conductorId)
        }
    }

    fun iniciarModoEspera15Min(context: Context, conductorId: String) {
        if (conductorId.isBlank()) return
        val appCtx = context.applicationContext
        appContext = appCtx
        if (modoGpsActual == "espera" && conductorGpsActivoId == conductorId && gpsRunnable != null) return
        detenerCicloGps(limpiarNotificacion = true)
        conductorGpsActivoId = conductorId
        modoGpsActual = "espera"

        val tarea = object : Runnable {
            override fun run() {
                val viaje = _uiState.value.viajeActivo
                val estadoViaje = viaje?.get("estado") as? String
                if (!_uiState.value.disponible || estadoViaje == "en_curso") {
                    detenerCicloGps(limpiarNotificacion = true)
                    return
                }
                if (estadoViaje == "aceptado") {
                    val vId = viaje["id"] as? String
                    val oLat = (viaje["origenLat"] as? Number)?.toDouble()
                    val oLng = (viaje["origenLng"] as? Number)?.toDouble()
                    if (!vId.isNullOrBlank() && oLat != null && oLng != null) {
                        iniciarModoRecogida90Seg(appCtx, conductorId, vId, oLat, oLng)
                        return
                    }
                }
                viewModelScope.launch {
                    try {
                        val (lat, lng) = repository.obtenerUbicacionUnicaGps(appCtx)
                        repository.actualizarUbicacionPeriodicaConductor(conductorId, lat, lng)
                    } catch (_: Throwable) {
                    }
                }
                gpsHandler.postDelayed(this, intervaloGps15MinMs)
            }
        }
        gpsRunnable = tarea
        gpsHandler.postDelayed(tarea, intervaloGps15MinMs)
    }

    fun iniciarModoRecogida90Seg(
        context: Context,
        conductorId: String,
        viajeId: String,
        origenLat: Double,
        origenLng: Double
    ) {
        if (conductorId.isBlank() || viajeId.isBlank()) return
        val appCtx = context.applicationContext
        appContext = appCtx
        if (modoGpsActual == "recogida" && viajeRecogidaActivoId == viajeId && gpsRunnable != null) return
        detenerCicloGps(limpiarNotificacion = false)
        conductorGpsActivoId = conductorId
        modoGpsActual = "recogida"
        viajeRecogidaActivoId = viajeId

        val tarea = object : Runnable {
            override fun run() {
                val estadoViaje = _uiState.value.viajeActivo?.get("estado") as? String
                if (estadoViaje == "en_curso") {
                    detenerCicloGps(limpiarNotificacion = true)
                    return
                }
                viewModelScope.launch {
                    try {
                        val (lat, lng) = repository.obtenerUbicacionUnicaGps(appCtx)
                        val resultados = FloatArray(1)
                        Location.distanceBetween(lat, lng, origenLat, origenLng, resultados)
                        val distanciaMetros = resultados[0].coerceAtLeast(0f)
                        val distanciaTexto = if (distanciaMetros < 1000f) {
                            "${distanciaMetros.roundToInt()} m"
                        } else {
                            String.format(Locale.US, "%.1f km", distanciaMetros / 1000f)
                        }
                        val etaMinutos = ((distanciaMetros / 1000.0) / 30.0 * 60.0)
                            .roundToInt()
                            .coerceIn(1, 300)

                        repository.actualizarUbicacionRecogidaConDistancia(
                            viajeId = viajeId,
                            conductorId = conductorId,
                            lat = lat,
                            lng = lng,
                            etaMinutos = etaMinutos,
                            distanciaTexto = distanciaTexto
                        )
                        NotificationHelper.mostrarNotificacionSeguimientoRecogida(
                            context = appCtx,
                            distanciaTexto = distanciaTexto,
                            etaMinutos = etaMinutos
                        )
                    } catch (_: Throwable) {
                    }
                }
                gpsHandler.postDelayed(this, intervaloGps90SegMs)
            }
        }
        gpsRunnable = tarea
        gpsHandler.post(tarea)
    }

    fun iniciarCicloGps15Min(context: Context, conductorId: String) {
        iniciarModoEspera15Min(context, conductorId)
    }

    fun detenerCicloGps(limpiarNotificacion: Boolean = true) {
        gpsRunnable?.let { gpsHandler.removeCallbacks(it) }
        gpsRunnable = null
        modoGpsActual = null
        viajeRecogidaActivoId = null
        conductorGpsActivoId = null
        if (limpiarNotificacion) {
            appContext?.let { NotificationHelper.cancelarNotificacionSeguimientoRecogida(it) }
        }
    }

    fun detenerCicloGps15Min() {
        detenerCicloGps(limpiarNotificacion = true)
    }

    suspend fun desactivarConductorAlCerrarSesion(conductorId: String) {
        detenerCicloGps(limpiarNotificacion = true)
        ofertaTimerJob?.cancel()
        try {
            repository.actualizarDisponibilidadConductor(
                conductorId = conductorId,
                disponible = false
            )
        } catch (_: Throwable) {
        }
        _uiState.value = _uiState.value.copy(
            disponible = false,
            ofertaPendiente = null,
            segundosOfertaRestantes = null
        )
    }

    fun cambiarDisponibilidad(
        context: Context,
        conductorId: String,
        activo: Boolean,
        onExito: () -> Unit = {},
        onFallo: (String) -> Unit = {}
    ) {
        val previo = _uiState.value.disponible
        actualizandoDisponibilidadLock = true
        _uiState.value = _uiState.value.copy(
            disponible = activo,
            actualizandoDisponibilidad = true,
            mensajeEstado = null
        )
        viewModelScope.launch {
            try {
                if (activo) {
                    // Capturar ubicación GPS UNA SOLA VEZ y programar ciclo de 15 min con Handler
                    val (lat, lng) = repository.obtenerUbicacionUnicaGps(context)
                    repository.actualizarDisponibilidadConductor(
                        conductorId = conductorId,
                        disponible = true,
                        lat = lat,
                        lng = lng,
                        tipoVehiculo = _uiState.value.vehiculoTipo,
                        capacidad = _uiState.value.capacidad
                    )
                    iniciarCicloGps15Min(context, conductorId)
                } else {
                    // Al pasar a Inactivo, detener Handler, marcar disponible = false y estadoOperativo = "inactivo"
                    detenerCicloGps15Min()
                    repository.actualizarDisponibilidadConductor(
                        conductorId = conductorId,
                        disponible = false
                    )
                    ofertaTimerJob?.cancel()
                    _uiState.value = _uiState.value.copy(
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null
                    )
                }
                actualizandoDisponibilidadLock = false
                _uiState.value = _uiState.value.copy(
                    disponible = activo,
                    actualizandoDisponibilidad = false
                )
                onExito()
            } catch (e: Exception) {
                actualizandoDisponibilidadLock = false
                if (!activo) detenerCicloGps15Min()
                val msg = e.localizedMessage ?: "No se pudo actualizar tu estado en Firestore."
                _uiState.value = _uiState.value.copy(
                    disponible = previo,
                    actualizandoDisponibilidad = false,
                    mensajeEstado = msg
                )
                onFallo(msg)
            }
        }
    }

    fun limpiarMensajeEstado() {
        _uiState.value = _uiState.value.copy(mensajeEstado = null)
    }

    fun setAppEnPrimerPlano(enPrimerPlano: Boolean) {
        appEnPrimerPlano = enPrimerPlano
    }

    @Suppress("UNCHECKED_CAST")
    private fun procesarOfertasEntrantes(conductorId: String, ofertas: List<Map<String, Any>>) {
        if (_uiState.value.viajeActivo != null || !_uiState.value.disponible) {
            ofertaTimerJob?.cancel()
            _uiState.value = _uiState.value.copy(
                ofertaPendiente = null,
                segundosOfertaRestantes = null
            )
            return
        }

        var indiceTurno = 0
        val ofertaEnTurno = ofertas.firstOrNull { viaje ->
            val cola = (viaje["colaConductores"] as? List<String>).orEmpty()
            if (cola.isEmpty()) return@firstOrNull false
            val idx = ((viaje["ofertaActualIndex"] as? Number)?.toInt() ?: 0) % cola.size
            if (cola[idx] == conductorId) {
                indiceTurno = idx
                true
            } else {
                false
            }
        }

        if (ofertaEnTurno == null) {
            ofertaTimerJob?.cancel()
            _uiState.value = _uiState.value.copy(
                ofertaPendiente = null,
                segundosOfertaRestantes = null
            )
            return
        }

        val viajeId = ofertaEnTurno["id"] as? String ?: return
        val expiraAt = (ofertaEnTurno["ofertaExpiraAt"] as? Number)?.toLong()
            ?: (System.currentTimeMillis() + 15_000L)

        // Si el conductor está usando otra app (ej. Waze) o tiene la pantalla apagada/bloqueada,
        // lanzar notificación flotante Heads-up + FullScreenIntent de inmediato.
        val ctx = appContext
        if (ctx != null && !appEnPrimerPlano) {
            val pasajero = (ofertaEnTurno["pasajeroNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "Pasajero"
            val origen = (ofertaEnTurno["origenNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "Punto de recogida"
            val destino = (ofertaEnTurno["destinoNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "Destino"
            val monto = (ofertaEnTurno["montoAproximado"] as? Number)?.toInt() ?: 0
            NotificationHelper.mostrarOfertaViajeHeadsUp(
                context = ctx,
                titulo = "Nueva oferta de viaje · $pasajero",
                cuerpo = "$origen → $destino · Tarifa aprox: ₡$monto (15s para aceptar)",
                viajeId = viajeId,
                claveDeduplicacion = "oferta_${viajeId}_$indiceTurno"
            )
        }

        _uiState.value = _uiState.value.copy(ofertaPendiente = ofertaEnTurno)
        ofertaTimerJob?.cancel()
        ofertaTimerJob = viewModelScope.launch {
            while (true) {
                val restantes = ((expiraAt - System.currentTimeMillis()) / 1000L).toInt().coerceAtLeast(0)
                _uiState.value = _uiState.value.copy(segundosOfertaRestantes = restantes)
                if (restantes <= 0) {
                    try {
                        repository.avanzarColaPorTimeoutSecuencial(viajeId, conductorId)
                    } catch (_: Exception) {
                    }
                    break
                }
                delay(1_000L)
            }
        }
    }

    fun aceptarOfertaActual(conductorId: String, onAceptado: (String) -> Unit = {}) {
        val oferta = _uiState.value.ofertaPendiente ?: return
        val viajeId = oferta["id"] as? String ?: return
        if (_uiState.value.procesandoOferta) return
        val origenLat = (oferta["origenLat"] as? Number)?.toDouble()
        val origenLng = (oferta["origenLng"] as? Number)?.toDouble()

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(procesandoOferta = true, mensajeEstado = null)
            val result = repository.aceptarOfertaAtomicamente(viajeId, conductorId)
            result.fold(
                onSuccess = {
                    ofertaTimerJob?.cancel()
                    iniciarEscuchaViajeDocumento(viajeId, conductorId)
                    val ctx = appContext
                    if (ctx != null && origenLat != null && origenLng != null) {
                        iniciarModoRecogida90Seg(ctx, conductorId, viajeId, origenLat, origenLng)
                    }
                    _uiState.value = _uiState.value.copy(
                        procesandoOferta = false,
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null,
                        errorPin = null
                    )
                    onAceptado(viajeId)
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        procesandoOferta = false,
                        mensajeEstado = err.localizedMessage ?: "No se pudo aceptar la oferta."
                    )
                }
            )
        }
    }

    fun rechazarOfertaActual(conductorId: String) {
        val oferta = _uiState.value.ofertaPendiente ?: return
        val viajeId = oferta["id"] as? String ?: return
        if (_uiState.value.procesandoOferta) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(procesandoOferta = true)
            try {
                repository.rechazarOfertaSecuencial(viajeId, conductorId)
                ofertaTimerJob?.cancel()
                _uiState.value = _uiState.value.copy(
                    procesandoOferta = false,
                    ofertaPendiente = null,
                    segundosOfertaRestantes = null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    procesandoOferta = false,
                    mensajeEstado = e.localizedMessage ?: "No se pudo rechazar la oferta."
                )
            }
        }
    }

    fun verificarPin(
        viajeId: String,
        conductorId: String,
        pinIngresado: String,
        onPinCorrecto: () -> Unit = {}
    ) {
        if (pinIngresado.trim().length != 3) {
            _uiState.value = _uiState.value.copy(errorPin = "Ingresa el PIN de 3 dígitos.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(errorPin = null)
            try {
                val valido = repository.verificarPinViaje(viajeId, conductorId, pinIngresado)
                if (valido) {
                    // Detener por completo el Handler GPS al recoger al pasajero (PIN confirmado)
                    detenerCicloGps(limpiarNotificacion = true)
                    onPinCorrecto()
                } else {
                    _uiState.value = _uiState.value.copy(
                        errorPin = "PIN incorrecto. Pídele al pasajero el código de 3 dígitos."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorPin = e.localizedMessage ?: "No se pudo verificar el PIN."
                )
            }
        }
    }

    fun observarChat(viajeId: String) {
        chatListener?.remove()
        chatListener = repository.observarMensajesChat(viajeId) { msgs ->
            _uiState.value = _uiState.value.copy(mensajesChat = msgs)
        }
    }

    fun detenerChat() {
        chatListener?.remove()
        chatListener = null
    }

    fun enviarMensajeChat(viajeId: String, conductorId: String, texto: String) {
        viewModelScope.launch {
            try {
                repository.enviarMensajeChat(
                    viajeId = viajeId,
                    autorUid = conductorId,
                    autorRol = "conductor",
                    autorNombre = _uiState.value.nombreConductor.ifBlank { "Conductor" },
                    texto = texto
                )
            } catch (_: Exception) {
            }
        }
    }

    private fun iniciarEscuchaViajeDocumento(viajeId: String, conductorId: String) {
        if (viajeId.isBlank()) return
        if (viajeDocObservadoId == viajeId && viajeDocListener != null) return
        viajeDocListener?.remove()
        viajeDocObservadoId = viajeId
        viajeDocListener = repository.observarViajePorId(viajeId) { viaje ->
            if (viaje == null) {
                viajeDocListener?.remove()
                viajeDocListener = null
                viajeDocObservadoId = null
                _uiState.value = _uiState.value.copy(viajeActivo = null)
                return@observarViajePorId
            }

            val estado = viaje["estado"] as? String
            when (estado) {
                "aceptado" -> {
                    ofertaTimerJob?.cancel()
                    val ctx = appContext
                    val oLat = (viaje["origenLat"] as? Number)?.toDouble()
                    val oLng = (viaje["origenLng"] as? Number)?.toDouble()
                    if (ctx != null && oLat != null && oLng != null) {
                        iniciarModoRecogida90Seg(ctx, conductorId, viajeId, oLat, oLng)
                    }
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = viaje,
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null
                    )
                }
                "en_curso" -> {
                    ofertaTimerJob?.cancel()
                    detenerCicloGps(limpiarNotificacion = true)
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = viaje,
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null
                    )
                }
                "cancelado" -> {
                    viajeDocListener?.remove()
                    viajeDocListener = null
                    viajeDocObservadoId = null
                    detenerCicloGps(limpiarNotificacion = true)
                    val ctx = appContext
                    if (ctx != null) {
                        iniciarModoEspera15Min(ctx, conductorId)
                    }
                    val canceladoPor = viaje["canceladoPor"] as? String
                    if (canceladoPor == "pasajero" || (viajeId != cancelacionPropiaViajeId && canceladoPor != "conductor")) {
                        val pasajeroNombre = (viaje["pasajeroNombre"] as? String)?.takeIf { it.isNotBlank() } ?: "El pasajero"
                        val motivo = (viaje["motivoCancelacion"] as? String)?.takeIf { it.isNotBlank() }
                            ?: "El pasajero canceló el viaje."
                        viewModelScope.launch {
                            try {
                                repository.restaurarConductorDisponibleTrasCancelacion(conductorId)
                            } catch (_: Exception) {
                            }
                        }
                        onViajeCanceladoPorPasajero(pasajeroNombre, motivo)
                    } else {
                        _uiState.value = _uiState.value.copy(viajeActivo = null, disponible = true)
                    }
                }
                "finalizado" -> {
                    viajeDocListener?.remove()
                    viajeDocListener = null
                    viajeDocObservadoId = null
                    detenerCicloGps(limpiarNotificacion = true)
                    val ctx = appContext
                    if (ctx != null && _uiState.value.disponible) {
                        iniciarModoEspera15Min(ctx, conductorId)
                    }
                }
            }
        }
    }

    fun restaurarEstadoYFinanzas(conductorId: String, context: Context? = null) {
        if (context != null) {
            appContext = context.applicationContext
        }
        if (perfilObservadoUid != conductorId) {
            perfilListener?.remove()
            viajeActivoListener?.remove()
            ofertasListener?.remove()
            perfilObservadoUid = conductorId

            perfilListener = repository.observarPerfilConductor(conductorId) { perfil ->
                aplicarPerfilConductor(perfil)
            }
            viajeActivoListener = repository.observarViajeActivoConductor(conductorId) { viaje ->
                if (viaje != null) {
                    val vId = viaje["id"] as? String
                    if (!vId.isNullOrBlank()) {
                        iniciarEscuchaViajeDocumento(vId, conductorId)
                    }
                    ofertaTimerJob?.cancel()
                    _uiState.value = _uiState.value.copy(
                        viajeActivo = viaje,
                        ofertaPendiente = null,
                        segundosOfertaRestantes = null
                    )
                } else if (viajeDocListener == null) {
                    _uiState.value = _uiState.value.copy(viajeActivo = null)
                }
            }
            ofertasListener = repository.observarOfertasConductor(conductorId) { ofertas ->
                procesarOfertasEntrantes(conductorId, ofertas)
            }
        }
        viewModelScope.launch {
            try {
                val viaje = repository.recuperarViajeActivoConductor(conductorId)
                val perfil = repository.obtenerPerfilYLicenciaConductor(conductorId)
                if (viaje != null) {
                    val vId = viaje["id"] as? String
                    if (!vId.isNullOrBlank()) {
                        iniciarEscuchaViajeDocumento(vId, conductorId)
                    }
                    _uiState.value = _uiState.value.copy(viajeActivo = viaje)
                } else if (viajeDocListener == null) {
                    _uiState.value = _uiState.value.copy(viajeActivo = null)
                }
                if (perfil != null) {
                    aplicarPerfilConductor(perfil)
                }
                val ctx = context?.applicationContext ?: appContext
                val estadoViajeActual = viaje?.get("estado") as? String
                val vIdActual = viaje?.get("id") as? String
                val oLatActual = (viaje?.get("origenLat") as? Number)?.toDouble()
                val oLngActual = (viaje?.get("origenLng") as? Number)?.toDouble()
                if (ctx != null) {
                    when {
                        estadoViajeActual == "aceptado" && !vIdActual.isNullOrBlank() && oLatActual != null && oLngActual != null -> {
                            iniciarModoRecogida90Seg(ctx, conductorId, vIdActual, oLatActual, oLngActual)
                        }
                        estadoViajeActual == "en_curso" -> {
                            detenerCicloGps(limpiarNotificacion = true)
                        }
                        _uiState.value.disponible && gpsRunnable == null -> {
                            iniciarModoEspera15Min(ctx, conductorId)
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo sincronizar datos del conductor."
                )
            }
        }
    }

    fun cargarMisSolicitudes(conductorId: String) {
        viewModelScope.launch {
            try {
                val lista = repository.obtenerMisSolicitudesCambio(conductorId)
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = lista,
                    solicitudesCargadas = true
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(solicitudesCargadas = true)
            }
        }
    }

    fun enviarSolicitudCambioConductor(
        conductorId: String,
        cambios: Map<String, Any>,
        motivo: String
    ) {
        if (cambios.isEmpty() || motivo.trim().length < 3) return
        viewModelScope.launch {
            try {
                val creada = repository.crearSolicitudCambioDatos(
                    solicitanteUid = conductorId,
                    rol = "conductor",
                    nombreActual = _uiState.value.nombreConductor.ifBlank { "Conductor Rural" },
                    resumenActual = "${_uiState.value.vehiculoTipo} · Placa ${_uiState.value.placa}",
                    cambios = cambios,
                    motivo = motivo
                )
                _uiState.value = _uiState.value.copy(
                    misSolicitudes = listOf(creada) + _uiState.value.misSolicitudes,
                    mensajeEstado = "Petición enviada al Administrador para su aprobación."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo enviar la petición."
                )
            }
        }
    }

    fun cargarHistorial(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargandoHistorial = true)
            try {
                val lista = repository.obtenerHistorialConductor(conductorId, 20L)
                _uiState.value = _uiState.value.copy(
                    historial = lista,
                    historialCargado = true,
                    cargandoHistorial = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(cargandoHistorial = false)
            }
        }
    }

    fun finalizarViaje(viajeId: String, conductorId: String, pasajeroId: String, montoCobrado: Double) {
        viewModelScope.launch {
            try {
                repository.finalizarViajeConFinanzas(viajeId, conductorId, montoCobrado)
                detenerCicloGps(limpiarNotificacion = true)
                val (hoy, mes) = repository.obtenerFinanzasConductor(conductorId)
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    finanzas = ConductorFinanzasSimple(gananciasHoy = hoy, gananciasMes = mes),
                    mostrarModalCobro = true,
                    montoACobrar = montoCobrado,
                    ultimoViajeId = viajeId,
                    ultimoPasajeroId = pasajeroId
                )
                val ctx = appContext
                if (ctx != null && _uiState.value.disponible) {
                    iniciarModoEspera15Min(ctx, conductorId)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "Error al finalizar el viaje."
                )
            }
        }
    }

    fun calificarPasajero(conductorId: String, estrellas: Int, comentario: String) {
        val viajeId = _uiState.value.ultimoViajeId ?: return
        val pasajeroId = _uiState.value.ultimoPasajeroId ?: return
        viewModelScope.launch {
            try {
                repository.enviarCalificacionYActualizarPromedio(
                    viajeId = viajeId,
                    autorUid = conductorId,
                    destinatarioUid = pasajeroId,
                    destinatarioRol = "pasajero",
                    estrellas = estrellas,
                    comentario = comentario
                )
            } catch (_: Exception) {
            } finally {
                _uiState.value = _uiState.value.copy(mostrarModalCobro = false)
            }
        }
    }

    fun cancelarViajeActivo(viajeId: String, conductorId: String, motivo: String) {
        if (motivo.trim().length < 3) return
        cancelacionPropiaViajeId = viajeId
        viajeDocListener?.remove()
        viajeDocListener = null
        viajeDocObservadoId = null
        viewModelScope.launch {
            try {
                repository.cancelarViajeConMotivo(
                    viajeId = viajeId,
                    canceladoPor = "conductor",
                    motivo = motivo,
                    conductorId = conductorId
                )
                detenerCicloGps(limpiarNotificacion = true)
                _uiState.value = _uiState.value.copy(
                    viajeActivo = null,
                    disponible = true,
                    mensajeEstado = "Viaje cancelado. Motivo registrado: ${motivo.trim()}"
                )
                val ctx = appContext
                if (ctx != null) {
                    iniciarModoEspera15Min(ctx, conductorId)
                }
            } catch (e: Exception) {
                cancelacionPropiaViajeId = null
                _uiState.value = _uiState.value.copy(
                    mensajeEstado = e.localizedMessage ?: "No se pudo cancelar el viaje."
                )
            }
        }
    }

    fun onViajeCanceladoPorPasajero(pasajeroNombre: String, motivo: String) {
        _uiState.value = _uiState.value.copy(
            viajeActivo = null,
            disponible = true,
            avisoCancelacionFlotante = "$pasajeroNombre canceló el viaje: \"$motivo\""
        )
    }

    fun limpiarAvisoCancelacionFlotante() {
        _uiState.value = _uiState.value.copy(avisoCancelacionFlotante = null)
    }

    fun cerrarModalCobro() {
        _uiState.value = _uiState.value.copy(mostrarModalCobro = false)
    }
}

// =============================================================================
// 3. ADMIN VIEWMODEL (Pestañas Modulares, Lazy limit(20), Fichas en Modal)
// =============================================================================
enum class AdminSeccion { RESUMEN, PENDIENTES, CONDUCTORES, PASAJEROS, SOLICITUDES, ALERTAS, DUPLICADOS, CONFIGURACION }

data class ConductorAdminItem(
    val uid: String,
    val nombre: String,
    val placa: String,
    val vehiculoTipo: String,
    val tarifaBase: Double,
    val tarifaPorKm: Double,
    val gananciasMes: Double,
    val esTarifaAbusiva: Boolean,
    val estadoCuenta: String,
    val cedulaHash: String = "",
    val diasLicenciaRestantes: Int = 30,
    val etiquetaLicencia: String = "Quedan 30 días",
    val estadoLicencia: String = "vigente",
    val fechaLicenciaTexto: String = ""
)

data class ConductorDocumentosUi(
    val fotoVehiculo: String = "",
    val fotoCedula: String = "",
    val fotoLicencia: String = "",
    val fotoCirculacion: String = ""
)

data class PasajeroAdminItem(
    val uid: String,
    val nombre: String,
    val promedioCalificacion: Double,
    val bloqueado: Boolean,
    val telefono: String = "",
    val email: String = "",
    val cedula: String = ""
)

data class VehiculoTipoUi(
    val nombre: String,
    val maxPasajeros: Int,
    val descripcion: String = ""
)

data class ConfiguracionGeneralUi(
    val whatsappSoporte: String = "62546546",
    val sinpeNumero: String = "62546546",
    val sinpeTitular: String = "Administración Viaje Rural",
    val adminNombre: String = "Administrador Viaje Rural",
    val adminTelefono: String = "62546546",
    val adminEmail: String = "sindicatosiserge@gmail.com",
    val linkDescarga: String = ViajeRepository.DEFAULT_LINK_DESCARGA,
    val terminosCondiciones: String = "",
    val tiposVehiculo: List<VehiculoTipoUi> = emptyList()
)

data class AdminUiState(
    val seccionActual: AdminSeccion = AdminSeccion.RESUMEN,
    val resumen: AdminResumenLigero = AdminResumenLigero(),
    val pendientes: List<ConductorAdminItem> = emptyList(),
    val pendientesCargados: Boolean = false,
    val conductores: List<ConductorAdminItem> = emptyList(),
    val conductoresCargados: Boolean = false,
    val pasajeros: List<PasajeroAdminItem> = emptyList(),
    val pasajerosCargados: Boolean = false,
    val solicitudesCambio: List<SolicitudCambioData> = emptyList(),
    val solicitudesCargadas: Boolean = false,
    val conductorSeleccionado: ConductorAdminItem? = null,
    val documentosConductorSeleccionado: ConductorDocumentosUi? = null,
    val cargandoDocumentos: Boolean = false,
    val aprobandoConductor: Boolean = false,
    val renovandoLicencia: Boolean = false,
    val pasajeroSeleccionado: PasajeroAdminItem? = null,
    val gestionandoPasajero: Boolean = false,
    val configuracion: ConfiguracionGeneralUi = ConfiguracionGeneralUi(),
    val promedioBaseFlota: Double = 1500.0,
    val promedioKmFlota: Double = 650.0,
    val cargando: Boolean = false,
    val errorMensaje: String? = null,
    val accionMensaje: String? = null
)

class AdminViewModel(
    private val repository: ViajeRepository = ViajeRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    @Suppress("UNCHECKED_CAST")
    private fun parseConfiguracionUi(rawConfig: Map<String, Any>): ConfiguracionGeneralUi {
        val tiposRaw = (rawConfig["tiposVehiculo"] as? List<Map<String, Any>>).orEmpty()
        val tiposUi = tiposRaw.map { t ->
            VehiculoTipoUi(
                nombre = t["nombre"] as? String ?: "",
                maxPasajeros = (t["maxPasajeros"] as? Number)?.toInt() ?: 4,
                descripcion = t["descripcion"] as? String ?: ""
            )
        }
        return ConfiguracionGeneralUi(
            whatsappSoporte = rawConfig["whatsappSoporte"] as? String ?: "62546546",
            sinpeNumero = rawConfig["sinpeNumero"] as? String ?: "62546546",
            sinpeTitular = rawConfig["adminSinpeTitular"] as? String ?: "Administración Viaje Rural",
            adminNombre = rawConfig["adminNombre"] as? String ?: "Administrador Viaje Rural",
            adminTelefono = rawConfig["adminTelefono"] as? String ?: "62546546",
            adminEmail = rawConfig["adminEmail"] as? String ?: "sindicatosiserge@gmail.com",
            linkDescarga = (rawConfig["linkDescarga"] as? String)?.trim()?.takeIf { it.isNotBlank() }
                ?: ViajeRepository.DEFAULT_LINK_DESCARGA,
            terminosCondiciones = rawConfig["terminosCondiciones"] as? String ?: "",
            tiposVehiculo = tiposUi
        )
    }

    private fun mapConductoresUi(
        rawConductores: List<Map<String, Any>>,
        promedioBase: Double = 1500.0,
        promedioKm: Double = 650.0
    ): List<ConductorAdminItem> {
        return rawConductores.map { c ->
            val tBase = (c["tarifaBase"] as? Number)?.toDouble() ?: 0.0
            val tKm = (c["tarifaPorKm"] as? Number)?.toDouble() ?: 0.0
            val abusiva = tBase > promedioBase * 1.30 || tKm > promedioKm * 1.30
            val licInfo = calcularDiasLicenciaRestantes(c["licenciaExp"])
            ConductorAdminItem(
                uid = c["uid"] as? String ?: "",
                nombre = c["nombre"] as? String ?: "",
                placa = c["placa"] as? String ?: "",
                vehiculoTipo = c["vehiculoTipo"] as? String ?: "",
                tarifaBase = tBase,
                tarifaPorKm = tKm,
                gananciasMes = (c["gananciasMes"] as? Number)?.toDouble() ?: 0.0,
                esTarifaAbusiva = abusiva,
                estadoCuenta = c["estadoCuenta"] as? String ?: "pendiente",
                cedulaHash = c["cedulaHash"] as? String ?: "",
                diasLicenciaRestantes = licInfo.dias,
                etiquetaLicencia = licInfo.etiqueta,
                estadoLicencia = licInfo.estado,
                fechaLicenciaTexto = licInfo.fechaTexto
            )
        }
    }

    fun cargarResumenInicial() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val resumen = repository.obtenerResumenAdminLigero()
                val rawConfig = try {
                    repository.obtenerConfiguracionGeneral()
                } catch (_: Exception) {
                    null
                }
                val configUi = rawConfig?.let { parseConfiguracionUi(it) } ?: _uiState.value.configuracion
                _uiState.value = _uiState.value.copy(
                    resumen = resumen,
                    configuracion = configUi,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = "Panel Administrador activo. Inicia sesión con cuenta admin para sincronizar datos en la nube (${e.localizedMessage ?: "sin conexión"})."
                )
            }
        }
    }

    /**
     * Carga cada pestaña bajo demanda con limit(20) ÚNICAMENTE cuando el Admin la toca.
     */
    fun seleccionarSeccion(seccion: AdminSeccion) {
        _uiState.value = _uiState.value.copy(seccionActual = seccion, accionMensaje = null)
        when (seccion) {
            AdminSeccion.RESUMEN -> cargarResumenInicial()
            AdminSeccion.PENDIENTES -> cargarPendientesLazy()
            AdminSeccion.CONDUCTORES, AdminSeccion.ALERTAS, AdminSeccion.DUPLICADOS -> {
                if (!_uiState.value.conductoresCargados) cargarConductoresLazy()
            }
            AdminSeccion.PASAJEROS -> {
                if (!_uiState.value.pasajerosCargados) cargarPasajerosLazy()
            }
            AdminSeccion.SOLICITUDES -> {
                if (!_uiState.value.solicitudesCargadas) cargarSolicitudesCambioLazy()
            }
            AdminSeccion.CONFIGURACION -> cargarConfiguracion()
        }
    }

    fun cargarPendientesLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawPendientes = repository.obtenerConductoresPendientesAdmin(20L)
                val lista = mapConductoresUi(rawPendientes)
                _uiState.value = _uiState.value.copy(
                    pendientes = lista,
                    pendientesCargados = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los conductores pendientes."
                )
            }
        }
    }

    fun cargarSolicitudesCambioLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val lista = repository.obtenerSolicitudesCambioAdmin(20L)
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = lista,
                    solicitudesCargadas = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar las peticiones."
                )
            }
        }
    }

    fun resolverSolicitudCambio(
        solicitud: SolicitudCambioData,
        aprobar: Boolean,
        respuestaAdmin: String = ""
    ) {
        viewModelScope.launch {
            try {
                repository.resolverSolicitudCambioAdmin(solicitud, aprobar, respuestaAdmin)
                val actualizadas = _uiState.value.solicitudesCambio.map {
                    if (it.id == solicitud.id) {
                        it.copy(
                            estado = if (aprobar) "aprobada" else "rechazada",
                            respuestaAdmin = respuestaAdmin
                        )
                    } else it
                }
                _uiState.value = _uiState.value.copy(
                    solicitudesCambio = actualizadas,
                    conductoresCargados = if (aprobar && solicitud.rol == "conductor") false else _uiState.value.conductoresCargados,
                    pasajerosCargados = if (aprobar && solicitud.rol == "pasajero") false else _uiState.value.pasajerosCargados
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo procesar la petición."
                )
            }
        }
    }

    fun cargarConductoresLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawConductores = repository.obtenerConductoresAdmin(20L)
                val promedioBase = if (rawConductores.isNotEmpty()) {
                    rawConductores.mapNotNull { (it["tarifaBase"] as? Number)?.toDouble() }.average()
                } else 1500.0
                val promedioKm = if (rawConductores.isNotEmpty()) {
                    rawConductores.mapNotNull { (it["tarifaPorKm"] as? Number)?.toDouble() }.average()
                } else 650.0

                val conductoresUi = mapConductoresUi(rawConductores, promedioBase, promedioKm)
                _uiState.value = _uiState.value.copy(
                    conductores = conductoresUi,
                    conductoresCargados = true,
                    promedioBaseFlota = promedioBase,
                    promedioKmFlota = promedioKm,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los conductores."
                )
            }
        }
    }

    fun cargarPasajerosLazy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawPasajeros = repository.obtenerPasajerosAdmin(20L)
                val pasajerosUi = rawPasajeros.map { p ->
                    PasajeroAdminItem(
                        uid = p["uid"] as? String ?: "",
                        nombre = p["nombre"] as? String ?: "",
                        promedioCalificacion = (p["promedioCalificacion"] as? Number)?.toDouble() ?: 5.0,
                        bloqueado = p["bloqueado"] as? Boolean ?: false
                    )
                }
                _uiState.value = _uiState.value.copy(
                    pasajeros = pasajerosUi,
                    pasajerosCargados = true,
                    cargando = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudieron cargar los pasajeros."
                )
            }
        }
    }

    fun cargarConfiguracion() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(cargando = true, errorMensaje = null)
            try {
                val rawConfig = repository.obtenerConfiguracionGeneral()
                val configUi = parseConfiguracionUi(rawConfig)
                _uiState.value = _uiState.value.copy(configuracion = configUi, cargando = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    cargando = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo cargar la configuración."
                )
            }
        }
    }

    fun seleccionarConductor(conductor: ConductorAdminItem) {
        _uiState.value = _uiState.value.copy(
            conductorSeleccionado = conductor,
            documentosConductorSeleccionado = null,
            cargandoDocumentos = true
        )
        viewModelScope.launch {
            try {
                val rawDocs = repository.obtenerDocumentosConductorAdmin(conductor.uid)
                val docsUi = ConductorDocumentosUi(
                    fotoVehiculo = rawDocs?.get("fotoVehiculo") as? String ?: "",
                    fotoCedula = rawDocs?.get("fotoCedula") as? String ?: "",
                    fotoLicencia = rawDocs?.get("fotoLicencia") as? String ?: "",
                    fotoCirculacion = rawDocs?.get("fotoCirculacion") as? String ?: ""
                )
                _uiState.value = _uiState.value.copy(
                    documentosConductorSeleccionado = docsUi,
                    cargandoDocumentos = false
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(
                    documentosConductorSeleccionado = ConductorDocumentosUi(),
                    cargandoDocumentos = false
                )
            }
        }
    }

    fun cerrarFichaConductor() {
        _uiState.value = _uiState.value.copy(
            conductorSeleccionado = null,
            documentosConductorSeleccionado = null,
            cargandoDocumentos = false,
            renovandoLicencia = false
        )
    }

    fun renovarLicenciaUnMes(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(renovandoLicencia = true, errorMensaje = null)
            try {
                val nuevaExp = repository.renovarLicenciaConductorAdmin(conductorId)
                val licInfo = calcularDiasLicenciaRestantes(nuevaExp)
                val actualizarItem: (ConductorAdminItem) -> ConductorAdminItem = { item ->
                    if (item.uid == conductorId) {
                        item.copy(
                            diasLicenciaRestantes = licInfo.dias,
                            etiquetaLicencia = licInfo.etiqueta,
                            estadoLicencia = licInfo.estado,
                            fechaLicenciaTexto = licInfo.fechaTexto
                        )
                    } else item
                }
                _uiState.value = _uiState.value.copy(
                    renovandoLicencia = false,
                    conductorSeleccionado = _uiState.value.conductorSeleccionado?.let(actualizarItem),
                    conductores = _uiState.value.conductores.map(actualizarItem),
                    pendientes = _uiState.value.pendientes.map(actualizarItem),
                    accionMensaje = "Licencia renovada (+1 mes) hasta ${licInfo.fechaTexto}."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    renovandoLicencia = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo renovar la licencia."
                )
            }
        }
    }

    fun aprobarYActivarConductor(conductorId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(aprobandoConductor = true, errorMensaje = null)
            try {
                val nuevaExp = repository.aprobarYActivarConductorAdmin(conductorId)
                val licInfo = calcularDiasLicenciaRestantes(nuevaExp)
                _uiState.value = _uiState.value.copy(
                    aprobandoConductor = false,
                    conductorSeleccionado = null,
                    documentosConductorSeleccionado = null,
                    pendientes = _uiState.value.pendientes.filterNot { it.uid == conductorId },
                    conductores = _uiState.value.conductores.map {
                        if (it.uid == conductorId) {
                            it.copy(
                                estadoCuenta = "activo",
                                diasLicenciaRestantes = licInfo.dias,
                                etiquetaLicencia = licInfo.etiqueta,
                                estadoLicencia = licInfo.estado,
                                fechaLicenciaTexto = licInfo.fechaTexto
                            )
                        } else it
                    },
                    conductoresCargados = false,
                    accionMensaje = "Conductor aprobado y activado. Licencia vigente hasta ${licInfo.fechaTexto}."
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    aprobandoConductor = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo aprobar y activar el conductor."
                )
            }
        }
    }

    fun seleccionarPasajero(pasajero: PasajeroAdminItem) {
        viewModelScope.launch {
            try {
                val pii = repository.obtenerPiiUsuarioAdmin(pasajero.uid)
                _uiState.value = _uiState.value.copy(
                    pasajeroSeleccionado = pasajero.copy(
                        telefono = pii?.get("telefono") as? String ?: "",
                        email = pii?.get("email") as? String ?: "",
                        cedula = pii?.get("cedula") as? String ?: ""
                    )
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(pasajeroSeleccionado = pasajero)
            }
        }
    }

    fun guardarFichaPasajero(
        uid: String,
        nombre: String,
        telefono: String,
        email: String,
        cedula: String
    ) {
        viewModelScope.launch {
            try {
                repository.actualizarFichaPasajeroAdmin(uid, nombre, telefono, email, cedula)
                _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null)
                cargarPasajerosLazy()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo guardar el pasajero."
                )
            }
        }
    }

    fun toggleBloqueoPasajero(pasajero: PasajeroAdminItem) {
        val nuevoEstado = !pasajero.bloqueado
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(gestionandoPasajero = true, errorMensaje = null)
            try {
                repository.toggleBloqueoPasajeroAdmin(pasajero.uid, nuevoEstado)
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    pasajeroSeleccionado = _uiState.value.pasajeroSeleccionado?.copy(bloqueado = nuevoEstado),
                    pasajeros = _uiState.value.pasajeros.map {
                        if (it.uid == pasajero.uid) it.copy(bloqueado = nuevoEstado) else it
                    },
                    accionMensaje = if (nuevoEstado) "Pasajero bloqueado en Firestore." else "Pasajero desbloqueado en Firestore."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo actualizar el bloqueo del pasajero."
                )
            }
        }
    }

    fun eliminarCuentaPasajero(pasajeroId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(gestionandoPasajero = true, errorMensaje = null)
            try {
                repository.eliminarCuentaPasajeroAdmin(pasajeroId)
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    pasajeroSeleccionado = null,
                    pasajeros = _uiState.value.pasajeros.filterNot { it.uid == pasajeroId },
                    accionMensaje = "Cuenta del pasajero eliminada de Firestore."
                )
                cargarResumenInicial()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    gestionandoPasajero = false,
                    errorMensaje = e.localizedMessage ?: "No se pudo eliminar la cuenta del pasajero."
                )
            }
        }
    }

    fun cerrarFichaPasajero() {
        _uiState.value = _uiState.value.copy(pasajeroSeleccionado = null, gestionandoPasajero = false)
    }

    fun limpiarAccionMensaje() {
        _uiState.value = _uiState.value.copy(accionMensaje = null)
    }

    fun guardarConfiguracion(config: ConfiguracionGeneralUi) {
        viewModelScope.launch {
            try {
                val tiposMap = config.tiposVehiculo.map {
                    mapOf(
                        "nombre" to it.nombre,
                        "maxPasajeros" to it.maxPasajeros,
                        "descripcion" to it.descripcion
                    )
                }
                repository.guardarConfiguracionGeneralAdmin(
                    whatsappSoporte = config.whatsappSoporte,
                    sinpeNumero = config.sinpeNumero,
                    sinpeTitular = config.sinpeTitular,
                    adminNombre = config.adminNombre,
                    adminTelefono = config.adminTelefono,
                    adminEmail = config.adminEmail,
                    terminosCondiciones = config.terminosCondiciones,
                    tiposVehiculo = tiposMap,
                    linkDescarga = config.linkDescarga
                )
                _uiState.value = _uiState.value.copy(
                    configuracion = config,
                    accionMensaje = "Configuración y enlace de descarga guardados."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMensaje = e.localizedMessage ?: "No se pudo guardar la configuración."
                )
            }
        }
    }
}
