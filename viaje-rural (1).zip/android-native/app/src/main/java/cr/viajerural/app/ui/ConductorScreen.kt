package cr.viajerural.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import cr.viajerural.app.data.CambioItemData
import cr.viajerural.app.data.LicenciaRestanteInfo
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.data.ViajeRepository
import cr.viajerural.app.data.calcularMensualidadConductorActual
import cr.viajerural.app.data.formatearColonesEntero
import cr.viajerural.app.messaging.NotificationHelper
import cr.viajerural.app.service.PickupLocationService
import cr.viajerural.app.util.ImageCompressionUtils
import cr.viajerural.app.viewmodel.ConductorTab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Pantalla del Conductor con BottomNavigation (4 pestañas) y diseño ordenado estilo Web:
 * - Inicio: Ofertas de viaje 15s, estado Activo/Inactivo, días de licencia, Waze, PIN y botones Ver Mapa / Abrir Chat.
 * - Finanzas: SOLO 2 datos (Generado Hoy y Generado en el Mes) + estado de licencia.
 * - Historial: Carga lazy limit(20) solo al tocar la pestaña.
 * - Perfil: Tarifa base (₡), Precio por kilómetro adicional (₡), ficha bloqueada, compartir app y cerrar sesión.
 */
@Composable
fun ConductorScreen(
    tabActual: ConductorTab,
    onSelectTab: (ConductorTab) -> Unit,
    conductorId: String,
    viajeActivoId: String?,
    estadoViaje: String?,
    pasajeroNombre: String?,
    cantidadPasajeros: Int,
    resenaUbicacion: String?,
    origenLat: Double?,
    origenLng: Double?,
    destinoLat: Double?,
    destinoLng: Double?,
    segundosOfertaRestantes: Int?,
    gananciasHoy: Double,
    gananciasMes: Double,
    historial: List<Map<String, Any>>,
    cargandoHistorial: Boolean,
    mostrarModalCobro: Boolean,
    montoACobrar: Double,
    onAceptarOferta: () -> Unit,
    onRechazarOferta: () -> Unit,
    onVerificarPin: (String) -> Unit,
    onFinalizarViaje: (montoCobrado: Double) -> Unit,
    onCalificarPasajero: (estrellas: Int, comentario: String) -> Unit,
    onDismissModalCobro: () -> Unit,
    licenciaRestante: LicenciaRestanteInfo? = null,
    nombreConductor: String = "",
    telefonoConductor: String = "",
    placa: String = "",
    vehiculoTipo: String = "",
    vehiculoMarca: String = "",
    vehiculoModelo: String = "",
    vehiculoColor: String = "",
    vehiculoAnio: String = "",
    capacidad: Int = 4,
    tarifaBase: Double = 1500.0,
    tarifaBaseCarga: Double? = null,
    tarifaPorKm: Double = 650.0,
    tieneCascoExtra: Boolean = false,
    tieneCapaDisponible: Boolean = false,
    fotoVehiculoActual: String = "",
    fotoCedulaActual: String = "",
    fotoLicenciaActual: String = "",
    fotoCirculacionActual: String = "",
    misSolicitudes: List<SolicitudCambioData> = emptyList(),
    onEnviarSolicitudCambio: (cambios: Map<String, Any>, motivo: String) -> Unit = { _, _ -> },
    onEnviarSolicitudCambioLineas: (items: List<CambioItemData>, motivo: String) -> Unit = { _, _ -> },
    onActualizarTarifasYEquipamiento: (
        tarifaBase: Double,
        tarifaPorKm: Double,
        tarifaBaseCarga: Double?,
        tieneCascoExtra: Boolean,
        tieneCapaDisponible: Boolean
    ) -> Unit = { _, _, _, _, _ -> },
    onCancelarViaje: (motivo: String) -> Unit = {},
    avisoCancelacionFlotante: String? = null,
    onDismissAvisoCancelacion: () -> Unit = {},
    disponible: Boolean = false,
    actualizandoDisponibilidad: Boolean = false,
    mensajeEstado: String? = null,
    onDismissMensajeEstado: () -> Unit = {},
    onToggleDisponible: (Boolean) -> Unit = {},
    procesandoOferta: Boolean = false,
    errorPin: String? = null,
    mensajesChat: List<Map<String, Any>> = emptyList(),
    onAbrirChat: (String) -> Unit = {},
    onCerrarChat: () -> Unit = {},
    onEnviarMensajeChat: (String, String) -> Unit = { _, _ -> },
    linkDescarga: String = "https://viajerural.com/descargar",
    onCerrarSesion: () -> Unit = {},
    chatNoLeidos: Int = 0,
    alertaChatFlotante: String? = null,
    onDismissAlertaChat: () -> Unit = {},
    conductorLlego: Boolean = false,
    onNotificarLlegada: () -> Unit = {},
    montoMensualBase: Int = ViajeRepository.DEFAULT_MONTO_MENSUAL_CONDUCTOR_BASE,
    anioBaseMensualidad: Int = ViajeRepository.DEFAULT_ANIO_BASE_MENSUALIDAD,
    multiplicadorTopeNormal: Double = ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_NORMAL,
    multiplicadorTopeCarga: Double = ViajeRepository.DEFAULT_MULTIPLICADOR_TOPE_CARGA,
    terminosConductor: String = ViajeRepository.DEFAULT_TERMINOS_CONDICIONES_CONDUCTOR,
    sinpeNumero: String = "62546546",
    sinpeTitular: String = "Administración Viaje Rural",
    esCargaFleteViajeActivo: Boolean = false,
    montoAproximadoViajeActivo: Double = 0.0,
    montoReferenciaViajeActivo: Double = 0.0,
    limiteMaximoViajeActivo: Double = 0.0
) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current

    var isActivo by remember { mutableStateOf(disponible) }
    LaunchedEffect(disponible, actualizandoDisponibilidad) {
        if (!actualizandoDisponibilidad) {
            isActivo = disponible
        }
    }

    var pinInput by remember { mutableStateOf("") }
    var estrellasPasajero by remember { mutableIntStateOf(5) }
    var comentarioPasajero by remember { mutableStateOf("") }

    LaunchedEffect(viajeActivoId, estadoViaje, mostrarModalCobro) {
        if (viajeActivoId == null || estadoViaje != "aceptado" || mostrarModalCobro) {
            pinInput = ""
        }
    }
    LaunchedEffect(mostrarModalCobro) {
        estrellasPasajero = 5
        comentarioPasajero = ""
    }
    var mostrarMapaModal by remember { mutableStateOf(false) }
    var mostrarChatModal by remember { mutableStateOf(false) }
    var mostrarModalSolicitud by remember { mutableStateOf(false) }
    var mostrarModalCancelar by remember { mutableStateOf(false) }
    var mostrarModalPermisos by remember { mutableStateOf(false) }
    var mostrarModalTerminosConductor by remember { mutableStateOf(false) }
    val calculoMensualidad = remember(montoMensualBase, anioBaseMensualidad) {
        calcularMensualidadConductorActual(
            montoBase = montoMensualBase,
            anioBase = anioBaseMensualidad
        )
    }
    var mesHistorial by remember { mutableStateOf(obtenerMesActualCostaRicaKey()) }
    var motivoCancelacionInput by remember { mutableStateOf("") }
    var tarifaBaseInput by remember(tarifaBase) { mutableStateOf(tarifaBase.toInt().toString()) }
    var tarifaKmInput by remember(tarifaPorKm) { mutableStateOf(tarifaPorKm.toInt().toString()) }
    var tarifaBaseCargaInput by remember(tarifaBaseCarga) {
        mutableStateOf(tarifaBaseCarga?.toInt()?.toString() ?: "")
    }
    var cascoExtraInput by remember(tieneCascoExtra) { mutableStateOf(tieneCascoExtra) }
    var capaDisponibleInput by remember(tieneCapaDisponible) { mutableStateOf(tieneCapaDisponible) }
    var mostrarDialogoConfirmarCobro by remember { mutableStateOf(false) }
    var montoCobroInput by remember { mutableStateOf("") }

    LaunchedEffect(avisoCancelacionFlotante) {
        if (!avisoCancelacionFlotante.isNullOrBlank()) {
            PickupLocationService.stop(context)
            mostrarMapaModal = false
            mostrarChatModal = false
            mostrarModalCancelar = false
        }
    }

    // Estados y lanzadores secuenciales de permisos críticos del Conductor
    var notificacionesOk by remember { mutableStateOf(tienePermisoNotificaciones(context)) }
    var ubicacionFinaOk by remember { mutableStateOf(tienePermisoUbicacionFina(context)) }
    var ubicacionSegundoPlanoOk by remember { mutableStateOf(tienePermisoUbicacionSegundoPlano(context)) }
    var mostrarDialogoSegundoPlano by remember { mutableStateOf(false) }
    var pendienteActivarConductor by remember { mutableStateOf(false) }
    var solicitudesPermisosIniciadas by remember { mutableStateOf(false) }

    fun refrescarPermisos() {
        notificacionesOk = tienePermisoNotificaciones(context)
        ubicacionFinaOk = tienePermisoUbicacionFina(context)
        ubicacionSegundoPlanoOk = tienePermisoUbicacionSegundoPlano(context)
    }

    val launcherSegundoPlano = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        refrescarPermisos()
        if (granted || tienePermisoUbicacionSegundoPlano(context)) {
            mostrarDialogoSegundoPlano = false
        }
    }

    val launcherUbicacionPrimerPlano = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        refrescarPermisos()
        val finaConcedida = granted || tienePermisoUbicacionFina(context)
        if (finaConcedida) {
            if (pendienteActivarConductor) {
                pendienteActivarConductor = false
                isActivo = true
                // Pulso GPS único de bajo consumo ejecutado en ViewModel + Repository
                onToggleDisponible(true)
            }
            // SOLO después de aceptar ubicación en primer plano, solicitar ACCESS_BACKGROUND_LOCATION
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !tienePermisoUbicacionSegundoPlano(context)) {
                mostrarDialogoSegundoPlano = true
            }
        } else {
            pendienteActivarConductor = false
            isActivo = false
        }
    }

    val launcherNotificaciones = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        refrescarPermisos()
        // Encadenar ubicación en primer plano tras resolver notificaciones
        if (!tienePermisoUbicacionFina(context)) {
            try {
                launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            } catch (_: Throwable) {
                pendienteActivarConductor = false
            }
        } else {
            if (pendienteActivarConductor) {
                pendienteActivarConductor = false
                isActivo = true
                onToggleDisponible(true)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !tienePermisoUbicacionSegundoPlano(context)) {
                mostrarDialogoSegundoPlano = true
            }
        }
    }

    // Al regresar de Ajustes ("Permitir todo el tiempo"), actualizar estado de permisos
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refrescarPermisos()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Al iniciar la pantalla principal del Conductor:
    // 1) POST_NOTIFICATIONS (Android 13+) -> 2) ACCESS_FINE_LOCATION -> 3) ACCESS_BACKGROUND_LOCATION
    LaunchedEffect(Unit) {
        if (!solicitudesPermisosIniciadas) {
            solicitudesPermisosIniciadas = true
            refrescarPermisos()
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !tienePermisoNotificaciones(context)) {
                    launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else if (!tienePermisoUbicacionFina(context)) {
                    launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !tienePermisoUbicacionSegundoPlano(context)) {
                    mostrarDialogoSegundoPlano = true
                }
            } catch (_: Throwable) {
            }
        }
    }

    // El ciclo GPS híbrido (15 min en espera / 90s en recogida / detenido al verificar PIN)
    // se gestiona directamente en ConductorViewModel para evitar lecturas duplicadas.

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Scaffold(
        containerColor = Color(0xFFF7F8F6),
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = tabActual == ConductorTab.INICIO,
                    onClick = { onSelectTab(ConductorTab.INICIO) },
                    icon = { Text("🏠") },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.FINANZAS,
                    onClick = { onSelectTab(ConductorTab.FINANZAS) },
                    icon = { Text("₡") },
                    label = { Text("Finanzas") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.HISTORIAL,
                    onClick = { onSelectTab(ConductorTab.HISTORIAL) },
                    icon = { Text("📜") },
                    label = { Text("Historial") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.PERFIL,
                    onClick = { onSelectTab(ConductorTab.PERFIL) },
                    icon = { Text("⚙️") },
                    label = { Text("Perfil") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (tabActual) {
                    ConductorTab.INICIO -> {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Viaje Rural — Conductor",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14231A)
                                    )
                                    Text(
                                        text = if (nombreConductor.isNotBlank()) "$nombreConductor · $placa" else "Panel operativo",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                }
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedIconButton(
                                        onClick = { mostrarModalPermisos = true }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = "Permisos y Configuración",
                                            tint = Color(0xFF15803D)
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = { compartirAppConductor(context, linkDescarga) },
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Compartir App")
                                    }
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(
                                    1.dp,
                                    if (isActivo) Color(0xFF86EFAC) else Color(0xFFE2E6DF)
                                ),
                                colors = CardDefaults.outlinedCardColors(
                                    containerColor = if (isActivo) Color(0xFFF0FDF4) else Color.White
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(end = 12.dp)
                                    ) {
                                        Text(
                                            text = if (isActivo) "En Línea (Activo)" else "Activar / En Línea",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isActivo) Color(0xFF15803D) else Color(0xFF14231A)
                                        )
                                        Text(
                                            text = when {
                                                actualizandoDisponibilidad -> "Capturando ubicación única y guardando..."
                                                isActivo -> "Activo cada 15 min · Permanece en línea aunque uses Waze."
                                                else -> "Activa el interruptor para pasar a en línea y recibir ofertas."
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                    Switch(
                                        checked = isActivo,
                                        onCheckedChange = { activar ->
                                            if (activar) {
                                                val faltaNotif = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                                    !tienePermisoNotificaciones(context)
                                                val faltaFina = !tienePermisoUbicacionFina(context)

                                                if (faltaNotif && faltaFina) {
                                                    pendienteActivarConductor = true
                                                    try {
                                                        launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                    } catch (_: Throwable) {
                                                        pendienteActivarConductor = false
                                                    }
                                                } else if (faltaFina) {
                                                    pendienteActivarConductor = true
                                                    try {
                                                        launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                                                    } catch (_: Throwable) {
                                                        pendienteActivarConductor = false
                                                    }
                                                } else if (faltaNotif) {
                                                    pendienteActivarConductor = true
                                                    try {
                                                        launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                    } catch (_: Throwable) {
                                                        pendienteActivarConductor = false
                                                    }
                                                } else {
                                                    isActivo = true
                                                    onToggleDisponible(true)
                                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                                                        !tienePermisoUbicacionSegundoPlano(context)
                                                    ) {
                                                        mostrarDialogoSegundoPlano = true
                                                    }
                                                }
                                            } else {
                                                pendienteActivarConductor = false
                                                isActivo = false
                                                PickupLocationService.stop(context)
                                                onToggleDisponible(false)
                                            }
                                        },
                                        enabled = viajeActivoId == null && !actualizandoDisponibilidad
                                    )
                                }
                            }

                            if (!mensajeEstado.isNullOrBlank()) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = mensajeEstado,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF991B1B),
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(end = 8.dp)
                                        )
                                        TextButton(onClick = onDismissMensajeEstado) {
                                            Text("Cerrar")
                                        }
                                    }
                                }
                            }

                            if (!notificacionesOk || !ubicacionFinaOk || !ubicacionSegundoPlanoOk) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFFFBEB))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "Permisos requeridos para recibir ofertas",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF78350F)
                                        )
                                        Text(
                                            text = buildString {
                                                append("• Notificaciones: ")
                                                append(if (notificacionesOk) "OK\n" else "Falta activar\n")
                                                append("• Ubicación en primer plano: ")
                                                append(if (ubicacionFinaOk) "OK\n" else "Falta activar\n")
                                                append("• Ubicación en segundo plano (todo el tiempo): ")
                                                append(if (ubicacionSegundoPlanoOk) "OK" else "Falta activar")
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF78350F)
                                        )
                                        OutlinedButton(
                                            onClick = {
                                                try {
                                                    when {
                                                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificacionesOk -> {
                                                            launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                        }
                                                        !ubicacionFinaOk -> {
                                                            launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                                                        }
                                                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !ubicacionSegundoPlanoOk -> {
                                                            mostrarDialogoSegundoPlano = true
                                                        }
                                                    }
                                                } catch (_: Throwable) {
                                                    abrirAjustesAplicacion(context)
                                                }
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Configurar permisos faltantes", fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }

                            licenciaRestante?.let { lic ->
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(
                                        containerColor = when (lic.estado) {
                                            "vencida" -> Color(0xFFFEF2F2)
                                            "por_vencer" -> Color(0xFFFEF3C7)
                                            else -> Color.White
                                        }
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Estado de Licencia", fontWeight = FontWeight.SemiBold)
                                            if (lic.fechaTexto.isNotBlank() && lic.fechaTexto != "--/--/----") {
                                                Text(
                                                    text = "Vence: ${lic.fechaTexto}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = Color(0xFF525B50)
                                                )
                                            }
                                        }
                                        Text(
                                            text = if (lic.dias > 0) "Licencia vigente: ${lic.dias} días" else "Licencia vencida",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = if (lic.dias <= 0) Color(0xFFDC2626) else Color(0xFF15803D)
                                        )
                                    }
                                }
                            }

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
                                !NotificationHelper.puedeUsarFullScreenIntent(context)
                            ) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFFFBEB))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Activa \"Notificaciones a pantalla completa\" para ver ofertas sobre Waze o pantalla bloqueada.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF78350F),
                                            modifier = Modifier.weight(1f)
                                        )
                                        TextButton(
                                            onClick = {
                                                try {
                                                    val intent = Intent(
                                                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                                        Uri.fromParts("package", context.packageName, null)
                                                    ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                                                    context.startActivity(intent)
                                                } catch (_: Throwable) {
                                                    abrirAjustesAplicacion(context)
                                                }
                                            }
                                        ) { Text("Activar") }
                                    }
                                }
                            }

                            if (viajeActivoId != null && (estadoViaje == "aceptado" || estadoViaje == "en_curso") && !alertaChatFlotante.isNullOrBlank()) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.dp, Color(0xFF15803D)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFDCFCE7))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Nuevo mensaje del pasajero", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                                            Text(alertaChatFlotante, style = MaterialTheme.typography.bodySmall, color = Color(0xFF14231A))
                                        }
                                        Row {
                                            TextButton(
                                                onClick = {
                                                    onDismissAlertaChat()
                                                    onAbrirChat(viajeActivoId)
                                                    mostrarChatModal = true
                                                }
                                            ) { Text("Ver") }
                                            TextButton(onClick = onDismissAlertaChat) { Text("✕") }
                                        }
                                    }
                                }
                            }

                            if (viajeActivoId != null && estadoViaje == "aceptado" && origenLat != null && origenLng != null) {
                                Button(
                                    onClick = { abrirWaze(context, origenLat, origenLng) },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp)
                                ) { Text("Retomar recogida (Waze)", fontWeight = FontWeight.SemiBold) }

                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            text = "Pasajero: ${pasajeroNombre.orEmpty()} ($cantidadPasajeros pax)",
                                            fontWeight = FontWeight.Bold
                                        )
                                        Surface(
                                            color = Color(0xFFF7F8F6),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "Reseña: ${resenaUbicacion.orEmpty().ifBlank { "Sin referencia" }}",
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(10.dp)
                                            )
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(
                                                onClick = { mostrarMapaModal = true },
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text("Ver Mapa") }
                                            OutlinedButton(
                                                onClick = {
                                                    viajeActivoId?.let { onAbrirChat(it) }
                                                    mostrarChatModal = true
                                                },
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text(if (chatNoLeidos > 0) "Chat ($chatNoLeidos)" else "Abrir Chat") }
                                        }

                                        if (!conductorLlego) {
                                            Button(
                                                onClick = onNotificarLlegada,
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(50.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Ya llegué (Avisar al pasajero)", fontWeight = FontWeight.Bold)
                                            }
                                        } else {
                                            Surface(
                                                color = Color(0xFFECFDF5),
                                                shape = RoundedCornerShape(10.dp),
                                                border = BorderStroke(1.dp, Color(0xFF15803D)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = Color(0xFF15803D),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                    Text(
                                                        text = "¡Ya llegaste! El pasajero recibió tu notificación. Pídele el PIN de 3 dígitos.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = Color(0xFF14532D)
                                                    )
                                                }
                                            }
                                        }

                                        OutlinedTextField(
                                            value = pinInput,
                                            onValueChange = { if (it.length <= 3) pinInput = it.filter(Char::isDigit) },
                                            label = { Text("Ingresar PIN de 3 dígitos del pasajero") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        if (!errorPin.isNullOrBlank()) {
                                            Text(
                                                text = errorPin,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.error
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                onVerificarPin(pinInput)
                                            },
                                            enabled = pinInput.length == 3,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                        ) { Text("Confirmar PIN y apagar GPS") }

                                        OutlinedButton(
                                            onClick = {
                                                motivoCancelacionInput = ""
                                                mostrarModalCancelar = true
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) { Text("Cancelar viaje (ingresar nota)") }
                                    }
                                }
                            } else if (viajeActivoId != null && estadoViaje == "en_curso" && destinoLat != null && destinoLng != null) {
                                Button(
                                    onClick = { abrirWaze(context, destinoLat, destinoLng) },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp)
                                ) { Text("Retomar viaje al destino (Waze)", fontWeight = FontWeight.SemiBold) }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { mostrarMapaModal = true },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Ver Mapa") }
                                    OutlinedButton(
                                        onClick = {
                                            viajeActivoId?.let { onAbrirChat(it) }
                                            mostrarChatModal = true
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) { Text(if (chatNoLeidos > 0) "Chat ($chatNoLeidos)" else "Abrir Chat") }
                                }

                                if (esCargaFleteViajeActivo) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFFFFBEB),
                                        border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "CON CARGA / FLETE · Estimado ₡${montoAproximadoViajeActivo.toInt()}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF92400E),
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                                Button(
                                    onClick = {
                                        pinInput = ""
                                        val inicial = montoAproximadoViajeActivo.takeIf { it > 0.0 }?.toInt()
                                            ?: tarifaBase.toInt()
                                        montoCobroInput = inicial.toString()
                                        mostrarDialogoConfirmarCobro = true
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                ) {
                                    Text("Finalizar viaje y cobrar", fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        motivoCancelacionInput = ""
                                        mostrarModalCancelar = true
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Cancelar viaje (ingresar nota)") }
                            } else if (segundosOfertaRestantes != null) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.5.dp, Color(0xFF15803D)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Text(
                                            text = "Nueva solicitud (${segundosOfertaRestantes}s)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF15803D)
                                        )
                                        if (esCargaFleteViajeActivo) {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = Color(0xFFFFFBEB),
                                                border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(
                                                    text = "CON CARGA / FLETE · Estimado ₡${montoAproximadoViajeActivo.toInt()}",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF92400E),
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "Referencia del pasajero: ${resenaUbicacion.orEmpty().ifBlank { "Sin referencia" }}",
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text("Cantidad: $cantidadPasajeros pasajeros")
                                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            OutlinedButton(
                                                onClick = onRechazarOferta,
                                                enabled = !procesandoOferta,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text("Rechazar") }
                                            Button(
                                                onClick = onAceptarOferta,
                                                enabled = !procesandoOferta,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text(if (procesandoOferta) "Aceptando..." else "Aceptar") }
                                        }
                                    }
                                }
                            } else {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("Modo Espera", fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "GPS apagado para ahorrar batería y datos mientras esperas solicitudes.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    ConductorTab.FINANZAS -> {
                        Text(
                            text = "Finanzas del Conductor",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedCard(
                                modifier = Modifier.weight(1f),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("Generado Hoy", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                    Text(
                                        text = "₡${gananciasHoy.toInt()}",
                                        fontSize = 24.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D)
                                    )
                                }
                            }
                            OutlinedCard(
                                modifier = Modifier.weight(1f),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("Generado Mes", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                    Text(
                                        text = "₡${gananciasMes.toInt()}",
                                        fontSize = 24.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14231A)
                                    )
                                }
                            }
                        }

                        licenciaRestante?.let { lic ->
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("Estado de Licencia Mensual", style = MaterialTheme.typography.labelMedium, color = Color(0xFF525B50))
                                    Text(
                                        text = lic.etiqueta,
                                        fontSize = 22.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (lic.estado == "vencida") Color(0xFFDC2626) else Color(0xFF15803D)
                                    )
                                    Text(
                                        text = "Vence: ${lic.fechaTexto} · Cuota vigente ${formatearColonesEntero(calculoMensualidad.montoActual)}/mes (+10% cada 1 de enero)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Text(
                                        text = "Base ${calculoMensualidad.anioBase}: ${formatearColonesEntero(calculoMensualidad.montoBase)} · Incrementos aplicados: ${calculoMensualidad.incrementosAplicados} · Próx. 1 ene: ${formatearColonesEntero(calculoMensualidad.montoProximoEnero)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFF15803D)
                                    )
                                }
                            }
                        }
                    }

                    ConductorTab.HISTORIAL -> {
                        val historialMes = remember(historial, mesHistorial) {
                            filtrarViajesPorMesCostaRica(historial, mesHistorial)
                        }
                        Text(
                            text = "Historial del Conductor",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        SelectorMesHistorialCard(
                            viajes = historial,
                            viajesFiltrados = historialMes,
                            mesSeleccionado = mesHistorial,
                            onSelectMes = { mesHistorial = it },
                            etiquetaTotal = "Generado en el mes"
                        )
                        if (cargandoHistorial) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                        if (!cargandoHistorial && historialMes.isEmpty()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "No hay viajes registrados en este mes",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(historialMes) { v ->
                                    OutlinedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = cardShape,
                                        border = cardBorder,
                                        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            val fechaHoraTexto = formatearFechaHoraCostaRica(v)
                                            Text("${v["pasajeroNombre"] ?: ""} · ${v["destinoNombre"] ?: ""}", fontWeight = FontWeight.Bold)
                                            Text(
                                                text = "$fechaHoraTexto · ${v["origenNombre"] ?: ""}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF525B50)
                                            )
                                            val montoHist = (v["montoCobrado"] as? Number)?.toInt()?.takeIf { it > 0 }
                                                ?: (v["montoAproximado"] as? Number)?.toInt()
                                                ?: 0
                                            Text(
                                                text = "₡$montoHist · ${v["estado"] ?: ""}",
                                                fontFamily = FontFamily.Monospace,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF15803D)
                                            )
                                            val motivoHist = v["motivoCancelacion"] as? String
                                            if (!motivoHist.isNullOrBlank()) {
                                                val por = if (v["canceladoPor"] == "conductor") "conductor" else "pasajero"
                                                Text(
                                                    text = "Cancelado por $por: \"$motivoHist\"",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ConductorTab.PERFIL -> {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                text = "Tarifas y Perfil",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    val esVehiculoCargoPerfil = ViajeRepository.esVehiculoCargo(vehiculoTipo)
                                    val esVehiculoMotoPerfil = ViajeRepository.esVehiculoMoto(vehiculoTipo)
                                    Text("Configuración de Tarifas y Equipamiento", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = buildString {
                                            append("Referencia promedio: Base ~₡1,500 · Adicional ~₡650/km")
                                            if (esVehiculoCargoPerfil) append(" · Con carga ~₡3,000")
                                            append(". El administrador monitorea variaciones >30%.")
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        OutlinedTextField(
                                            value = tarifaBaseInput,
                                            onValueChange = { tarifaBaseInput = it.filter(Char::isDigit) },
                                            label = { Text("Tarifa base (₡)") },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = tarifaKmInput,
                                            onValueChange = { tarifaKmInput = it.filter(Char::isDigit) },
                                            label = { Text("Precio / km (₡)") },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (esVehiculoCargoPerfil) {
                                        OutlinedTextField(
                                            value = tarifaBaseCargaInput,
                                            onValueChange = { tarifaBaseCargaInput = it.filter(Char::isDigit) },
                                            label = { Text("Tarifa base con carga / flete (₡)") },
                                            placeholder = { Text("Opcional · Ej: 3000") },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    val tBaseEd = tarifaBaseInput.toDoubleOrNull() ?: ViajeRepository.DEFAULT_TARIFA_BASE_NORMAL
                                    val tKmEd = tarifaKmInput.toDoubleOrNull() ?: ViajeRepository.DEFAULT_TARIFA_KM
                                    val tCargaEd = tarifaBaseCargaInput.toDoubleOrNull()
                                    if (tBaseEd > ViajeRepository.DEFAULT_TARIFA_BASE_NORMAL * 1.30 ||
                                        tKmEd > ViajeRepository.DEFAULT_TARIFA_KM * 1.30 ||
                                        (esVehiculoCargoPerfil && tCargaEd != null && tCargaEd > ViajeRepository.DEFAULT_TARIFA_BASE_CARGA * 1.30)
                                    ) {
                                        Text(
                                            text = "Alerta: Tu tarifa supera en >30% la referencia promedio de la plataforma.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFFB45309),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    if (esVehiculoMotoPerfil) {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = Color(0xFFF0FDF4),
                                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp)) {
                                                Text(
                                                    text = "Equipamiento en Moto",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF14532D)
                                                )
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Checkbox(
                                                        checked = cascoExtraInput,
                                                        onCheckedChange = { cascoExtraInput = it }
                                                    )
                                                    Text("Cuento con casco extra para pasajero", style = MaterialTheme.typography.bodySmall)
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Checkbox(
                                                        checked = capaDisponibleInput,
                                                        onCheckedChange = { capaDisponibleInput = it }
                                                    )
                                                    Text("Cuento con capa disponible", style = MaterialTheme.typography.bodySmall)
                                                }
                                            }
                                        }
                                    }
                                    Button(
                                        onClick = {
                                            val tb = tarifaBaseInput.toDoubleOrNull() ?: tarifaBase
                                            val tk = tarifaKmInput.toDoubleOrNull() ?: tarifaPorKm
                                            val tc = if (esVehiculoCargoPerfil) tarifaBaseCargaInput.toDoubleOrNull() else null
                                            onActualizarTarifasYEquipamiento(
                                                tb,
                                                tk,
                                                tc,
                                                esVehiculoMotoPerfil && cascoExtraInput,
                                                esVehiculoMotoPerfil && capaDisponibleInput
                                            )
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Guardar tarifas y equipamiento", fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }

                            licenciaRestante?.let { lic ->
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Licencia de Conducción", fontWeight = FontWeight.Bold)
                                        Text(
                                            text = if (lic.dias > 0) {
                                                "Licencia vigente: ${lic.dias} días · Vence ${lic.fechaTexto}"
                                            } else {
                                                "Licencia vencida"
                                            },
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (lic.dias <= 0) Color(0xFFDC2626) else Color(0xFF15803D)
                                        )
                                    }
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Datos Registrados (Bloqueados)", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "Para evitar manipulación de identidad o placa, estos datos solo se modifican mediante petición al Administrador.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Text("Conductor: ${nombreConductor.ifBlank { "Registrado" }}", fontWeight = FontWeight.Medium)
                                    Text("Vehículo: ${vehiculoTipo.ifBlank { "-" }} · Placa: ${placa.ifBlank { "-" }}", fontWeight = FontWeight.Medium)
                                    OutlinedButton(
                                        onClick = { mostrarModalSolicitud = true },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Solicitar cambio de datos al Administrador")
                                    }
                                }
                            }

                            if (misSolicitudes.isNotEmpty()) {
                                var imagenAmpliadaConductor by remember { mutableStateOf<Pair<String, String>?>(null) }
                                Text("Mis Peticiones de Cambio", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                misSolicitudes.forEachIndexed { idxSol, sol ->
                                    val aprobadosCount = sol.items.count { it.estado == "aprobado" }
                                    val rechazadosCount = sol.items.count { it.estado == "rechazado" }
                                    val pendientesCount = sol.items.count { it.estado == "pendiente" }
                                    val esUltima = idxSol == 0
                                    OutlinedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = cardShape,
                                        border = BorderStroke(
                                            1.dp,
                                            if (sol.tienePendientes) Color(0xFFF59E0B) else Color(0xFFE2E6DF)
                                        ),
                                        colors = CardDefaults.outlinedCardColors(
                                            containerColor = if (esUltima) Color(0xFFFAFCF9) else Color.White
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = if (esUltima) "Última solicitud · ${sol.estadoGeneral.uppercase()}" else sol.estadoGeneral.uppercase(),
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (sol.tienePendientes) Color(0xFFB45309) else Color(0xFF15803D),
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                                if (sol.items.isNotEmpty()) {
                                                    Text(
                                                        text = "$aprobadosCount aprob. · $rechazadosCount rech. · $pendientesCount pend.",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = Color(0xFF525B50)
                                                    )
                                                }
                                            }
                                            if (sol.motivo.isNotBlank()) {
                                                Text(
                                                    text = "Motivo: ${sol.motivo}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = Color(0xFF14231A)
                                                )
                                            }
                                            if (sol.items.isNotEmpty()) {
                                                sol.items.forEach { item ->
                                                    val (badgeBg, badgeFg, badgeTxt) = when (item.estado) {
                                                        "aprobado" -> Triple(Color(0xFFDCFCE7), Color(0xFF166534), "Aprobado")
                                                        "rechazado" -> Triple(Color(0xFFFEE2E2), Color(0xFF991B1B), "Rechazado")
                                                        else -> Triple(Color(0xFFFEF3C7), Color(0xFF92400E), "Pendiente")
                                                    }
                                                    Surface(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = Color.White,
                                                        border = BorderStroke(1.dp, Color(0xFFE2E6DF))
                                                    ) {
                                                        Column(
                                                            modifier = Modifier.padding(10.dp),
                                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                                        ) {
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text(
                                                                    text = item.etiqueta,
                                                                    style = MaterialTheme.typography.labelMedium,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = Color(0xFF14231A),
                                                                    modifier = Modifier.weight(1f)
                                                                )
                                                                Surface(
                                                                    shape = RoundedCornerShape(6.dp),
                                                                    color = badgeBg
                                                                ) {
                                                                    Text(
                                                                        text = badgeTxt,
                                                                        color = badgeFg,
                                                                        style = MaterialTheme.typography.labelSmall,
                                                                        fontWeight = FontWeight.Bold,
                                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                                    )
                                                                }
                                                            }
                                                            if (item.tipo == "imagen") {
                                                                val bmpNuevo = remember(item.valorNuevo) {
                                                                    decodificarBase64BitmapConductor(item.valorNuevo)
                                                                }
                                                                Row(
                                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                                    verticalAlignment = Alignment.CenterVertically
                                                                ) {
                                                                    if (bmpNuevo != null) {
                                                                        Image(
                                                                            bitmap = bmpNuevo,
                                                                            contentDescription = item.etiqueta,
                                                                            contentScale = ContentScale.Crop,
                                                                            modifier = Modifier
                                                                                .size(56.dp)
                                                                                .clip(RoundedCornerShape(8.dp))
                                                                                .clickable {
                                                                                    imagenAmpliadaConductor = item.etiqueta to item.valorNuevo
                                                                                }
                                                                        )
                                                                    }
                                                                    Text(
                                                                        text = "Nueva imagen adjunta (toca para ver)",
                                                                        style = MaterialTheme.typography.bodySmall,
                                                                        color = Color(0xFF525B50)
                                                                    )
                                                                }
                                                            } else {
                                                                Text(
                                                                    text = "Anterior: ${item.valorAnterior.ifBlank { "No registrado" }}",
                                                                    style = MaterialTheme.typography.bodySmall,
                                                                    color = Color(0xFF6B7280)
                                                                )
                                                                Text(
                                                                    text = "Solicitado: ${item.valorNuevo}",
                                                                    style = MaterialTheme.typography.bodySmall,
                                                                    fontWeight = FontWeight.SemiBold,
                                                                    color = Color(0xFF14231A)
                                                                )
                                                            }
                                                            if (item.estado == "rechazado" && item.motivoRechazo.isNotBlank()) {
                                                                Text(
                                                                    text = "Motivo de rechazo: ${item.motivoRechazo}",
                                                                    style = MaterialTheme.typography.bodySmall,
                                                                    fontWeight = FontWeight.SemiBold,
                                                                    color = Color(0xFF991B1B)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            } else if (sol.cambios.isNotEmpty()) {
                                                Text(
                                                    text = "Solicitado: ${sol.cambios.entries.joinToString { "${it.key}: ${it.value}" }}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = Color(0xFF525B50)
                                                )
                                            }
                                            if (sol.respuestaAdmin.isNotBlank()) {
                                                Text("Admin: ${sol.respuestaAdmin}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF15803D))
                                            }
                                        }
                                    }
                                }
                                imagenAmpliadaConductor?.let { (tituloImg, dataUrlImg) ->
                                    val bmpFull = remember(dataUrlImg) { decodificarBase64BitmapConductor(dataUrlImg) }
                                    Dialog(onDismissRequest = { imagenAmpliadaConductor = null }) {
                                        Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                                            Column(
                                                modifier = Modifier.padding(16.dp),
                                                verticalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Text(tituloImg, fontWeight = FontWeight.Bold)
                                                if (bmpFull != null) {
                                                    Image(
                                                        bitmap = bmpFull,
                                                        contentDescription = tituloImg,
                                                        contentScale = ContentScale.Fit,
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .heightIn(max = 360.dp)
                                                            .clip(RoundedCornerShape(10.dp))
                                                    )
                                                }
                                                Button(
                                                    onClick = { imagenAmpliadaConductor = null },
                                                    modifier = Modifier.fillMaxWidth()
                                                ) { Text("Cerrar") }
                                            }
                                        }
                                    }
                                }
                            }

                            PanelPermisosConfiguracionCard(rol = "conductor")

                            HorizontalDivider(color = Color(0xFFE2E6DF), modifier = Modifier.padding(vertical = 4.dp))

                            OutlinedButton(
                                onClick = { mostrarModalTerminosConductor = true },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text(
                                    text = "Términos y Condiciones (${formatearColonesEntero(calculoMensualidad.montoActual)}/mes)",
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            OutlinedButton(
                                onClick = { compartirAppConductor(context, linkDescarga) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text("Compartir App", fontWeight = FontWeight.SemiBold)
                            }

                            Button(
                                onClick = {
                                    PickupLocationService.stop(context)
                                    onCerrarSesion()
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text("Cerrar Sesión", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            if (!avisoCancelacionFlotante.isNullOrBlank()) {
                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    shape = cardShape,
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = Color(0xFFFEF2F2)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Viaje cancelado por el pasajero", fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                            Text(avisoCancelacionFlotante, style = MaterialTheme.typography.bodySmall, color = Color(0xFF7F1D1D))
                        }
                        TextButton(onClick = onDismissAvisoCancelacion) { Text("Cerrar") }
                    }
                }
            }
        }
    }

    if (mostrarModalCobro) {
        AlertDialog(
            onDismissRequest = onDismissModalCobro,
            title = { Text("Viaje Finalizado — Cobro en Efectivo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Monto a cobrar al pasajero:")
                    Text(
                        text = "₡${montoACobrar.toInt()}",
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text("Califica al pasajero ($estrellasPasajero/5 ★):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { n ->
                            FilledTonalButton(onClick = { estrellasPasajero = n }) {
                                Text(if (n <= estrellasPasajero) "★" else "☆")
                            }
                        }
                    }
                    OutlinedTextField(
                        value = comentarioPasajero,
                        onValueChange = { comentarioPasajero = it },
                        label = { Text("Comentario opcional") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        pinInput = ""
                        onCalificarPasajero(estrellasPasajero, comentarioPasajero)
                    }
                ) {
                    Text("Guardar Calificación")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pinInput = ""
                        onDismissModalCobro()
                    }
                ) { Text("Cerrar") }
            }
        )
    }

    if (mostrarMapaModal) {
        val latMapa = if (estadoViaje == "en_curso") destinoLat else origenLat
        val lngMapa = if (estadoViaje == "en_curso") destinoLng else origenLng
        Dialog(onDismissRequest = { mostrarMapaModal = false }) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Mapa Bajo Demanda (Coordenada Estática)", fontWeight = FontWeight.Bold)
                    Text(
                        text = if (latMapa != null && lngMapa != null) {
                            "Punto guardado en Firestore: %.5f, %.5f".format(latMapa, lngMapa)
                        } else {
                            "Sin coordenadas disponibles para este viaje."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF525B50)
                    )
                    if (latMapa != null && lngMapa != null) {
                        Button(
                            onClick = { abrirGoogleMapsEstaticoConductor(context, latMapa, lngMapa) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Abrir en Google Maps (caché nativa)")
                        }
                    }
                    OutlinedButton(onClick = { mostrarMapaModal = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cerrar y liberar mapa")
                    }
                }
            }
        }
    }

    if (mostrarChatModal) {
        var textoChat by remember { mutableStateOf("") }
        Dialog(
            onDismissRequest = {
                onCerrarChat()
                mostrarChatModal = false
            }
        ) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Chat Privado del Viaje", fontWeight = FontWeight.Bold)
                    Text(
                        text = "Notificaciones flotantes activas sin exponer números telefónicos.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF525B50)
                    )
                    Surface(
                        color = Color(0xFFF7F8F6),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp, max = 220.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(10.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (mensajesChat.isEmpty()) {
                                Text(
                                    text = "Aún no hay mensajes. Escribe al pasajero aquí.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                            } else {
                                mensajesChat.forEach { msg ->
                                    val autor = msg["autorNombre"] as? String ?: "Usuario"
                                    val contenido = msg["texto"] as? String ?: ""
                                    Text(
                                        text = "$autor: $contenido",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF14231A)
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textoChat,
                            onValueChange = { if (it.length <= 400) textoChat = it },
                            placeholder = { Text("Escribe un mensaje...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            enabled = textoChat.isNotBlank() && viajeActivoId != null,
                            onClick = {
                                val vId = viajeActivoId ?: return@Button
                                onEnviarMensajeChat(vId, textoChat)
                                textoChat = ""
                            }
                        ) { Text("Enviar") }
                    }
                    OutlinedButton(
                        onClick = {
                            onCerrarChat()
                            mostrarChatModal = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Cerrar Chat") }
                }
            }
        }
    }

    if (mostrarModalSolicitud) {
        val scopeSolicitud = rememberCoroutineScope()
        val tarifaBaseActualStr = remember(tarifaBase) { tarifaBase.toInt().toString() }
        val tarifaBaseCargaActualStr = remember(tarifaBaseCarga) { tarifaBaseCarga?.toInt()?.toString() ?: "" }
        val precioKmActualStr = remember(tarifaPorKm) { tarifaPorKm.toInt().toString() }
        val capacidadActualStr = remember(capacidad) { capacidad.toString() }

        var reqNombre by remember { mutableStateOf(nombreConductor) }
        var reqTelefono by remember { mutableStateOf(telefonoConductor) }
        var reqVehiculoTipo by remember { mutableStateOf(vehiculoTipo) }
        var reqMarca by remember { mutableStateOf(vehiculoMarca) }
        var reqModelo by remember { mutableStateOf(vehiculoModelo) }
        var reqColor by remember { mutableStateOf(vehiculoColor) }
        var reqAnio by remember { mutableStateOf(vehiculoAnio) }
        var reqPlaca by remember { mutableStateOf(placa) }
        var reqCapacidad by remember { mutableStateOf(capacidadActualStr) }
        var reqTarifaBase by remember { mutableStateOf(tarifaBaseActualStr) }
        var reqTarifaBaseCarga by remember { mutableStateOf(tarifaBaseCargaActualStr) }
        var reqPrecioKm by remember { mutableStateOf(precioKmActualStr) }
        var reqCascoExtra by remember { mutableStateOf(tieneCascoExtra) }
        var reqCapaDisponible by remember { mutableStateOf(tieneCapaDisponible) }
        var reqFotoVehiculo by remember { mutableStateOf("") }
        var reqFotoCedula by remember { mutableStateOf("") }
        var reqFotoLicencia by remember { mutableStateOf("") }
        var reqFotoMarchamoRtv by remember { mutableStateOf("") }
        var comprimiendoDoc by remember { mutableStateOf(false) }
        var errorCompresionDoc by remember { mutableStateOf<String?>(null) }
        var reqMotivo by remember { mutableStateOf("") }
        val tiposSugeridos = listOf("Moto", "Sedan", "Pickup 4x4", "SUV Rural", "Microbus")

        fun procesarUriDoc(uri: Uri?, onListo: (String) -> Unit) {
            if (uri == null) return
            comprimiendoDoc = true
            errorCompresionDoc = null
            scopeSolicitud.launch {
                val base64 = withContext(Dispatchers.IO) {
                    ImageCompressionUtils.comprimirImagenABase64(
                        context = context,
                        uri = uri,
                        maxAnchoPx = 800,
                        calidadJpeg = 70,
                        maxBase64Chars = 95_000
                    )
                }
                comprimiendoDoc = false
                if (base64.isNullOrBlank()) {
                    errorCompresionDoc = "No se pudo procesar la imagen seleccionada."
                } else {
                    onListo(base64)
                }
            }
        }

        val pickVehiculo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            procesarUriDoc(uri) { reqFotoVehiculo = it }
        }
        val pickCedula = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            procesarUriDoc(uri) { reqFotoCedula = it }
        }
        val pickLicencia = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            procesarUriDoc(uri) { reqFotoLicencia = it }
        }
        val pickMarchamoRtv = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            procesarUriDoc(uri) { reqFotoMarchamoRtv = it }
        }

        val itemsModificados = remember(
            reqNombre, reqTelefono, reqVehiculoTipo, reqMarca, reqModelo, reqColor, reqAnio,
            reqPlaca, reqCapacidad, reqTarifaBase, reqTarifaBaseCarga, reqPrecioKm,
            reqCascoExtra, reqCapaDisponible,
            reqFotoVehiculo, reqFotoCedula, reqFotoLicencia, reqFotoMarchamoRtv,
            nombreConductor, telefonoConductor, vehiculoTipo, vehiculoMarca, vehiculoModelo,
            vehiculoColor, vehiculoAnio, placa, capacidadActualStr, tarifaBaseActualStr,
            tarifaBaseCargaActualStr, precioKmActualStr, tieneCascoExtra, tieneCapaDisponible,
            fotoVehiculoActual, fotoCedulaActual, fotoLicenciaActual, fotoCirculacionActual
        ) {
            val list = mutableListOf<CambioItemData>()
            fun agregarSiCambioTexto(clave: String, etiqueta: String, anterior: String, nuevo: String, minLen: Int = 2) {
                val ant = anterior.trim()
                val nvo = nuevo.trim()
                if (nvo.length >= minLen && nvo != ant) {
                    list.add(CambioItemData(clave, etiqueta, "texto", ant, nvo))
                }
            }
            agregarSiCambioTexto("nombre", "Nombre completo", nombreConductor, reqNombre, 2)
            agregarSiCambioTexto("telefono", "Teléfono", telefonoConductor, reqTelefono, 6)
            agregarSiCambioTexto("vehiculoTipo", "Tipo de vehículo", vehiculoTipo, reqVehiculoTipo, 2)
            agregarSiCambioTexto("vehiculoMarca", "Marca del vehículo", vehiculoMarca, reqMarca, 2)
            agregarSiCambioTexto("vehiculoModelo", "Modelo del vehículo", vehiculoModelo, reqModelo, 2)
            agregarSiCambioTexto("color", "Color del vehículo", vehiculoColor, reqColor, 2)
            agregarSiCambioTexto("vehiculoAnio", "Año del vehículo", vehiculoAnio, reqAnio, 2)
            val placaAnt = placa.trim().uppercase()
            val placaNva = reqPlaca.trim().uppercase()
            if (placaNva.length >= 3 && placaNva != placaAnt) {
                list.add(CambioItemData("placa", "Placa", "texto", placaAnt, placaNva))
            }
            val capNva = reqCapacidad.toIntOrNull()
            if (capNva != null && capNva in 1..24 && capNva.toString() != capacidadActualStr) {
                list.add(CambioItemData("capacidad", "Capacidad (pasajeros)", "texto", capacidadActualStr, capNva.toString()))
            }
            val tbNva = reqTarifaBase.toIntOrNull()
            if (tbNva != null && tbNva in 500..50_000 && tbNva.toString() != tarifaBaseActualStr) {
                list.add(CambioItemData("tarifaBase", "Tarifa base (₡)", "texto", tarifaBaseActualStr, tbNva.toString()))
            }
            if (ViajeRepository.esVehiculoCargo(reqVehiculoTipo)) {
                val tbcNva = reqTarifaBaseCarga.toIntOrNull()
                if (tbcNva != null && tbcNva in 500..150_000 && tbcNva.toString() != tarifaBaseCargaActualStr) {
                    list.add(
                        CambioItemData(
                            "tarifaBaseCarga",
                            "Tarifa base con carga / flete (₡)",
                            "texto",
                            tarifaBaseCargaActualStr.ifBlank { "No definida" },
                            tbcNva.toString()
                        )
                    )
                }
            }
            val pkNva = reqPrecioKm.toIntOrNull()
            if (pkNva != null && pkNva in 100..10_000 && pkNva.toString() != precioKmActualStr) {
                list.add(CambioItemData("precioKm", "Precio por km (₡)", "texto", precioKmActualStr, pkNva.toString()))
            }
            if (ViajeRepository.esVehiculoMoto(reqVehiculoTipo)) {
                if (reqCascoExtra != tieneCascoExtra) {
                    list.add(
                        CambioItemData(
                            "tieneCascoExtra",
                            "Casco extra para pasajero",
                            "texto",
                            if (tieneCascoExtra) "Sí" else "No",
                            if (reqCascoExtra) "Sí" else "No"
                        )
                    )
                }
                if (reqCapaDisponible != tieneCapaDisponible) {
                    list.add(
                        CambioItemData(
                            "tieneCapaDisponible",
                            "Capa impermeable disponible",
                            "texto",
                            if (tieneCapaDisponible) "Sí" else "No",
                            if (reqCapaDisponible) "Sí" else "No"
                        )
                    )
                }
            }
            if (reqFotoVehiculo.isNotBlank()) {
                list.add(CambioItemData("fotoVehiculo", "Foto del vehículo", "imagen", fotoVehiculoActual, reqFotoVehiculo))
            }
            if (reqFotoCedula.isNotBlank()) {
                list.add(CambioItemData("fotoCedula", "Foto de Cédula", "imagen", fotoCedulaActual, reqFotoCedula))
            }
            if (reqFotoLicencia.isNotBlank()) {
                list.add(CambioItemData("fotoLicencia", "Foto de Licencia", "imagen", fotoLicenciaActual, reqFotoLicencia))
            }
            if (reqFotoMarchamoRtv.isNotBlank()) {
                list.add(CambioItemData("fotoMarchamoRtv", "Foto Marchamo / RTV", "imagen", fotoCirculacionActual, reqFotoMarchamoRtv))
            }
            list
        }

        AlertDialog(
            onDismissRequest = { if (!comprimiendoDoc) mostrarModalSolicitud = false },
            title = { Text("Solicitud de Cambio de Datos", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 470.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Solo se enviarán los campos o documentos que modifiques. El Administrador aprobará o rechazará cada cambio línea por línea.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF525B50)
                    )
                    Surface(
                        color = if (itemsModificados.isNotEmpty()) Color(0xFFF0FDF4) else Color(0xFFF7F8F6),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(
                            1.dp,
                            if (itemsModificados.isNotEmpty()) Color(0xFF86EFAC) else Color(0xFFE2E6DF)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (itemsModificados.isNotEmpty()) {
                                "${itemsModificados.size} cambio(s) detectado(s): ${itemsModificados.joinToString(", ") { it.etiqueta }}"
                            } else {
                                "Edita un campo o selecciona una nueva foto para generar la solicitud."
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (itemsModificados.isNotEmpty()) Color(0xFF166534) else Color(0xFF525B50),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    OutlinedTextField(
                        value = reqNombre,
                        onValueChange = { reqNombre = it },
                        label = { Text("Nombre completo") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = reqTelefono,
                        onValueChange = { reqTelefono = it },
                        label = { Text("Teléfono") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Tipo de vehículo:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        tiposSugeridos.take(3).forEach { tipo ->
                            FilterChip(
                                selected = reqVehiculoTipo == tipo,
                                onClick = { reqVehiculoTipo = tipo },
                                label = { Text(tipo, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        tiposSugeridos.drop(3).forEach { tipo ->
                            FilterChip(
                                selected = reqVehiculoTipo == tipo,
                                onClick = { reqVehiculoTipo = tipo },
                                label = { Text(tipo, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = reqMarca,
                        onValueChange = { reqMarca = it },
                        label = { Text("Marca") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = reqModelo,
                        onValueChange = { reqModelo = it },
                        label = { Text("Modelo") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = reqColor,
                            onValueChange = { reqColor = it },
                            label = { Text("Color") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = reqAnio,
                            onValueChange = { reqAnio = it.filter(Char::isDigit).take(4) },
                            label = { Text("Año") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = reqPlaca,
                            onValueChange = { reqPlaca = it.uppercase() },
                            label = { Text("Placa") },
                            singleLine = true,
                            modifier = Modifier.weight(1.2f)
                        )
                        OutlinedTextField(
                            value = reqCapacidad,
                            onValueChange = { reqCapacidad = it.filter(Char::isDigit).take(2) },
                            label = { Text("Cap. pax") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = reqTarifaBase,
                            onValueChange = { reqTarifaBase = it.filter(Char::isDigit).take(6) },
                            label = { Text("Tarifa base (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = reqPrecioKm,
                            onValueChange = { reqPrecioKm = it.filter(Char::isDigit).take(5) },
                            label = { Text("Precio / km (₡)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (ViajeRepository.esVehiculoCargo(reqVehiculoTipo)) {
                        OutlinedTextField(
                            value = reqTarifaBaseCarga,
                            onValueChange = { reqTarifaBaseCarga = it.filter(Char::isDigit).take(6) },
                            label = { Text("Tarifa base con carga / flete (₡)") },
                            placeholder = { Text("Opcional · Ej: 3000") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (ViajeRepository.esVehiculoMoto(reqVehiculoTipo)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = reqCascoExtra, onCheckedChange = { reqCascoExtra = it })
                            Text("Casco extra para pasajero", style = MaterialTheme.typography.bodySmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = reqCapaDisponible, onCheckedChange = { reqCapaDisponible = it })
                            Text("Capa impermeable disponible", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    HorizontalDivider(color = Color(0xFFE2E6DF), modifier = Modifier.padding(vertical = 2.dp))
                    Text(
                        text = "Actualizar documentos o fotos (opcional · máx. 800px JPEG 70%)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { pickVehiculo.launch("image/*") },
                            enabled = !comprimiendoDoc,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (reqFotoVehiculo.isNotBlank()) "Vehículo ✓ (${ImageCompressionUtils.estimarPesoKbBase64(reqFotoVehiculo)}KB)" else "Foto Vehículo",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        OutlinedButton(
                            onClick = { pickCedula.launch("image/*") },
                            enabled = !comprimiendoDoc,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (reqFotoCedula.isNotBlank()) "Cédula ✓ (${ImageCompressionUtils.estimarPesoKbBase64(reqFotoCedula)}KB)" else "Foto Cédula",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { pickLicencia.launch("image/*") },
                            enabled = !comprimiendoDoc,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (reqFotoLicencia.isNotBlank()) "Licencia ✓ (${ImageCompressionUtils.estimarPesoKbBase64(reqFotoLicencia)}KB)" else "Foto Licencia",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        OutlinedButton(
                            onClick = { pickMarchamoRtv.launch("image/*") },
                            enabled = !comprimiendoDoc,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (reqFotoMarchamoRtv.isNotBlank()) "RTV ✓ (${ImageCompressionUtils.estimarPesoKbBase64(reqFotoMarchamoRtv)}KB)" else "Marchamo / RTV",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    if (comprimiendoDoc) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Text("Redimensionando (800px) y comprimiendo JPEG (70%)...", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    errorCompresionDoc?.let { err ->
                        Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }

                    OutlinedTextField(
                        value = reqMotivo,
                        onValueChange = { if (it.length <= 300) reqMotivo = it },
                        label = { Text("Motivo del cambio (obligatorio)") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = !comprimiendoDoc && reqMotivo.trim().length >= 3 && itemsModificados.isNotEmpty(),
                    onClick = {
                        onEnviarSolicitudCambioLineas(itemsModificados, reqMotivo.trim())
                        mostrarModalSolicitud = false
                    }
                ) { Text("Enviar Petición") }
            },
            dismissButton = {
                TextButton(
                    enabled = !comprimiendoDoc,
                    onClick = { mostrarModalSolicitud = false }
                ) { Text("Cancelar") }
            }
        )
    }

    if (mostrarDialogoConfirmarCobro) {
        val montoRefDialog = if (montoReferenciaViajeActivo > 0.0) {
            montoReferenciaViajeActivo
        } else {
            montoAproximadoViajeActivo.takeIf { it > 0.0 } ?: tarifaBase
        }
        val multAplicado = if (esCargaFleteViajeActivo) multiplicadorTopeCarga else multiplicadorTopeNormal
        val limiteDialog = if (limiteMaximoViajeActivo > 0.0) {
            limiteMaximoViajeActivo
        } else {
            ViajeRepository.calcularLimiteMaximoPermitido(
                montoReferenciaPromedio = montoRefDialog,
                esCargaFlete = esCargaFleteViajeActivo,
                multiplicadorTopeNormal = multiplicadorTopeNormal,
                multiplicadorTopeCarga = multiplicadorTopeCarga
            )
        }
        val montoIngresado = montoCobroInput.toDoubleOrNull() ?: 0.0
        val superaLimite = montoIngresado > limiteDialog && montoIngresado > 0.0
        AlertDialog(
            onDismissRequest = { mostrarDialogoConfirmarCobro = false },
            title = { Text("Confirmar cobro en efectivo", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (esCargaFleteViajeActivo) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFFBEB),
                            border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Modalidad: Pickup con carga / flete (tope ${multAplicado}x)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                    Text(
                        text = "Referencia promedio de la zona: ₡${montoRefDialog.toInt()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF525B50)
                    )
                    Text(
                        text = "Tope máximo recomendado: ₡${limiteDialog.toInt()} (${multAplicado}x)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF14532D)
                    )
                    OutlinedTextField(
                        value = montoCobroInput,
                        onValueChange = { montoCobroInput = it.filter(Char::isDigit).take(7) },
                        label = { Text("Monto cobrado en efectivo (₡)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (superaLimite) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEF2F2),
                            border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Atención: El monto ingresado supera el tope máximo permitido (₡${limiteDialog.toInt()}). Se registrará una alerta de cobro excesivo para revisión del Administrador.",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF991B1B),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = montoIngresado >= 100.0,
                    onClick = {
                        mostrarDialogoConfirmarCobro = false
                        onFinalizarViaje(montoIngresado)
                    }
                ) {
                    Text("Finalizar y registrar cobro", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogoConfirmarCobro = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    if (mostrarModalCancelar) {
        val sugerenciasConductor = listOf(
            "Camino bloqueado o derrumbe",
            "Falla mecánica en el vehículo",
            "No puedo llegar al punto de recogida"
        )
        AlertDialog(
            onDismissRequest = { mostrarModalCancelar = false },
            title = { Text("Cancelar viaje aceptado") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Ingresa una nota explicando por qué no puedes completar o llegar al destino. El pasajero la verá de inmediato.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    sugerenciasConductor.forEach { opc ->
                        OutlinedButton(
                            onClick = { motivoCancelacionInput = opc },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(opc) }
                    }
                    OutlinedTextField(
                        value = motivoCancelacionInput,
                        onValueChange = { if (it.length <= 280) motivoCancelacionInput = it },
                        label = { Text("Nota de cancelación (obligatoria)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = motivoCancelacionInput.trim().length >= 3,
                    onClick = {
                        PickupLocationService.stop(context)
                        onCancelarViaje(motivoCancelacionInput.trim())
                        mostrarModalCancelar = false
                    }
                ) { Text("Confirmar cancelación") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalCancelar = false }) { Text("Volver") }
            }
        )
    }

    if (mostrarDialogoSegundoPlano && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        AlertDialog(
            onDismissRequest = { mostrarDialogoSegundoPlano = false },
            title = { Text("Ubicación en segundo plano", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Para recibir ofertas y mantener activo el servicio de ubicación aunque apagues la pantalla, selecciona \"Permitir todo el tiempo\" en la siguiente pantalla de Ajustes.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        mostrarDialogoSegundoPlano = false
                        try {
                            launcherSegundoPlano.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                        } catch (_: Throwable) {
                            abrirAjustesAplicacion(context)
                        }
                    }
                ) { Text("Continuar a Ajustes") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        mostrarDialogoSegundoPlano = false
                        abrirAjustesAplicacion(context)
                    }
                ) { Text("Abrir Ajustes App") }
            }
        )
    }

    if (!avisoCancelacionFlotante.isNullOrBlank()) {
        AlertDialog(
            onDismissRequest = onDismissAvisoCancelacion,
            title = {
                Text(
                    text = "Viaje cancelado por el pasajero",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF991B1B)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = avisoCancelacionFlotante,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF14231A)
                    )
                    Text(
                        text = "Tu estado volvió a Disponible automáticamente para recibir nuevas solicitudes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF15803D),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                Button(onClick = onDismissAvisoCancelacion) {
                    Text("Entendido")
                }
            }
        )
    }

    if (mostrarModalPermisos) {
        ModalPermisosConfiguracion(
            rol = "conductor",
            onDismiss = { mostrarModalPermisos = false }
        )
    }

    if (mostrarModalTerminosConductor) {
        ModalTerminosConductorDialog(
            terminosConductor = terminosConductor,
            montoBase = montoMensualBase,
            anioBase = anioBaseMensualidad,
            sinpeNumero = sinpeNumero,
            sinpeTitular = sinpeTitular,
            onDismiss = { mostrarModalTerminosConductor = false }
        )
    }
}

private fun tienePermisoNotificaciones(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
}

private fun tienePermisoUbicacionFina(context: Context): Boolean {
    return ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
}

private fun tienePermisoUbicacionSegundoPlano(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
}

private fun abrirAjustesAplicacion(context: Context) {
    try {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Throwable) {
    }
}

private fun abrirWaze(context: Context, lat: Double, lng: Double) {
    val uri = Uri.parse("https://waze.com/ul?ll=$lat,$lng&navigate=yes")
    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)
}

private fun abrirGoogleMapsEstaticoConductor(context: Context, lat: Double, lng: Double) {
    val geoUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(Punto Viaje Rural)")
    val mapsIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
        setPackage("com.google.android.apps.maps")
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    try {
        context.startActivity(mapsIntent)
    } catch (_: Throwable) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, geoUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
        } catch (_: Throwable) {
        }
    }
}

private fun compartirAppConductor(context: Context, linkDescarga: String) {
    try {
        val urlLimpia = linkDescarga.trim().ifBlank { "https://viajerural.com/descargar" }
        val mensaje = "¡Únete a Viaje Rural! Descarga la app para viajar o conducir en zonas rurales: $urlLimpia"
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Viaje Rural App")
            putExtra(Intent.EXTRA_TEXT, mensaje)
        }
        val chooser = Intent.createChooser(sendIntent, "Compartir Viaje Rural")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (_: Throwable) {
    }
}

private fun decodificarBase64BitmapConductor(raw: String): ImageBitmap? {
    if (raw.isBlank()) return null
    return try {
        val base64Part = raw.substringAfter("base64,", raw)
        val bytes = Base64.decode(base64Part, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}
