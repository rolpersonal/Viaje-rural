package cr.viajerural.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import cr.viajerural.app.data.LicenciaRestanteInfo
import cr.viajerural.app.data.SolicitudCambioData
import cr.viajerural.app.service.PickupLocationService
import cr.viajerural.app.viewmodel.ConductorTab

/**
 * Pantalla del Conductor con BottomNavigation (4 pestañas) y diseño ordenado estilo Web:
 * - Inicio: Ofertas de viaje 15s, estado Activo/Inactivo, días de licencia, Waze, PIN y botones Ver Mapa / Abrir Chat.
 * - Finanzas: SOLO 2 datos (Generado Hoy y Generado en el Mes) + estado de licencia.
 * - Historial: Carga lazy limit(20) solo al tocar la pestaña.
 * - Perfil: Tarifa base (₡), Precio por kilómetro adicional (₡), ficha bloqueada, compartir app y cerrar sesión.
 */
@Composable
fun ConductorScreen(
    tabActual: ConductorTab,
    onSelectTab: (ConductorTab) -> Unit,
    conductorId: String,
    viajeActivoId: String?,
    estadoViaje: String?,
    pasajeroNombre: String?,
    cantidadPasajeros: Int,
    resenaUbicacion: String?,
    origenLat: Double?,
    origenLng: Double?,
    destinoLat: Double?,
    destinoLng: Double?,
    segundosOfertaRestantes: Int?,
    gananciasHoy: Double,
    gananciasMes: Double,
    historial: List<Map<String, Any>>,
    cargandoHistorial: Boolean,
    mostrarModalCobro: Boolean,
    montoACobrar: Double,
    onAceptarOferta: () -> Unit,
    onRechazarOferta: () -> Unit,
    onVerificarPin: (String) -> Unit,
    onFinalizarViaje: () -> Unit,
    onCalificarPasajero: (estrellas: Int, comentario: String) -> Unit,
    onDismissModalCobro: () -> Unit,
    licenciaRestante: LicenciaRestanteInfo? = null,
    nombreConductor: String = "",
    placa: String = "",
    vehiculoTipo: String = "",
    tarifaBase: Double = 1500.0,
    tarifaPorKm: Double = 650.0,
    misSolicitudes: List<SolicitudCambioData> = emptyList(),
    onEnviarSolicitudCambio: (cambios: Map<String, Any>, motivo: String) -> Unit = { _, _ -> },
    onCancelarViaje: (motivo: String) -> Unit = {},
    avisoCancelacionFlotante: String? = null,
    onDismissAvisoCancelacion: () -> Unit = {},
    disponible: Boolean = false,
    actualizandoDisponibilidad: Boolean = false,
    mensajeEstado: String? = null,
    onDismissMensajeEstado: () -> Unit = {},
    onToggleDisponible: (Boolean) -> Unit = {},
    procesandoOferta: Boolean = false,
    errorPin: String? = null,
    mensajesChat: List<Map<String, Any>> = emptyList(),
    onAbrirChat: (String) -> Unit = {},
    onCerrarChat: () -> Unit = {},
    onEnviarMensajeChat: (String, String) -> Unit = { _, _ -> },
    linkDescarga: String = "https://viajerural.com/descargar",
    onCerrarSesion: () -> Unit = {}
) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current

    var isActivo by remember { mutableStateOf(disponible) }
    LaunchedEffect(disponible, actualizandoDisponibilidad) {
        if (!actualizandoDisponibilidad) {
            isActivo = disponible
        }
    }

    var pinInput by remember { mutableStateOf("") }
    var estrellasPasajero by remember { mutableIntStateOf(5) }
    var comentarioPasajero by remember { mutableStateOf("") }
    var mostrarMapaModal by remember { mutableStateOf(false) }
    var mostrarChatModal by remember { mutableStateOf(false) }
    var mostrarModalSolicitud by remember { mutableStateOf(false) }
    var mostrarModalCancelar by remember { mutableStateOf(false) }
    var motivoCancelacionInput by remember { mutableStateOf("") }
    var tarifaBaseInput by remember(tarifaBase) { mutableStateOf(tarifaBase.toInt().toString()) }
    var tarifaKmInput by remember(tarifaPorKm) { mutableStateOf(tarifaPorKm.toInt().toString()) }

    // Estados y lanzadores secuenciales de permisos críticos del Conductor
    var notificacionesOk by remember { mutableStateOf(tienePermisoNotificaciones(context)) }
    var ubicacionFinaOk by remember { mutableStateOf(tienePermisoUbicacionFina(context)) }
    var ubicacionSegundoPlanoOk by remember { mutableStateOf(tienePermisoUbicacionSegundoPlano(context)) }
    var mostrarDialogoSegundoPlano by remember { mutableStateOf(false) }
    var pendienteActivarConductor by remember { mutableStateOf(false) }
    var solicitudesPermisosIniciadas by remember { mutableStateOf(false) }

    fun refrescarPermisos() {
        notificacionesOk = tienePermisoNotificaciones(context)
        ubicacionFinaOk = tienePermisoUbicacionFina(context)
        ubicacionSegundoPlanoOk = tienePermisoUbicacionSegundoPlano(context)
    }

    val launcherSegundoPlano = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        refrescarPermisos()
        if (granted || tienePermisoUbicacionSegundoPlano(context)) {
            mostrarDialogoSegundoPlano = false
        }
    }

    val launcherUbicacionPrimerPlano = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        refrescarPermisos()
        val finaConcedida = granted || tienePermisoUbicacionFina(context)
        if (finaConcedida) {
            if (pendienteActivarConductor) {
                pendienteActivarConductor = false
                isActivo = true
                // Pulso GPS único de bajo consumo ejecutado en ViewModel + Repository
                onToggleDisponible(true)
            }
            // SOLO después de aceptar ubicación en primer plano, solicitar ACCESS_BACKGROUND_LOCATION
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !tienePermisoUbicacionSegundoPlano(context)) {
                mostrarDialogoSegundoPlano = true
            }
        } else {
            pendienteActivarConductor = false
            isActivo = false
        }
    }

    val launcherNotificaciones = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        refrescarPermisos()
        // Encadenar ubicación en primer plano tras resolver notificaciones
        if (!tienePermisoUbicacionFina(context)) {
            try {
                launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            } catch (_: Throwable) {
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !tienePermisoUbicacionSegundoPlano(context)) {
            mostrarDialogoSegundoPlano = true
        }
    }

    // Al regresar de Ajustes ("Permitir todo el tiempo"), actualizar estado de permisos
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refrescarPermisos()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Al iniciar la pantalla principal del Conductor:
    // 1) POST_NOTIFICATIONS (Android 13+) -> 2) ACCESS_FINE_LOCATION -> 3) ACCESS_BACKGROUND_LOCATION
    LaunchedEffect(Unit) {
        if (!solicitudesPermisosIniciadas) {
            solicitudesPermisosIniciadas = true
            refrescarPermisos()
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !tienePermisoNotificaciones(context)) {
                    launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else if (!tienePermisoUbicacionFina(context)) {
                    launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !tienePermisoUbicacionSegundoPlano(context)) {
                    mostrarDialogoSegundoPlano = true
                }
            } catch (_: Throwable) {
            }
        }
    }

    // Activar GPS de recogida SOLO cuando hay un viaje aceptado pendiente de PIN; en modo espera permanece apagado
    LaunchedEffect(viajeActivoId, estadoViaje, ubicacionFinaOk) {
        if (viajeActivoId != null && estadoViaje == "aceptado" && tienePermisoUbicacionFina(context)) {
            PickupLocationService.start(context, viajeActivoId, conductorId)
        } else {
            PickupLocationService.stop(context)
        }
    }

    val cardShape = RoundedCornerShape(16.dp)
    val cardBorder = BorderStroke(1.dp, Color(0xFFE2E6DF))

    Scaffold(
        containerColor = Color(0xFFF7F8F6),
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = tabActual == ConductorTab.INICIO,
                    onClick = { onSelectTab(ConductorTab.INICIO) },
                    icon = { Text("🏠") },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.FINANZAS,
                    onClick = { onSelectTab(ConductorTab.FINANZAS) },
                    icon = { Text("₡") },
                    label = { Text("Finanzas") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.HISTORIAL,
                    onClick = { onSelectTab(ConductorTab.HISTORIAL) },
                    icon = { Text("📜") },
                    label = { Text("Historial") }
                )
                NavigationBarItem(
                    selected = tabActual == ConductorTab.PERFIL,
                    onClick = { onSelectTab(ConductorTab.PERFIL) },
                    icon = { Text("⚙️") },
                    label = { Text("Perfil") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (tabActual) {
                    ConductorTab.INICIO -> {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Viaje Rural — Conductor",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14231A)
                                    )
                                    Text(
                                        text = if (nombreConductor.isNotBlank()) "$nombreConductor · $placa" else "Panel operativo",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                }
                                OutlinedButton(
                                    onClick = { compartirAppConductor(context, linkDescarga) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Compartir App")
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = BorderStroke(
                                    1.dp,
                                    if (isActivo) Color(0xFF86EFAC) else Color(0xFFE2E6DF)
                                ),
                                colors = CardDefaults.outlinedCardColors(
                                    containerColor = if (isActivo) Color(0xFFF0FDF4) else Color.White
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(end = 12.dp)
                                    ) {
                                        Text(
                                            text = if (isActivo) "Activo (Esperando ofertas)" else "Inactivo",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isActivo) Color(0xFF15803D) else Color(0xFF14231A)
                                        )
                                        Text(
                                            text = when {
                                                actualizandoDisponibilidad -> "Capturando ubicación única y guardando..."
                                                isActivo -> "Visible para ofertas · GPS apagado para ahorrar batería."
                                                else -> "Activa el interruptor para reportar tu posición y recibir ofertas."
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                    Switch(
                                        checked = isActivo,
                                        onCheckedChange = { activar ->
                                            if (activar) {
                                                val faltaNotif = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                                    !tienePermisoNotificaciones(context)
                                                val faltaFina = !tienePermisoUbicacionFina(context)

                                                if (faltaNotif && faltaFina) {
                                                    pendienteActivarConductor = true
                                                    try {
                                                        launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                    } catch (_: Throwable) {
                                                        pendienteActivarConductor = false
                                                    }
                                                } else if (faltaFina) {
                                                    pendienteActivarConductor = true
                                                    try {
                                                        launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                                                    } catch (_: Throwable) {
                                                        pendienteActivarConductor = false
                                                    }
                                                } else {
                                                    if (faltaNotif) {
                                                        try {
                                                            launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                        } catch (_: Throwable) {
                                                        }
                                                    }
                                                    isActivo = true
                                                    onToggleDisponible(true)
                                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                                                        !tienePermisoUbicacionSegundoPlano(context)
                                                    ) {
                                                        mostrarDialogoSegundoPlano = true
                                                    }
                                                }
                                            } else {
                                                pendienteActivarConductor = false
                                                isActivo = false
                                                PickupLocationService.stop(context)
                                                onToggleDisponible(false)
                                            }
                                        },
                                        enabled = viajeActivoId == null && !actualizandoDisponibilidad
                                    )
                                }
                            }

                            if (!mensajeEstado.isNullOrBlank()) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFEF2F2))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = mensajeEstado,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF991B1B),
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(end = 8.dp)
                                        )
                                        TextButton(onClick = onDismissMensajeEstado) {
                                            Text("Cerrar")
                                        }
                                    }
                                }
                            }

                            if (!notificacionesOk || !ubicacionFinaOk || !ubicacionSegundoPlanoOk) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFFFFFBEB))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "Permisos requeridos para recibir ofertas",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF78350F)
                                        )
                                        Text(
                                            text = buildString {
                                                append("• Notificaciones: ")
                                                append(if (notificacionesOk) "OK\n" else "Falta activar\n")
                                                append("• Ubicación en primer plano: ")
                                                append(if (ubicacionFinaOk) "OK\n" else "Falta activar\n")
                                                append("• Ubicación en segundo plano (todo el tiempo): ")
                                                append(if (ubicacionSegundoPlanoOk) "OK" else "Falta activar")
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF78350F)
                                        )
                                        OutlinedButton(
                                            onClick = {
                                                try {
                                                    when {
                                                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificacionesOk -> {
                                                            launcherNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                        }
                                                        !ubicacionFinaOk -> {
                                                            launcherUbicacionPrimerPlano.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                                                        }
                                                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !ubicacionSegundoPlanoOk -> {
                                                            mostrarDialogoSegundoPlano = true
                                                        }
                                                    }
                                                } catch (_: Throwable) {
                                                    abrirAjustesAplicacion(context)
                                                }
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Configurar permisos faltantes", fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }

                            licenciaRestante?.let { lic ->
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(
                                        containerColor = when (lic.estado) {
                                            "vencida" -> Color(0xFFFEF2F2)
                                            "por_vencer" -> Color(0xFFFEF3C7)
                                            else -> Color.White
                                        }
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Estado de Licencia", fontWeight = FontWeight.SemiBold)
                                            if (lic.fechaTexto.isNotBlank() && lic.fechaTexto != "--/--/----") {
                                                Text(
                                                    text = "Vence: ${lic.fechaTexto}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = Color(0xFF525B50)
                                                )
                                            }
                                        }
                                        Text(
                                            text = if (lic.dias > 0) "Licencia vigente: ${lic.dias} días" else "Licencia vencida",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = if (lic.dias <= 0) Color(0xFFDC2626) else Color(0xFF15803D)
                                        )
                                    }
                                }
                            }

                            if (viajeActivoId != null && estadoViaje == "aceptado" && origenLat != null && origenLng != null) {
                                Button(
                                    onClick = { abrirWaze(context, origenLat, origenLng) },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp)
                                ) { Text("Retomar recogida (Waze)", fontWeight = FontWeight.SemiBold) }

                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            text = "Pasajero: ${pasajeroNombre.orEmpty()} ($cantidadPasajeros pax)",
                                            fontWeight = FontWeight.Bold
                                        )
                                        Surface(
                                            color = Color(0xFFF7F8F6),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "Reseña: ${resenaUbicacion.orEmpty().ifBlank { "Sin referencia" }}",
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(10.dp)
                                            )
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(
                                                onClick = { mostrarMapaModal = true },
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text("Ver Mapa") }
                                            OutlinedButton(
                                                onClick = {
                                                    viajeActivoId?.let { onAbrirChat(it) }
                                                    mostrarChatModal = true
                                                },
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text("Abrir Chat") }
                                        }

                                        OutlinedTextField(
                                            value = pinInput,
                                            onValueChange = { if (it.length <= 3) pinInput = it.filter(Char::isDigit) },
                                            label = { Text("Ingresar PIN de 3 dígitos del pasajero") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        if (!errorPin.isNullOrBlank()) {
                                            Text(
                                                text = errorPin,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.error
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                onVerificarPin(pinInput)
                                            },
                                            enabled = pinInput.length == 3,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                        ) { Text("Confirmar PIN y apagar GPS") }

                                        OutlinedButton(
                                            onClick = {
                                                motivoCancelacionInput = ""
                                                mostrarModalCancelar = true
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) { Text("Cancelar viaje (ingresar nota)") }
                                    }
                                }
                            } else if (viajeActivoId != null && estadoViaje == "en_curso" && destinoLat != null && destinoLng != null) {
                                Button(
                                    onClick = { abrirWaze(context, destinoLat, destinoLng) },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp)
                                ) { Text("Retomar viaje al destino (Waze)", fontWeight = FontWeight.SemiBold) }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { mostrarMapaModal = true },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Ver Mapa") }
                                    OutlinedButton(
                                        onClick = {
                                            viajeActivoId?.let { onAbrirChat(it) }
                                            mostrarChatModal = true
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Abrir Chat") }
                                }

                                Button(
                                    onClick = onFinalizarViaje,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                ) {
                                    Text("Finalizar viaje y cobrar", fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        motivoCancelacionInput = ""
                                        mostrarModalCancelar = true
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Cancelar viaje (ingresar nota)") }
                            } else if (segundosOfertaRestantes != null) {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = BorderStroke(1.5.dp, Color(0xFF15803D)),
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Text(
                                            text = "Nueva solicitud (${segundosOfertaRestantes}s)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF15803D)
                                        )
                                        Text(
                                            text = "Referencia del pasajero: ${resenaUbicacion.orEmpty().ifBlank { "Sin referencia" }}",
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text("Cantidad: $cantidadPasajeros pasajeros")
                                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            OutlinedButton(
                                                onClick = onRechazarOferta,
                                                enabled = !procesandoOferta,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text("Rechazar") }
                                            Button(
                                                onClick = onAceptarOferta,
                                                enabled = !procesandoOferta,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            ) { Text(if (procesandoOferta) "Aceptando..." else "Aceptar") }
                                        }
                                    }
                                }
                            } else {
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("Modo Espera", fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "GPS apagado para ahorrar batería y datos mientras esperas solicitudes.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF525B50)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    ConductorTab.FINANZAS -> {
                        Text(
                            text = "Finanzas del Conductor",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedCard(
                                modifier = Modifier.weight(1f),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("Generado Hoy", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                    Text(
                                        text = "₡${gananciasHoy.toInt()}",
                                        fontSize = 24.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D)
                                    )
                                }
                            }
                            OutlinedCard(
                                modifier = Modifier.weight(1f),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("Generado Mes", style = MaterialTheme.typography.bodySmall, color = Color(0xFF525B50))
                                    Text(
                                        text = "₡${gananciasMes.toInt()}",
                                        fontSize = 24.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF14231A)
                                    )
                                }
                            }
                        }

                        licenciaRestante?.let { lic ->
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("Estado de Licencia Mensual", style = MaterialTheme.typography.labelMedium, color = Color(0xFF525B50))
                                    Text(
                                        text = lic.etiqueta,
                                        fontSize = 22.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (lic.estado == "vencida") Color(0xFFDC2626) else Color(0xFF15803D)
                                    )
                                    Text(
                                        text = "Vence: ${lic.fechaTexto} · Cuota mensual ₡7,000 (+10% cada 1 de enero)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                }
                            }
                        }
                    }

                    ConductorTab.HISTORIAL -> {
                        Text(
                            text = "Historial del Conductor",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        if (cargandoHistorial) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                        if (!cargandoHistorial && historial.isEmpty()) {
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Text(
                                    text = "Aún no tienes viajes completados.",
                                    modifier = Modifier.padding(18.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF525B50)
                                )
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(historial) { v ->
                                    OutlinedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = cardShape,
                                        border = cardBorder,
                                        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text("${v["pasajeroNombre"] ?: ""} · ${v["destinoNombre"] ?: ""}", fontWeight = FontWeight.Bold)
                                            Text(
                                                text = "₡${v["montoAproximado"] ?: 0} · ${v["estado"] ?: ""}",
                                                fontFamily = FontFamily.Monospace,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF15803D)
                                            )
                                            val motivoHist = v["motivoCancelacion"] as? String
                                            if (!motivoHist.isNullOrBlank()) {
                                                val por = if (v["canceladoPor"] == "conductor") "conductor" else "pasajero"
                                                Text(
                                                    text = "Cancelado por $por: \"$motivoHist\"",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ConductorTab.PERFIL -> {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                text = "Tarifas y Perfil",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Configuración de Tarifas", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "Ajusta tu tarifa base y precio por kilómetro adicional. El administrador monitorea variaciones >30%.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        OutlinedTextField(
                                            value = tarifaBaseInput,
                                            onValueChange = { tarifaBaseInput = it.filter(Char::isDigit) },
                                            label = { Text("Tarifa base (₡)") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = tarifaKmInput,
                                            onValueChange = { tarifaKmInput = it.filter(Char::isDigit) },
                                            label = { Text("Precio / km (₡)") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            licenciaRestante?.let { lic ->
                                OutlinedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = cardShape,
                                    border = cardBorder,
                                    colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Licencia de Conducción", fontWeight = FontWeight.Bold)
                                        Text(
                                            text = if (lic.dias > 0) {
                                                "Licencia vigente: ${lic.dias} días · Vence ${lic.fechaTexto}"
                                            } else {
                                                "Licencia vencida"
                                            },
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (lic.dias <= 0) Color(0xFFDC2626) else Color(0xFF15803D)
                                        )
                                    }
                                }
                            }

                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = cardShape,
                                border = cardBorder,
                                colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Datos Registrados (Bloqueados)", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "Para evitar manipulación de identidad o placa, estos datos solo se modifican mediante petición al Administrador.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF525B50)
                                    )
                                    Text("Conductor: ${nombreConductor.ifBlank { "Registrado" }}", fontWeight = FontWeight.Medium)
                                    Text("Vehículo: ${vehiculoTipo.ifBlank { "-" }} · Placa: ${placa.ifBlank { "-" }}", fontWeight = FontWeight.Medium)
                                    OutlinedButton(
                                        onClick = { mostrarModalSolicitud = true },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Solicitar cambio de datos al Administrador")
                                    }
                                }
                            }

                            if (misSolicitudes.isNotEmpty()) {
                                Text("Mis Peticiones de Cambio", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                misSolicitudes.forEach { sol ->
                                    OutlinedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = cardShape,
                                        border = cardBorder,
                                        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text("${sol.estado.uppercase()} · ${sol.motivo}", fontWeight = FontWeight.SemiBold)
                                            if (sol.respuestaAdmin.isNotBlank()) {
                                                Text("Admin: ${sol.respuestaAdmin}", style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }
                                }
                            }

                            HorizontalDivider(color = Color(0xFFE2E6DF), modifier = Modifier.padding(vertical = 4.dp))

                            OutlinedButton(
                                onClick = { compartirAppConductor(context, linkDescarga) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text("Compartir App", fontWeight = FontWeight.SemiBold)
                            }

                            Button(
                                onClick = {
                                    PickupLocationService.stop(context)
                                    onCerrarSesion()
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text("Cerrar Sesión", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            if (!avisoCancelacionFlotante.isNullOrBlank()) {
                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    shape = cardShape,
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = Color(0xFFFEF2F2)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Viaje cancelado por el pasajero", fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                            Text(avisoCancelacionFlotante, style = MaterialTheme.typography.bodySmall, color = Color(0xFF7F1D1D))
                        }
                        TextButton(onClick = onDismissAvisoCancelacion) { Text("Cerrar") }
                    }
                }
            }
        }
    }

    if (mostrarModalCobro) {
        AlertDialog(
            onDismissRequest = onDismissModalCobro,
            title = { Text("Viaje Finalizado — Cobro en Efectivo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Monto a cobrar al pasajero:")
                    Text(
                        text = "₡${montoACobrar.toInt()}",
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text("Califica al pasajero ($estrellasPasajero/5 ★):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { n ->
                            FilledTonalButton(onClick = { estrellasPasajero = n }) {
                                Text(if (n <= estrellasPasajero) "★" else "☆")
                            }
                        }
                    }
                    OutlinedTextField(
                        value = comentarioPasajero,
                        onValueChange = { comentarioPasajero = it },
                        label = { Text("Comentario opcional") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = { onCalificarPasajero(estrellasPasajero, comentarioPasajero) }) {
                    Text("Guardar Calificación")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissModalCobro) { Text("Cerrar") }
            }
        )
    }

    if (mostrarMapaModal) {
        Dialog(onDismissRequest = { mostrarMapaModal = false }) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Mapa Bajo Demanda", fontWeight = FontWeight.Bold)
                    Text("Solo activo mientras esta ventana está abierta.")
                    Button(onClick = { mostrarMapaModal = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cerrar y liberar mapa")
                    }
                }
            }
        }
    }

    if (mostrarChatModal) {
        var textoChat by remember { mutableStateOf("") }
        Dialog(
            onDismissRequest = {
                onCerrarChat()
                mostrarChatModal = false
            }
        ) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Chat Privado del Viaje", fontWeight = FontWeight.Bold)
                    Text(
                        text = "Notificaciones flotantes activas sin exponer números telefónicos.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF525B50)
                    )
                    Surface(
                        color = Color(0xFFF7F8F6),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp, max = 220.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(10.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (mensajesChat.isEmpty()) {
                                Text(
                                    text = "Aún no hay mensajes. Escribe al pasajero aquí.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF525B50)
                                )
                            } else {
                                mensajesChat.forEach { msg ->
                                    val autor = msg["autorNombre"] as? String ?: "Usuario"
                                    val contenido = msg["texto"] as? String ?: ""
                                    Text(
                                        text = "$autor: $contenido",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF14231A)
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textoChat,
                            onValueChange = { if (it.length <= 400) textoChat = it },
                            placeholder = { Text("Escribe un mensaje...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            enabled = textoChat.isNotBlank() && viajeActivoId != null,
                            onClick = {
                                val vId = viajeActivoId ?: return@Button
                                onEnviarMensajeChat(vId, textoChat)
                                textoChat = ""
                            }
                        ) { Text("Enviar") }
                    }
                    OutlinedButton(
                        onClick = {
                            onCerrarChat()
                            mostrarChatModal = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Cerrar Chat") }
                }
            }
        }
    }

    if (mostrarModalSolicitud) {
        var reqNombre by remember { mutableStateOf("") }
        var reqTelefono by remember { mutableStateOf("") }
        var reqPlaca by remember { mutableStateOf("") }
        var reqModelo by remember { mutableStateOf("") }
        var reqMotivo by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { mostrarModalSolicitud = false },
            title = { Text("Petición de Cambio al Administrador") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Completa solo los campos que deseas corregir o actualizar.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = reqNombre, onValueChange = { reqNombre = it }, label = { Text("Nuevo nombre (opcional)") })
                    OutlinedTextField(value = reqTelefono, onValueChange = { reqTelefono = it }, label = { Text("Nuevo teléfono (opcional)") })
                    OutlinedTextField(value = reqPlaca, onValueChange = { reqPlaca = it.uppercase() }, label = { Text("Nueva placa (opcional)") })
                    OutlinedTextField(value = reqModelo, onValueChange = { reqModelo = it }, label = { Text("Nuevo modelo de vehículo (opcional)") })
                    OutlinedTextField(value = reqMotivo, onValueChange = { reqMotivo = it }, label = { Text("Motivo del cambio (obligatorio)") })
                }
            },
            confirmButton = {
                Button(
                    enabled = reqMotivo.trim().length >= 3 && (reqNombre.isNotBlank() || reqTelefono.isNotBlank() || reqPlaca.isNotBlank() || reqModelo.isNotBlank()),
                    onClick = {
                        val cambios = mutableMapOf<String, Any>()
                        if (reqNombre.isNotBlank()) cambios["nombre"] = reqNombre.trim()
                        if (reqTelefono.isNotBlank()) cambios["telefono"] = reqTelefono.trim()
                        if (reqPlaca.isNotBlank()) cambios["placa"] = reqPlaca.trim().uppercase()
                        if (reqModelo.isNotBlank()) cambios["vehiculoModelo"] = reqModelo.trim()
                        onEnviarSolicitudCambio(cambios, reqMotivo.trim())
                        mostrarModalSolicitud = false
                    }
                ) { Text("Enviar Petición") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalSolicitud = false }) { Text("Cancelar") }
            }
        )
    }

    if (mostrarModalCancelar) {
        val sugerenciasConductor = listOf(
            "Camino bloqueado o derrumbe",
            "Falla mecánica en el vehículo",
            "No puedo llegar al punto de recogida"
        )
        AlertDialog(
            onDismissRequest = { mostrarModalCancelar = false },
            title = { Text("Cancelar viaje aceptado") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Ingresa una nota explicando por qué no puedes completar o llegar al destino. El pasajero la verá de inmediato.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    sugerenciasConductor.forEach { opc ->
                        OutlinedButton(
                            onClick = { motivoCancelacionInput = opc },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(opc) }
                    }
                    OutlinedTextField(
                        value = motivoCancelacionInput,
                        onValueChange = { if (it.length <= 280) motivoCancelacionInput = it },
                        label = { Text("Nota de cancelación (obligatoria)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = motivoCancelacionInput.trim().length >= 3,
                    onClick = {
                        PickupLocationService.stop(context)
                        onCancelarViaje(motivoCancelacionInput.trim())
                        mostrarModalCancelar = false
                    }
                ) { Text("Confirmar cancelación") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalCancelar = false }) { Text("Volver") }
            }
        )
    }

    if (mostrarDialogoSegundoPlano && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        AlertDialog(
            onDismissRequest = { mostrarDialogoSegundoPlano = false },
            title = { Text("Ubicación en segundo plano", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Para recibir ofertas y mantener activo el servicio de ubicación aunque apagues la pantalla, selecciona \"Permitir todo el tiempo\" en la siguiente pantalla de Ajustes.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        mostrarDialogoSegundoPlano = false
                        try {
                            launcherSegundoPlano.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                        } catch (_: Throwable) {
                            abrirAjustesAplicacion(context)
                        }
                    }
                ) { Text("Continuar a Ajustes") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        mostrarDialogoSegundoPlano = false
                        abrirAjustesAplicacion(context)
                    }
                ) { Text("Abrir Ajustes App") }
            }
        )
    }
}

private fun tienePermisoNotificaciones(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
}

private fun tienePermisoUbicacionFina(context: Context): Boolean {
    return ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
}

private fun tienePermisoUbicacionSegundoPlano(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
}

private fun abrirAjustesAplicacion(context: Context) {
    try {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Throwable) {
    }
}

private fun abrirWaze(context: Context, lat: Double, lng: Double) {
    val uri = Uri.parse("https://waze.com/ul?ll=$lat,$lng&navigate=yes")
    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)
}

private fun compartirAppConductor(context: Context, linkDescarga: String) {
    try {
        val urlLimpia = linkDescarga.trim().ifBlank { "https://viajerural.com/descargar" }
        val mensaje = "¡Únete a Viaje Rural! Descarga la app para viajar o conducir en zonas rurales: $urlLimpia"
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Viaje Rural App")
            putExtra(Intent.EXTRA_TEXT, mensaje)
        }
        val chooser = Intent.createChooser(sendIntent, "Compartir Viaje Rural")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (_: Throwable) {
    }
}
