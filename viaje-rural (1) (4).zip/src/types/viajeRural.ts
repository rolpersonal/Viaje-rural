import { Timestamp } from 'firebase/firestore';

export type RolUsuario = 'pasajero' | 'conductor' | 'admin';

export type TipoVehiculo = string;

export interface VehiculoTipoConfig {
  nombre: string;
  maxPasajeros: number;
  descripcion: string;
}

export type EstadoCuentaConductor = 'pendiente' | 'activo' | 'bloqueado';

export type EstadoOperativoConductor = 'offline' | 'disponible' | 'en_camino' | 'en_viaje';

export type EstadoViaje = 'buscando' | 'aceptado' | 'en_curso' | 'finalizado' | 'cancelado';

export interface UsuarioPublico {
  uid: string;
  nombre: string;
  rol: RolUsuario;
  fotoUrl?: string;
  bloqueado: boolean;
  terminosAceptados: boolean;
  terminosAceptadosAt?: Timestamp | null;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

export interface UsuarioPII {
  uid: string;
  telefono: string;
  email?: string;
  cedula: string;
  updatedAt?: Timestamp | null;
}

export interface Conductor {
  uid: string;
  nombre: string;
  fotoUrl?: string;
  fotoVehiculoUrl?: string;
  vehiculoTipo: TipoVehiculo;
  vehiculoModelo?: string;
  vehiculoColor?: string;
  vehiculoAnio?: string;
  placa: string;
  capacidad: number;
  tarifaBase: number;
  tarifaPorKm: number;
  estadoCuenta: EstadoCuentaConductor;
  estadoOperativo: EstadoOperativoConductor;
  disponible?: boolean;
  lat?: number;
  lng?: number;
  ultimoPingAt?: Timestamp | null;
  ultimaActualizacion?: Timestamp | null;
  licenciaExp: Timestamp;
  mensualidadPendiente?: boolean;
  promedioCalificacion: number;
  totalCalificaciones?: number;
  totalViajes?: number;
  gananciasHoy?: number;
  gananciasMes?: number;
  cedulaHash?: string;
  terminosAceptados: boolean;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

export interface RutaFavorita {
  id: string;
  alias: string;
  origenNombre: string;
  origenLat: number;
  origenLng: number;
  destinoNombre: string;
  destinoLat: number;
  destinoLng: number;
}

export interface Pasajero {
  uid: string;
  nombre: string;
  fotoUrl?: string;
  promedioCalificacion: number;
  totalCalificaciones?: number;
  favoritos: string[];
  rutasFavoritas?: RutaFavorita[];
  bloqueado: boolean;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

export interface Viaje {
  id: string;
  pasajeroId: string;
  pasajeroNombre: string;
  pasajeroFotoUrl?: string;
  conductorId?: string | null;
  conductorNombre?: string | null;
  conductorFotoUrl?: string | null;
  conductorPlaca?: string | null;
  vehiculoTipoSeleccionado?: string | null;
  tiposVehiculoPermitidos?: TipoVehiculo[];
  cantidadPasajeros: number;
  origenNombre: string;
  origenLat: number;
  origenLng: number;
  destinoNombre: string;
  destinoLat: number;
  destinoLng: number;
  distanciaKm: number;
  resenaUbicacion: string;
  montoAproximado: number;
  tarifaBaseAplicada?: number;
  tarifaKmAplicada?: number;
  pinHash: string;
  pinVerificado: boolean;
  gpsConductorActivo: boolean;
  conductorLat?: number | null;
  conductorLng?: number | null;
  etaMinutos?: number | null;
  colaConductores: string[];
  ofertaActualIndex: number;
  ofertaExpiraAt?: number;
  estado: EstadoViaje;
  canceladoPor?: 'pasajero' | 'conductor' | 'admin' | null;
  motivoCancelacion?: string | null;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

export interface MensajeChat {
  id: string;
  viajeId: string;
  autorUid: string;
  autorRol: 'pasajero' | 'conductor';
  autorNombre: string;
  texto: string;
  createdAt?: Timestamp | null;
}

export interface Calificacion {
  id: string;
  viajeId: string;
  autorUid: string;
  destinatarioUid: string;
  destinatarioRol: 'pasajero' | 'conductor';
  estrellas: number;
  comentario?: string;
  createdAt?: Timestamp | null;
}

export interface RuralDestino {
  nombre: string;
  canton: string;
  lat: number;
  lng: number;
}

export interface NotificacionApp {
  id: string;
  titulo: string;
  cuerpo: string;
  tipo: 'oferta' | 'aceptado' | 'proximidad' | 'mensualidad' | 'alerta';
  hora: string;
  leida: boolean;
}

export interface ConfiguracionGeneral {
  whatsappSoporte: string;
  sinpeNumero: string;
  adminNombre: string;
  adminTelefono: string;
  adminEmail: string;
  adminSinpeTitular: string;
  terminosCondiciones: string;
  linkDescarga?: string;
  tiposVehiculo?: VehiculoTipoConfig[];
  updatedAt?: Timestamp | null;
}

export interface ConductorDocumentos {
  uid: string;
  fotoVehiculo: string;
  fotoCedula: string;
  fotoLicencia: string;
  fotoCirculacion: string;
  updatedAt?: Timestamp | null;
}

export type EstadoSolicitudCambio = 'pendiente' | 'aprobada' | 'rechazada';

export interface CambiosSolicitados {
  nombre?: string;
  telefono?: string;
  email?: string;
  cedula?: string;
  vehiculoTipo?: string;
  vehiculoModelo?: string;
  vehiculoColor?: string;
  vehiculoAnio?: string;
  placa?: string;
  capacidad?: number;
}

export interface SolicitudCambioDatos {
  id: string;
  solicitanteUid: string;
  rol: 'pasajero' | 'conductor';
  nombreActual: string;
  resumenActual: string;
  cambios: CambiosSolicitados;
  motivo: string;
  estado: EstadoSolicitudCambio;
  respuestaAdmin?: string;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

